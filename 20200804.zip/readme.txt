/AML/WebContent/fpages/creditcard/xml/CreditCardSysParams.xml
/AML/WebContent/fpages/creditcard/ftl/CreditCardSysParams.ftl
/AML/topreport/com/huateng/hsbc/creditcard/getter/CreditCardSysParamsGetter.java
/AML/topreport/com/huateng/hsbc/creditcard/update/CreditCardSysParamsUpdate.java

/AML/topreport/com/huateng/hsbc/creditcard/dwr/CreditCardDwrFunction.java
/AML/WebContent/WEB-INF/dwr.xml
/AML/WebContent/fpages/creditcard/xml/CreditCardMsgInfo.xml
/AML/WebContent/fpages/creditcard/ftl/CreditCardDtl.ftl
/AML/topreport/com/huateng/hsbc/creditcard/bean/CreditCardMsg.java
/AML/topreport/resources/creditcard/hbm/pub/CreditCardMsg.hbm.xml
/AML/topreport/com/huateng/hsbc/creditcard/update/SaveMsgUpdate.java
/AML/topreport/com/huateng/hsbc/creditcard/utils/SftpUtils.java
/AML/topreport/com/huateng/hsbc/creditcard/job/GenerateMsgFileService.java
/AML/topreport/com/huateng/hsbc/creditcard/job/GenerateMsgFileJob.java
/AML/topreport/com/huateng/hsbc/creditcard/utils/CreditCommUtils.java

/AML/topreport/com/huateng/hsbc/creditcard/job/AutoExtractJob.java
/AML/topreport/com/huateng/hsbc/creditcard/job/AutoExtractService.java
/AML/topreport/com/huateng/hsbc/creditcard/operation/ApproveOperation.java
/AML/topreport/com/huateng/hsbc/creditcard/operation/ExtractOperation.java

/AML/WebContent/fpages/creditcard/ftl/CreditCardQueryInfo.ftl
/AML/topreport/com/huateng/report/hfaml3/utils/HfAml3Utils.java

/AML/topreport/com/huateng/hsbc/creditcard/getter/CreditCardProofGetter.java
/AML/WebContent/fpages/creditcard/ftl/CreditCardDtl.ftl
/AML/WebContent/fpages/creditcard/xml/CreditCardDtl.xml
/AML/WebContent/login/index.jsp
/AML/topreport/com/huateng/hsbc/creditcard/controller/ProofUploadController.java
/AML/WebContent/fpages/creditcard/jsp/importProof.jsp
/AML/WebContent/fpages/creditcard/jsp/message.jsp
/AML/topreport/com/huateng/excel/imp/BatchImportController.java
/AML/WebContent/WEB-INF/credit.mvc.xml

/AML/WebContent/WEB-INF/query/meta/creditCardMeta.xml
/AML/topreport/com/huateng/hsbc/creditcard/utils/CreditConstant.java