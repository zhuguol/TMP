/AML/topreport/com/huateng/report/hf/aml/getter/AmlBHdsHisApproveGetter.java
/AML/topreport/com/huateng/report/hf/aml/getter/AmlBHdsHisQuery2Getter.java
/AML/topreport/com/huateng/report/hf/aml/getter/AmlBSUplaodHisQueryGetter.java
/AML/topreport/com/huateng/report/hf/aml/getter/AmlBSUploadBakApproveGetter.java

/AML/topreport/com/huateng/report/hfaml3/bh/getter/AmlBHdsHisApproveThreeGetter.java
/AML/topreport/com/huateng/report/hfaml3/bh/getter/AmlBHdsHisQueryThreeGetter.java

/AML/topreport/com/huateng/report/hfaml3/bs/getter/AmlBSUplaodHisQueryThreeGetter.java
/AML/topreport/com/huateng/report/hfaml3/bs/getter/AmlBSUploadBakApproveThreeGetter.java

/AML/WebContent/fpages/hf/ftl/AmlBHdsHisApprove.ftl
/AML/WebContent/fpages/hf/ftl/AmlBSUploadBakApprove.ftl

/AML/WebContent/fpages/hf/ftl/AmlBhbsDsBakMirror.ftl
/AML/WebContent/fpages/hf/ftl/AmlBSUploadBakApproveInfo.ftl

/AML/WebContent/fpages/hfaml3/xml/bh/AmlBhbsDsBakMirrorThree.xml
/AML/WebContent/fpages/hfaml3/xml/bh/AmlBHdsHisApproveThree.xml

/AML/WebContent/fpages/hfaml3/xml/bs/AmlBSDsCollInfo.xml
/AML/WebContent/fpages/hfaml3/xml/bs/AmlBSUploadBakApproveThree.xml


insert into SYS_PARAMS (PARAMGROUP_ID, PARAM_ID, PARAM_VAL, PARAM_NAME, MEMO, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER) values ('AML3', 'CHANGEDATE', '20190401', '2����ͣ������', null, '4', 'F', 'F', null, null, null);
