package com.huateng.report.aml.download;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import resources.bean.report.form.CBlackListUpload;

import com.huateng.ebank.business.common.GlobalInfo;
import com.huateng.ebank.framework.util.WebDownloadFile;
import com.huateng.ebank.framework.web.servlet.BaseServlet;
import com.huateng.excel.imp.DataMyUtil;
import com.huateng.report.utils.ReportUtils;

/**
 * 下载AML客户信息与报文信息的Action.
 */
@SuppressWarnings("serial")
public class CBlackListUploadDownloadAction extends BaseServlet {
	
	public static final String CBlackListUpload = "CBlackListUpload"; 
	public static final String CBlackListSplitConfirm = "CBlackListSplitConfirm"; 
	
	public static final String CBlackTransDownloadRet = "CBlackTransDownloadRet"; 
	public static final String CBlackBatchStatus = "CBlackBatchStatus"; 
	
	public static final String CreditCard0905ListUpload = "CreditCard0905ListUpload"; 
	
	public static final String XLSX = ".xlsx"; 
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
     	Connection connect = null;
    	Statement st = null;
    	ResultSet rs = null;
        try {
            this.init(request);
            String path = ReportUtils.getSysParamsValue("Downoload", "AML");
            String etlDateStart = request.getParameter("etlDateStart");
            String etlDateEnd = request.getParameter("etlDateEnd");
            String notice = request.getParameter("notice");
            String qtableName = request.getParameter("qtableName");        
            String keyWords = request.getParameter("keyWords");
            String tbName = null;
      		if (qtableName.equals("CBlackListSplitConfirm")) {
      			tbName = "C_BLACK_LIST_SPLIT_CONFIRM";
    		}
    		
    		if (qtableName.equals("CBlackTransDownloadRet")) {
    			tbName = "C_BLACK_TRANS_DOWNLOAD_RET";
    		}
    		if (qtableName.equals("CBlackBatchStatus")) {
    			tbName = "C_BLACK_BATCH_STATUS";
    		}
    		if (qtableName.equals("CreditCard0905ListUpload")){
    			tbName = "CREDIT_CARD_0905_LIST_UPLOAD";
    		}
    		
    			String currentTime = DataMyUtil.getFullDateTime();
    			currentTime = currentTime.substring(0,14);
    			//InputStream is = this.getClass().getClassLoader().getResourceAsStream(qtableName+XLSX);//获取模板文件
    			InputStream is = this.getClass().getClassLoader().getResourceAsStream(qtableName + ".xlsx");//获取模板文件
    			String destFileName = path + "filetmp/"+ qtableName + "-"+ currentTime + ".xlsx";
    			File file = null;
    			if(CBlackListUpload.equals(qtableName)){
    				destFileName = path + "filetmp/黑名单上传信息"+ currentTime + ".xlsx";
        		    file = new File(destFileName);
        			copyFile(is, file, true);
        			writeExcel(file, etlDateStart, etlDateEnd, notice, keyWords, qtableName);//填充XLSX文件
        			WebDownloadFile.downloadFile(resp, file, file.getName());
    			}else{
    				rs=ExportBlackNameUtils.getBeanBySql(tbName, etlDateStart, etlDateEnd, notice, keyWords);					
    				file = ExportBlackNameUtils.createXLSFile2(rs,path+"xls/",tbName);
    				WebDownloadFile.downloadFile(resp, file, file.getName());				
    			}
    			
//    			 用于监控页面加载圈
                ServletContext serContext = this.getServletContext();
    			//UserSessionInfo userInfo = (UserSessionInfo) this.getSession(request).getAttribute("USER_SESSION_INFO");
    			String tlrno = GlobalInfo.getCurrentInstance().getTlrno();
    			//String tlrno = userInfo.getTlrNo();        			
    			serContext.setAttribute(qtableName+"_"+tlrno, "黑名单");
    	    	if(file!=null){
    	            file.delete();  
    	        }
            }catch (Exception e) {
                e.printStackTrace();
                String errMsg = e.toString();
                request.setAttribute("errormsg", errMsg);
                request.getRequestDispatcher("/common/error.jsp").forward(request, resp);
                resp.sendRedirect(request.getContextPath() + "/common/error.jsp");
            }finally {
            	if(rs!=null){
            		try {
    					rs.close();
    				} catch (SQLException e) {
    					e.printStackTrace();
    				}
            	} 
            	if(st!=null){
            		try {
    					st.close();
    				} catch (SQLException e) {
    					e.printStackTrace();
    				}
            	} 
            	if(connect!=null){
            		try {
    					connect.close();
    				} catch (SQLException e) {
    					e.printStackTrace();
    				}
            	} 
            }
    	}
    	
    	
    	
    	
    	

    	public static void writeExcel(File file, String etlDateStart, String etlDateEnd, String notice, String keyWords,String qtableName)throws Exception {
    		InputStream is = new FileInputStream(file);
    		XSSFWorkbook workbook = new XSSFWorkbook(is);  
       	if(CBlackListUpload.equals(qtableName)){
    		Sheet sheet = workbook.getSheet("黑名单上传");
    		List<Object> beanList = ExportBlackNameUtils.getBeanList(qtableName, etlDateStart, etlDateEnd, notice,null);
    		if(sheet!=null){//填充单元格  行和列都从0开始		
    			for(int i=0;i<beanList.size();i++){
    				CBlackListUpload bean = (CBlackListUpload)beanList.get(i);
    				Row row = sheet.createRow(i+1);
    				row.createCell(0).setCellValue(bean.getId().getId());//序列号
    				row.createCell(1).setCellValue(bean.getId().getEtlDate());//批处理日期
    				row.createCell(2).setCellValue(bean.getSerial());//
    				row.createCell(3).setCellValue(bean.getIssuPboc());//
    				row.createCell(4).setCellValue(bean.getNotice());//
    				row.createCell(5).setCellValue(bean.getTargetName());//
    				row.createCell(6).setCellValue(bean.getDob());//
    				row.createCell(7).setCellValue(bean.getAlias());//
    				row.createCell(8).setCellValue(bean.getNationality());//
    				row.createCell(9).setCellValue(bean.getOthers());//
    				row.createCell(10).setCellValue(bean.getWorldCheck());//
    				row.createCell(11).setCellValue(bean.getRemark());//
    				//设置边框
    			}
    		}
    	}		
    		FileOutputStream fileOut = new FileOutputStream(file);
    		workbook.write(fileOut);
    		try{
    			workbook.close();
    	        fileOut.close();
    		}catch (Exception e2) {
    			e2.printStackTrace();
    		}
    	}
    	
    	
    	
    	
    	@SuppressWarnings("unused")
    	private static int excelColStrToNum(String colStr) {
    		int num = 0;
    		int result = 0;
    		int length = colStr.length();
    		for (int i = 0; i < length; i++) {
    			char ch = colStr.charAt(length - i - 1);
    			num = (int) (ch - 'A' + 1);
    			num *= Math.pow(26, i);
    			result += num;
    		}
    		return result;
    	}
    	
    	
    	
    	public static boolean copyFile(String srcFileName, File destFile, boolean overlay) {
    		File srcFile = new File(srcFileName);
    		// 判断源文件是否存在
    		if (!srcFile.exists()) {
    			return false;
    		} else if (!srcFile.isFile()) {
    			return false;
    		}
    		// 判断目标文件是否存在
    		if (destFile.exists()) {
    			// 如果目标文件存在并允许覆盖
    			if (overlay) {
    				// 删除已经存在的目标文件，无论目标文件是目录还是单个文件
    				destFile.delete();
    			}
    		} else {
    			// 如果目标文件所在目录不存在，则创建目录
    			if (!destFile.getParentFile().exists()) {
    				// 目标文件所在目录不存在
    				if (!destFile.getParentFile().mkdirs()) {
    					// 复制文件失败：创建目标文件所在目录失败
    					return false;
    				}
    			}
    		}
    		// 复制文件
    		int byteread = 0; // 读取的字节数
    		InputStream in = null;
    		OutputStream out = null;
    		try {
    			in = new FileInputStream(srcFile);
    			out = new FileOutputStream(destFile);
    			byte[] buffer = new byte[1024];

    			while ((byteread = in.read(buffer)) != -1) {
    				out.write(buffer, 0, byteread);
    			}
    			return true;
    		} catch (FileNotFoundException e) {
    			return false;
    		} catch (IOException e) {
    			return false;
    		} finally {
    			try {
    				if (out != null)
    					out.close();
    				if (in != null)
    					in.close();
    			} catch (IOException e) {
    				e.printStackTrace();
    			}
    		}
    	}
    	
    	
    	public static boolean copyFile(InputStream in, File destFile, boolean overlay) {
    		if (destFile.exists()) {
    			// 如果目标文件存在并允许覆盖
    			if (overlay) {
    				// 删除已经存在的目标文件，无论目标文件是目录还是单个文件
    				destFile.delete();
    			}
    		} else {
    			// 如果目标文件所在目录不存在，则创建目录
    			if (!destFile.getParentFile().exists()) {
    				// 目标文件所在目录不存在
    				if (!destFile.getParentFile().mkdirs()) {
    					// 复制文件失败：创建目标文件所在目录失败
    					return false;
    				}
    			}
    		}
    		// 复制文件
    		int byteread = 0; // 读取的字节数
    		OutputStream out = null;
    		try {
    			out = new FileOutputStream(destFile);
    			byte[] buffer = new byte[1024];

    			while ((byteread = in.read(buffer)) != -1) {
    				out.write(buffer, 0, byteread);
    			}
    			return true;
    		} catch (FileNotFoundException e) {
    			return false;
    		} catch (IOException e) {
    			return false;
    		} finally {
    			try {
    				if (out != null)
    					out.close();
    				if (in != null)
    					in.close();
    			} catch (IOException e) {
    				e.printStackTrace();
    			}
    		}
    	}
    	
    	
    	
    	
    	
    }  