package resources.bean.report.form;

import java.io.Serializable;
import java.math.BigDecimal;

public class AStaffAcctTradInfoRRB implements Serializable{
	private static final long serialVersionUID = 1L;
	private String recId;
	private String dataDate;//数据日期
	private String alertId;//告警号
	private String custNo;//客户号
	private String acctNo;//客户账号
	private String acctType;//客户账号类型
	private String bankCardType;//银行卡类型
	private String bankCardNo;//银行卡号码
	private String tstm;//交易发生日期
	private String tradPlace;//交易发生地
	private String payMatchNoType;//收付款方匹配号码类型
	private String tradType;//交易方式
	private String fundPayFlag;//资金收付标志
	private String fundPayPurpos;//资金用途
	private String ccyCd;//币种
	private BigDecimal tradAmt;//交易金额(元)
	private BigDecimal cnyTradAmt;//交易金额转人民币(元)
	private String opsFinaOrgName;//对方金融机构网点名称
	private String opsFinaOrgAreaCode;//对方金融机构网点行政代码
	private String tradAdvsName;//交易对手名称
	private String tradAdvsIdCertNo;//交易对手身份证件号码
	private String tradAdvsAcctNo;//交易对手账号
	private String nonCotrTradType;//非柜台交易方式
	private String nonCotrTradTypeCode ;//非柜台交易方式设备号码
	private String ruleCode;//规则代码
	private String bussFlag;//业务标识
	private String tbnm;//交易代办人姓名
	private String tbid;//代办人身份证件/证明文件号码
	private String etlFlag;//数据频度
	private String filler1;//预留字段1
	private String filler2;//预留字段2
	private String filler3;//预留字段3
	public String getRecId() {
		return recId;
	}
	public void setRecId(String recId) {
		this.recId = recId;
	}
	public String getDataDate() {
		return dataDate;
	}
	public void setDataDate(String dataDate) {
		this.dataDate = dataDate;
	}
	public String getAlertId() {
		return alertId;
	}
	public void setAlertId(String alertId) {
		this.alertId = alertId;
	}
	public String getCustNo() {
		return custNo;
	}
	public void setCustNo(String custNo) {
		this.custNo = custNo;
	}
	public String getAcctNo() {
		return acctNo;
	}
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}
	public String getAcctType() {
		return acctType;
	}
	public void setAcctType(String acctType) {
		this.acctType = acctType;
	}
	public String getBankCardType() {
		return bankCardType;
	}
	public void setBankCardType(String bankCardType) {
		this.bankCardType = bankCardType;
	}
	public String getBankCardNo() {
		return bankCardNo;
	}
	public void setBankCardNo(String bankCardNo) {
		this.bankCardNo = bankCardNo;
	}
	public String getTstm() {
		return tstm;
	}
	public void setTstm(String tstm) {
		this.tstm = tstm;
	}
	public String getTradPlace() {
		return tradPlace;
	}
	public void setTradPlace(String tradPlace) {
		this.tradPlace = tradPlace;
	}
	public String getPayMatchNoType() {
		return payMatchNoType;
	}
	public void setPayMatchNoType(String payMatchNoType) {
		this.payMatchNoType = payMatchNoType;
	}
	public String getTradType() {
		return tradType;
	}
	public void setTradType(String tradType) {
		this.tradType = tradType;
	}
	public String getFundPayFlag() {
		return fundPayFlag;
	}
	public void setFundPayFlag(String fundPayFlag) {
		this.fundPayFlag = fundPayFlag;
	}
	public String getFundPayPurpos() {
		return fundPayPurpos;
	}
	public void setFundPayPurpos(String fundPayPurpos) {
		this.fundPayPurpos = fundPayPurpos;
	}
	public String getCcyCd() {
		return ccyCd;
	}
	public void setCcyCd(String ccyCd) {
		this.ccyCd = ccyCd;
	}
	public BigDecimal getTradAmt() {
		return tradAmt;
	}
	public void setTradAmt(BigDecimal tradAmt) {
		this.tradAmt = tradAmt;
	}
	public BigDecimal getCnyTradAmt() {
		return cnyTradAmt;
	}
	public void setCnyTradAmt(BigDecimal cnyTradAmt) {
		this.cnyTradAmt = cnyTradAmt;
	}
	public String getOpsFinaOrgName() {
		return opsFinaOrgName;
	}
	public void setOpsFinaOrgName(String opsFinaOrgName) {
		this.opsFinaOrgName = opsFinaOrgName;
	}
	public String getOpsFinaOrgAreaCode() {
		return opsFinaOrgAreaCode;
	}
	public void setOpsFinaOrgAreaCode(String opsFinaOrgAreaCode) {
		this.opsFinaOrgAreaCode = opsFinaOrgAreaCode;
	}
	public String getTradAdvsName() {
		return tradAdvsName;
	}
	public void setTradAdvsName(String tradAdvsName) {
		this.tradAdvsName = tradAdvsName;
	}
	public String getTradAdvsIdCertNo() {
		return tradAdvsIdCertNo;
	}
	public void setTradAdvsIdCertNo(String tradAdvsIdCertNo) {
		this.tradAdvsIdCertNo = tradAdvsIdCertNo;
	}
	public String getTradAdvsAcctNo() {
		return tradAdvsAcctNo;
	}
	public void setTradAdvsAcctNo(String tradAdvsAcctNo) {
		this.tradAdvsAcctNo = tradAdvsAcctNo;
	}
	public String getNonCotrTradType() {
		return nonCotrTradType;
	}
	public void setNonCotrTradType(String nonCotrTradType) {
		this.nonCotrTradType = nonCotrTradType;
	}
	public String getNonCotrTradTypeCode() {
		return nonCotrTradTypeCode;
	}
	public void setNonCotrTradTypeCode(String nonCotrTradTypeCode) {
		this.nonCotrTradTypeCode = nonCotrTradTypeCode;
	}
	public String getRuleCode() {
		return ruleCode;
	}
	public void setRuleCode(String ruleCode) {
		this.ruleCode = ruleCode;
	}
	public String getBussFlag() {
		return bussFlag;
	}
	public void setBussFlag(String bussFlag) {
		this.bussFlag = bussFlag;
	}
	public String getTbnm() {
		return tbnm;
	}
	public void setTbnm(String tbnm) {
		this.tbnm = tbnm;
	}
	public String getTbid() {
		return tbid;
	}
	public void setTbid(String tbid) {
		this.tbid = tbid;
	}
	public String getEtlFlag() {
		return etlFlag;
	}
	public void setEtlFlag(String etlFlag) {
		this.etlFlag = etlFlag;
	}
	public String getFiller1() {
		return filler1;
	}
	public void setFiller1(String filler1) {
		this.filler1 = filler1;
	}
	public String getFiller2() {
		return filler2;
	}
	public void setFiller2(String filler2) {
		this.filler2 = filler2;
	}
	public String getFiller3() {
		return filler3;
	}
	public void setFiller3(String filler3) {
		this.filler3 = filler3;
	}
	public AStaffAcctTradInfoRRB() {
		super();
	}
	public AStaffAcctTradInfoRRB(String recId, String dataDate, String alertId,
			String custNo, String acctNo, String acctType, String bankCardType,
			String bankCardNo, String tstm, String tradPlace,
			String payMatchNoType, String tradType, String fundPayFlag,
			String fundPayPurpos, String ccyCd, BigDecimal tradAmt,
			BigDecimal cnyTradAmt, String opsFinaOrgName,
			String opsFinaOrgAreaCode, String tradAdvsName,
			String tradAdvsIdCertNo, String tradAdvsAcctNo,
			String nonCotrTradType, String nonCotrTradTypeCode,
			String ruleCode, String bussFlag, String tbnm, String tbid,
			String etlFlag, String filler1, String filler2, String filler3) {
		super();
		this.recId = recId;
		this.dataDate = dataDate;
		this.alertId = alertId;
		this.custNo = custNo;
		this.acctNo = acctNo;
		this.acctType = acctType;
		this.bankCardType = bankCardType;
		this.bankCardNo = bankCardNo;
		this.tstm = tstm;
		this.tradPlace = tradPlace;
		this.payMatchNoType = payMatchNoType;
		this.tradType = tradType;
		this.fundPayFlag = fundPayFlag;
		this.fundPayPurpos = fundPayPurpos;
		this.ccyCd = ccyCd;
		this.tradAmt = tradAmt;
		this.cnyTradAmt = cnyTradAmt;
		this.opsFinaOrgName = opsFinaOrgName;
		this.opsFinaOrgAreaCode = opsFinaOrgAreaCode;
		this.tradAdvsName = tradAdvsName;
		this.tradAdvsIdCertNo = tradAdvsIdCertNo;
		this.tradAdvsAcctNo = tradAdvsAcctNo;
		this.nonCotrTradType = nonCotrTradType;
		this.nonCotrTradTypeCode = nonCotrTradTypeCode;
		this.ruleCode = ruleCode;
		this.bussFlag = bussFlag;
		this.tbnm = tbnm;
		this.tbid = tbid;
		this.etlFlag = etlFlag;
		this.filler1 = filler1;
		this.filler2 = filler2;
		this.filler3 = filler3;
	}
	@Override
	public String toString() {
		return "AStaffAcctTradInfo [recId=" + recId + ", dataDate=" + dataDate
				+ ", alertId=" + alertId + ", custNo=" + custNo + ", acctNo="
				+ acctNo + ", acctType=" + acctType + ", bankCardType="
				+ bankCardType + ", bankCardNo=" + bankCardNo + ", tstm="
				+ tstm + ", tradPlace=" + tradPlace + ", payMatchNoType="
				+ payMatchNoType + ", tradType=" + tradType + ", fundPayFlag="
				+ fundPayFlag + ", fundPayPurpos=" + fundPayPurpos + ", ccyCd="
				+ ccyCd + ", tradAmt=" + tradAmt + ", cnyTradAmt=" + cnyTradAmt
				+ ", opsFinaOrgName=" + opsFinaOrgName
				+ ", opsFinaOrgAreaCode=" + opsFinaOrgAreaCode
				+ ", tradAdvsName=" + tradAdvsName + ", tradAdvsIdCertNo="
				+ tradAdvsIdCertNo + ", tradAdvsAcctNo=" + tradAdvsAcctNo
				+ ", nonCotrTradType=" + nonCotrTradType
				+ ", nonCotrTradTypeCode=" + nonCotrTradTypeCode
				+ ", ruleCode=" + ruleCode + ", bussFlag=" + bussFlag
				+ ", tbnm=" + tbnm + ", tbid=" + tbid + ", etlFlag=" + etlFlag
				+ ", filler1=" + filler1 + ", filler2=" + filler2
				+ ", filler3=" + filler3 + "]";
	}
	
}
