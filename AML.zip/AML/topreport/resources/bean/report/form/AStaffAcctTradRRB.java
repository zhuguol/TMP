package resources.bean.report.form;

import java.io.Serializable;

public class AStaffAcctTradRRB implements Serializable{
	private static final long serialVersionUID = 1L;
	private String dataDate;//数据日期
	private String alertId;//告警号
	private String custName;//客户名称/姓名
	private String custIdCertNo;//客户身份证件号码
	private String custNo;//客户号
	private String staffNumber;//员工编号
	private String staffDepartment;//员工所在部门
	private String staffJobTitle;//员工职位名称
	private String ruleCode;//规则代码
	private String bussFlag;//业务标识
	private String managerName;//直线经理姓名
	private String ctar;//客户住址/经营地址
	private String ctnt;//客户国籍
	private String invesResultByOps;//初步调查结论(by OPS)
	private String checkDate;//初步调查日期
	private String investigator;//调查者
	private String status;//调查阶段
	private String appearanceTime;//(日报当月/月报当季)被抓出次数
	private String reportDOrM;//日报/月报
	private String feedbackFrom;//反馈结果(从FCTM或者President)
	private String feedbackDate;//收到反馈时间
	private String potentialCaseType;//(初步调查)上报的可以类型
	private String concludedType;//(收到反馈)判定的可疑类型
	private String comfirmedSusp;//是否判定可疑(及由哪方判定)
	private String caseId;//上报案件编号
	private String approveStatus;//记录状态
	private String approveUpdTlr;//审核人员
	private String approveResult;//审核说明
	private String approveUpdTm;//审核日期
	private String recordUpdTlr;//记录修改人
	private String recordUpdTm;//记录修改时间
	private String freeFlag;//自查状态
	private String etlFlag;//数据频度
	private String reportDate;//上报日期
	private String filler1;//预留字段1
	private String filler2;//预留字段2
	private String filler3;//预留字段3
	private String branCode;//机构号
	private String alterUar;//反馈案件编号
	public String getDataDate() {
		return dataDate;
	}
	public void setDataDate(String dataDate) {
		this.dataDate = dataDate;
	}
	public String getAlertId() {
		return alertId;
	}
	public void setAlertId(String alertId) {
		this.alertId = alertId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustIdCertNo() {
		return custIdCertNo;
	}
	public void setCustIdCertNo(String custIdCertNo) {
		this.custIdCertNo = custIdCertNo;
	}
	public String getCustNo() {
		return custNo;
	}
	public void setCustNo(String custNo) {
		this.custNo = custNo;
	}
	public String getStaffNumber() {
		return staffNumber;
	}
	public void setStaffNumber(String staffNumber) {
		this.staffNumber = staffNumber;
	}
	public String getStaffDepartment() {
		return staffDepartment;
	}
	public void setStaffDepartment(String staffDepartment) {
		this.staffDepartment = staffDepartment;
	}
	public String getStaffJobTitle() {
		return staffJobTitle;
	}
	public void setStaffJobTitle(String staffJobTitle) {
		this.staffJobTitle = staffJobTitle;
	}
	public String getRuleCode() {
		return ruleCode;
	}
	public void setRuleCode(String ruleCode) {
		this.ruleCode = ruleCode;
	}
	public String getBussFlag() {
		return bussFlag;
	}
	public void setBussFlag(String bussFlag) {
		this.bussFlag = bussFlag;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public String getCtar() {
		return ctar;
	}
	public void setCtar(String ctar) {
		this.ctar = ctar;
	}
	public String getCtnt() {
		return ctnt;
	}
	public void setCtnt(String ctnt) {
		this.ctnt = ctnt;
	}
	public String getInvesResultByOps() {
		return invesResultByOps;
	}
	public void setInvesResultByOps(String invesResultByOps) {
		this.invesResultByOps = invesResultByOps;
	}
	public String getCheckDate() {
		return checkDate;
	}
	public void setCheckDate(String checkDate) {
		this.checkDate = checkDate;
	}
	public String getInvestigator() {
		return investigator;
	}
	public void setInvestigator(String investigator) {
		this.investigator = investigator;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getAppearanceTime() {
		return appearanceTime;
	}
	public void setAppearanceTime(String appearanceTime) {
		this.appearanceTime = appearanceTime;
	}
	public String getReportDOrM() {
		return reportDOrM;
	}
	public void setReportDOrM(String reportDOrM) {
		this.reportDOrM = reportDOrM;
	}
	public String getFeedbackFrom() {
		return feedbackFrom;
	}
	public void setFeedbackFrom(String feedbackFrom) {
		this.feedbackFrom = feedbackFrom;
	}
	public String getFeedbackDate() {
		return feedbackDate;
	}
	public void setFeedbackDate(String feedbackDate) {
		this.feedbackDate = feedbackDate;
	}
	public String getPotentialCaseType() {
		return potentialCaseType;
	}
	public void setPotentialCaseType(String potentialCaseType) {
		this.potentialCaseType = potentialCaseType;
	}
	public String getConcludedType() {
		return concludedType;
	}
	public void setConcludedType(String concludedType) {
		this.concludedType = concludedType;
	}
	public String getComfirmedSusp() {
		return comfirmedSusp;
	}
	public void setComfirmedSusp(String comfirmedSusp) {
		this.comfirmedSusp = comfirmedSusp;
	}
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public String getApproveStatus() {
		return approveStatus;
	}
	public void setApproveStatus(String approveStatus) {
		this.approveStatus = approveStatus;
	}
	public String getApproveUpdTlr() {
		return approveUpdTlr;
	}
	public void setApproveUpdTlr(String approveUpdTlr) {
		this.approveUpdTlr = approveUpdTlr;
	}
	public String getApproveResult() {
		return approveResult;
	}
	public void setApproveResult(String approveResult) {
		this.approveResult = approveResult;
	}
	public String getApproveUpdTm() {
		return approveUpdTm;
	}
	public void setApproveUpdTm(String approveUpdTm) {
		this.approveUpdTm = approveUpdTm;
	}
	public String getRecordUpdTlr() {
		return recordUpdTlr;
	}
	public void setRecordUpdTlr(String recordUpdTlr) {
		this.recordUpdTlr = recordUpdTlr;
	}
	public String getRecordUpdTm() {
		return recordUpdTm;
	}
	public void setRecordUpdTm(String recordUpdTm) {
		this.recordUpdTm = recordUpdTm;
	}
	public String getFreeFlag() {
		return freeFlag;
	}
	public void setFreeFlag(String freeFlag) {
		this.freeFlag = freeFlag;
	}
	public String getEtlFlag() {
		return etlFlag;
	}
	public void setEtlFlag(String etlFlag) {
		this.etlFlag = etlFlag;
	}
	public String getReportDate() {
		return reportDate;
	}
	public void setReportDate(String reportDate) {
		this.reportDate = reportDate;
	}
	public String getFiller1() {
		return filler1;
	}
	public void setFiller1(String filler1) {
		this.filler1 = filler1;
	}
	public String getFiller2() {
		return filler2;
	}
	public void setFiller2(String filler2) {
		this.filler2 = filler2;
	}
	public String getFiller3() {
		return filler3;
	}
	public void setFiller3(String filler3) {
		this.filler3 = filler3;
	}
	public String getBranCode() {
		return branCode;
	}
	public void setBranCode(String branCode) {
		this.branCode = branCode;
	}
	public String getAlterUar() {
		return alterUar;
	}
	public void setAlterUar(String alterUar) {
		this.alterUar = alterUar;
	}
	public AStaffAcctTradRRB() {
		super();
	}
	public AStaffAcctTradRRB(String dataDate, String alertId, String custName,
			String custIdCertNo, String custNo, String staffNumber,
			String staffDepartment, String staffJobTitle, String ruleCode,
			String bussFlag, String managerName, String ctar, String ctnt,
			String invesResultByOps, String checkDate, String investigator,
			String status, String appearanceTime, String reportDOrM,
			String feedbackFrom, String feedbackDate, String potentialCaseType,
			String concludedType, String comfirmedSusp, String caseId,
			String approveStatus, String approveUpdTlr, String approveResult,
			String approveUpdTm, String recordUpdTlr, String recordUpdTm,
			String freeFlag, String etlFlag, String reportDate, String filler1,
			String filler2, String filler3, String branCode, String alterUar) {
		super();
		this.dataDate = dataDate;
		this.alertId = alertId;
		this.custName = custName;
		this.custIdCertNo = custIdCertNo;
		this.custNo = custNo;
		this.staffNumber = staffNumber;
		this.staffDepartment = staffDepartment;
		this.staffJobTitle = staffJobTitle;
		this.ruleCode = ruleCode;
		this.bussFlag = bussFlag;
		this.managerName = managerName;
		this.ctar = ctar;
		this.ctnt = ctnt;
		this.invesResultByOps = invesResultByOps;
		this.checkDate = checkDate;
		this.investigator = investigator;
		this.status = status;
		this.appearanceTime = appearanceTime;
		this.reportDOrM = reportDOrM;
		this.feedbackFrom = feedbackFrom;
		this.feedbackDate = feedbackDate;
		this.potentialCaseType = potentialCaseType;
		this.concludedType = concludedType;
		this.comfirmedSusp = comfirmedSusp;
		this.caseId = caseId;
		this.approveStatus = approveStatus;
		this.approveUpdTlr = approveUpdTlr;
		this.approveResult = approveResult;
		this.approveUpdTm = approveUpdTm;
		this.recordUpdTlr = recordUpdTlr;
		this.recordUpdTm = recordUpdTm;
		this.freeFlag = freeFlag;
		this.etlFlag = etlFlag;
		this.reportDate = reportDate;
		this.filler1 = filler1;
		this.filler2 = filler2;
		this.filler3 = filler3;
		this.branCode = branCode;
		this.alterUar = alterUar;
	}
	@Override
	public String toString() {
		return "AStaffAcctTradRRB [dataDate=" + dataDate + ", alertId="
				+ alertId + ", custName=" + custName + ", custIdCertNo="
				+ custIdCertNo + ", custNo=" + custNo + ", staffNumber="
				+ staffNumber + ", staffDepartment=" + staffDepartment
				+ ", staffJobTitle=" + staffJobTitle + ", ruleCode=" + ruleCode
				+ ", bussFlag=" + bussFlag + ", managerName=" + managerName
				+ ", ctar=" + ctar + ", ctnt=" + ctnt + ", invesResultByOps="
				+ invesResultByOps + ", checkDate=" + checkDate
				+ ", investigator=" + investigator + ", status=" + status
				+ ", appearanceTime=" + appearanceTime + ", reportDOrM="
				+ reportDOrM + ", feedbackFrom=" + feedbackFrom
				+ ", feedbackDate=" + feedbackDate + ", potentialCaseType="
				+ potentialCaseType + ", concludedType=" + concludedType
				+ ", comfirmedSusp=" + comfirmedSusp + ", caseId=" + caseId
				+ ", approveStatus=" + approveStatus + ", approveUpdTlr="
				+ approveUpdTlr + ", approveResult=" + approveResult
				+ ", approveUpdTm=" + approveUpdTm + ", recordUpdTlr="
				+ recordUpdTlr + ", recordUpdTm=" + recordUpdTm + ", freeFlag="
				+ freeFlag + ", etlFlag=" + etlFlag + ", reportDate="
				+ reportDate + ", filler1=" + filler1 + ", filler2=" + filler2
				+ ", filler3=" + filler3 + ", branCode=" + branCode
				+ ", alterUar=" + alterUar + "]";
	}
}
