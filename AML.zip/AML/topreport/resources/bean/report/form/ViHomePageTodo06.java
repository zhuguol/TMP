package resources.bean.report.form;

import java.io.Serializable;
import java.math.BigDecimal;

public class ViHomePageTodo06 implements Serializable{
private static final long serialVersionUID = 1L;
	
	private java.lang.String id;
	private String dataDate;
	private String reportDOrM;
	private java.math.BigDecimal cNt;
	private java.math.BigDecimal sNt;
	public java.lang.String getId() {
		return id;
	}
	public void setId(java.lang.String id) {
		this.id = id;
	}
	public String getDataDate() {
		return dataDate;
	}
	public void setDataDate(String dataDate) {
		this.dataDate = dataDate;
	}
	public String getReportDOrM() {
		return reportDOrM;
	}
	public void setReportDOrM(String reportDOrM) {
		this.reportDOrM = reportDOrM;
	}
	public java.math.BigDecimal getcNt() {
		return cNt;
	}
	public void setcNt(java.math.BigDecimal cNt) {
		this.cNt = cNt;
	}
	public java.math.BigDecimal getsNt() {
		return sNt;
	}
	public void setsNt(java.math.BigDecimal sNt) {
		this.sNt = sNt;
	}
	public ViHomePageTodo06() {
		super();
	}
	public ViHomePageTodo06(String id, String dataDate, String reportDOrM,
			BigDecimal cNt, BigDecimal sNt) {
		super();
		this.id = id;
		this.dataDate = dataDate;
		this.reportDOrM = reportDOrM;
		this.cNt = cNt;
		this.sNt = sNt;
	}
	@Override
	public String toString() {
		return "ViHomePageTodo06 [id=" + id + ", dataDate=" + dataDate
				+ ", reportDOrM=" + reportDOrM + ", cNt=" + cNt + ", sNt="
				+ sNt + "]";
	}
	
	
}
