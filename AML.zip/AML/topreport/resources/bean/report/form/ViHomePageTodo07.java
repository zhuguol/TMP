package resources.bean.report.form;

import java.io.Serializable;
import java.math.BigDecimal;

public class ViHomePageTodo07 implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private java.lang.String id;
	private String dataDate;
	private String reportDOrM;
	private String brNo;
	private java.math.BigDecimal sNt;
	public java.lang.String getId() {
		return id;
	}
	public void setId(java.lang.String id) {
		this.id = id;
	}
	public String getDataDate() {
		return dataDate;
	}
	public void setDataDate(String dataDate) {
		this.dataDate = dataDate;
	}
	public String getReportDOrM() {
		return reportDOrM;
	}
	public void setReportDOrM(String reportDOrM) {
		this.reportDOrM = reportDOrM;
	}
	public String getBrNo() {
		return brNo;
	}
	public void setBrNo(String brNo) {
		this.brNo = brNo;
	}
	public java.math.BigDecimal getsNt() {
		return sNt;
	}
	public void setsNt(java.math.BigDecimal sNt) {
		this.sNt = sNt;
	}
	public ViHomePageTodo07() {
		super();
	}
	public ViHomePageTodo07(String id, String dataDate, String reportDOrM,
			String brNo, BigDecimal sNt) {
		super();
		this.id = id;
		this.dataDate = dataDate;
		this.reportDOrM = reportDOrM;
		this.brNo = brNo;
		this.sNt = sNt;
	}
	@Override
	public String toString() {
		return "ViHomePageTodo07 [id=" + id + ", dataDate=" + dataDate
				+ ", reportDOrM=" + reportDOrM + ", brNo=" + brNo + ", sNt="
				+ sNt + "]";
	}
	
}
