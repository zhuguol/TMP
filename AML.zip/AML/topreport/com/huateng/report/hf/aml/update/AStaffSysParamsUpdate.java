package com.huateng.report.hf.aml.update;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import resource.bean.report.SysParams;
import resource.bean.report.SysParamsPK;

import com.huateng.commquery.result.MultiUpdateResultBean;
import com.huateng.commquery.result.UpdateResultBean;
import com.huateng.commquery.result.UpdateReturnBean;
import com.huateng.ebank.business.common.GlobalInfo;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.util.ExceptionUtil;
import com.huateng.ebank.framework.web.commQuery.BaseUpdate;
import com.huateng.exception.AppException;

public class AStaffSysParamsUpdate extends BaseUpdate {
	private static final String DATASET_ID = "AStaffSysParams";

	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request,
			HttpServletResponse respone) throws AppException {
		GlobalInfo gInfo = GlobalInfo.getCurrentInstance();
		UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID(DATASET_ID);
		UpdateReturnBean updateReturnBean = new UpdateReturnBean();
		SysParams sysParams = new SysParams();
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		while (updateResultBean.hasNext()) {
			Map map = updateResultBean.next();
			mapToObject(sysParams, map);
			String paramgroupId = (String) map.get("paramgroupId");
			String paramId = (String) map.get("paramId");
			String paramVal = (String) map.get("paramVal");//参数值
			if("ALTER".equals(paramgroupId.trim()) && "ALTER".equals(paramId.trim())){
				if("".equals(paramVal.trim())){
					ExceptionUtil.throwCommonException("交易自查比例参数不能为空，请检查！");
				}else{
					try{
						int num =  Integer.parseInt(paramVal.trim());
						if(num < 0 || num > 100){
							ExceptionUtil.throwCommonException("交易自查比例参数只能设置在\"0~100\"之间，请检查！");
						}
					}catch(NumberFormatException e){
						ExceptionUtil.throwCommonException("交易自查比例参数只能设置数字，请检查！");
					}
					
				}
			}
			sysParams.setId(new SysParamsPK(paramgroupId, paramId));
			rootdao.update(sysParams);
		}
		return updateReturnBean;
	}
}