package com.huateng.report.hf.aml.update;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import resources.bean.report.form.AStaffAcctTradM;

import com.huateng.common.err.Module;
import com.huateng.common.err.Rescode;
import com.huateng.commquery.result.MultiUpdateResultBean;
import com.huateng.commquery.result.UpdateResultBean;
import com.huateng.commquery.result.UpdateReturnBean;
import com.huateng.ebank.business.common.GlobalInfo;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.util.DataFormat;
import com.huateng.ebank.framework.util.ExceptionUtil;
import com.huateng.ebank.framework.web.commQuery.BaseUpdate;
import com.huateng.excel.imp.DataMyUtil;
import com.huateng.exception.AppException;

public class AStaffAcctTradMApproveSave extends BaseUpdate {
	private static final String DATASET_ID = "AStaffAcctTradMUpdate";

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request,
			HttpServletResponse response) throws AppException {
		try {
			UpdateReturnBean updateReturnBean = new UpdateReturnBean();
			UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID(DATASET_ID);
			ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
			String approveStatusChoose = updateResultBean.getParameter("approveStatusChoose");//记录状态
			String approveResultChoose = updateResultBean.getParameter("approveResultChoose");//审核说明
			String recordUpdTlrChoose = updateResultBean.getParameter("recordUpdTlrChoose");//新调查者
			AStaffAcctTradM asfM = new AStaffAcctTradM();
			//获取用户信息
			GlobalInfo gInfo = GlobalInfo.getCurrentInstance();
			while (updateResultBean.hasNext()) {
				mapToObject(asfM, updateResultBean.next());
				String recordUpdTlr = asfM.getRecordUpdTlr().trim();//记录修改人
				String investigator = asfM.getInvestigator().trim();//调查者
				String qcComment = asfM.getQcComment().trim();//质检意见
				
				if("01".equals(approveStatusChoose)){//审核通过
					asfM.setApproveStatus("03");
				}else{//审核不通过
					asfM.setApproveStatus("04");
					if(!DataFormat.isEmpty(recordUpdTlrChoose)){//不为空
						if(!recordUpdTlr.equals(recordUpdTlrChoose)){
							investigator = investigator + "," + recordUpdTlrChoose ;
							if(investigator.length() > 4000){
								ExceptionUtil.throwCommonException("调查者长度为4000！");
							}else{
								asfM.setInvestigator(investigator);
							}
							asfM.setRecordUpdTlr(recordUpdTlrChoose);
						}
					}
				}
				//质检意见与审核说明
				if(!DataFormat.isEmpty(approveResultChoose)){
					if(!"".equals(qcComment)){//质检意见
						qcComment = qcComment + "," + approveResultChoose;
						if(qcComment.length() > 4000){
							ExceptionUtil.throwCommonException("质检意见长度为4000！");
						}else{
							asfM.setQcComment(qcComment);
						}
					}else{
						asfM.setQcComment(approveResultChoose);
					}
					asfM.setApproveResult(approveResultChoose);
				}
				
				asfM.setApproveUpdTlr(gInfo.getTlrno());//审核人员
				asfM.setApproveUpdTm(DataMyUtil.getDate().substring(0,8));//审核日期
				rootdao.update(asfM);
			}
			return updateReturnBean;
		} catch (AppException appEx){
			throw appEx;
		} catch (Exception ex) {
			throw new AppException(Module.SYSTEM_MODULE, Rescode.DEFAULT_RESCODE, ex.getMessage(), ex);
		}
	}
}
