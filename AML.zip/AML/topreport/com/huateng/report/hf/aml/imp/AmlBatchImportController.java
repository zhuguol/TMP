package com.huateng.report.hf.aml.imp;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.ui.ModelMap;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import resource.bean.report.AmlBhbsDs;
import resource.bean.report.Amlupload;
import resource.bean.report.SysParams;
import resources.bean.report.form.AStaffAcctTrad;
import resources.bean.report.form.AStaffAcctTradM;
import resources.bean.report.form.AStaffAcctTradMRRB;
import resources.bean.report.form.AStaffAcctTradRRB;
import resources.bean.report.form.CBlackListSplitConfirm;
import resources.bean.report.form.CBlackListUpload;
import resources.bean.report.form.CBlackListUploadPk;
import resources.bean.report.form.ExchangeWithinCounter;

import com.huateng.ebank.business.common.GlobalInfo;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.exceptions.CommonException;
import com.huateng.ebank.framework.util.DataFormat;
import com.huateng.ebank.framework.util.ExceptionUtil;
import com.huateng.excel.imp.Config;
import com.huateng.excel.imp.DataMyUtil;
import com.huateng.report.aml.download.ExportBlackNameUtils;
import com.huateng.report.aml.feedback.service.AmlFeedBackservice;
import com.huateng.report.aml.feedback.service.AmlFeedBackservices;
import com.huateng.report.common.service.ReportCommonService;
import com.huateng.report.constants.AMLConstants;
import com.huateng.report.hf.aml.bs.bean.AmlBsFileUpload;
import com.huateng.report.hf.aml.bs.bean.AmlBsTransUpload;
import com.huateng.report.hf.aml.service.AmlBHdsBakService;
import com.huateng.report.hf.aml.utils.HsbcAmlBizLogUtils;
import com.huateng.report.hf.aml.utils.HsbcAmlUtils;
import com.huateng.report.hf.aml.utils.SftpUtil;
import com.huateng.report.utils.ReportUtils;

/**
 * author: kin wong
 *
 * class desc:批量导入统一控制器（黑白名单、第三方网址等名单导入、模板下载）
 */
public class AmlBatchImportController extends MultiActionController {
    // 人民币币种
    private static String cny = "CNY";

    public CommonsMultipartResolver getMultipartResolver() {
        return multipartResolver;
    }

    protected Logger logger = Logger.getLogger(getClass());

    protected String result;// 结果返回页面

    protected String resultWithMail;// Mail结果返回页面

    protected CommonsMultipartResolver multipartResolver;// 文件上传

    public void setResult(String result) {
        this.result = result;
    }

    public void setMultipartResolver(CommonsMultipartResolver multipartResolver) {
        this.multipartResolver = multipartResolver;
    }

    public String getResult() {
        return result;
    }

    public String getResultWithMail() {
        return resultWithMail;
    }

    public void setResultWithMail(String resultWithMail) {
        this.resultWithMail = resultWithMail;
    }

    @SuppressWarnings({ "deprecation" })
    public ModelAndView uploadFileSftp(HttpServletRequest request, HttpServletResponse reponse)
            throws Exception {
        MultipartResolver resolver = new CommonsMultipartResolver(request.getSession().getServletContext());
        MultipartHttpServletRequest mrequest = resolver.resolveMultipart(request);
        MultipartFile file = mrequest.getFile("uploadFile");
        String fileName = file.getOriginalFilename();
        InputStream in = file.getInputStream();
        List<String> errorList = new ArrayList<String>();
        ModelMap mmap = new ModelMap();
        mmap.addObject("errors", errorList);
        ModelAndView modelAndView = new ModelAndView(result, mmap);
        try {
            SftpUtil.uploadFile(in, fileName);
        } catch (Exception e) {
            e.printStackTrace();
            errorList.add("系统内部出错，错误信息：" + e.getMessage());
        }
        return modelAndView;
    }

    // 邮件发送测试功能
    @SuppressWarnings({ "deprecation" })
    public ModelAndView mailTest(HttpServletRequest request, HttpServletResponse reponse) throws Exception {

        List<String> errorList = new ArrayList<String>();

        ModelMap mmap = new ModelMap();
        mmap.addObject("errors", errorList);
        ModelAndView modelAndView = new ModelAndView(resultWithMail, mmap);

        String user = request.getParameter("user");
        String passWord = request.getParameter("passWord");
        String server = request.getParameter("server");
        String to = request.getParameter("to");
        String title = request.getParameter("title");
        String describe = request.getParameter("describe");
        if ("1".equals(passWord)) {
            passWord = null;
        }

        // tiatianhappy@sina.com smtp.sina.com litianlong@chinasofti.com

        try {
            // 0. 邮件参数
            Properties prop = new Properties();
            prop.put("mail.transport.protocol", "smtp"); // 指定协议
            // prop.put("mail.smtp.host", "smtp.sina.com"); // 新浪主机 smtp.sina.com
            // prop.put("mail.smtp.port", 25); // 端口
            prop.put("mail.smtp.auth", "true"); // 用户密码认证
            prop.put("mail.debug", "true"); // 调试模式

            // 1. 创建一个邮件的会话
            Session session = Session.getDefaultInstance(prop);
            // 2. 创建邮件体对象 (整封邮件对象)
            MimeMessage message = new MimeMessage(session);
            // 3. 设置邮件体参数:
            // 3.1 标题
            message.setSubject(title);
            // 3.2 邮件发送时间
            message.setSentDate(new Date());
            // 3.3 发件人
            // message.setSender(new InternetAddress("tiatianhappy@sina.com"));
            message.setFrom(new InternetAddress(user));
            // 3.4 接收人
            message.setRecipient(RecipientType.TO, new InternetAddress(to));
            // 3.5内容
            message.setText(describe); // 简单纯文本邮件
            // 邮件中含有超链接
            // 4. 发送
            Transport trans = session.getTransport();
            trans.connect(server, 25, user, passWord);
            // 发送邮件
            trans.sendMessage(message, message.getAllRecipients());
            trans.close();
        } catch (Exception e) {
            e.printStackTrace();
            errorList.add("系统内部出错，错误信息：" + e.getMessage());
        }
        return modelAndView;
    }

    // 交易批量导入
    @SuppressWarnings({ "unused", "deprecation", "unchecked", "rawtypes" })
    public ModelAndView uploadImport(HttpServletRequest request, HttpServletResponse reponse)
            throws Exception {
        File uploadFile = null;
        String f = request.getQueryString();
        MultipartResolver resolver = new CommonsMultipartResolver(request.getSession().getServletContext());
        MultipartHttpServletRequest mrequest = resolver.resolveMultipart(request);
        String fileflag = mrequest.getParameter("fileflag");

        String workDate = mrequest.getParameter("workDate");
        HttpSession httpSession = request.getSession();
        GlobalInfo globalInfo = (GlobalInfo) httpSession.getAttribute(GlobalInfo.KEY_GLOBAL_INFO);
        GlobalInfo.setCurrentInstance(globalInfo);
        // 封装页面返回对象
        List errorList = new ArrayList();
        ModelMap mmap = new ModelMap();
        mmap.addObject("errors", errorList);
        ModelAndView modelAndView = new ModelAndView(result, mmap);

        try {
            // 验证上传的文件大小限制
            mrequest.setCharacterEncoding("UTF-8");
            MultipartFile file = mrequest.getFile("uploadFile");

            // 验证上传文件路径（是否存在，是否符合格式）
            // String path = this.getClass().getResource("").getPath()+
            // "filetmp/";

            AmlFeedBackservice service = AmlFeedBackservice.getInstance();
            String path = service.getParentDir("Downoload", "AML") + "filetmp/";

            mkdirIfNotExists(path);
            // 上传文件到指定的文件夹（用时间作为文件名保存防止文件重名）
            String currentTime = DataMyUtil.getFullDateTime();
            String fullFileName = path + currentTime + ".xls";
            uploadFile = new File(fullFileName);
            file.transferTo(uploadFile);
            // 获取原上传文件名
            String originalFilename = file.getOriginalFilename();
            if ("AMLBHds".equals(fileflag)) {// 大额批量导入
                importBHExcelData(originalFilename, fullFileName, workDate, globalInfo);

                // GlobalInfo.getCurrentInstance().addBizLog("Updater.log",new
                // String[] { globalInfo.getTlrno(), globalInfo.getBrno(),
                // "大额批量导入-工作日期【"+workDate +"】 文件名称【"+originalFilename+"】"});
                HsbcAmlBizLogUtils.setLogToBizLog(globalInfo, "Updater.log",
                        new String[] { globalInfo.getTlrno(), globalInfo.getBrno(),
                                "大额批量导入-工作日期【" + workDate + "】 文件名称【" + originalFilename + "】" }, "大额批量导入");

            } else if ("AMLBsTrans".equals(fileflag)) {// 可疑批量导入
                int reportId = Integer.parseInt(mrequest.getParameter("reportId"));
                importBSExcelData(fullFileName, reportId, workDate);
                // GlobalInfo.getCurrentInstance().addBizLog("Updater.log",new
                // String[] { globalInfo.getTlrno(), globalInfo.getBrno(),
                // "可疑批量导入【"+reportId+"】工作日期【"+workDate
                // +"】 文件名称【"+originalFilename+"】"});
                HsbcAmlBizLogUtils.setLogToBizLog(globalInfo, "Updater.log",
                        new String[] {
                                globalInfo.getTlrno(),
                                globalInfo.getBrno(),
                                "可疑批量导入【" + reportId + "】工作日期【" + workDate + "】 文件名称【" + originalFilename
                                        + "】" }, "可疑批量导入");

            }

        } catch (Exception e) {
            e.printStackTrace();
            errorList.add("系统内部出错，错误信息：" + e.toString());
        } finally {
            if (uploadFile != null) {
                uploadFile.delete();
            }
        }
        return modelAndView;
    }

    //update zgl 黑名单上传
    @SuppressWarnings({ "unchecked", "rawtypes", "deprecation" })
	public ModelAndView uploadBlackName(HttpServletRequest request, HttpServletResponse reponse)
            throws Exception {
        File uploadFile = null;
        MultipartResolver resolver = new CommonsMultipartResolver(request.getSession().getServletContext());
        MultipartHttpServletRequest mrequest = resolver.resolveMultipart(request);
        String fileflag = mrequest.getParameter("fileflag");

        String workDate = mrequest.getParameter("workDate");
        HttpSession httpSession = request.getSession();
        GlobalInfo globalInfo = (GlobalInfo) httpSession.getAttribute(GlobalInfo.KEY_GLOBAL_INFO);
        GlobalInfo.setCurrentInstance(globalInfo);
        // 封装页面返回对象
        List errorList = new ArrayList();
        ModelMap mmap = new ModelMap();
        mmap.addObject("errors", errorList);
        ModelAndView modelAndView = new ModelAndView(result, mmap);

        try {
            // 验证上传的文件大小限制
            mrequest.setCharacterEncoding("UTF-8");
            MultipartFile file = mrequest.getFile("uploadFile");

            AmlFeedBackservice service = AmlFeedBackservice.getInstance();
            String path = service.getParentDir("Downoload", "AML") + "filetmp/";

            mkdirIfNotExists(path);
            // 上传文件到指定的文件夹（用时间作为文件名保存防止文件重名）
            String currentTime = DataMyUtil.getFullDateTime();
            String fullFileName = path + currentTime + ".xls";
            uploadFile = new File(fullFileName);
            file.transferTo(uploadFile);
            // 获取原上传文件名
            String originalFilename = file.getOriginalFilename();
            if ("CBlackListUpload".equals(fileflag)) {// 黑名单批量导入
            	if(originalFilename.indexOf("黑名单上传导入模板")>-1){
            		importBNxcelData(originalFilename, fullFileName, workDate, globalInfo);

                    HsbcAmlBizLogUtils.setLogToBizLog(globalInfo, "Updater.log",
                            new String[] { globalInfo.getTlrno(), globalInfo.getBrno(),
                                    "黑名单上传批量导入-工作日期【" + workDate + "】 文件名称【" + originalFilename + "】" }, "黑名单上传批量导入");
                }else{
                	throw new Exception("此入口只能导入\"黑名单上传导入模板\"，请检查！");
                }
            } else if("CBlackListSplitConfirm".equals(fileflag)){//黑名单拆分导入
            	if(originalFilename.indexOf("黑名单拆分导入模板")>-1){
            		importBNxcelData(originalFilename, fullFileName, workDate, globalInfo);

                    HsbcAmlBizLogUtils.setLogToBizLog(globalInfo, "Updater.log",
                            new String[] { globalInfo.getTlrno(), globalInfo.getBrno(),
                                    "黑名单拆分批量导入-工作日期【" + workDate + "】 文件名称【" + originalFilename + "】" }, "黑名单拆分批量导入");
                }else{
                	throw new Exception("此入口只能导入\"黑名单拆分导入模板\"，请检查！");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            errorList.add("系统内部出错，错误信息：" + e.toString());
        } finally {
            if (uploadFile != null) {
                uploadFile.delete();
            }
        }
        return modelAndView;
    }

    // 多文件上传 测试方法
    @SuppressWarnings({ "unused", "deprecation", "unchecked", "rawtypes" })
    public ModelAndView uploadFilsesImport(HttpServletRequest request, HttpServletResponse reponse)
            throws Exception {
        File uploadFile = null;
        String f = request.getQueryString();
        MultipartResolver resolver = new CommonsMultipartResolver(request.getSession().getServletContext());
        MultipartHttpServletRequest mrequest = resolver.resolveMultipart(request);
        String fileflag = mrequest.getParameter("fileflag");

        String workDate = mrequest.getParameter("workDate");
        HttpSession httpSession = request.getSession();
        GlobalInfo globalInfo = (GlobalInfo) httpSession.getAttribute(GlobalInfo.KEY_GLOBAL_INFO);
        GlobalInfo.setCurrentInstance(globalInfo);
        // 封装页面返回对象
        List errorList = new ArrayList();
        ModelMap mmap = new ModelMap();
        mmap.addObject("errors", errorList);
        ModelAndView modelAndView = new ModelAndView(result, mmap);

        try {
            System.out.println("====================================================================");

            long startTime = System.currentTimeMillis();
            // 验证上传的文件大小限制
            mrequest.setCharacterEncoding("UTF-8");
            // MultipartFile file = mrequest.getFile("uploadFile");
            List<MultipartFile> fileList = mrequest.getFiles("uploadFile");

            // 验证上传文件路径（是否存在，是否符合格式）
            // String path = this.getClass().getResource("").getPath()+
            // "filetmp/";

            AmlFeedBackservice service = AmlFeedBackservice.getInstance();
            String path = service.getParentDir("Downoload", "AML") + "filetmp/";

            mkdirIfNotExists(path);
            // 上传文件到指定的文件夹（用时间作为文件名保存防止文件重名）
            String currentTime = DataMyUtil.getFullDateTime();
            String fullFileName;

            Map<String, String> fileMap = new HashMap<String, String>();
            for (int i = 0; i < fileList.size(); i++) {
                if (fileList.get(i).getOriginalFilename().endsWith("xlsx")) {// 根据导入文件名称判断读取03还是10版excel
                    fullFileName = path + i + ".xlsx";
                } else {
                    fullFileName = path + i + ".xls";
                }

                uploadFile = new File(fullFileName);

                fileMap.put(fileList.get(i).getOriginalFilename(), fullFileName);

                fileList.get(i).transferTo(uploadFile);
            }

            for (String key : fileMap.keySet()) {
                try {
                    importuploadFilsesExcelData(key, fileMap.get(key), workDate, globalInfo);
                } finally {
                    uploadFile = new File(fileMap.get(key));
                    // 入库后 对临时文件做删除操作
                    // uploadFile.delete();
                }

            }
            System.out.println("=============================总导入时间："
                    + (System.currentTimeMillis() - startTime) / 1000
                    + "秒=======================================");
            System.out.println("====================================================================");
        } catch (Exception e) {
            e.printStackTrace();
            errorList.add("系统内部出错，错误信息：" + e.toString());
        } finally {
            // if (uploadFile != null) {
            // uploadFile.delete();
            // }
        }
        return modelAndView;
    }

    // 可疑报文的附件上传
    @SuppressWarnings({ "unused", "deprecation", "unchecked", "rawtypes" })
    public ModelAndView uploadImport01(HttpServletRequest request, HttpServletResponse reponse)
            throws Exception {
        HttpSession httpSession = request.getSession();
        GlobalInfo globalInfo = (GlobalInfo) httpSession.getAttribute(GlobalInfo.KEY_GLOBAL_INFO);
        GlobalInfo.setCurrentInstance(globalInfo);
        ROOTDAO root = ROOTDAOUtils.getROOTDAO();
        // 获取参数
        MultipartResolver resolver = new CommonsMultipartResolver(request.getSession().getServletContext());
        MultipartHttpServletRequest mrequest = resolver.resolveMultipart(request);
        String fileflag = mrequest.getParameter("fileflag");
        int reportId = Integer.parseInt(mrequest.getParameter("reportId"));
        String workDate = mrequest.getParameter("workDate");
        // 封装页面返回对象
        List errorList = new ArrayList();
        ModelMap mmap = new ModelMap();
        mmap.addObject("errors", errorList);
        ModelAndView modelAndView = new ModelAndView(result, mmap);

        // 消息提示
        InputStream in = null;
        FileOutputStream out = null;
        try {
            AmlFeedBackservices service = AmlFeedBackservices.getInstance();
            String path = service.getParentDir("BSFILE", "AML");
            String savePath = path + workDate;
            // 判断上传文件的保存目录是否存在
            mkdirIfNotExists(savePath);
            // 验证上传的文件大小限制
            mrequest.setCharacterEncoding("UTF-8");
            MultipartFile file = mrequest.getFile("uploadFile");
            long filesize = file.getSize();
            if (filesize > 1024 * 1024 * 5) {
                errorList.add("文件大小超过导入限制,只能上传5M以内的文件");
                return modelAndView;
            }
            String filename = file.getOriginalFilename();
            // 获取上传文件的输入流
            in = file.getInputStream();
            // 创建一个文件输出流
            String filepath = savePath + "/" + filename;
            out = new FileOutputStream(filepath);
            // 创建一个缓冲区
            byte buffer[] = new byte[1024];
            // 判断输入流中的数据是否已经读完的标识
            int len = 0;
            while ((len = in.read(buffer)) > 0) {
                out.write(buffer, 0, len);
            }

            // 检查是否有上传的同一文件，有做更新，没有做插入
            // String hql =
            // "from AmlBsFileUpload abful where abful.reportId = ? and abful.workDate = ? and abful.filename = ?";
            // Session session=root.getSessionFactory().openSession();
            // Query query = session.createQuery(hql);
            // query.setInteger(0, reportId);
            // query.setString(1, workDate);
            // query.setString(2, filepath);
            // List<AmlBsFileUpload> list = query.list();

            String hql = "from AmlBsFileUpload abful where abful.reportId = '" + reportId
                    + "' and abful.workDate = '" + workDate + "' and abful.filename = '" + filepath + "'";
            List list = root.queryByQL2List(hql);

            AmlBsFileUpload amlBsFileUploadByQuery = null;

            // 上传成功存入数据库
            AmlBsFileUpload amlBsFileUpload = new AmlBsFileUpload();

            if (list.size() > 0) {
                for (int i = 0; i < list.size(); i++) {
                    // 附件更新第一条
                    if (i == 0) {
                        amlBsFileUploadByQuery = (AmlBsFileUpload) list.get(i);
                        amlBsFileUpload.setId(amlBsFileUploadByQuery.getId());
                    } else {
                        // reportId workDate filepath 三元素相同的附件做 删除操作。
                        root.delete((AmlBsFileUpload) list.get(i));
                    }
                }
            } else {
                amlBsFileUpload.setId(ReportUtils.getUUID());
            }

            amlBsFileUpload.setWorkDate(workDate);
            amlBsFileUpload.setReportId(reportId);
            amlBsFileUpload.setFilename(filepath);
            amlBsFileUpload.setFilesize(filesize);
            amlBsFileUpload.setUploadtlr(globalInfo.getTlrno());
            amlBsFileUpload.setUploadtm(new Date());
            // 检查是否有上传的同一文件，有做更新，没有做插入
            root.saveOrUpdate(amlBsFileUpload);
            String fileName = filepath.substring(filepath.lastIndexOf("/") + 1);
            // GlobalInfo.getCurrentInstance().addBizLog("Updater.log",new
            // String[] { globalInfo.getTlrno(), globalInfo.getBrno(),
            // "可疑报文-新增-上传附件 -内部编号【"+reportId+ "】工作日期【"+workDate
            // +"】 文件名称【"+fileName+"】"});

            HsbcAmlBizLogUtils.setLogToBizLog(globalInfo, "Updater.log", new String[] {
                    globalInfo.getTlrno(), globalInfo.getBrno(),
                    "可疑报文-新增-上传附件 -内部编号【" + reportId + "】工作日期【" + workDate + "】 文件名称【" + fileName + "】" },
                    "可疑报文上传附件");

        } catch (Exception e) {
            e.printStackTrace();
            errorList.add("系统内部出错，错误信息：" + e.toString());
        } finally {
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
        }
        return modelAndView;
    }

    // 可疑模板导入
    protected void importBSExcelData(String filePath, int reportId, String workDate) throws Exception {
        InputStream is = new FileInputStream(new File(filePath));
        List<String> error_list = new ArrayList<String>();
        ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
        HSSFWorkbook hssfWorkbook = new HSSFWorkbook(new POIFSFileSystem(is));

        ArrayList<AmlBsTransUpload> arrayAmlBsTransUploadList = new ArrayList<AmlBsTransUpload>();
        HashMap<String, AmlBsTransUpload> arrayAmlBsTransUploadMap = new HashMap<String, AmlBsTransUpload>();

        ArrayList errerList = new ArrayList();
        // 导入标识
        boolean beanSaveFlag = true;
        int beanSaveFlagIndex = 0;
        // 全量数据规则校验标识
        String htdtOrTstmFlag = null;

        HSSFSheet hssfSheet = null;
        boolean hssfSheetFlag = false;
        Sheet sheet = null;
        // 记录不符合导入规则的sheet名称
        String sheetName = null;
        String errMsg = "";
        for (int i = 0; i < hssfWorkbook.getNumberOfSheets(); i++) {
            hssfSheet = hssfWorkbook.getSheetAt(i);

            if (hssfSheet.getSheetName().indexOf("交易信息") != -1) {
                hssfSheetFlag = true;

                for (int rowNum = 1; rowNum <= hssfSheet.getLastRowNum(); rowNum++) {
                    if (!isBlankRow(hssfSheet.getRow(rowNum))) {
                        AmlBsTransUpload bean = new AmlBsTransUpload();
                        bean.setId(ReportUtils.getUUID());
                        bean.setReportId(reportId);
                        bean.setWorkDate(workDate);
                        bean.setIsComp("0"); // 完整标识为否
                        HSSFRow hssfRow = hssfSheet.getRow(rowNum); // 从第二行开始读取
                        String Ctnm = getCellStringValue(hssfRow.getCell(0)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(0));
                        if (null != Ctnm && !Ctnm.trim().equals("@N") && getTruelength(Ctnm) > 64) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易主体客户名称过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCtnm(Ctnm);// 交易主体客户名称

                        String Citp = getCellStringValue(hssfRow.getCell(1)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(1)).split("-")[0].trim();
                        if (null != Citp && !Citp.trim().equals("@N") && getTruelength(Citp) > 32) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易主体客户身份证件类型过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCitp(Citp);// 交易主体客户身份证件类型

                        String Aoitp = getCellStringValue(hssfRow.getCell(2)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(2));
                        if (null != Aoitp && !Aoitp.trim().equals("@N") && getTruelength(Aoitp) > 30) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易主体客户身份证件类型其他类说明过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCitpDesc(Aoitp);// 交易主体客户身份证件类型其他类说明

                        String Ctid = getCellStringValue(hssfRow.getCell(3)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(3));
                        if (null != Ctid && !Ctid.trim().equals("@N") && getTruelength(Ctid) > 20) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "客户身份证件/证明文件号码过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCtid(Ctid);// 交易主体客户证件号码

                        String Csnm = getCellStringValue(hssfRow.getCell(4)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(4));
                        if (null != Csnm && !Csnm.trim().equals("@N") && getTruelength(Csnm) > 32) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易主体客户号过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCsnm(Csnm);// 交易主体客户号

                        String Rlfc = getCellStringValue(hssfRow.getCell(5)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(5)).split("-")[0].trim();
                        if (null != Rlfc && !Rlfc.trim().equals("@N") && getTruelength(Rlfc) > 2) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易主体金融机构与客户的关系过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setRlfc(Rlfc);// 交易主体金融机构与客户的关系

                        String Finc = getCellStringValue(hssfRow.getCell(6)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(6)).split("-")[0].trim();
                        if (null != Finc && !Finc.trim().equals("@N") && getTruelength(Finc) > 6) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易主体金融机构网点代码过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setFinc(Finc);// 交易主体金融机构网点代码

                        String Catp = getCellStringValue(hssfRow.getCell(7)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(7)).split("-")[0].trim();
                        if (null != Catp && !Catp.trim().equals("@N") && getTruelength(Catp) > 4) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易主体账户类型过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCatp(Catp);// 交易主体账户类型

                        String Ctac = getCellStringValue(hssfRow.getCell(8)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(8));
                        if (null != Ctac && !Ctac.trim().equals("@N") && getTruelength(Ctac) > 64) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易主体账号过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCtac(Ctac);// 交易主体账号

                        String Oatm = getCellStringValue(hssfRow.getCell(9)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(9));
                        if (null != Oatm && !Oatm.trim().equals("@N") && getTruelength(Oatm) > 8) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易主体客户开户时间过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setOatm(Oatm);// 交易主体客户开户时间

                        String Catm = getCellStringValue(hssfRow.getCell(10)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(10));
                        if (null != Catm && !Catm.trim().equals("@N") && getTruelength(Catm) > 8) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易主体客户销户时间过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCatm(Catm);// 交易主体客户销户时间

                        String Cbct = getCellStringValue(hssfRow.getCell(11)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(11)).split("-")[0].trim();
                        if (null != Cbct && !Cbct.trim().equals("@N") && getTruelength(Cbct) > 2) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易主体银行卡类型过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCbct(Cbct);// 交易主体银行卡类型

                        String Ocbt = getCellStringValue(hssfRow.getCell(12)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(12));
                        if (null != Ocbt && !Ocbt.trim().equals("@N") && getTruelength(Ocbt) > 32) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易主体银行卡类型其他说明过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setOcbt(Ocbt);// 交易主体银行卡类型其他说明

                        String Cbcn = getCellStringValue(hssfRow.getCell(13)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(13));
                        if (null != Cbcn && !Cbcn.trim().equals("@N") && getTruelength(Cbcn) > 64) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易主体银行卡号码过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCbcn(Cbcn);// 交易主体银行卡号码

                        String Tbnm = getCellStringValue(hssfRow.getCell(14)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(14));
                        if (null != Tbnm && !Tbnm.trim().equals("@N") && getTruelength(Tbnm) > 32) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易主体交易代办人姓名过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTbnm(Tbnm);// 交易主体交易代办人姓名

                        String Tbit = getCellStringValue(hssfRow.getCell(15)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(15)).split("-")[0].trim();
                        if (null != Tbit && !Tbit.trim().equals("@N") && getTruelength(Tbit) > 2) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易主体代办人身份证件类型过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTbit(Tbit);// 交易主体代办人身份证件类型

                        String Boitp = getCellStringValue(hssfRow.getCell(16)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(16));
                        if (null != Boitp && !Boitp.trim().equals("@N") && getTruelength(Boitp) > 30) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易主体代办人身份证件类型其他类说明过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setBitpDesc(Boitp);// 交易主体代办人身份证件类型其他类说明

                        String Tbid = getCellStringValue(hssfRow.getCell(17)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(17));
                        if (null != Tbid && !Tbid.trim().equals("@N") && getTruelength(Tbid) > 20) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易主体交易代办人身份证件号码过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTbid(Tbid);// 交易主体交易代办人身份证件号码

                        String Tbnt = getCellStringValue(hssfRow.getCell(18)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(18)).split("-")[0].trim();
                        if (null != Tbnt && !Tbnt.trim().equals("@N") && getTruelength(Tbnt) > 3) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易主体代办人国籍过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTbnt(Tbnt);// 交易主体代办人国籍


						String tstmTemp = getCellStringValue(hssfRow
								.getCell(19)) == null ? ""
								: getCellStringValue(hssfRow.getCell(19));

						if (null != tstmTemp && !tstmTemp.trim().equals("@N")
								&& getTruelength(tstmTemp) != 8
								&& getTruelength(tstmTemp) != 14) {
							try {
								new SimpleDateFormat("yyyyMMdd")
										.parse(tstmTemp);
								new SimpleDateFormat("yyyyMMddHHmmss")
										.parse(tstmTemp);
							} catch (Exception e) {
								sheetName = hssfSheet.getSheetName();
								beanSaveFlagIndex = rowNum + 1;
								errMsg = "交易日期格式错误！";
								errerList.add(errMsg);
								e.printStackTrace();
								break;
							}
						}
						/*if (null != tstmTemp && !tstmTemp.trim().equals("@N")
								&&getTruelength(tstmTemp) != 8) {
							try {
								new SimpleDateFormat("yyyyMMdd")
										.parse(tstmTemp);
							} catch (Exception e) {
								sheetName = hssfSheet.getSheetName();
								beanSaveFlagIndex = rowNum + 1;
								errMsg = "交易日期格式错误！";
								errerList.add(errMsg);
								e.printStackTrace();
								break;
							}
						} else if (null != tstmTemp
								&& !tstmTemp.trim().equals("@N")
								&& getTruelength(tstmTemp) != 14) {
							try {
								new SimpleDateFormat("yyyyMMddHHmmss")
										.parse(tstmTemp);
							} catch (Exception e) {
								sheetName = hssfSheet.getSheetName();
								beanSaveFlagIndex = rowNum + 1;
								errMsg = "交易日期格式错误！";
								errerList.add(errMsg);
								e.printStackTrace();
								break;
							}
						}*/
						bean.setTstm(tstmTemp);// 交易时间

						if (getTruelength(tstmTemp) == 8) {
							tstmTemp = tstmTemp + "000000";
						}
						bean.setTstm(tstmTemp);// 交易时间
                        // 交易发生地
                        String trcdDesc = getCellStringValue(hssfRow.getCell(20)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(20));

                        if (trcdDesc.length() > 3) {
                            String Trcd = trcdDesc.substring(0, 3);
                            bean.setTrcd(Trcd);
                            // 交易发生地
                            String TrcdSuffix = trcdDesc.substring(3);
                            if (null != TrcdSuffix && !TrcdSuffix.trim().equals("@N")
                                    && getTruelength(TrcdSuffix) > 6) {
                                sheetName = hssfSheet.getSheetName();
                                beanSaveFlagIndex = rowNum + 1;
                                errMsg = "交易发生地字段过长！";
                                errerList.add(errMsg);
                                break;
                            }
                            bean.setTrcdSuffix(TrcdSuffix);
                        } else {
                            bean.setTrcd(trcdDesc);
                            bean.setTrcdSuffix("@N");
                        }

                        // 获取业务标示号
                        String ticdtemp = getCellStringValue(hssfRow.getCell(21)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(21));
                        if (null == ticdtemp || ticdtemp.trim().equals("@N")) {

                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "获取业务标示号不能为空！";
                            errerList.add(errMsg);
                            break;
                        }
                        if (getTruelength(ticdtemp) > 50) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "获取业务标示号字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        
                        String ticd = ticdtemp + "A";
                        if (null != ticd && !ticd.trim().equals("@N") && getTruelength(ticd) > 64) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "业务标示号字段过长！";
                            errerList.add(errMsg);
                            break;
                        } else {
                            String[] para = new String[1];
                            para[0] = ticd;
                            StringBuffer hql = new StringBuffer("from AmlBsTransUpload s where 1=1");
                            if (StringUtils.isNotBlank(ticd)) {
                                hql.append(" AND s.ticd = ?");
                            }

                            /*List<AmlBsTransUpload> result = rootdao.queryByQL2List(hql.toString(), para);
                            if (result != null && result.size() > 0) {

                                sheetName = hssfSheet.getSheetName();
                                beanSaveFlagIndex = rowNum + 1;
                                errMsg = "该业务标识号已经存在！";
                                errerList.add(errMsg);
                                break;
                            }*/
                        }
                        bean.setTicd(ticd);
                 
                        String Rpmt = getCellStringValue(hssfRow.getCell(22)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(22)).split("-")[0].trim();
                        if (null != Rpmt && !Rpmt.trim().equals("@N") && getTruelength(Rpmt) > 2) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "收付款方匹配号类型过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setRpmt(Rpmt);// 收付款方匹配号类型

                        String Rpmn = getCellStringValue(hssfRow.getCell(23)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(23));
                        if (null != Rpmn && !Rpmn.trim().equals("@N") && getTruelength(Rpmn) > 500) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "收付款方匹配号过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setRpmn(Rpmn);// 收付款方匹配号

                        String Tstp = getCellStringValue(hssfRow.getCell(24)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(24)).split("-")[0].trim();
                        if (null != Tstp && !Tstp.trim().equals("@N") && getTruelength(Tstp) > 6) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易方式过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTstp(Tstp);// 交易方式

                        String Octt = getCellStringValue(hssfRow.getCell(25)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(25)).split("-")[0].trim();
                        if (null != Octt && !Octt.trim().equals("@N") && getTruelength(Octt) > 2) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "非柜台交易方式过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setOctt(Octt);// 非柜台交易方式

                        String Ooct = getCellStringValue(hssfRow.getCell(26)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(26));
                        if (null != Ooct && !Ooct.trim().equals("@N") && getTruelength(Ooct) > 32) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "其他类非柜台交易方式说明过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setOoct(Ooct);// 其他类非柜台交易方式说明

                        String Ocec = getCellStringValue(hssfRow.getCell(27)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(27)).split("-")[0].trim();
                        if (null != Ocec && !Ocec.trim().equals("@N") && getTruelength(Ocec) > 512) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "非柜台交易方式的设备代码过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setOcec(Ocec);// 非柜台交易方式的设备代码

                        String Bptc = getCellStringValue(hssfRow.getCell(28)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(28)).split("-")[0].trim();
                        if (null != Bptc && !Bptc.trim().equals("@N") && getTruelength(Bptc) > 500) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "银行与支付机构之间的业务交易编码过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setBptc(Bptc);// 银行与支付机构之间的业务交易编码

                        String Tsct = getCellStringValue(hssfRow.getCell(29)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(29)).split("-")[0].trim();
                        if (null != Tsct && !Tsct.trim().equals("@N") && getTruelength(Tsct) > 6) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "涉外收支交易分类与代码过长";
                            errerList.add(errMsg);
                            break;
                        }
                        if (Tsct.equals("@N")) {
                            Tsct = "000000";
                        }
                        bean.setTsct(Tsct);// 涉外收支交易分类与代码

                        String Tsdr = getCellStringValue(hssfRow.getCell(30)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(30)).split("-")[0].trim();
                        if (null != Tsdr && !Tsdr.trim().equals("@N") && getTruelength(Tsdr) > 2) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "资金收付标识过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTsdr(Tsdr);// 资金收付标识

                        String Crsp = getCellStringValue(hssfRow.getCell(31)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(31));
                        if (null != Crsp && !Crsp.trim().equals("@N") && getTruelength(Crsp) > 384) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "资金用途过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCrsp(Crsp);// 资金用途

                        // 币种
                        String crtp = getCellStringValue(hssfRow.getCell(32)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(32)).split("-")[0].trim();
                        if (null != crtp && !crtp.trim().equals("@N") && getTruelength(crtp) > 3) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易币种过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCrtp(crtp);// 交易币种
                        // 交易金额
                        String cratStr = getCellStringValue(hssfRow.getCell(33)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(33));
                        if (null == cratStr || cratStr.trim().equals("@N")) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易金额不能为空";
                            errerList.add(errMsg);
                            break;
                        }
                        if (getTruelength(cratStr) > 20) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易金额过长";
                            errerList.add(errMsg);
                            break;
                        }
                        BigDecimal crat = null;
                        try {
                            crat = new BigDecimal(cratStr);
                        } catch (Exception e) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            throw new Exception("sheet[" + sheetName + "]第" + beanSaveFlagIndex
                                    + "请检查交易金额格式是否正确，正确的交易金额只允许出现0-9的数字");
                        }

                        bean.setCrat(crat);
                        //对方金融机构网点名称
                        String Cfin = getCellStringValue(hssfRow.getCell(34)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(34));
                        if (null != Cfin && !Cfin.trim().equals("@N") && getTruelength(Cfin) > 96) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易对手金融机构网点名称过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCfin(Cfin);// 交易对手金融机构网点名称

                        String Cfct = getCellStringValue(hssfRow.getCell(35)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(35)).split("-")[0].trim();
                        if (null != Cfct && !Cfct.trim().equals("@N") && getTruelength(Cfct) > 2) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易对手金融机构网点代码类型过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCfct(Cfct);// 交易对手金融机构网点代码类型

                        String Cfic = getCellStringValue(hssfRow.getCell(36)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(36)).split("-")[0].trim();
                        if (null != Cfic && !Cfic.trim().equals("@N") && getTruelength(Cfic) > 12) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易对手金融机构网点代码过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCfic(Cfic);// 交易对手金融机构网点代码

                        // bean.setCfrcSuffix(getCellStringValue(hssfRow.getCell(37))==null?"":getCellStringValue(hssfRow.getCell(37)).split("-")[0].trim());//交易对手金融机构网点所在地区行政区划代码
                        String cfrcAndCfrcSuffix = getCellStringValue(hssfRow.getCell(37)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(37));// 交易对手金融机构网点所在地区行政区划代码

                        // if(cfrcAndCfrcSuffix.length()>3){
                        // bean.setCfrc(cfrcAndCfrcSuffix.substring(0,3));
                        // bean.setCfrcSuffix(cfrcAndCfrcSuffix.substring(3));
                        // }
                        if (cfrcAndCfrcSuffix.length() > 3) {
                            String Cfrc = cfrcAndCfrcSuffix.substring(0, 3);
                            bean.setCfrc(Cfrc);
                            // 交易对手金融机构网点所在地过长
                            String CfrcSuffix = cfrcAndCfrcSuffix.substring(3);
                            if (null != CfrcSuffix && !CfrcSuffix.trim().equals("@N")
                                    && getTruelength(CfrcSuffix) > 6) {
                                sheetName = hssfSheet.getSheetName();
                                beanSaveFlagIndex = rowNum + 1;
                                errMsg = "交易对手金融机构网点所在地过长";
                                errerList.add(errMsg);
                                break;
                            }
                            bean.setCfrcSuffix(CfrcSuffix);
                        } else {
                            bean.setCfrc(cfrcAndCfrcSuffix);
                            bean.setCfrcSuffix("@N");
                        }

                        String Tcnm = getCellStringValue(hssfRow.getCell(38)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(38));
                        if (null != Tcnm && !Tcnm.trim().equals("@N") && getTruelength(Tcnm) > 96) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易对手客户名称过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTcnm(Tcnm);// 交易对手客户名称

                        String Tcit = getCellStringValue(hssfRow.getCell(39)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(39)).split("-")[0].trim();
                        if (null != Tcit && !Tcit.trim().equals("@N") && getTruelength(Tcit) > 32) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易对手客户身份证件类型过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTcit(Tcit);// 交易对手客户身份证件类型

                        String Coitp = getCellStringValue(hssfRow.getCell(40)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(40));
                        if (null != Coitp && !Coitp.trim().equals("@N") && getTruelength(Coitp) > 30) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易对手客户身份证件类型其他类说明过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTcitDesc(Coitp);// 交易对手客户身份证件类型其他类说明

                        String Tcid = getCellStringValue(hssfRow.getCell(41)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(41));
                        if (null != Tcid && !Tcid.trim().equals("@N") && getTruelength(Tcid) > 20) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易对手客户证件号码过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTcid(Tcid);// 交易对手客户证件号码

                        String Tcat = getCellStringValue(hssfRow.getCell(42)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(42)).split("-")[0].trim();
                        if (null != Tcat && !Tcat.trim().equals("@N") && getTruelength(Tcat) > 4) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易对手账户类型过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTcat(Tcat);// 交易对手账户类型

                        String Tcac = getCellStringValue(hssfRow.getCell(43)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(43));
                        if (null != Tcac && !Tcac.trim().equals("@N") && getTruelength(Tcac) > 64) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易对手账号过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTcac(Tcac);// 交易对手账号

                        // String corpCustLegalRepresName =
                        // getCellStringValue(hssfRow.getCell(44))==null?"":getCellStringValue(hssfRow.getCell(44)).split("-")[0].trim();
                        // if (null != corpCustLegalRepresName &&
                        // !corpCustLegalRepresName.trim().equals("") &&
                        // getTruelength(corpCustLegalRepresName) > 64) {
                        // sheetName = hssfSheet.getSheetName();
                        // beanSaveFlagIndex = rowNum + 1;
                        // errMsg = "对公客户法定代表人姓名";
                        // errerList.add(errMsg);
                        // break;
                        // }
                        // bean.setTcac(corpCustLegalRepresName);//对公客户法定代表人姓名
                        //
                        // String corpCustRegiam =
                        // getCellStringValue(hssfRow.getCell(45))==null?"":getCellStringValue(hssfRow.getCell(45)).split("-")[0].trim();
                        // if (null != corpCustRegiam &&
                        // !corpCustRegiam.trim().equals("") &&
                        // getTruelength(corpCustRegiam) > 20) {
                        // sheetName = hssfSheet.getSheetName();
                        // beanSaveFlagIndex = rowNum + 1;
                        // errMsg = "对公客户注册资金";
                        // errerList.add(errMsg);
                        // break;
                        // }
                        // bean.setTcac(corpCustRegiam);//对公客户注册资金
                        //
                        // String corpCustIdType =
                        // getCellStringValue(hssfRow.getCell(46))==null?"":getCellStringValue(hssfRow.getCell(46)).split("-")[0].trim();
                        // if (null != corpCustIdType &&
                        // !corpCustIdType.trim().equals("") &&
                        // getTruelength(corpCustIdType) > 32) {
                        // sheetName = hssfSheet.getSheetName();
                        // beanSaveFlagIndex = rowNum + 1;
                        // errMsg = "对公客户法定代表人身份证件类型";
                        // errerList.add(errMsg);
                        // break;
                        // }
                        // bean.setTcac(corpCustIdType);//对公客户法定代表人身份证件类型
                        //
                        // String corpCustIdCertNo =
                        // getCellStringValue(hssfRow.getCell(47))==null?"":getCellStringValue(hssfRow.getCell(47)).split("-")[0].trim();
                        // if (null != corpCustIdCertNo &&
                        // !corpCustIdCertNo.trim().equals("") &&
                        // getTruelength(corpCustIdCertNo) > 20) {
                        // sheetName = hssfSheet.getSheetName();
                        // beanSaveFlagIndex = rowNum + 1;
                        // errMsg = "对公客户法定代表人身份证件号码";
                        // errerList.add(errMsg);
                        // break;
                        // }
                        // bean.setTcac(corpCustIdCertNo);//对公客户法定代表人身份证件号码
                        //
                        // String corpCustIdTypeDesc =
                        // getCellStringValue(hssfRow.getCell(48))==null?"":getCellStringValue(hssfRow.getCell(48)).split("-")[0].trim();
                        // if (null != corpCustIdTypeDesc &&
                        // !corpCustIdTypeDesc.trim().equals("") &&
                        // getTruelength(corpCustIdTypeDesc) > 100) {
                        // sheetName = hssfSheet.getSheetName();
                        // beanSaveFlagIndex = rowNum + 1;
                        // errMsg = "对公客户法定代表人身份证件类型说明";
                        // errerList.add(errMsg);
                        // break;
                        // }
                        // bean.setTcac(corpCustIdTypeDesc);//对公客户法定代表人身份证件类型说明

                        String Rotf1 = getCellStringValue(hssfRow.getCell(49)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(49));
                        if (null != Rotf1 && !Rotf1.trim().equals("@N") && getTruelength(Rotf1) > 64) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易信息备注1过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setRotf1(Rotf1);// 交易信息备注1

                        String Rotf2 = getCellStringValue(hssfRow.getCell(50)) == null ? ""
                                : getCellStringValue(hssfRow.getCell(50));
                        if (null != Rotf2 && !Rotf2.trim().equals("@N") && getTruelength(Rotf2) > 64) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易信息备注2过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setRotf2(Rotf2);// 交易信息备注2
                        
                        //20181012 ADD  可疑交易需要导入入账日期
                        String ccpdt = getCellStringValue(hssfRow.getCell(52)) == null ? "": getCellStringValue(hssfRow.getCell(52));
                        if (null != ccpdt && !ccpdt.trim().equals("@N") && getTruelength(ccpdt) > 8) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "入账日期过长";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCcpdt(ccpdt);//入账日期
                        
                        /*if (null == arrayAmlBsTransUploadMap.get(ticd)) {
                        	arrayAmlBsTransUploadMap.put(ticd, bean);
                        } else {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "本次导入的Excel文档存中已存在此业务标识号！";
                            errerList.add(errMsg);
                            break;
                        }*/

                        arrayAmlBsTransUploadList.add(bean);
                        // rootdao.save(bean);
                    }
                }
            }
        }

        if (errerList.size() > 0) {
            arrayAmlBsTransUploadList.clear();
            throw new Exception("sheet[" + sheetName + "]第" + beanSaveFlagIndex + "行数据错误！错误原因："
                    + errerList.get(0));
        } else {
            for (AmlBsTransUpload bean : arrayAmlBsTransUploadList) {
                if (bean != null) {

                    rootdao.save(bean);
                }
            }
            arrayAmlBsTransUploadList.clear();
        }
        // String sheetName = hssfWorkbook.getSheetName(0);
        // HSSFSheet hssfSheet = hssfWorkbook.getSheetAt(0);
        if (!hssfSheetFlag) {
            throw new Exception("没有可用的Sheet，请确认文件是否正确");
        }

        hssfWorkbook.close();
        is.close();
    }

    // 大额模板导入
    protected void importBHExcelData(String fileName, String filePath, String workDate, GlobalInfo globalInfo)
            throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd hh:mm:ss");
        System.out.println("====================================================================");
        System.out.println("===========大额批量导入开始时间:" + sdf.format(new Date()) + "=================");
        System.out.println("===========导入文件名称：" + fileName + "=============================");
        System.out.println("====================================================================");
        InputStream is = new FileInputStream(new File(filePath));
        ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
        GlobalInfo gi = GlobalInfo.getCurrentInstance();

        Workbook wb = null;
        if (fileName.endsWith("xlsx")) {// 根据导入文件名称判断读取03还是10版excel
            wb = new XSSFWorkbook(is);
        } else {
            wb = new HSSFWorkbook(is);
        }

        // HSSFWorkbook hssfWorkbook = new HSSFWorkbook(new
        // POIFSFileSystem(is));

        HashMap<String, AmlBhbsDs> arrayAmlBhbsDsMap = new HashMap<String, AmlBhbsDs>();

        ArrayList errerList = new ArrayList();
        // 导入标识
        boolean beanSaveFlag = true;
        int beanSaveFlagIndex = 0;
        // 全量数据规则校验标识
        String htdtOrTstmFlag = null;
        // 记录不符合导入规则的sheet名称
        String sheetName = null;
        String errMsg = "";
        Sheet sheet = null;
        boolean hssfSheetFlag = false;

        String reportType = null;

        // 以sheet名来判断是否执行导入操作
        for (int i = 0; i < wb.getNumberOfSheets(); i++) {
            sheet = wb.getSheetAt(i);
            if (sheet.getSheetName().indexOf("交易信息") != -1) {
                hssfSheetFlag = true;
                for (int rowNum = 1; rowNum <= sheet.getLastRowNum(); rowNum++) {
                    if (!isBlankRow(sheet.getRow(rowNum))) {

                        Row row = sheet.getRow(rowNum);
                        AmlBhbsDs bean = new AmlBhbsDs();
                        bean.setId(ReportUtils.getUUID());
                        bean.setBrNo(globalInfo.getBrno()); // 机构号
                        bean.setRoleName(HsbcAmlUtils.getDepartByUserId(globalInfo.getTlrno()));// 被分派操作员的部门编号
                        bean.setCrtTm(new Date()); // 创建时间
                        bean.setApptype(AMLConstants.REPORT_APP_TYPE_AML); // 应用类型AML
                        bean.setRecStatus(AMLConstants.REPORT_RECSTATUS_01); // 记录状态01-待补录
                        bean.setRepStatus(AMLConstants.AML_REPSTATUS_01); // 回执状态01-待返回
                        bean.setSubSuccess(AMLConstants.REPORT_IS_SUB_SUCCESS_NO); // 是否成功上报0-否
                        bean.setCurrentfile(AMLConstants.REPORT_FILE_TYPE_AML_BH);
                        // bean.setReportType(AMLConstants.AML_REPORT_TYPE_NBH);
                        bean.setIsDel("0"); // 删除标示设置为 0-未删除
                        bean.setIsComp("0"); // 完整标识为否
                        bean.setSourceType("2");// 数据来源 2-批量导入F
                        bean.setLstUpdTlr(globalInfo.getTlrno()); // 设置分派的操作员编号
                        bean.setLstUpdTm(new Date());

                        SysParams param = ReportCommonService.getInstance().getSysparamsByPk(
                                globalInfo.getBrcode(), "AMLCODE");
                        bean.setRinm(param.getParamName()); // 报告机构名称
                        bean.setRicd(param.getParamVal()); // 报告机构编码

                        String htdt = getCellStringValue(sheet.getRow(rowNum).getCell(0)).trim();
                        try {
                            new SimpleDateFormat("yyyyMMdd").parse(htdt);
                            // bean.setTstm(tstmTemp);//交易时间
                        } catch (Exception e) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "大额交易发生日期格式错误，正确格式为“年年年年月月日日”！";
                            errerList.add(errMsg);
                            e.printStackTrace();
                            break;

                        }
                        if (null == htdt || htdt.trim().equals("@N")) {// 大额交易发生日期为空不能导入
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "大额交易发生日期为空不能导入！";
                            errerList.add(errMsg);
                            break;
                        } else if (htdt.length() > 8) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "大额交易发生日期字段过长！";
                            errerList.add(errMsg);
                            break;
                        } else if (htdtOrTstmFlag == null) {// 确保htdtOrTstmFlag只被赋值一次
                            htdtOrTstmFlag = htdt;
                        } else if (!htdt.equals(htdtOrTstmFlag)) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "大额交易发生日期不符合校验规则！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setHtdt(htdt);// 大额交易发生日期

                        // 根据大额交易发生日期判断并设置报文类型
                        if (null == reportType) {
                            reportType = AmlBHdsBakService.JudgeReportType(htdt, "BH");
                            bean.setReportType(reportType);
                        } else {
                            bean.setReportType(reportType);
                        }


                        String crcdTemp = getCellStringValue(sheet.getRow(rowNum).getCell(1)).split("-")[0].trim();

                        if (null == crcdTemp || crcdTemp.trim().equals("@N")) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "大额交易特征代码为空！";
                            errerList.add(errMsg);
                            break;
                        }
                        // String crcd = crcdTemp;
                        if (getTruelength(crcdTemp) > 4) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "大额交易特征代码字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCrcd(crcdTemp);// 大额交易特征代码

                        // 客户名称/姓名
                        String ctnm = getCellStringValue(row.getCell(2)) == null ? ""
                                : getCellStringValue(row.getCell(2));
                        if (null != ctnm && !ctnm.trim().equals("@N") && getTruelength(ctnm) > 64) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "客户名称/姓名字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCtnm(ctnm);//
                        // 客户身份证件/证明文件类型
                        String citp = getCellStringValue(row.getCell(3)) == null ? "" : getCellStringValue(
                                row.getCell(3)).split("-")[0].trim();
                        if (null != citp && !citp.trim().equals("@N") && getTruelength(citp) > 2) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "客户身份证件/证明文件类型字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCitp(citp);// 交易主体客户身份证件类型
                        // 交易主体客户身份证件类型其他类说明
                        String aoitp = getCellStringValue(row.getCell(4)) == null ? ""
                                : getCellStringValue(row.getCell(4));
                        if (null != aoitp && !aoitp.trim().equals("@N") && getTruelength(aoitp) > 30) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易主体客户身份证件类型其他类说明！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setAoitp(aoitp);
                        // 客户身份证件/证明文件号码
                        String ctid = getCellStringValue(row.getCell(5)) == null ? ""
                                : getCellStringValue(row.getCell(5));
                        if (null != ctid && !ctid.trim().equals("@N") && getTruelength(ctid) > 20) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "客户身份证件/证明文件号码";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCtid(ctid);
                        // 客户号
                        String csnm = getCellStringValue(sheet.getRow(rowNum).getCell(6)).trim();
                        if (null == csnm || csnm.trim().equals("@N")) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "客户号不能为空！";
                            errerList.add(errMsg);
                            break;
                        } else if (getTruelength(csnm) > 32) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "客户号字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCsnm(csnm);
                        // 客户国籍
                        String ctnt = getCellStringValue(row.getCell(7)) == null ? "" : getCellStringValue(
                                row.getCell(7)).split("-")[0].trim();
                        if (null != ctnt && !ctnt.trim().equals("@N") && getTruelength(ctnt) > 3) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "客户国籍字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCtnt(ctnt);
                        // 客户职业（对私）或客户行业（对公）
                        String ctvc = getCellStringValue(row.getCell(8)) == null ? "" : getCellStringValue(
                                row.getCell(8)).split("-")[0].trim();
                        if (null != ctvc && !ctvc.trim().equals("@N") && getTruelength(ctvc) > 32) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "客户职业（对私）或客户行业（对公）字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCtvc(ctvc);
                        // 联系电话
                        String cctl = getCellStringValue(row.getCell(9)) == null ? ""
                                : getCellStringValue(row.getCell(9));
                        if (null != cctl && !cctl.trim().equals("@N") && getTruelength(cctl) > 800) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "联系电话字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCctl(cctl);
                        // 客户其他联系方式
                        String ccei = getCellStringValue(row.getCell(10)) == null ? ""
                                : getCellStringValue(row.getCell(10));
                        if (null != ccei && !ccei.trim().equals("@N") && getTruelength(ccei) > 4000) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "客户其他联系方式字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCcei(ccei);
                        // 客户住址/经营地址
                        String ctar = getCellStringValue(row.getCell(11)) == null ? ""
                                : getCellStringValue(row.getCell(11));
                        if (null != ctar && !ctar.trim().equals("@N") && getTruelength(ctar) > 40000) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "客户住址/经营地址字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCtar(ctar);
                        // 金融机构与客户的关系
                        String rlfc = getCellStringValue(row.getCell(12)) == null ? ""
                                : getCellStringValue(row.getCell(12));
                        if (null != rlfc && !rlfc.trim().equals("@N") && getTruelength(rlfc) > 2) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "金融机构与客户的关系字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setRlfc(rlfc);
                        // 交易主体金融机构网点代码
                        String finc = getCellStringValue(row.getCell(13)) == null ? "" : getCellStringValue(
                                row.getCell(13)).split("-")[0].trim();
                        if (null != finc && !finc.trim().equals("@N") && getTruelength(finc) > 12) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易主体金融机构网点代码字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setFinc(finc);
                        // 客户账户类型
                        String catp = getCellStringValue(row.getCell(14)) == null ? "" : getCellStringValue(
                                row.getCell(14)).split("-")[0].trim();
                        if (null != catp && !catp.trim().equals("@N") && getTruelength(catp) > 4) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "客户账户类型字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCatp(catp);
                        // 客户账号
                        String ctac = getCellStringValue(row.getCell(15)) == null ? ""
                                : getCellStringValue(row.getCell(15));
                        if (null != ctac && !ctac.trim().equals("@N") && getTruelength(ctac) > 64) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "客户账号字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCtac(ctac);
                        // 客户账户开户时间
                        String oatm = getCellStringValue(row.getCell(16)) == null ? ""
                                : getCellStringValue(row.getCell(16));
                        if (null != oatm && !oatm.trim().equals("@N") && getTruelength(oatm) > 14) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "客户账户开户时间字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setOatm(oatm);
                        // 客户银行卡类型
                        String Cbct = getCellStringValue(row.getCell(17)) == null ? "" : getCellStringValue(
                                row.getCell(17)).split("-")[0].trim();
                        if (null != Cbct && !Cbct.trim().equals("@N") && getTruelength(Cbct) > 2) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "客户银行卡类型字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCbct(Cbct);
                        // 客户银行卡其他类型
                        String Ocbt = getCellStringValue(row.getCell(18)) == null ? "" : getCellStringValue(
                                row.getCell(18)).split("-")[0].trim();
                        if (null != Ocbt && !Ocbt.trim().equals("@N") && getTruelength(Ocbt) > 32) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "客户银行卡其他类型字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setOcbt(Ocbt);// 交易主体银行卡类型其他说明
                        // 客户银行卡号码
                        String Cbcn = getCellStringValue(row.getCell(19)) == null ? ""
                                : getCellStringValue(row.getCell(19));
                        if (null != Cbcn && !Cbcn.trim().equals("@N") && getTruelength(Cbcn) > 64) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "客户银行卡号码字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCbcn(Cbcn);
                        // 交易代办人姓名
                        String Tbnm = getCellStringValue(row.getCell(20)) == null ? ""
                                : getCellStringValue(row.getCell(20));
                        if (null != Tbnm && !Tbnm.trim().equals("@N") && getTruelength(Tbnm) > 32) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易代办人姓名字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTbnm(Tbnm);
                        // 交易代办人身份证件/证明文件类型
                        String Tbit = getCellStringValue(row.getCell(21)) == null ? "" : getCellStringValue(
                                row.getCell(21)).split("-")[0].trim();
                        if (null != Tbit && !Tbit.trim().equals("@N") && getTruelength(Tbit) > 2) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易代办人身份证件/证明文件类型字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTbit(Tbit);
                        // 交易代办人其他身份证件/证明文件类型
                        String Boitp = getCellStringValue(row.getCell(22)) == null ? "" : getCellStringValue(
                                row.getCell(22)).split("-")[0].trim();
                        if (null != Boitp && !Boitp.trim().equals("@N") && getTruelength(Boitp) > 30) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易代办人其他身份证件/证明文件类型字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setBoitp(Boitp);
                        // 代办人身份证件/证明文件号码
                        String Tbid = getCellStringValue(row.getCell(23)) == null ? ""
                                : getCellStringValue(row.getCell(23));
                        if (null != Tbid && !Tbid.trim().equals("@N") && getTruelength(Tbid) > 20) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "代办人身份证件/证明文件号码字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTbid(Tbid);
                        // 代办人国籍
                        String Tbnt = getCellStringValue(row.getCell(24)) == null ? "" : getCellStringValue(
                                row.getCell(24)).split("-")[0].trim();
                        if (null != Tbnt && !Tbnt.trim().equals("@N") && getTruelength(Tbnt) > 3) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "代办人国籍字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTbnt(Tbnt);
                        // 交易时间
                        String tstmTemp = getCellStringValue(sheet.getRow(rowNum).getCell(25)).trim();
                        int lengtn = tstmTemp.length();
                        for (int j = 0; j < 14 - lengtn; j++) {
                            tstmTemp = tstmTemp + "0";
                        }
                        if (null == tstmTemp || tstmTemp.equals("@N")) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易日期不能为空";
                            errerList.add(errMsg);
                            break;
                        } else if (!tstmTemp.substring(0, 8).equals(htdtOrTstmFlag)) {// 交易日期前8位不等于大额发生日期不能导入
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易日期前8位不等于大额交易发生日期！";
                            errerList.add(errMsg);
                            break;
                        }

                        try {
                            bean.setTstm(tstmTemp);// 交易时间
                            bean.setWorkDate(tstmTemp.substring(0, 8)); // 工作日期
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        // 交易发生地
                        String trcdDesc = getCellStringValue(row.getCell(26)) == null ? "@N"
                                : getCellStringValue(row.getCell(26));

                        if (trcdDesc.length() > 3) {
                            String Trcd = trcdDesc.substring(0, 3);
                            bean.setTrcd(Trcd);
                            // 交易发生地
                            String TrcdSuffix = trcdDesc.substring(3);
                            if (null != TrcdSuffix && !TrcdSuffix.trim().equals("@N")
                                    && getTruelength(TrcdSuffix) > 6) {
                                sheetName = sheet.getSheetName();
                                beanSaveFlagIndex = rowNum + 1;
                                errMsg = "交易发生地字段过长！";
                                errerList.add(errMsg);
                                break;
                            }
                            bean.setTrcdSuffix(TrcdSuffix);
                        } else {
                            bean.setTrcd(trcdDesc);
                            bean.setTrcdSuffix("@N");
                        }
                        // 获取业务标示号
                        String ticdtemp = getCellStringValue(sheet.getRow(rowNum).getCell(27)).trim();
                        if (null == ticdtemp || ticdtemp.trim().equals("@N")) {

                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "获取业务标示号不能为空！";
                            errerList.add(errMsg);
                            break;
                        }
                        if (getTruelength(ticdtemp) > 256) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "获取业务标示号字段过长！";
                            errerList.add(errMsg);
                            break;
                        }

                        // 业务标示号序列号
                        String ticdSeqNo = getCellStringValue(sheet.getRow(rowNum).getCell(52)).trim();
                        if (getTruelength(ticdSeqNo) > 256) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "业务标示号序列号字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        /*if(null == ticdSeqNo || ticdSeqNo.trim().equals("@N")){
                        	sheetName = sheet.getSheetName();
                        	beanSaveFlagIndex = rowNum + 1;
                            errMsg = "获取业务标示号序列号不能为空！";
                            errerList.add(errMsg);
                            break;
                        }*/
                        String ticd = "";
                        if(null == ticdSeqNo || ticdSeqNo.trim().equals("@N")){
                        	ticd = tstmTemp + ticdtemp +"A";
                        }else{
                            ticd = tstmTemp + ticdtemp + ticdSeqNo + "A";
                        }
                        // 业务标示号 = 交易时间+业务标识号+业务标示号序列号+A
                        if (null != ticd && !ticd.trim().equals("@N") && getTruelength(ticd) > 64) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "业务标示号字段过长！";
                            errerList.add(errMsg);
                            break;
                        } else {
                        	//20181011 Start 添加业务标识号只能为数字和字母的校验
                        	String isTicd = "^[A-Za-z0-9.]+$";
                        	if(!ticd.matches(isTicd)){
                        		 sheetName = sheet.getSheetName();
                                 beanSaveFlagIndex = rowNum + 1;
                        		 errMsg = "业务标识号只能填写数字、字母和.！";
                                 errerList.add(errMsg);
                                 break;
                        	}
                        	//20181011 End 添加业务标识号只能为数字和字母的校验
                        	
                            String[] para = new String[1];
                            para[0] = ticd;
                            StringBuffer hql = new StringBuffer("from AmlBhbsDs s where 1=1");
                            if (StringUtils.isNotBlank(ticd)) {
                                hql.append(" AND s.ticd = ?");
                            }

                            List<AmlBhbsDs> result = rootdao.queryByQL2List(hql.toString(), para);
                            if (result != null && result.size() > 0) {

                                sheetName = sheet.getSheetName();
                                beanSaveFlagIndex = rowNum + 1;
                                errMsg = "该业务标识号已经存在！";
                                errerList.add(errMsg);
                                break;
                            }
                        }
                        bean.setTicd(ticd);
                        
                        // 收付款方匹配号类型
                        String Rpmt = getCellStringValue(row.getCell(28)) == null ? "" : getCellStringValue(
                                row.getCell(28)).split("-")[0].trim();
                        if (null != Rpmt && !Rpmt.trim().equals("@N") && getTruelength(Rpmt) > 2) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "收付款方匹配号类型字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setRpmt(Rpmt);// 收付款方匹配好類型
                        // 收付款方匹配号
                        String Rpmn = getCellStringValue(row.getCell(29)) == null ? ""
                                : getCellStringValue(row.getCell(29));

                        if (null != Rpmn && !Rpmn.trim().equals("@N") && getTruelength(Rpmn) > 500) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "收付款方匹配号字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setRpmn(Rpmn);
                        // 交易方式
                        String Tstp = getCellStringValue(row.getCell(30)) == null ? "" : getCellStringValue(
                                row.getCell(30)).split("-")[0].trim();
                        if (null != Tstp && !Tstp.trim().equals("@N") && getTruelength(Tstp) > 6) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易方式字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTstp(Tstp);
                        // 非柜台交易方式
                        String Octt = getCellStringValue(row.getCell(31)) == null ? "" : getCellStringValue(
                                row.getCell(31)).split("-")[0].trim();
                        if (null != Octt && !Octt.trim().equals("@N") && getTruelength(Octt) > 2) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "非柜台交易方式字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setOctt(Octt);
                        // 其他非柜台交易方式
                        String Ooct = getCellStringValue(row.getCell(32)) == null ? "" : getCellStringValue(
                                row.getCell(32)).split("-")[0].trim();
                        if (null != Ooct && !Ooct.trim().equals("@N") && getTruelength(Ooct) > 32) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "其他非柜台交易方式字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setOoct(Ooct);// 其他类非柜台交易方式说明
                        // 非柜台交易方式的设备代码
                        String Ocec = getCellStringValue(row.getCell(33)) == null ? ""
                                : getCellStringValue(row.getCell(33));
                        if (null != Ocec && !Ocec.trim().equals("@N") && getTruelength(Ocec) > 512) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "非柜台交易方式的设备代码字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setOcec(Ocec);
                        // 银行与支付机构之间的业务交易编码
                        String Bptc = getCellStringValue(row.getCell(34)) == null ? "" : getCellStringValue(
                                row.getCell(34)).split("-")[0].trim();
                        if (null != Bptc && !Bptc.trim().equals("@N") && getTruelength(Bptc) > 500) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "银行与支付机构之间的业务交易编码字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setBptc(Bptc);
                        // 涉外收支交易分类与代码
                        String Tsct = getCellStringValue(row.getCell(35)) == null ? "" : getCellStringValue(
                                row.getCell(35)).split("-")[0].trim();
                        if (null != Tsct && !Tsct.trim().equals("@N") && getTruelength(Tsct) > 6) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "涉外收支交易分类与代码字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTsct(Tsct);
                        // 资金收付标志
                        String Tsdrtemp = getCellStringValue(sheet.getRow(rowNum).getCell(36)).trim();
                        if (null == Tsdrtemp || Tsdrtemp.trim().equals("@N")) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "资金收付标志不能为空！";
                            errerList.add(errMsg);
                            break;
                        }
                        String Tsdr = Tsdrtemp.split("-")[0].trim();
                        if (null == Tsdr && Tsdr.trim().equals("@N") && getTruelength(Tsdr) > 2) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "资金收付标志字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTsdr(Tsdr);
                        // 资金用途
                        String Crpp = getCellStringValue(row.getCell(37)) == null ? ""
                                : getCellStringValue(row.getCell(37));
                        if (null != Crpp && !Crpp.trim().equals("@N") && getTruelength(Crpp) > 256) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "资金用途字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCrpp(Crpp);

                        // 币种
                        String crtpTemp = getCellStringValue(sheet.getRow(rowNum).getCell(38)).trim();// 币种
                        if (null == crtpTemp || crtpTemp.trim().equals("@N")) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "币种不能为空！";
                            errerList.add(errMsg);
                            break;
                        }
                        String crtp = crtpTemp.split("-")[0].trim();
                        if (getTruelength(crtp) > 3) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "币种字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCrtp(crtp);

                        String cratStr = getCellStringValue(sheet.getRow(rowNum).getCell(39)).trim();// 交易金额
                        if (cratStr == null || cratStr.equals("@N")) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "金额不能为空！";
                            errerList.add(errMsg);
                            break;
                        }

                        BigDecimal crat;
                        try {
                            if (cratStr != null && !cratStr.equals("@N")) {
                                crat = new BigDecimal(cratStr);
                                if(crat.compareTo(BigDecimal.ZERO)==-1){
                                	sheetName = sheet.getSheetName();
                                	beanSaveFlagIndex = rowNum + 1;
                                    errMsg = "金额不能为负！";
                                    errerList.add(errMsg);
                                    break;
                                }
                            } else {
                                crat = new BigDecimal(0);
                            }
                        } catch (Exception e) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            throw new Exception("sheet[" + sheetName + "]第" + beanSaveFlagIndex
                                    + "请检查交易金额格式是否正确，正确的交易金额只允许出现0-9的数字");

                        }

                        bean.setCrat(crat);
                        HsbcAmlUtils.calAmounyt(bean);// 根据交易金额、日期和币种计算对应的人民币和美元金额
                        // bean.setCrtp(getCellStringValue(hssfRow.getCell(36))==null?"":getCellStringValue(hssfRow.getCell(36)));
                        // bean.setCrat(getCellStringValue(hssfRow.getCell(37))==null?"":getCellStringValue(hssfRow.getCell(37)));
                        // 对方金融机构网点名称
                        String Cfin = getCellStringValue(row.getCell(40)) == null ? ""
                                : getCellStringValue(row.getCell(40));
                        if (null != Cfin && !Cfin.trim().equals("@N") && getTruelength(Cfin) > 64) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "对方金融机构网点名称字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCfin(Cfin);
                        // 对方金融机构代码网点类型
                        String Cfct = getCellStringValue(row.getCell(41)) == null ? "" : getCellStringValue(
                                row.getCell(41)).split("-")[0].trim();
                        if (null != Cfct && !Cfct.trim().equals("@N") && getTruelength(Cfct) > 2) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "对方金融机构代码网点类型字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCfct(Cfct);
                        // 对方金融机构网点代码
                        String Cfic = getCellStringValue(row.getCell(42)) == null ? ""
                                : getCellStringValue(row.getCell(42));
                        if (null != Cfic && !Cfic.trim().equals("@N") && getTruelength(Cfic) > 12) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "对方金融机构网点代码字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCfic(Cfic);

                        String cfrcAndCfrcSuffix = getCellStringValue(row.getCell(43)) == null ? ""
                                : getCellStringValue(row.getCell(43));

                        // bean.setCfrcSuffix(getCellStringValue(hssfRow.getCell(41))==null?"":getCellStringValue(hssfRow.getCell(41)));//交易对手金融机构网点所在地区行政区划代码
                        if (cfrcAndCfrcSuffix.length() > 3) {
                            bean.setCfrc(cfrcAndCfrcSuffix.substring(0, 3));
                            String CfrcSuffix = cfrcAndCfrcSuffix.substring(3);
                            if (null != CfrcSuffix && !CfrcSuffix.trim().equals("@N")
                                    && getTruelength(CfrcSuffix) > 6) {
                                sheetName = sheet.getSheetName();
                                beanSaveFlagIndex = rowNum + 1;
                                errMsg = "对方金融机构网点行政区划代码字段过长！";
                                errerList.add(errMsg);
                                break;
                            }
                            bean.setCfrcSuffix(CfrcSuffix);
                        }
                        // 交易对手姓名/名称
                        String Tcnm = getCellStringValue(row.getCell(44)) == null ? ""
                                : getCellStringValue(row.getCell(44));
                        if (null != Tcnm && !Tcnm.trim().equals("@N") && getTruelength(Tcnm) > 64) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易对手姓名/名称字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTcnm(Tcnm);
                        // 交易对手身份证件/证明文件类型
                        String Tcit = getCellStringValue(row.getCell(45)) == null ? "" : getCellStringValue(
                                row.getCell(45)).split("-")[0].trim();
                        if (null != Tcit && !Tcit.trim().equals("@N") && getTruelength(Tcit) > 2) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易对手身份证件/证明文件类型过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTcit(Tcit);

                        // 其他身份证件/证明文件类型
                        String Coitp = getCellStringValue(row.getCell(46)) == null ? "" : getCellStringValue(
                                row.getCell(46)).split("-")[0].trim();
                        if (null != Coitp && !Coitp.trim().equals("@N") && getTruelength(Coitp) > 30) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "其他身份证件/证明文件类型字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setCoitp(Coitp);
                        // 交易对手身份证件/证明文件号码
                        String Tcid = getCellStringValue(row.getCell(47)) == null ? ""
                                : getCellStringValue(row.getCell(47));
                        if (null != Tcid && !Tcid.trim().equals("@N") && getTruelength(Tcid) > 20) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易对手身份证件/证明文件号码字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTcid(Tcid);
                        // 交易对手账户类型
                        String Tcat = getCellStringValue(row.getCell(48)) == null ? "" : getCellStringValue(
                                row.getCell(48)).split("-")[0].trim();
                        if (null != Tcat && !Tcat.trim().equals("@N") && getTruelength(Tcat) > 4) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易对手账户类型字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTcat(Tcat);
                        // 交易对手账号
                        String Tcac = getCellStringValue(row.getCell(49)) == null ? ""
                                : getCellStringValue(row.getCell(49));
                        if (null != ctnm && !ctnm.trim().equals("@N") && getTruelength(Tcac) > 64) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易对手账号字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTcac(Tcac);
                        // 交易信息备注1
                        String Rotf1 = getCellStringValue(row.getCell(50)) == null ? ""
                                : getCellStringValue(row.getCell(50));
                        if (null != Rotf1 && !Rotf1.trim().equals("@N") && getTruelength(Rotf1) > 64) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易信息备注1字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setRotf1(Rotf1);
                        // 交易信息备注2
                        String Rotf2 = getCellStringValue(row.getCell(51)) == null ? ""
                                : getCellStringValue(row.getCell(51));
                        if (null != Rotf2 && !Rotf2.trim().equals("@N") && getTruelength(Rotf2) > 64) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易信息备注2字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setRotf2(Rotf2);
                        // 金融机构网点名称
                        String Finn = getCellStringValue(row.getCell(53)) == null ? "" : getCellStringValue(
                                row.getCell(53)).split("-")[0].trim();
                        if (null != Finn && !Finn.trim().equals("@N") && getTruelength(Finn) > 64) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "金融机构网点名称字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setFinn(Finn);// 金融机构网点名称
                        // 金融机构网点所在地区行政区划代码
                        String Firc = getCellStringValue(row.getCell(54)) == null ? "" : getCellStringValue(
                                row.getCell(54)).split("-")[0].trim();
                        if (null != Firc && !Firc.trim().equals("@N") && getTruelength(Firc) > 6) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "金融机构网点所在地区行政区划代码字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setFirc(Firc);// 金融机构网点所在地区行政区划代码
                        // 金融机构网点与大额交易的关系
                        String Rltp = getCellStringValue(row.getCell(55)) == null ? "" : getCellStringValue(
                                row.getCell(55)).replaceAll(" ", "").split("-")[0];
                        if (null != Rltp && !Rltp.trim().equals("@N") && getTruelength(Rltp) > 2) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "金融机构网点与大额交易的关系字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setRltp(Rltp);// 金融机构网点与大额交易的关系

                        bean.setFict("00");// 金融机构网点代码类型(默认00)
                        // 交易方向
                        String Tdrc = getCellStringValue(row.getCell(57)) == null ? "" : getCellStringValue(
                                row.getCell(57)).split("-")[0].trim();
                        if (null != Tdrc && !Tdrc.trim().equals("@N") && getTruelength(Tdrc) > 9) {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "交易方向字段过长！";
                            errerList.add(errMsg);
                            break;
                        }
                        bean.setTdrc(Tdrc);// 交易方向
                        // arrayAmlBhbsDsList.add(bean);
                        if (null == arrayAmlBhbsDsMap.get(ticd)) {
                            arrayAmlBhbsDsMap.put(ticd, bean);
                        } else {
                            sheetName = sheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "本次导入的Excel文档存中已存在此业务标识号！";
                            errerList.add(errMsg);
                            break;
                        }

                    }
                }
            }
        }
        if (errerList.size() > 0) {
            arrayAmlBhbsDsMap.clear();
            throw new Exception("sheet[" + sheetName + "]第" + beanSaveFlagIndex + "行数据错误！错误原因："
                    + errerList.get(0));
        } else {
            for (AmlBhbsDs bean : arrayAmlBhbsDsMap.values()) {
                if (bean != null) {
                    rootdao.save(bean);
                }
            }

            arrayAmlBhbsDsMap.clear();
            // for (AmlBhbsDs bean :arrayAmlBhbsDsList) {
            // if (bean != null) {
            //
            // rootdao.save(bean);
            // }
            // }
            // arrayAmlBhbsDsList.clear();
        }
        // 找不到可用的sheet时抛出异常
        if (!hssfSheetFlag) {
            // 找不到sheet時拋出异常
            throw new Exception("没有找到可用的Sheet,请使用模板进行导入~");
        }

        // gi.appendBizLog("Updater.log",new String[] { gi.getTlrno(),
        // gi.getBrno(),"大额报文补录-批量导入-导入时间【" + sdf.format(new Date()) + "】" });
        System.out.println("====================================================================");
        System.out.println("===========大额批量导入结束时间:" + sdf.format(new Date()) + "=================");
        System.out.println("====================================================================");
        wb.close();
        is.close();
    }

    //黑名单相关信息导入
    protected void importBNxcelData(String fileName, String filePath, String workDate, GlobalInfo globalInfo) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd hh:mm:ss");
        System.out.println("====================================================================");
        System.out.println("===========黑名单导入开始时间:" + sdf.format(new Date()) + "=================");
        System.out.println("===========导入文件名称：" + fileName + "=============================");
        System.out.println("====================================================================");
        InputStream is = new FileInputStream(new File(filePath));
        ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
        List<String>  err_list=new ArrayList<String>();
        String errmsg=null;
        Workbook wb = null;
        if(fileName.endsWith("xlsx")) {// 根据导入文件名称判断读取03还是10版excel
            wb = new XSSFWorkbook(is);
        }else{
            wb = new HSSFWorkbook(is);
        }
        Sheet sheet = null;
        boolean hssfSheetFlag = false;
        for(int i = 0; i < wb.getNumberOfSheets(); i++){
        	sheet = wb.getSheetAt(i);
            if(sheet.getSheetName().indexOf("黑名单上传")>-1 && fileName.indexOf("黑名单上传导入模板")>-1){    
                ArrayList<CBlackListUpload> beanlist = new ArrayList<CBlackListUpload>();
                CBlackListUpload bean = null;
                hssfSheetFlag = true;
                String etlDate = null;
                String serial = null;
                String pboc = null;
                String notice = null;
                String targetName = null;
                String dob = null;
                String alias = null;
                String nationality = null;
                String others = null;
                String worldCheck = null;
                String remark = null;
                String uid = null;
                //获取用户编号
                String updatePerson = GlobalInfo.getCurrentInstance().getTlrno();
                //获取用户角色
        		String roleName = HsbcAmlUtils.getDepartByUserId(updatePerson);
                int error_row = 1;
                for(int rowNum = 1;rowNum <= sheet.getLastRowNum();rowNum++) {
                    if(!isBlankRow(sheet.getRow(rowNum))) {
                		Row row = sheet.getRow(rowNum);   
                        error_row = rowNum + 1;
                        etlDate = getCellStringValue3(row.getCell(0)).trim() == null ? "" : getCellStringValue3(row.getCell(0)).trim();
                        if(!isValidDate(etlDate)){
                        	errmsg = "批处理日期格式错误，正确格式为\"年年年年月月日日\"，请确认单元格格式与模板格式一致！";
                        	err_list.add(errmsg);
                            break;
                        }
                        
                        serial = getCellStringValue3(row.getCell(1)).trim();
                        if(serial.length() > 100){
                        	errmsg = "Serial的长度不能超过100！";
                        	err_list.add(errmsg);
                        	break;
						}
                        
                        pboc = getCellStringValue3(row.getCell(2)).trim();
                        if(pboc.length() > 20){
                        	errmsg = "Issued by PBOC in的长度不能超过20！";
                        	err_list.add(errmsg);
                        	break;
						}
                        
                        notice = getCellStringValue3(row.getCell(3)).trim();
                        if(notice.length() > 400){
                        	errmsg = "Notice的长度不能超过400！";
                        	err_list.add(errmsg);
                        	break;
						}
                        //update zgl 20191223
                        //去除"'"、"("、"."、"-"、","、"‘"、"&"、"/"、"’"、'"'、"a-z)"、")"、":"、"a-z)"、"na"、"NA"、"@N"、"1-4:"、"N/A"符号
                        targetName = "";
                        //fullWidth2halfWidth()将全角转换为半角符号,替换"'"、"("、"."、"-"、","、"‘"、"&"、"/"、"’"、'"'、"a-z)"、")"符号
                        String targetNameInfo = fullWidth2halfWidth(getCellStringValue3(row.getCell(4))).replaceAll("'", "").replaceAll("\\(", "").replaceAll("\\.", "").replaceAll("\\-", "").replaceAll(",", "").replaceAll("‘", "").replaceAll("&", "").replaceAll("\\/", "").replaceAll("’", "").replaceAll("\"", "").replaceAll("[a-z]{1}\\)", "").replaceAll("\\)", "").trim();
                        if(!"".equals(targetNameInfo)){
                        	if(targetNameInfo.indexOf("1:")>-1 || targetNameInfo.indexOf("2:")>-1 ||
                        		targetNameInfo.indexOf("3:")>-1 || targetNameInfo.indexOf("4:")>-1){
                        		//替换"1:"、"na"等信息
                        		String[] strArr = targetNameInfo.split("\\d+:");
                            	for(int j = 0;j < strArr.length;j++){
                            		String str = strArr[j].trim();
                            		//na不区分大小写都要去掉
                            		if(!"".equals(str) && !"na".equalsIgnoreCase(str) &&
                            				!"N/A".equalsIgnoreCase(str) && !"@N".equalsIgnoreCase(str)){
                            			//判断targetName是否是第一次赋值
                            			if("".equals(targetName)){
                            				targetName = str;
                            			}else{
                            				targetName = targetName + " " + str; 
                            			}
                            		}
                            	}
                        	}else{
                        		//if(!"na".equalsIgnoreCase(targetNameInfo)){
                        		if(!"na".equalsIgnoreCase(targetNameInfo) && !"N/A".equalsIgnoreCase(targetNameInfo) && !"@N".equalsIgnoreCase(targetNameInfo)){
                        			targetName = targetNameInfo;
                        		}
                        	}
                        	//替换":"
                        	targetName = targetName.replaceAll("\\:", "");
                        }
                        if(DataFormat.isEmpty(targetName)){
                        	errmsg = "Sanctions Targets Name为必填项！";
                        	err_list.add(errmsg);
                        	break;
						}
                        if(targetName.length() > 4000){
                        	errmsg = "Sanctions Targets Name的长度不能超过4000！";
                        	err_list.add(errmsg);
                        	break;
						}
                        
                        dob = getCellStringValue3(row.getCell(5)).trim();
                        if(dob.length() > 400){
                        	errmsg = "DOB的长度不能超过400！";
                        	err_list.add(errmsg);
                        	break;
						}
                        //update zgl 20191223 去除 "a-z)"、"'"、"-"、"na"、"N/A"、"@N"等信息
                        alias = "";
                        //fullWidth2halfWidth()将全角转换为半角符号,替换"'"、"("、"."、"-"、","、"‘"、"&"、"/"、"’"、'"'、"a-z)"、")"符号
                        String aliasInfo = fullWidth2halfWidth(getCellStringValue3(row.getCell(6))).replaceAll("'", "").replaceAll("\\(", "").replaceAll("\\.", "").replaceAll("\\-", "").replaceAll(",", "").replaceAll("‘", "").replaceAll("&", "").replaceAll("\\/", "").replaceAll("’", "").replaceAll("\"", "").replaceAll("[a-z]{1}\\)", "").replaceAll("\\)", "").trim();
                        if(!"".equals(aliasInfo)){
                        	if(aliasInfo.indexOf("1:")>-1 || aliasInfo.indexOf("2:")>-1 || 
                        		aliasInfo.indexOf("3:")>-1 || aliasInfo.indexOf("4:")>-1){
                        		//替换"1:"、"na"等信息
                        		String[] strArr = aliasInfo.split("\\d+:");
                        		for(int j = 0;j < strArr.length;j++){
                        			String str = strArr[j].trim();
                        			if(!"".equals(str) && !"na".equalsIgnoreCase(str) &&
                        				!"N/A".equalsIgnoreCase(str) && !"@N".equalsIgnoreCase(str)){
                        				//判断targetName是否是第一次赋值
                            			if("".equals(alias)){
                            				alias = str;
                            			}else{
                            				alias = alias + " " + str; 
                            			}
                        			}
                        		}
                        	}else{
                        		//20200311 update alias改为aliasInfo
                        		if(!"na".equalsIgnoreCase(aliasInfo) && !"N/A".equalsIgnoreCase(aliasInfo) && !"@N".equalsIgnoreCase(aliasInfo)){
                                	alias = aliasInfo;
                                }
                        	}
                        	//替换":"
                        	alias = alias.replaceAll("\\:", "");
                        }
                        //如果alias为空，则插入@N
                        if(DataFormat.isEmpty(alias)){
                        	alias = "@N";
						}
                        //update zgl 20191223 alias长度改为900
                        if(alias.length() > 900){
                        	errmsg = "Alias的长度不能超过900！";
                        	err_list.add(errmsg);
                        	break;
						}
                        
                        nationality = getCellStringValue3(row.getCell(7)).trim();
                        if(nationality.length() > 4000){
                        	errmsg = "Nationality的长度不能超过4000！";
                        	err_list.add(errmsg);
                        	break;
						}
                        
                        others = getCellStringValue3(row.getCell(8)).trim();
                        if (others.length() > 400) {
                        	errmsg = "Others的长度不能超过400！";
                        	err_list.add(errmsg);
                        	break;
						}
                        
                        worldCheck = getCellStringValue3(row.getCell(9)).trim();
                        if(worldCheck.length() > 10) {
                        	errmsg = "Has been added to World-Check的长度不能超过10！";
                        	err_list.add(errmsg);
                        	break;
						}
                        
                        remark = getCellStringValue3(row.getCell(10)).trim();
                        if(remark.length() > 400) {
                        	errmsg = "Remark的长度不能超过400！";
                        	err_list.add(errmsg);
                        	break;
						}
                        
                        uid = rootdao.queryListBySql("select SEQ_CBLACKLISTUPLOAD.nextval from DUAL").get(0).toString();
                        CBlackListUploadPk id=new CBlackListUploadPk(uid, etlDate);                
                        bean = new CBlackListUpload(id, serial, pboc, notice, targetName, dob, alias, nationality, others, worldCheck, remark, updatePerson, roleName);               
                        beanlist.add(bean); 
                    }
                }
                if(err_list.size() > 0){
                	beanlist.clear();
                	throw new Exception("sheet[" + sheet.getSheetName() + "]第" + (error_row) + "行数据错误！错误原因："+ err_list.get(0));
                }else{
                	for(CBlackListUpload cul : beanlist) {
                		if (cul != null){
                			rootdao.save(cul);
                		}
                	}
                	beanlist.clear();       
                }
		        System.out.println("====================================================================");
		        System.out.println("===========黑名单上传导入结束时间:" + sdf.format(new Date()) + "=================");
		        System.out.println("====================================================================");
            }else if (sheet.getSheetName().indexOf("黑名单拆分")>-1 && fileName.indexOf("黑名单拆分导入模板")>-1){
            	ArrayList<CBlackListSplitConfirm> beanlist = new ArrayList<CBlackListSplitConfirm>();
            	CBlackListSplitConfirm bean = null;
            	hssfSheetFlag = true;
            	String sid = null;
            	String etlDate = null;
            	String serial = null;
            	String issuPboc = null;
            	String notice = null;
            	String targetName = null;
            	String dob = null;
            	String alias = null;
            	String nationality = null;
            	String others = null;
            	String worldCheck = null;
            	String uid = null;
            	String splitType = null;
            	String keyWords = null;
            	String retName = null;
            	//获取用户编号
                String updatePerson = GlobalInfo.getCurrentInstance().getTlrno();
                //获取用户角色
        		String roleName = HsbcAmlUtils.getDepartByUserId(updatePerson);
            	int error_row=1;
            	for(int rowNum = 1; rowNum <= sheet.getLastRowNum(); rowNum++){
            		if(!isBlankRow(sheet.getRow(rowNum))){
            			Row row = sheet.getRow(rowNum); 
            			error_row = rowNum + 1;
            			etlDate = getCellStringValue3(row.getCell(1)).trim() == null ? "" : getCellStringValue3(row.getCell(1)).trim();
            			if(!isValidDate(etlDate)){
            				errmsg = "批处理日期格式错误，正确格式为\"年年年年月月日日\"，请确认单元格格式与模板格式一致！";
							err_list.add(errmsg);
							break;
            			}
						
						serial = getCellStringValue3(row.getCell(2)).trim();
						if(serial.length() > 100){
							errmsg = "Serial的长度不能超过100！";
							err_list.add(errmsg);
							break;
						}
						
						issuPboc = getCellStringValue3(row.getCell(3)).trim();
						if(issuPboc.length() > 20){
							errmsg = "Issued by PBOC in的长度不能超过20！";
							err_list.add(errmsg);
							break;
						}
						
						notice = getCellStringValue3(row.getCell(4)).trim();
						if (notice.length() > 400){
							errmsg = "Notice的长度不能超过400！";
							err_list.add(errmsg);
							break;
						}
						
						targetName = getCellStringValue3(row.getCell(5)).trim();
						if (targetName.length() > 4000) {
							errmsg = "Sanctions Targets Name的长度不能超过4000！";
							err_list.add(errmsg);
							break;
						}
						
						dob = getCellStringValue3(row.getCell(6)).trim();
						if (dob.length() > 400){
							errmsg = "DOB的长度不能超过400！";
							err_list.add(errmsg);
							break;
						}
						
						alias = getCellStringValue3(row.getCell(7)).trim();
                        if (alias.length() > 900){
							errmsg = "Alias的长度不能超过900！";
							err_list.add(errmsg);
							break;
						}
						
						nationality = getCellStringValue3(row.getCell(8)).trim();
						if (nationality.length() > 4000){
							errmsg = "Nationality的长度不能超过4000！";
							err_list.add(errmsg);
							break;
						}
						
						others = getCellStringValue3(row.getCell(9)).trim();
						if (others.length() > 400){
							errmsg = "Others的长度不能超过400！";
							err_list.add(errmsg);
							break;
						}
						
						worldCheck = getCellStringValue3(row.getCell(10)).trim();
						if (worldCheck.length() > 10){
							errmsg = "Has been added to World-Check的长度不能超过10！";
							err_list.add(errmsg);
							break;
						}
						
						splitType = getCellStringValue3(row.getCell(11)).trim();
						if (splitType.length() > 10){
							errmsg = "SPLIT TYPE的长度不能超过10！";
							err_list.add(errmsg);
							break;
						} 
						
						keyWords = getCellStringValue3(row.getCell(12)).trim();
						if (keyWords.length() > 400){
							errmsg = "KEY WORDS的长度不能超过400！";
							err_list.add(errmsg);
							break;
						} 
						
						retName = getCellStringValue3(row.getCell(13)).toUpperCase().trim();
						if("@N".equalsIgnoreCase(retName) || "na".equalsIgnoreCase(retName) 
								|| "N/A".equalsIgnoreCase(retName) || DataFormat.isEmpty(retName)){
                        	errmsg = "检查搜索名称为必填项！";
                        	err_list.add(errmsg);
                        	break;
						}
						if (retName.length() > 400){
							errmsg="检查搜索名称的长度不能超过400！";
							err_list.add(errmsg);
							break;
						} 
						uid = getCellStringValue3(row.getCell(0)).trim();
						sid = ExportBlackNameUtils.get20UUID();
						bean = new CBlackListSplitConfirm(sid, uid, etlDate, serial, issuPboc, notice, targetName, dob, alias, nationality, others, worldCheck, splitType, keyWords, retName, null, null, null, updatePerson, roleName) ;    
						beanlist.add(bean); 
            		}
            	}	
       
				if(err_list.size() > 0){
					beanlist.clear();
					throw new Exception("sheet[" + sheet.getSheetName() + "]第" + (error_row) + "行数据错误！错误原因："+ err_list.get(0));
				}else{
					for (CBlackListSplitConfirm csc : beanlist){
						if (csc != null){
							rootdao.save(csc);
						}
					}
					beanlist.clear();       
				}
				System.out.println("====================================================================");
				System.out.println("===========黑名单拆分导入结束时间:" + sdf.format(new Date()) + "=================");
				System.out.println("====================================================================");
            }else{
            	if(!hssfSheetFlag){
					//找不到sheet時拋出异常
					throw new Exception(fileName+"的sheet[" + sheet.getSheetName() + "]出错,请使用正确的模板进行导入！");
				}else{
					if(sheet.getSheetName().indexOf("填写说明") < 0){
						throw new Exception(fileName+"的sheet[" + sheet.getSheetName() + "]出错,请使用正确的模板进行导入！");
					}
				}
            }
        }
        wb.close();
        is.close();
    }

    // 多文件上传 测试方法
    private void importuploadFilsesExcelData(String fileName, String filePath, String workDate,
            GlobalInfo globalInfo) throws CommonException, IOException {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd hh:mm:ss");

        long startCurrentTime = System.currentTimeMillis();

        File fileSource = new File(filePath);

        String fileNameS = fileSource.getName().split("\\.")[0];

        String tableNmae = "import_files_" + fileNameS;

        InputStream is = new FileInputStream(fileSource);
        ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
        GlobalInfo gi = GlobalInfo.getCurrentInstance();

        Workbook wb = null;
        if (fileName.endsWith("xlsx")) {// 根据导入文件名称判断读取03还是10版excel
            wb = new XSSFWorkbook(is);
        } else {
            wb = new HSSFWorkbook(is);
        }
        Sheet sheet = null;

        // 以sheet名来判断是否执行导入操作
        for (int i = 0; i < wb.getNumberOfSheets(); i++) {
            sheet = wb.getSheetAt(i);
            if (sheet.getSheetName().indexOf("交易信息") != -1) {

                Object[] param;

                for (int rowNum = 1; rowNum <= sheet.getLastRowNum(); rowNum++) {
                    if (!isBlankRow(sheet.getRow(rowNum))) {

                        Row row = sheet.getRow(rowNum);

                        // int cellNum = row.getLastCellNum();
                        param = new Object[52];
                        for (int j = 0; j < 52; j++) {
                            if ((j == 26 || j == 43) && getCellStringValue(row.getCell(j)).length() > 3) {
                                param[j] = getCellStringValue(row.getCell(j)).subSequence(0, 3);
                            } else {
                                param[j] = getCellStringValue(row.getCell(j)).split("-")[0];
                            }

                        }
                        //
                        //
                        String sql = "insert into "
                                + tableNmae
                                + "(rec_id,htdt,CRCD,Ctnm,Citp,Aoitp,Ctid,Csnm,Ctnt,Ctvc,Cctl,CCEI,CTAR,Rlfc,Finc,Catp,Ctac,Oatm,Cbct,ocbt,Cbcn,Tbnm,Tbit,Boitp,Tbid,Tbnt,Tstm,TRCD,TICD,Rpmt,Rpmn,Tstp,Octt,ooct,Ocec,Bptc,Tsct,Tsdr,Crpp,CRTP,CRAT,CFIN,Cfct,Cfic,cfrcSuffix,Tcnm,Tcit,Coitp,Tcid,Tcat,Tcac,Rotf1,Rotf2) values(sys_guid(),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                        //
                        rootdao.executeSqlWithPara(sql, param);
                    }
                }
            }
        }

        System.out.println("===========导入文件名称：" + fileName + "===============用时："
                + (System.currentTimeMillis() - startCurrentTime) / 1000 + "秒==============");
    }

    /**
     * <b>method desc:下载模板文件</b> <br/>
     * method detail:
     *
     * @param request 页面请求对象
     * @param response 响应页面对象
     * @return 页面数据模型对象
     * @throws Exception 异常
     */
    @SuppressWarnings({ "deprecation", "unchecked", "rawtypes" })
    public ModelAndView downloadTemp(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        // 封装页面返回对象
        List errorList = new ArrayList();
        ModelMap mmap = new ModelMap();
        mmap.addObject("errors", errorList);
        ModelAndView modelAndView = new ModelAndView(result, mmap);

        String fileflag = request.getParameter("fileflag");

        String modulePath = "fpages/creditreport/excel/modelexcel/";
        modulePath = modulePath.replace("/", File.separator);
        StringBuffer excelDownLoadPath = new StringBuffer();

        excelDownLoadPath.append(getServletContext().getRealPath("/")).append(modulePath);

        String downloadPath = excelDownLoadPath.toString();
        // String downloadPath =
        // PropertiesUtils.getProperty("excel_download_path");

        String fileName = Config.getValue(fileflag) + ".xls";

        mkdirIfNotExists(downloadPath);

        excelDownLoadPath.append(fileName);

        File file = new File(excelDownLoadPath.toString());

        if (!file.exists()) {
            errorList.add("模板文件[" + fileName + "]不存在;");
        } else {
            BufferedInputStream bis = null;
            BufferedOutputStream bos = null;

            try {
                response.setContentType("application/x-msdownload");
                response.setHeader("Content-disposition",
                        "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));// 进行编码

                bis = new BufferedInputStream(new FileInputStream(excelDownLoadPath.toString()));
                bos = new BufferedOutputStream(response.getOutputStream());
                byte[] buff = new byte[2048];
                int bytesRead;
                while (-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
                    bos.write(buff, 0, bytesRead);
                }
            } catch (Exception e) {
                errorList.add("系统内部出错：" + e.toString());
            } finally {
                try {
                    if (bis != null) {
                        bis.close();
                    }
                    if (bos != null) {
                        bos.close();
                    }
                } catch (IOException e2) {
                    errorList.add("系统内部出错：" + e2.toString());
                }
            }
        }

        if (errorList.size() > 0)
            return modelAndView;
        return null;
    }

    // 人工补正导入
    @SuppressWarnings({ "unused", "deprecation", "unchecked", "rawtypes" })
    public ModelAndView artificialCorrectionImport(HttpServletRequest request, HttpServletResponse reponse)
            throws Exception {
        HttpSession httpSession = request.getSession();
        GlobalInfo globalInfo = (GlobalInfo) httpSession.getAttribute(GlobalInfo.KEY_GLOBAL_INFO);
        GlobalInfo.setCurrentInstance(globalInfo);
        // 封装页面返回对象
        List errorList = new ArrayList();
        ModelMap mmap = new ModelMap();
        mmap.addObject("errors", errorList);
        ModelAndView modelAndView = new ModelAndView(result, mmap);
        // 得到上传文件的保存目录
        // String savePath = "/home/topreport/AML/Upload/";

        AmlFeedBackservice service = AmlFeedBackservice.getInstance();
        String savePath = service.getParentDir("FEEDBACK", "AML");

        File file = null;
        if (savePath != null) {
            file = new File(savePath);
        }
        // 判断上传文件的保存目录是否存在
        if (!file.exists() && !file.isDirectory()) {
            System.out.println(savePath + "目录不存在，需要创建");
            file.mkdir();
        }
        // 消息提示
        String message = "";
        InputStream in = null;
        FileOutputStream out = null;
        try {
            DiskFileItemFactory factory = new DiskFileItemFactory();
            ServletFileUpload upload = new ServletFileUpload(factory);
            upload.setHeaderEncoding("UTF-8");
            if (!ServletFileUpload.isMultipartContent(request)) {
                return null;
            }
            List<FileItem> list = upload.parseRequest(request);
            ROOTDAO root = ROOTDAOUtils.getROOTDAO();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            Amlupload bean = new Amlupload();
            for (FileItem item : list) {
                String value = null;
                String filename = null;
                bean.setId(ReportUtils.getUUID());
                if (item.isFormField()) {
                    String name = item.getFieldName();
                    value = item.getString("UTF-8");
                    System.out.println(name + "=" + value);
                    bean.setReportid(value.replaceAll("'", ""));
                } else {
                    // 得到上传的文件名称，
                    filename = item.getName();
                    System.out.println(filename);
                    if (filename == null || filename.trim().equals("")) {
                        continue;
                    }
                    // 从文件路径中截取文件名称
                    filename = filename.substring(filename.lastIndexOf(File.separator) + 1);
                    // 如果系统为Linux系统，但文件在windows系统上导致无法从文件路径中截取到文件名称 20161008
                    if (filename.indexOf("/") > 0 || filename.indexOf("\\") > 0) {
                        filename = filename.substring(filename.lastIndexOf("\\") + 1);
                    }
                    // 获取item中的上传文件的输入流
                    in = item.getInputStream();
                    // 创建一个文件输出流
                    out = new FileOutputStream(savePath + filename);
                    // 创建一个缓冲区
                    byte buffer[] = new byte[1024];
                    // 判断输入流中的数据是否已经读完的标识
                    int len = 0;
                    while ((len = in.read(buffer)) > 0) {
                        out.write(buffer, 0, len);
                    }
                    // 读取导入的文件
                    readReceiptFile(filename, savePath);
                    // 删除处理文件上传时生成的临时文件
                    item.delete();
                    bean.setUploadtlr(globalInfo.getTlrno());
                    bean.setUploadname(savePath + filename);
                    bean.setUploadtm(sdf.format(new Date()));
                }
            }
            root.saveOrUpdate(bean);
        } catch (Exception e) {
            message = e.getMessage();
            errorList.add(message);
            e.printStackTrace();
        } finally {
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
        }
        return modelAndView;
    }

    public void readReceiptFile(String filename, String savepath) throws CommonException {
        String reportType = filename.substring(0, 3);
        if (AMLConstants.REPORT_XMLTYPE_BH_A.equals(reportType)) {

        } else if (AMLConstants.REPORT_XMLTYPE_BS_A.equals(reportType)) {

        } else if (AMLConstants.REPORT_XMLTYPE_BS_S.equals(reportType)) {

        }

    }

    public String getCellStringValue(Cell cell) {
        String cellValue = "@N";

        if (cell != null) {
            switch (cell.getCellType()) {
            case HSSFCell.CELL_TYPE_STRING:// 字符串类型
                cellValue = cell.getStringCellValue();
                if (cellValue.trim().equals("") || cellValue.trim().length() <= 0)
                    cellValue = "@N";
                break;
            case HSSFCell.CELL_TYPE_NUMERIC: // 数值类型
                if (HSSFDateUtil.isCellDateFormatted(cell)) {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                    cellValue = sdf.format(HSSFDateUtil.getJavaDate(cell.getNumericCellValue())).toString();
                } else {
                    cellValue = String.valueOf(cell.getNumericCellValue());
                }
                break;
            case HSSFCell.CELL_TYPE_FORMULA: // 公式
                cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
                cellValue = String.valueOf(cell.getNumericCellValue());
                break;
            case HSSFCell.CELL_TYPE_BLANK:
                break;
            case HSSFCell.CELL_TYPE_BOOLEAN:
                break;
            case HSSFCell.CELL_TYPE_ERROR:
                break;
            default:
                break;
            }
            return cellValue.replaceAll(String.valueOf((char)160), "");

        } else {
            return cellValue;
        }
    }

    public String getCellStringValue2(Cell cell) {
        String cellValue = "";
        if (cell != null) {
            switch (cell.getCellType()) {
            case HSSFCell.CELL_TYPE_STRING:// 字符串类型
                cellValue = cell.getStringCellValue();
                if (cellValue.trim().equals("") || cellValue.trim().length() <= 0)
                    cellValue = "";
                break;
            case HSSFCell.CELL_TYPE_NUMERIC: // 数值类型
                if (HSSFDateUtil.isCellDateFormatted(cell)) {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                    cellValue = sdf.format(HSSFDateUtil.getJavaDate(cell.getNumericCellValue())).toString();
                } else {
                    cellValue = String.valueOf(cell.getNumericCellValue());
                }
                break;
            case HSSFCell.CELL_TYPE_FORMULA: // 公式
                cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
                cellValue = String.valueOf(cell.getNumericCellValue());
                break;
            case HSSFCell.CELL_TYPE_BLANK:
                break;
            case HSSFCell.CELL_TYPE_BOOLEAN:
                break;
            case HSSFCell.CELL_TYPE_ERROR:
                break;
            default:
                break;
            }
            return cellValue;

        } else {
            return cellValue;
        }
    }

    /*public String getCellStringValue3(Cell cell) {
        String cellValue = "@N";

        if (cell != null) {
            switch (cell.getCellType()) {
            case HSSFCell.CELL_TYPE_STRING:// 字符串类型
                cellValue = cell.getStringCellValue();
                if (cellValue.trim().equals("") || cellValue.trim().length() <= 0)
                    cellValue = "@N";
                break;
            case HSSFCell.CELL_TYPE_NUMERIC: // 数值类型
                if (HSSFDateUtil.isCellDateFormatted(cell)) {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
                    cellValue = sdf.format(HSSFDateUtil.getJavaDate(cell.getNumericCellValue())).toString();
                } else {
                   cellValue = String.valueOf(cell.getNumericCellValue());
                }
                break;
            case HSSFCell.CELL_TYPE_FORMULA: // 公式
                cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
                cellValue = String.valueOf(cell.getNumericCellValue());
                break;
            case HSSFCell.CELL_TYPE_BLANK:
                break;
            case HSSFCell.CELL_TYPE_BOOLEAN:
                break;
            case HSSFCell.CELL_TYPE_ERROR:
                break;
            default:
                break;
            }
            return cellValue.replaceAll(String.valueOf((char)160), "");

        } else {
            return cellValue;
        }
    }*/
    
    public static String getCellStringValue3(Cell cell) {
		String cellValue = "@N";
		if (cell != null) {
			switch (cell.getCellType()) {
			case HSSFCell.CELL_TYPE_STRING:// 字符串类型
				cellValue = cell.getStringCellValue();
				if (cellValue.trim().equals("") || cellValue.trim().length() <= 0)
					cellValue = "@N";
				break;
			case HSSFCell.CELL_TYPE_NUMERIC: // 数值类型
				if (HSSFDateUtil.isCellDateFormatted(cell)) {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
					cellValue = sdf.format(HSSFDateUtil.getJavaDate(cell.getNumericCellValue())).toString();
				} else {
					//这里将无论何种数字格式都识别为String 
					cell.setCellType(HSSFCell.CELL_TYPE_STRING);					
					cellValue = cell.getStringCellValue().trim();//得到值
				}
				break;
			case HSSFCell.CELL_TYPE_FORMULA: // 公式
				cell.setCellType(HSSFCell.CELL_TYPE_STRING);
				cellValue = cell.getStringCellValue().trim();//得到值
				break;
			case HSSFCell.CELL_TYPE_BLANK:
				break;
			case HSSFCell.CELL_TYPE_BOOLEAN:
				break;
			case HSSFCell.CELL_TYPE_ERROR:
				break;
			default:
				break;
			}
			return cellValue.replaceAll(String.valueOf((char) 160), "");
		} else {
			return cellValue;
		}
	}
    
    /**
	 * 判断参数的格式是否为“yyyyMMdd”格式的合法日期字符串
	 * 
	 */
	public static boolean isValidDate(String str) {
		boolean boo = true;
		if(str.length()!=8){
			return boo = false;
		}else{
			SimpleDateFormat sfm = new SimpleDateFormat("yyyyMMdd");
			try{
				Date date = sfm.parse(str);
				return boo = true;
			}catch(Exception e){
				e.printStackTrace();
				return boo = false;
			}
		}
	}
    
    /**
     * 全角字符串转换半角字符串
     * @param fullWidthStr 非空的全角字符串
     * @return 半角字符串
     */
    public static String fullWidth2halfWidth(String fullWidthStr) {
        if (null == fullWidthStr || fullWidthStr.length() <= 0) {
            return "";
        }
        char[] charArray = fullWidthStr.toCharArray();
        //对全角字符转换的char数组遍历
        for (int i = 0; i < charArray.length; ++i) {
            int charIntValue = (int) charArray[i];
            //如果符合转换关系,将对应下标之间减掉偏移量65248;如果是空格的话,直接做转换
            if (charIntValue >= 65281 && charIntValue <= 65374) {
                charArray[i] = (char) (charIntValue - 65248);
            } else if (charIntValue == 12288) {
                charArray[i] = (char) 32;
            }
        }
        return new String(charArray);
    }
    
    // 判断整行是否为空
    public static boolean isBlankRow(Row row) {
        if (row == null)
            return true;
        boolean result = true;
        for (int i = row.getFirstCellNum(); i < row.getLastCellNum(); i++) {
            Cell cell = row.getCell(i, Row.RETURN_BLANK_AS_NULL);
            String value = "";
            if (cell != null) {
                switch (cell.getCellType()) {
                case HSSFCell.CELL_TYPE_STRING:
                    value = cell.getStringCellValue();
                    break;
                case HSSFCell.CELL_TYPE_NUMERIC:
                    value = String.valueOf((int) cell.getNumericCellValue());
                    break;
                case HSSFCell.CELL_TYPE_BOOLEAN:
                    value = String.valueOf(cell.getBooleanCellValue());
                    break;
                case HSSFCell.CELL_TYPE_FORMULA:
                    value = String.valueOf(cell.getCellFormula());
                    break;
                // case Cell.CELL_TYPE_BLANK:
                // break;
                default:
                    break;
                }

                if (!value.trim().equals("")) {
                    result = false;
                    break;
                }
            }
        }

        return result;
    }

    // 计算含有 中文字符字符串的 实际长度，数据库保存中中文计3个长度
    public static double getTruelength(String str) {
        double valueLength = 0;
        // String chinese = "[\u4e00-\u9fa5]";
        String chinese = "[^\\x00-\\xff]";
        // 获取字段值的长度，如果含中文字符，则每个中文字符长度为3，否则为1
        for (int i = 0; i < str.length(); i++) {
            // 获取一个字符
            String temp = str.substring(i, i + 1);
            // 判断是否为中文字符
            if (temp.matches(chinese)) {
                // 中文字符长度为1
                valueLength += 3;
            } else {
                // 其他字符长度为0.5
                valueLength += 1;
            }
        }
        // 进位取整
        return Math.ceil(valueLength);
    }

    /**
     * 文件目录不存在则创建文件目录，带层级
     * 
     * @param path
     */
    private void mkdirIfNotExists(String path) {
        File file = new File(path);
        if (!file.exists()) {
            file.mkdirs();
        }
    }

    // 个人购汇申请信息批量导入
    public ModelAndView uploadExchangeWithinCounter(HttpServletRequest request, HttpServletResponse reponse)
            throws Exception {
        File uploadFile = null;
        String f = request.getQueryString();
        MultipartResolver resolver = new CommonsMultipartResolver(request.getSession().getServletContext());
        MultipartHttpServletRequest mrequest = resolver.resolveMultipart(request);
        String fileflag = mrequest.getParameter("fileflag");
        String workDate = mrequest.getParameter("workDate");
        HttpSession httpSession = request.getSession();
        GlobalInfo globalInfo = (GlobalInfo) httpSession.getAttribute(GlobalInfo.KEY_GLOBAL_INFO);
        GlobalInfo.setCurrentInstance(globalInfo);
        // 封装页面返回对象
        List errorList = new ArrayList();
        ModelMap mmap = new ModelMap();
        mmap.addObject("errors", errorList);
        ModelAndView modelAndView = new ModelAndView(result, mmap);

        try {
            // 验证上传的文件大小限制
            mrequest.setCharacterEncoding("UTF-8");
            MultipartFile file = mrequest.getFile("uploadFile");
            AmlFeedBackservice service = AmlFeedBackservice.getInstance();
            String path = service.getParentDir("Downoload", "AML") + "filetmp/";

            mkdirIfNotExists(path);
            // 上传文件到指定的文件夹（用时间作为文件名保存防止文件重名）
            String currentTime = DataMyUtil.getFullDateTime();
            String fullFileName = path + currentTime + ".xls";
            uploadFile = new File(fullFileName);
            file.transferTo(uploadFile);
            // 获取原上传文件名
            String originalFilename = file.getOriginalFilename();

            InputStream is = new FileInputStream(new File(fullFileName));
            List<String> error_list = new ArrayList<String>();
            ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
            HSSFWorkbook hssfWorkbook = new HSSFWorkbook(new POIFSFileSystem(is));

            ArrayList errerList = new ArrayList();
            // 全量数据规则校验标识
            HSSFSheet hssfSheet = null;
            boolean hssfSheetFlag = false;
            int beanSaveFlagIndex = 0;
            // 记录不符合导入规则的sheet名称
            String sheetName = null;
            String errMsg = "";
            List<ExchangeWithinCounter> list = new ArrayList<ExchangeWithinCounter>();
            for (int i = 0; i < hssfWorkbook.getNumberOfSheets(); i++) {
                hssfSheet = hssfWorkbook.getSheetAt(i);
                hssfSheetFlag = true;
                for (int rowNum = 1; rowNum <= hssfSheet.getLastRowNum(); rowNum++) {
                    ExchangeWithinCounter bean = new ExchangeWithinCounter();
                    HSSFRow hssfRow = hssfSheet.getRow(rowNum); // 从第二行开始读取
                    // 购汇人姓名
                    String fenm = getCellStringValue2(hssfRow.getCell(0)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(0));
                    if (getTruelength(fenm) > 120) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "购汇人姓名过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setFenm(fenm);

                    // 购汇人身份证件号码
                    String feid = getCellStringValue2(hssfRow.getCell(1)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(1));
                    if (getTruelength(feid) > 30) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "购汇人身份证件号码过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setFeid(feid);

                    // 购汇币种
                    String fecr = getCellStringValue2(hssfRow.getCell(2)) == null ? "" : getCellStringValue2(
                            hssfRow.getCell(2)).split("-")[0].trim();
                    if (getTruelength(fecr) > 10) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "购汇币种过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setFecr(fecr);

                    // 购汇金额
                    String feam = getCellStringValue2(hssfRow.getCell(3)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(3));
                    try {
                        if (getTruelength(feam) > 18) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "购汇金额过长";
                            errerList.add(errMsg);
                            break;
                        } else if (!feam.equals("")) {
                            bean.setFeam(new BigDecimal(feam));
                        }
                    } catch (Exception e) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errerList.add("请检查购汇金额格式是否正确，正确的金额只允许出现0-9的数字");
                        errerList.add(errMsg);
                        break;
                    }

                    // 人民币账号
                    String rmac = getCellStringValue2(hssfRow.getCell(4)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(4));
                    if (getTruelength(rmac) > 20) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "人民币账号过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setRmac(rmac);

                    // 外汇账号
                    String feac = getCellStringValue2(hssfRow.getCell(5)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(5));
                    if (getTruelength(feac) > 20) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "外汇账号过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setFeac(feac);

                    // 代理人姓名
                    String agnm = getCellStringValue2(hssfRow.getCell(6)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(6));
                    if (getTruelength(agnm) > 120) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "代理人姓名过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setAgnm(agnm);

                    // 代理人身份证件号码
                    String agid = getCellStringValue2(hssfRow.getCell(7)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(7));
                    if (getTruelength(agid) > 50) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "代理人身份证件号码过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setAgid(agid);

                    // 预计用汇时间
                    String ettm = getCellStringValue2(hssfRow.getCell(8)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(8));
                    if (getTruelength(ettm) > 20) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "预计用汇时间过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setEttm(ettm);

                    // 因私旅游
                    String prtr = getCellStringValue2(hssfRow.getCell(9)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(9));
                    if (prtr.equals("Y") || prtr.equals("true")) {
                        bean.setPrtr("true");
                    } else if (prtr.equals("N") || prtr.equals("false")) {
                        bean.setPrtr("false");
                    }

                    // 因私旅游-预计境外停留时限
                    String pttm = getCellStringValue2(hssfRow.getCell(10)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(10));
                    if (getTruelength(pttm) > 20) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "因私旅游-预计境外停留时限过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setPttm(pttm);

                    // 因私旅游-目的地国家或地区
                    String ptds = getCellStringValue2(hssfRow.getCell(11)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(11));
                    if (getTruelength(ptds) > 200) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "因私旅游-目的地国家或地区过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setPtds(ptds);

                    // 因私旅游-旅行方式
                    String pttp = getCellStringValue2(hssfRow.getCell(12)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(12)).split("-")[0].trim();
                    if (getTruelength(pttp) > 2) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "因私旅游-旅行方式过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setPttp(pttp);

                    // 境外留学
                    String stab = getCellStringValue2(hssfRow.getCell(13)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(13));
                    if (stab.equals("Y") || stab.equals("true")) {
                        bean.setStab("true");
                    } else if (stab.equals("N") || stab.equals("false")) {
                        bean.setStab("false");
                    }

                    // 境外留学-学校名称
                    String sasn = getCellStringValue2(hssfRow.getCell(14)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(14));
                    if (getTruelength(sasn) > 500) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "境外留学-学校名称过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setSasn(sasn);

                    // 境外留学-留学国家或地区
                    String sacn = getCellStringValue2(hssfRow.getCell(15)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(15));
                    if (getTruelength(sacn) > 200) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "境外留学-留学国家或地区过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setSacn(sacn);

                    // 境外留学-年学费币种
                    String satc = getCellStringValue2(hssfRow.getCell(16)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(16)).split("-")[0].trim();
                    if (getTruelength(satc) > 10) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "境外留学-年学费币种过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setSatc(satc);

                    // 境外留学-年学费金额
                    String sata = getCellStringValue2(hssfRow.getCell(17)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(17));
                    try {
                        if (getTruelength(sata) > 18) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "境外留学-年学费金额过长";
                            errerList.add(errMsg);
                            break;
                        } else if (!sata.equals("")) {
                            bean.setSata(new BigDecimal(sata));
                        }
                    } catch (Exception e) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errerList.add("请检查境外留学-年学费金额格式是否正确，正确的金额只允许出现0-9的数字");
                        errerList.add(errMsg);
                        break;
                    }

                    // 境外留学-年生活费币种
                    String salc = getCellStringValue2(hssfRow.getCell(18)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(18)).split("-")[0].trim();
                    if (getTruelength(salc) > 10) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "境外留学-年生活费币种过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setSalc(salc);

                    // 境外留学-年生活费金额
                    String sala = getCellStringValue2(hssfRow.getCell(19)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(19));
                    try {
                        if (getTruelength(sala) > 18) {
                            sheetName = hssfSheet.getSheetName();
                            beanSaveFlagIndex = rowNum + 1;
                            errMsg = "境外留学-年生活费金额过长";
                            errerList.add(errMsg);
                            break;
                        } else if (!sala.equals("")) {
                            bean.setSala(new BigDecimal(sala));
                        }
                    } catch (Exception e) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errerList.add("请检查境外留学-年生活费金额格式是否正确，正确的金额只允许出现0-9的数字");
                        errerList.add(errMsg);
                        break;
                    }

                    // 公务及商务出国
                    String bsab = getCellStringValue2(hssfRow.getCell(20)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(20));
                    if (bsab.equals("Y") || bsab.equals("true")) {
                        bean.setBsab("true");
                    } else if (bsab.equals("N") || bsab.equals("false")) {
                        bean.setBsab("false");
                    }

                    // 公务及商务出国-预计境外停留时限
                    String batm = getCellStringValue2(hssfRow.getCell(21)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(21));
                    if (getTruelength(batm) > 20) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "公务及商务出国-预计境外停留时限过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setBatm(batm);

                    // 公务及商务出国-目的地国家或地区
                    String bads = getCellStringValue2(hssfRow.getCell(22)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(22));
                    if (getTruelength(bads) > 200) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "公务及商务出国-预计境外停留时限过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setBads(bads);

                    // 探亲
                    String vsfm = getCellStringValue2(hssfRow.getCell(23)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(23));
                    if (vsfm.equals("Y") || vsfm.equals("true")) {
                        bean.setVsfm("true");
                    } else if (vsfm.equals("N") || vsfm.equals("false")) {
                        bean.setVsfm("false");
                    }

                    // 探亲-预计境外停留时限
                    String vftm = getCellStringValue2(hssfRow.getCell(24)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(24));
                    if (getTruelength(vftm) > 20) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "探亲-预计境外停留时限过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setVftm(vftm);

                    // 探亲-目的地国家或地区
                    String vfds = getCellStringValue2(hssfRow.getCell(25)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(25));
                    if (getTruelength(vfds) > 200) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "探亲-目的地国家或地区过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setVfds(vfds);

                    // 探亲-境外亲属姓名
                    String vfnm = getCellStringValue2(hssfRow.getCell(26)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(26));
                    if (getTruelength(vfnm) > 120) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "探亲-境外亲属姓名过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setVfnm(vfnm);

                    // 探亲-与境外亲属关系
                    String vfrl = getCellStringValue2(hssfRow.getCell(27)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(27));
                    if (getTruelength(vfrl) > 100) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "探亲-与境外亲属关系过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setVfrl(vfrl);

                    // 境外就医
                    String ovmd = getCellStringValue2(hssfRow.getCell(28)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(28));
                    if (ovmd.equals("Y") || ovmd.equals("true")) {
                        bean.setOvmd("true");
                    } else if (ovmd.equals("N") || ovmd.equals("false")) {
                        bean.setOvmd("false");
                    }

                    // 境外就医-预计境外停留时限
                    String omtm = getCellStringValue2(hssfRow.getCell(29)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(29));
                    if (getTruelength(omtm) > 20) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "境外就医-预计境外停留时限过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setOmtm(omtm);

                    // 境外就医-目的地国家或地区
                    String omds = getCellStringValue2(hssfRow.getCell(30)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(30));
                    if (getTruelength(omds) > 120) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "境外就医-目的地国家或地区过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setOmds(omds);

                    // 境外就医-境外医院名称
                    String omhn = getCellStringValue2(hssfRow.getCell(31)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(31));
                    if (getTruelength(omhn) > 500) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "境外就医-境外医院名称过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setOmhn(omhn);

                    // 货物贸易
                    String gdtr = getCellStringValue2(hssfRow.getCell(32)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(32));
                    if (gdtr.equals("Y") || gdtr.equals("true")) {
                        bean.setGdtr("true");
                    } else if (gdtr.equals("N") || gdtr.equals("false")) {
                        bean.setGdtr("false");
                    }

                    // 货物贸易-交易对方名称
                    String gtnm = getCellStringValue2(hssfRow.getCell(33)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(33));
                    if (getTruelength(gtnm) > 500) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "货物贸易-交易对方名称过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setGtnm(gtnm);

                    // 货物贸易-目的地国家或地区
                    String gtds = getCellStringValue2(hssfRow.getCell(34)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(34));
                    if (getTruelength(gtds) > 120) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "货物贸易-目的地国家或地区过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setGtds(gtds);

                    // 非投资类保险
                    String niin = getCellStringValue2(hssfRow.getCell(35)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(35));
                    if (niin.equals("Y") || niin.equals("true")) {
                        bean.setNiin("true");
                    } else if (niin.equals("N") || niin.equals("false")) {
                        bean.setNiin("false");
                    }

                    // 非投资类保险-保险机构名称
                    String ninm = getCellStringValue2(hssfRow.getCell(36)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(36));
                    if (getTruelength(ninm) > 500) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "非投资类保险-保险机构名称过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setNinm(ninm);

                    // 非投资类保险-目的地国家或地区
                    String nids = getCellStringValue2(hssfRow.getCell(37)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(37));
                    if (getTruelength(nids) > 120) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "非投资类保险-目的地国家或地区过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setNids(nids);

                    // 咨询服务
                    String cssv = getCellStringValue2(hssfRow.getCell(38)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(38));
                    if (cssv.equals("Y") || cssv.equals("true")) {
                        bean.setCssv("true");
                    } else if (cssv.equals("N") || cssv.equals("false")) {
                        bean.setCssv("false");
                    }

                    // 咨询服务-提供咨询方名称
                    String csnm = getCellStringValue2(hssfRow.getCell(39)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(39));
                    if (getTruelength(csnm) > 500) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "咨询服务-提供咨询方名称过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setCsnm(csnm);

                    // 咨询服务-目的地国家或地区
                    String csds = getCellStringValue2(hssfRow.getCell(40)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(40));
                    if (getTruelength(csds) > 120) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "咨询服务-目的地国家或地区过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setCsds(csds);

                    // 其他
                    String othr = getCellStringValue2(hssfRow.getCell(41)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(41));
                    if (othr.equals("Y") || othr.equals("true")) {
                        bean.setOthr("true");
                    } else if (othr.equals("N") || othr.equals("false")) {
                        bean.setOthr("false");
                    }

                    // 其他-详细说明购汇事项
                    String otdt = getCellStringValue2(hssfRow.getCell(42)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(42));
                    if (getTruelength(otdt) > 120) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "其他-详细说明购汇事项过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setOtdt(otdt);

                    // 购汇操作日期
                    String fetm = getCellStringValue2(hssfRow.getCell(43)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(43));
                    if (getTruelength(fetm) > 20) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "购汇操作日期过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setFetm(fetm);

                    // 购汇办理人
                    String opid = getCellStringValue2(hssfRow.getCell(44)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(44));
                    if (getTruelength(opid) > 20) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "购汇办理人过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setOpid(opid);

                    // 办理时间
                    String optm = getCellStringValue2(hssfRow.getCell(45)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(45));
                    try {
                        if (!optm.equals("")) {
                            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
                            bean.setOptm(sdf.parse(optm));
                        }
                    } catch (Exception e) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errerList.add("请检查办理时间格式是否正确，正确的时间格式为yyyyMMdd HH:mm:ss");
                        errerList.add(errMsg);
                        break;
                    }

                    // 办理网点
                    String opbb = getCellStringValue2(hssfRow.getCell(46)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(46));
                    if (getTruelength(opbb) > 100) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "办理网点过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setOpbb(opbb);

                    // 交易渠道
                    String trch = getCellStringValue2(hssfRow.getCell(47)) == null ? ""
                            : getCellStringValue2(hssfRow.getCell(47)).split("-")[0].trim();
                    if (getTruelength(trch) > 100) {
                        sheetName = hssfSheet.getSheetName();
                        beanSaveFlagIndex = rowNum + 1;
                        errMsg = "交易渠道过长";
                        errerList.add(errMsg);
                        break;
                    }
                    bean.setTrch(trch);

                    bean.setMdid(GlobalInfo.getCurrentInstance().getTlrno());// 修改人
                    bean.setMdtm(new Date());// 修改时间(YYYYMMDD HH:MS:SS)
                    bean.setStat("01");// 状态（01-正常，02-删除）
                    list.add(bean);
                }
            }

            if (errerList.size() > 0) {
                list.clear();
                throw new Exception("sheet[" + sheetName + "]第" + beanSaveFlagIndex + "行数据错误！错误原因："
                        + errerList.get(0));
            } else {
                for (ExchangeWithinCounter bean : list) {
                    if (bean != null) {
                        rootdao.save(bean);
                    }
                }
            }
            if (!hssfSheetFlag) {
                throw new Exception("没有可用的Sheet，请确认文件是否正确");
            }
            hssfWorkbook.close();
            is.close();
            HsbcAmlBizLogUtils.setLogToBizLog(globalInfo, "Updater.log",
                    new String[] { globalInfo.getTlrno(), globalInfo.getBrno(),
                            "个人购汇申请批量导入，文件名称【" + originalFilename + "】" }, "个人购汇申请批量导入");
        } catch (Exception e) {
            e.printStackTrace();
            errorList.add("系统内部出错，错误信息：" + e.toString());
        } finally {
            if (uploadFile != null) {
                uploadFile.delete();
            }
        }
        return modelAndView;
    }

    //汇丰中国员工交易检测上传---zgl
    @SuppressWarnings({ "unchecked", "rawtypes", "deprecation" })
	public ModelAndView uploadAStaffAcctTrad(HttpServletRequest request, HttpServletResponse reponse)
            throws Exception {
        File uploadFile = null;
        MultipartResolver resolver = new CommonsMultipartResolver(request.getSession().getServletContext());
        MultipartHttpServletRequest mrequest = resolver.resolveMultipart(request);
        String fileflag = mrequest.getParameter("fileflag");//获取入口信息-日报or月报
        
        HttpSession httpSession = request.getSession();
        GlobalInfo globalInfo = (GlobalInfo) httpSession.getAttribute(GlobalInfo.KEY_GLOBAL_INFO);
        GlobalInfo.setCurrentInstance(globalInfo);
        // 封装页面返回对象
        List errorList = new ArrayList();
        ModelMap mmap = new ModelMap();
        mmap.addObject("errors", errorList);
        ModelAndView modelAndView = new ModelAndView(result, mmap);
        try {
            // 验证上传的文件大小限制
            mrequest.setCharacterEncoding("UTF-8");
            MultipartFile file = mrequest.getFile("uploadFile");
            AmlFeedBackservice service = AmlFeedBackservice.getInstance();
            String path = service.getParentDir("Downoload", "AML") + "filetmp/";

            mkdirIfNotExists(path);
            //上传文件到指定的文件夹（用时间作为文件名保存防止文件重名）
            String currentTime = DataMyUtil.getFullDateTime();
            String fullFileName = path + currentTime + ".xls";
            uploadFile = new File(fullFileName);
            file.transferTo(uploadFile);
            //获取原上传文件名
            String originalFilename = file.getOriginalFilename();
            if("AStaffAcctTrad".equals(fileflag)) {//日报入口
            	if(originalFilename.indexOf("员工交易监测调研日报")>-1){
            		importAStaffAcctTrad(fileflag, originalFilename, fullFileName, globalInfo, currentTime);
            		HsbcAmlBizLogUtils.setLogToBizLog(globalInfo, "Updater.log",new String[]{globalInfo.getTlrno(), 
            				globalInfo.getBrno(),"员工交易监测调研日报导入-工作日期【" + currentTime.substring(0,8) + 
            				"】 文件名称【" + originalFilename + "】" }, "员工交易监测调研日报导入");
                }else{
                	throw new Exception("此入口只能导入\"员工交易监测调研日报\"，请检查！");
                }
            }else if("AStaffAcctTradM".equals(fileflag)){//月报入口
            	if(originalFilename.indexOf("员工交易监测调研月报")>-1){
            		importAStaffAcctTrad(fileflag, originalFilename, fullFileName, globalInfo, currentTime);
                    HsbcAmlBizLogUtils.setLogToBizLog(globalInfo, "Updater.log",new String[]{globalInfo.getTlrno(),
                    		globalInfo.getBrno(),"员工交易监测调研月报导入-工作日期【" + currentTime.substring(0,8) +
                    		"】 文件名称【" + originalFilename + "】" }, "员工交易监测调研月报导入");
                }else{
                	throw new Exception("此入口只能导入\"员工交易监测调研月报\"，请检查！");
                }
            }
        }catch(Exception e){
            e.printStackTrace();
            errorList.add("系统内部出错，错误信息：" + e.toString());
        }finally{
            if(uploadFile != null){
                uploadFile.delete();
            }
        }
        return modelAndView;
    }
    
    //员工交易监测调研信息上传
    public void importAStaffAcctTrad(String fileflag, String originalFilename, String fullFileName, GlobalInfo globalInfo, String currentTime) throws Exception{
        SimpleDateFormat sdfHMS = new SimpleDateFormat("yyyyMMdd hh:mm:ss");
        SimpleDateFormat sdfs = new SimpleDateFormat("yyyyMMdd");
        System.out.println("====================================================================");
        if("AStaffAcctTrad".equals(fileflag)){
        	System.out.println("===========HBCN员工交易监测日报调研信息上传时间:" + sdfHMS.format(new Date()) + "===========");
        }else{
        	System.out.println("===========HBCN员工交易监测月报调研信息上传时间:" + sdfHMS.format(new Date()) + "===========");
        }
        System.out.println("===========导入文件名称：" + originalFilename + "=============================");
        System.out.println("====================================================================");
        InputStream is = new FileInputStream(new File(fullFileName));
        String tlrNo = GlobalInfo.getCurrentInstance().getTlrno();
        List<String> err_list = new ArrayList<String>();
        int error_row = 0;
        String errmsg = null;
        Workbook wb = null;
        if(originalFilename.endsWith("xlsx")){// 根据导入文件名称判断读取03还是10版excel
            try{
				wb = new XSSFWorkbook(is);
			}catch(IOException e) {
				e.printStackTrace();
			}
        }else{
            try{
				wb = new HSSFWorkbook(is);
			}catch(IOException e) {
				e.printStackTrace();
			}
        }
        Sheet sheet = null;
        ArrayList<AStaffAcctTrad> beanlist = null;
        ArrayList<AStaffAcctTradM> beanlistM = null;
        ROOTDAO rootDao = ROOTDAOUtils.getROOTDAO();
        if("AStaffAcctTrad".equals(fileflag)) {//日报入口
        	beanlist = new ArrayList<AStaffAcctTrad>();
        	for(int i = 0; i < wb.getNumberOfSheets(); i++){
            	sheet = wb.getSheetAt(i);
            	if("日报客户信息".equals(sheet.getSheetName())){  
            		AStaffAcctTrad beanOld = null;//数据库数据
            		String alertId = null;//告警号
                    String staffNumber = null;//员工编号
                    String approveStatus = null;//记录状态
                    String recordUpdTlr = null;//记录修改人
                    String checkDate = null;//初步调查日期
                    String investigator = null;//调查者
                    String status = null;//调查阶段
                    String managerName = null;//直线经理姓名
                    String invesResultByOps = null;//初步调查结论(by OPS)
                    String caseId = null;//上报案件编号
                    String reportDate = null;//上报日期
                    String potentialCaseType = null;//(初步调查)上报的可疑类型
                    String feedbackDate = null;//收到反馈时间
                    String concludedType = null;//(收到反馈)判定的可疑类型
                    String feedbackFrom = null;//反馈结果(从FCTM或者GB/GF指定部门)
                    String comfirmedSusp = null;//是否判定可疑(及由哪方判定)
                    //String alterUar = null;//反馈案件编号
                    for(int rowNum = 1;rowNum <= sheet.getLastRowNum();rowNum++){
                        if(!isBlankRow(sheet.getRow(rowNum))){
                    		Row row = sheet.getRow(rowNum);   
                            error_row = rowNum + 1;
                            //告警号
                            alertId = DataFormat.isEmpty(getCellStringValue3(row.getCell(1))) == true ? "" : getCellStringValue3(row.getCell(1)).trim();//第二列开始
                            if(alertId.length() > 40){
                            	errmsg = "\"告警号\"的长度不能超过40！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            if("@N".equals(alertId) || "".equals(alertId)){
                            	errmsg = "\"告警号\"字段不能为空！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            //查询告警号对应的记录
                            ArrayList<String> condList = new ArrayList<String>();
            				condList.add(alertId);
                            List<AStaffAcctTrad> taskList = rootDao.queryByCondition("from AStaffAcctTrad where 1=1 and alertId = ?", condList.toArray());
                            //判断数据库是否存在对应的记录
                            if(taskList.isEmpty()){
                            	errmsg = "\"告警号\"为" + alertId + "的记录不存在！";
                            	err_list.add(errmsg);
                            	break;
                            }
                            beanOld = taskList.get(0);
                            //获取数据的员工编号是否为空
                            //员工编号
                            staffNumber = DataFormat.isEmpty(beanOld.getStaffNumber()) == true ? "":beanOld.getStaffNumber();
                            if("".equals(staffNumber)){
                            	continue;
    						}
                            
                            //记录修改人
                            recordUpdTlr = DataFormat.isEmpty(beanOld.getRecordUpdTlr()) == true ? "":beanOld.getRecordUpdTlr();
                            if("".equals(recordUpdTlr)){
                            	errmsg = "\"记录修改人\"不存在，您操作错误！";
                            	err_list.add(errmsg);
                            	break;
                            }
                            if(!tlrNo.equals(recordUpdTlr)){
                            	errmsg = "\"记录修改人\"与\"当前用户\"匹配不成功！";
                            	err_list.add(errmsg);
                            	break;
                            }

                            //初步调查日期
                            checkDate = DataFormat.isEmpty(beanOld.getCheckDate()) == true ? "":beanOld.getCheckDate();
                            if("".equals(checkDate)){
                            	checkDate = currentTime.substring(0,8);
                            }
                            beanOld.setCheckDate(checkDate);
                            
                            //调查者
                            investigator = DataFormat.isEmpty(beanOld.getInvestigator()) == true ? "":beanOld.getInvestigator();
                            if("".equals(investigator)){
                            	investigator = recordUpdTlr;
                            }else{
                            	if(investigator.indexOf(recordUpdTlr) == -1){
            						investigator = investigator + "," + recordUpdTlr;
            					}
                            }
                            beanOld.setInvestigator(investigator);		
                            
                            //调查阶段
                            status = DataFormat.isEmpty(getCellStringValue3(row.getCell(17))) == true ? "" : getCellStringValue3(row.getCell(17)).split("\\-")[0].trim();
                            if("@N".equals(status)){
                            	status = "";
                            }
                            if("".equals(status)){
                            	errmsg = "\"调查阶段\"不可为空！";
                            	err_list.add(errmsg);
                            	break;
                            }
                            beanOld.setStatus(status);
                            
                            //直线经理姓名
                            managerName = DataFormat.isEmpty(getCellStringValue3(row.getCell(18))) == true ? "" : getCellStringValue3(row.getCell(18)).trim();
                            if(managerName.length() > 100){
                            	errmsg = "\"直线经理姓名\"的长度不能超过100！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            if("@N".equals(managerName)){
                            	managerName = "";
                            }
                            beanOld.setManagerName(managerName);
                            
                            //初步调查结论(by OPS)
                            invesResultByOps = DataFormat.isEmpty(getCellStringValue3(row.getCell(19))) == true ? "" : getCellStringValue3(row.getCell(19)).trim();
                            if(invesResultByOps.length() > 4000){
                            	errmsg = "\"初步调查结论(by OPS)\"的长度不能超过4000！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            if("@N".equals(invesResultByOps)){
                            	invesResultByOps = "";
                            }
                            if("".equals(invesResultByOps)){
                            	errmsg = "\"初步调查结论(by OPS)\"不可为空！";
                            	err_list.add(errmsg);
                            	break;
                            }
                            beanOld.setInvesResultByOps(invesResultByOps);
                            
                            //上报案件编号
                            caseId = DataFormat.isEmpty(getCellStringValue3(row.getCell(20))) == true ? "" : getCellStringValue3(row.getCell(20)).trim();
                            if(caseId.length() > 4000){
                            	errmsg = "\"上报案件编号\"的长度不能超过4000！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            if("@N".equals(caseId)){
                            	caseId = "";
                            }
                            beanOld.setCaseId(caseId);
                            
                            //上报日期
                            reportDate = DataFormat.isEmpty(getCellStringValue3(row.getCell(21))) == true ? "" : getCellStringValue3(row.getCell(21)).trim();
                            if("@N".equals(reportDate)){
                            	reportDate = "";
                            }else{
                            	if(!isValidDate(reportDate)){
                                	errmsg = "\"上报日期\"格式错误，正确格式为\"年年年年月月日日\"，请确认单元格格式与模板格式一致！";
                                	err_list.add(errmsg);
                                    break;
                                }
                            }
                            beanOld.setReportDate(reportDate);
                            
                            //(初步调查)上报的可疑类型
                            potentialCaseType = DataFormat.isEmpty(getCellStringValue3(row.getCell(22))) == true ? "" : getCellStringValue3(row.getCell(22)).split("\\-")[0].trim();
                            if("@N".equals(potentialCaseType)){
                            	potentialCaseType = "";
                            }
                            beanOld.setPotentialCaseType(potentialCaseType);
                            
                            //收到反馈时间
                            feedbackDate = DataFormat.isEmpty(getCellStringValue3(row.getCell(23))) == true ? "" : getCellStringValue3(row.getCell(23)).trim();
                            if("@N".equals(feedbackDate)){
                            	feedbackDate = "";
                            }else{
                            	if(!isValidDate(feedbackDate)){
                                	errmsg = "\"收到反馈时间\"格式错误，正确格式为\"年年年年月月日日\"，请确认单元格格式与模板格式一致！";
                                	err_list.add(errmsg);
                                	break;
        						}
                            }
                            beanOld.setFeedbackDate(feedbackDate);
                            
                            //(收到反馈)判定的可疑类型
                            concludedType = DataFormat.isEmpty(getCellStringValue3(row.getCell(24))) == true ? "" : getCellStringValue3(row.getCell(24)).split("\\-")[0].trim();
                            if("@N".equals(concludedType)){
                            	concludedType = "";
                            }
                            beanOld.setConcludedType(concludedType);
                            
                            //反馈结果(从FCTM或者GB/GF指定部门)
                            feedbackFrom = DataFormat.isEmpty(getCellStringValue3(row.getCell(25))) == true ? "" : getCellStringValue3(row.getCell(25)).trim();
                            if(feedbackFrom.length() > 4000){
                            	errmsg = "\"反馈结果(从FCTM或者GB/GF指定部门)\"的长度不能超过4000！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            if("@N".equals(feedbackFrom)){
                            	feedbackFrom = "";
                            }
                            beanOld.setFeedbackFrom(feedbackFrom);
                            
                            //是否判定可疑(及由哪方判定)
                            comfirmedSusp = DataFormat.isEmpty(getCellStringValue3(row.getCell(26))) == true ? "" : getCellStringValue3(row.getCell(26)).split("\\-")[0].trim();
                            if("@N".equals(comfirmedSusp)){
                            	comfirmedSusp = "";
                            }
                            beanOld.setComfirmedSusp(comfirmedSusp);
                            
                            //记录状态
                            approveStatus = DataFormat.isEmpty(beanOld.getApproveStatus()) == true ? "":beanOld.getApproveStatus();
                            //记录状态为"02"、"05"不用修改记录状态
                            if("00".equals(approveStatus)){
                            	errmsg = "记录状态不能为\"00-未处理\"，您操作错误！";
                            	err_list.add(errmsg);
                            	break;
                            }if("03".equals(approveStatus)){
                            	continue;
                            }else if("01".equals(approveStatus)){//01-已下载
                            	approveStatus = "02";//02-已调研
                            }else if("04".equals(approveStatus)){//04-审核失败，重新调研
                            	approveStatus = "05";//05-自查已调研
                            }
                            beanOld.setApproveStatus(approveStatus);
                            
                            //初步调查日期必须早于或等于上报日期
            				if(!"".equals(reportDate)){
            					Long checkDateTime = sdfs.parse(checkDate).getTime();//初步调查日期
            					Long reportDateTime = sdfs.parse(reportDate).getTime();//上报日期
            					if(checkDateTime > reportDateTime){
            						errmsg = "初步调查日期必须早于或等于上报日期！";
                                	err_list.add(errmsg);
                                	break;
            					}
            				}
                            
            				//收到反馈时间不早于上报日期，且不能晚于当前系统时间
            				if(!"".equals(feedbackDate)){
            					if("".equals(reportDate)){
            						errmsg = "收到反馈时间有值时，上报日期不可为空！";
            						err_list.add(errmsg);
                                	break;
            					}
            					Long feedbackDateTime = sdfs.parse(feedbackDate).getTime();//收到反馈时间
            					Long reportDateTime = sdfs.parse(reportDate).getTime();//上报日期
            					Long dateTimes = sdfs.parse(currentTime.substring(0,8)).getTime();//系统时间
            					//收到反馈时间不早于上报日期
            					if(reportDateTime > feedbackDateTime){
            						errmsg = "收到反馈时间不早于上报日期！";
            						err_list.add(errmsg);
                                	break;
            					}
            					//收到反馈时间不能晚于当前系统时间
            					if(feedbackDateTime > dateTimes){
            						errmsg = "收到反馈时间不能晚于当前系统时间！";
            						err_list.add(errmsg);
                                	break;
            					}
            				}
            				
            				//(初步调查)上报的可疑类型与上报日期需要同时为空或者同时有值
            				if(!"".equals(reportDate) && "".equals(potentialCaseType)){
            					errmsg = "上报日期与(初步调查)上报的可疑类型需要同时为空或者同时有值！";
            					err_list.add(errmsg);
                                break;
            				}else if("".equals(reportDate) && !"".equals(potentialCaseType)){
            					errmsg = "上报日期与(初步调查)上报的可疑类型需要同时为空或者同时有值！";
            					err_list.add(errmsg);
                                break;
            				}
            				
            				//收到反馈时间,反馈结果(从FCTM或者GB/GF指定部门),是否判定可疑(及由哪方判定)三者同时为空或同时有值
            				boolean flag = false;
            				if("".equals(feedbackDate) && "".equals(feedbackFrom) && "".equals(comfirmedSusp)){
            					flag = true;
            				}
            				if(!"".equals(feedbackDate) && !"".equals(feedbackFrom) && !"".equals(comfirmedSusp)){
            					flag = true;
            				}
            				if(!flag){
            					errmsg = "收到反馈时间,反馈结果(从FCTM或者GB/GF指定部门),是否判定可疑(及由哪方判定)三者同时为空或同时有值！";
            					err_list.add(errmsg);
                                break;
            				}
            				//记录修改时间
            				beanOld.setRecordUpdTm(currentTime.substring(0,14));
                            beanlist.add(beanOld);
                        }
                    }
            	}else{
            		if(!"日报交易信息".equals(sheet.getSheetName())){
            			ExceptionUtil.throwCommonException("员工交易监测调研日报模板错误，请检查！");
            		}
            	}
        	}
        }else{//月报入口
        	beanlistM = new ArrayList<AStaffAcctTradM>();
        	for(int i = 0; i < wb.getNumberOfSheets(); i++){
            	sheet = wb.getSheetAt(i);
            	if("月报客户信息".equals(sheet.getSheetName())){  
            		AStaffAcctTradM beanOld = null;//数据库数据
            		String alertId = null;//告警号
                    String staffNumber = null;//员工编号
                    String approveStatus = null;//记录状态
                    String recordUpdTlr = null;//记录修改人
                    String checkDate = null;//初步调查日期
                    String investigator = null;//调查者
                    String status = null;//调查阶段
                    String managerName = null;//直线经理姓名
                    String invesResultByOps = null;//初步调查结论(by OPS)
                    String caseId = null;//上报案件编号
                    String reportDate = null;//上报日期
                    String potentialCaseType = null;//(初步调查)上报的可疑类型
                    String feedbackDate = null;//收到反馈时间
                    String concludedType = null;//(收到反馈)判定的可疑类型
                    String feedbackFrom = null;//反馈结果(从FCTM或者GB/GF指定部门)
                    String comfirmedSusp = null;//是否判定可疑(及由哪方判定)
                    String updatePerson = GlobalInfo.getCurrentInstance().getTlrno();//当前操作员
                    for(int rowNum = 1;rowNum <= sheet.getLastRowNum();rowNum++){
                        if(!isBlankRow(sheet.getRow(rowNum))){
                    		Row row = sheet.getRow(rowNum);   
                            error_row = rowNum + 1;
                            //告警号
                            alertId = DataFormat.isEmpty(getCellStringValue3(row.getCell(1))) == true ? "" : getCellStringValue3(row.getCell(1)).trim();//第二列开始
                            if(alertId.length() > 40){
                            	errmsg = "\"告警号\"的长度不能超过40！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            if("@N".equals(alertId) || "".equals(alertId)){
                            	errmsg = "\"告警号\"字段不能为空！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            //查询告警号对应的记录
                            ArrayList<String> condList = new ArrayList<String>();
            				condList.add(alertId);
            				List<AStaffAcctTradM> taskList = rootDao.queryByCondition("from AStaffAcctTradM where 1=1 and alertId = ?", condList.toArray());
                            //判断数据库是否存在对应的记录
                            if(taskList.isEmpty()){
                            	errmsg = "\"告警号\"为" + alertId + "的记录不存在！";
                            	err_list.add(errmsg);
                            	break;
                            }
                            beanOld = taskList.get(0);
                            
                            //获取数据的员工编号是否为空
                            //员工编号
                            staffNumber = DataFormat.isEmpty(beanOld.getStaffNumber()) == true ? "":beanOld.getStaffNumber();
                            if("".equals(staffNumber)){
                            	continue;
    						}
                            
                            //记录修改人
                            recordUpdTlr = DataFormat.isEmpty(beanOld.getRecordUpdTlr()) == true ? "":beanOld.getRecordUpdTlr();
                            if("".equals(recordUpdTlr)){
                            	errmsg = "\"记录修改人\"不存在，您操作错误！";
                            	err_list.add(errmsg);
                            	break;
                            }
                            if(!tlrNo.equals(recordUpdTlr)){
                            	errmsg = "\"记录修改人\"与\"当前用户\"匹配不成功！";
                            	err_list.add(errmsg);
                            	break;
                            }
                            
                            //初步调查日期
                            checkDate = DataFormat.isEmpty(beanOld.getCheckDate()) == true ? "":beanOld.getCheckDate();
                            if("".equals(checkDate)){
                            	checkDate = currentTime.substring(0,8);
                            }
                            beanOld.setCheckDate(checkDate);
                            
                            //调查者
                            investigator = DataFormat.isEmpty(beanOld.getInvestigator()) == true ? "":beanOld.getInvestigator();
                            if("".equals(investigator)){
                            	investigator = recordUpdTlr;
                            }else{
                            	if(investigator.indexOf(recordUpdTlr) == -1){
            						investigator = investigator + "," + recordUpdTlr;
            					}
                            }
                            beanOld.setInvestigator(investigator);	
                            
                            //调查阶段
                            status = DataFormat.isEmpty(getCellStringValue3(row.getCell(17))) == true ? "" : getCellStringValue3(row.getCell(17)).split("\\-")[0].trim();
                            if("@N".equals(status)){
                            	status = "";
                            }
                            if("".equals(status)){
                            	errmsg = "\"调查阶段\"不可为空！";
                            	err_list.add(errmsg);
                            	break;
                            }
                            beanOld.setStatus(status);
                            
                            //直线经理姓名
                            managerName = DataFormat.isEmpty(getCellStringValue3(row.getCell(18))) == true ? "" : getCellStringValue3(row.getCell(18)).trim();
                            if(managerName.length() > 100){
                            	errmsg = "\"直线经理姓名\"的长度不能超过100！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            if("@N".equals(managerName)){
                            	managerName = "";
                            }
                            beanOld.setManagerName(managerName);
                            
                            //初步调查结论(by OPS)
                            invesResultByOps = DataFormat.isEmpty(getCellStringValue3(row.getCell(19))) == true ? "" : getCellStringValue3(row.getCell(19)).trim();
                            if(invesResultByOps.length() > 4000){
                            	errmsg = "\"初步调查结论(by OPS)\"的长度不能超过4000！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            if("@N".equals(invesResultByOps)){
                            	invesResultByOps = "";
                            }
                            if("".equals(invesResultByOps)){
                            	errmsg = "\"初步调查结论(by OPS)\"不可为空！";
                            	err_list.add(errmsg);
                            	break;
                            }
                            beanOld.setInvesResultByOps(invesResultByOps);
                            
                            //上报案件编号
                            caseId = DataFormat.isEmpty(getCellStringValue3(row.getCell(20))) == true ? "" : getCellStringValue3(row.getCell(20)).trim();
                            if(caseId.length() > 4000){
                            	errmsg = "\"上报案件编号\"的长度不能超过4000！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            if("@N".equals(caseId)){
                            	caseId = "";
                            }
                            beanOld.setCaseId(caseId);
                            
                            //上报日期
                            reportDate = DataFormat.isEmpty(getCellStringValue3(row.getCell(21))) == true ? "" : getCellStringValue3(row.getCell(21)).trim();
                            if("@N".equals(reportDate)){
                            	reportDate = "";
                            }else{
                            	if(!isValidDate(reportDate)){
                            		errmsg = "\"上报日期\"格式错误，正确格式为\"年年年年月月日日\"，请确认单元格格式与模板格式一致！";
                                	err_list.add(errmsg);
                                	break;
                            	}
                            }
                            beanOld.setReportDate(reportDate);
                            
                            //(初步调查)上报的可疑类型
                            potentialCaseType = DataFormat.isEmpty(getCellStringValue3(row.getCell(22))) == true ? "" : getCellStringValue3(row.getCell(22)).split("\\-")[0].trim();
                            if("@N".equals(potentialCaseType)){
                            	potentialCaseType = "";
                            }
                            beanOld.setPotentialCaseType(potentialCaseType);
                            
                            //收到反馈时间
                            feedbackDate = DataFormat.isEmpty(getCellStringValue3(row.getCell(23))) == true ? "" : getCellStringValue3(row.getCell(23)).trim();
                            if("@N".equals(feedbackDate)){
                            	feedbackDate = "";
                            }else{
                            	if(!isValidDate(feedbackDate)){
                            		errmsg = "\"收到反馈时间\"格式错误，正确格式为\"年年年年月月日日\"，请确认单元格格式与模板格式一致！";
                                	err_list.add(errmsg);
                                	break;
                            	}
                            }
                            beanOld.setFeedbackDate(feedbackDate);
                            
                            //(收到反馈)判定的可疑类型
                            concludedType = DataFormat.isEmpty(getCellStringValue3(row.getCell(24))) == true ? "" : getCellStringValue3(row.getCell(24)).split("\\-")[0].trim();
                            if("@N".equals(concludedType)){
                            	concludedType = "";
                            }
                            beanOld.setConcludedType(concludedType);
                            
                            //反馈结果(从FCTM或者GB/GF指定部门)
                            feedbackFrom = DataFormat.isEmpty(getCellStringValue3(row.getCell(25))) == true ? "" : getCellStringValue3(row.getCell(25)).trim();
                            if(feedbackFrom.length() > 4000){
                            	errmsg = "\"反馈结果(从FCTM或者GB/GF指定部门)\"的长度不能超过4000！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            if("@N".equals(feedbackFrom)){
                            	feedbackFrom = "";
                            }
                            beanOld.setFeedbackFrom(feedbackFrom);
                            
                            //是否判定可疑(及由哪方判定)
                            comfirmedSusp = DataFormat.isEmpty(getCellStringValue3(row.getCell(26))) == true ? "" : getCellStringValue3(row.getCell(26)).split("\\-")[0].trim();
                            if("@N".equals(comfirmedSusp)){
                            	comfirmedSusp = "";
                            }
                            beanOld.setComfirmedSusp(comfirmedSusp);
                            
                            //记录状态
                            approveStatus = DataFormat.isEmpty(beanOld.getApproveStatus()) == true ? "":beanOld.getApproveStatus().toString();
                            //记录状态为"02"、"05"不用修改记录状态
                            if("00".equals(approveStatus)){
                            	errmsg = "记录状态不能为\"00-未处理\"，您操作错误！";
                            	err_list.add(errmsg);
                            	break;
                            }if("03".equals(approveStatus)){
                            	continue;
                            }else if("01".equals(approveStatus)){//01-已下载
                            	approveStatus = "02";//02-已调研
                            }else if("04".equals(approveStatus)){//04-审核失败，重新调研
                            	approveStatus = "05";//05-自查已调研
                            }
                            beanOld.setApproveStatus(approveStatus);
                            
                            //初步调查日期必须早于或等于上报日期
            				if(!"".equals(reportDate)){
            					Long checkDateTime = sdfs.parse(checkDate).getTime();//初步调查日期
            					Long reportDateTime = sdfs.parse(reportDate).getTime();//上报日期
            					if(checkDateTime > reportDateTime){
            						errmsg = "初步调查日期必须早于或等于上报日期！";
                                	err_list.add(errmsg);
                                	break;
            					}
            				}
                            
            				//收到反馈时间不早于上报日期，且不能晚于当前系统时间
            				if(!"".equals(feedbackDate)){
            					if("".equals(reportDate)){
            						errmsg = "收到反馈时间有值时，上报日期不可为空！";
            						err_list.add(errmsg);
                                	break;
            					}
            					Long feedbackDateTime = sdfs.parse(feedbackDate).getTime();//收到反馈时间
            					Long reportDateTime = sdfs.parse(reportDate).getTime();//上报日期
            					Long dateTimes = sdfs.parse(currentTime.substring(0,8)).getTime();//系统时间
            					//收到反馈时间不早于上报日期
            					if(reportDateTime > feedbackDateTime){
            						errmsg = "收到反馈时间不早于上报日期！";
            						err_list.add(errmsg);
                                	break;
            					}
            					//收到反馈时间不能晚于当前系统时间
            					if(feedbackDateTime > dateTimes){
            						errmsg = "收到反馈时间不能晚于当前系统时间！";
            						err_list.add(errmsg);
                                	break;
            					}
            				}
            				
            				//(初步调查)上报的可疑类型与上报日期需要同时为空或者同时有值
            				if(!"".equals(reportDate) && "".equals(potentialCaseType)){
            					errmsg = "上报日期与(初步调查)上报的可疑类型需要同时为空或者同时有值！";
            					err_list.add(errmsg);
                                break;
            				}else if("".equals(reportDate) && !"".equals(potentialCaseType)){
            					errmsg = "上报日期与(初步调查)上报的可疑类型需要同时为空或者同时有值！";
            					err_list.add(errmsg);
                                break;
            				}
            				
            				//收到反馈时间,反馈结果(从FCTM或者GB/GF指定部门),是否判定可疑(及由哪方判定)三者同时为空或同时有值
            				boolean flag = false;
            				if("".equals(feedbackDate) && "".equals(feedbackFrom) && "".equals(comfirmedSusp)){
            					flag = true;
            				}
            				if(!"".equals(feedbackDate) && !"".equals(feedbackFrom) && !"".equals(comfirmedSusp)){
            					flag = true;
            				}
            				if(!flag){
            					errmsg = "收到反馈时间,反馈结果(从FCTM或者GB/GF指定部门),是否判定可疑(及由哪方判定)三者同时为空或同时有值！";
            					err_list.add(errmsg);
                                break;
            				}
            				//记录修改时间
            				beanOld.setRecordUpdTm(currentTime.substring(0,14));
                            beanlistM.add(beanOld);
                        }
                    }
            	}else{
            		if(!"月报交易信息".equals(sheet.getSheetName())){
            			ExceptionUtil.throwCommonException("员工交易监测调研月报模板错误，请检查！");
            		}
            	}
        	}
        }
        if(!err_list.isEmpty()){
        	if("AStaffAcctTrad".equals(fileflag)) {//日报入口
        		beanlist.clear();
        		throw new Exception("sheet[日报客户信息]第" + (error_row) + "行数据错误！错误原因："+ err_list.get(0));
        	}
        	if("AStaffAcctTradM".equals(fileflag)){
        		beanlistM.clear();
        		throw new Exception("sheet[月报客户信息]第" + (error_row) + "行数据错误！错误原因："+ err_list.get(0));
        	}
        }else{
        	if("AStaffAcctTrad".equals(fileflag)){
        		for(AStaffAcctTrad ast : beanlist) {
        			rootDao.update(ast);
            	}
            	beanlist.clear();
        	}else{
        		for(AStaffAcctTradM astm : beanlistM) {
        			rootDao.update(astm);//告警号
            	}
            	beanlistM.clear();
        	}
        }
        System.out.println("=========================================================================");
        if("AStaffAcctTrad".equals(fileflag)){
        	System.out.println("===========HBCN员工交易监测日报调研信息导入结束时间:" + sdfHMS.format(new Date()) + "=============");
        }else{
        	System.out.println("===========HBCN员工交易监测月报调研信息导入结束时间:" + sdfHMS.format(new Date()) + "=============");
        }
        System.out.println("=========================================================================");
    }
    
    //RRB村镇行员工交易检测上传
    @SuppressWarnings({ "unchecked", "rawtypes", "deprecation" })
	public ModelAndView uploadAStaffAcctTradRRB(HttpServletRequest request, HttpServletResponse reponse)
            throws Exception {
        File uploadFile = null;
        MultipartResolver resolver = new CommonsMultipartResolver(request.getSession().getServletContext());
        MultipartHttpServletRequest mrequest = resolver.resolveMultipart(request);
        String fileflag = mrequest.getParameter("fileflag");//获取入口信息-日报or月报
        
        HttpSession httpSession = request.getSession();
        GlobalInfo globalInfo = (GlobalInfo) httpSession.getAttribute(GlobalInfo.KEY_GLOBAL_INFO);
        GlobalInfo.setCurrentInstance(globalInfo);
        // 封装页面返回对象
        List errorList = new ArrayList();
        ModelMap mmap = new ModelMap();
        mmap.addObject("errors", errorList);
        ModelAndView modelAndView = new ModelAndView(result, mmap);
        try {
            // 验证上传的文件大小限制
            mrequest.setCharacterEncoding("UTF-8");
            MultipartFile file = mrequest.getFile("uploadFile");
            AmlFeedBackservice service = AmlFeedBackservice.getInstance();
            String path = service.getParentDir("Downoload", "AML") + "filetmp/";

            mkdirIfNotExists(path);
            //上传文件到指定的文件夹（用时间作为文件名保存防止文件重名）
            String currentTime = DataMyUtil.getFullDateTime();
            String fullFileName = path + currentTime + ".xls";
            uploadFile = new File(fullFileName);
            file.transferTo(uploadFile);
            //获取原上传文件名
            String originalFilename = file.getOriginalFilename();
            if("AStaffAcctTradRRB".equals(fileflag)) {//日报入口
            	if(originalFilename.indexOf("员工交易监测调研日报")>-1){
            		importAStaffAcctTradRRB(fileflag, originalFilename, fullFileName, globalInfo, currentTime);
            		HsbcAmlBizLogUtils.setLogToBizLog(globalInfo, "Updater.log",new String[]{globalInfo.getTlrno(), 
            				globalInfo.getBrno(),"员工交易监测调研日报导入-工作日期【" + currentTime.substring(0,8) + 
            				"】 文件名称【" + originalFilename + "】" }, "员工交易监测调研日报导入");
                }else{
                	throw new Exception("此入口只能导入\"员工交易监测调研日报\"，请检查！");
                }
            }else if("AStaffAcctTradMRRB".equals(fileflag)){//月报入口
            	if(originalFilename.indexOf("员工交易监测调研月报")>-1){
            		importAStaffAcctTradRRB(fileflag, originalFilename, fullFileName, globalInfo, currentTime);
                    HsbcAmlBizLogUtils.setLogToBizLog(globalInfo, "Updater.log",new String[]{globalInfo.getTlrno(),
                    		globalInfo.getBrno(),"员工交易监测调研月报导入-工作日期【" + currentTime.substring(0,8) +
                    		"】 文件名称【" + originalFilename + "】" }, "员工交易监测调研月报导入");
                }else{
                	throw new Exception("此入口只能导入\"员工交易监测调研月报\"，请检查！");
                }
            }
        }catch(Exception e){
            e.printStackTrace();
            errorList.add("系统内部出错，错误信息：" + e.toString());
        }finally{
            if(uploadFile != null){
                uploadFile.delete();
            }
        }
        return modelAndView;
    }
    
    //员工交易监测调研信息上传
    public void importAStaffAcctTradRRB(String fileflag, String originalFilename, String fullFileName, GlobalInfo globalInfo, String currentTime) throws Exception{
        SimpleDateFormat sdfHMS = new SimpleDateFormat("yyyyMMdd hh:mm:ss");
        SimpleDateFormat sdfs = new SimpleDateFormat("yyyyMMdd");
        System.out.println("====================================================================");
        if("AStaffAcctTradRRB".equals(fileflag)){
        	System.out.println("===========RRB员工交易监测日报调研信息上传时间:" + sdfHMS.format(new Date()) + "===========");
        }else{
        	System.out.println("===========RRB员工交易监测月报调研信息上传时间:" + sdfHMS.format(new Date()) + "===========");
        }
        System.out.println("===========导入文件名称：" + originalFilename + "=============================");
        System.out.println("====================================================================");
        InputStream is = new FileInputStream(new File(fullFileName));
        String tlrNo = GlobalInfo.getCurrentInstance().getTlrno();
        List<String> err_list = new ArrayList<String>();
        int error_row = 0;
        String errmsg = null;
        Workbook wb = null;
        if(originalFilename.endsWith("xlsx")){// 根据导入文件名称判断读取03还是10版excel
            try{
				wb = new XSSFWorkbook(is);
			}catch(IOException e) {
				e.printStackTrace();
			}
        }else{
            try{
				wb = new HSSFWorkbook(is);
			}catch(IOException e) {
				e.printStackTrace();
			}
        }
        Sheet sheet = null;
        ArrayList<AStaffAcctTradRRB> beanlistRRB = null;
        ArrayList<AStaffAcctTradMRRB> beanlistMRRB = null;
        ROOTDAO rootDao = ROOTDAOUtils.getROOTDAO();
        if("AStaffAcctTradRRB".equals(fileflag)) {//日报入口
        	beanlistRRB = new ArrayList<AStaffAcctTradRRB>();
        	for(int i = 0; i < wb.getNumberOfSheets(); i++){
            	sheet = wb.getSheetAt(i);
            	if("日报客户信息".equals(sheet.getSheetName())){  
            		AStaffAcctTradRRB beanOld = null;//数据库数据
            		String alertId = null;//告警号
                    String staffNumber = null;//员工编号
                    String approveStatus = null;//记录状态
                    String recordUpdTlr = null;//记录修改人
                    String checkDate = null;//初步调查日期
                    String investigator = null;//调查者
                    String status = null;//调查阶段
                    String managerName = null;//直线经理姓名
                    String invesResultByOps = null;//初步调查结论(by OPS)
                    String caseId = null;//上报案件编号
                    String reportDate = null;//上报日期
                    String potentialCaseType = null;//(初步调查)上报的可疑类型
                    String feedbackDate = null;//收到反馈时间
                    String concludedType = null;//(收到反馈)判定的可疑类型
                    String feedbackFrom = null;//反馈结果(从FCTM或者GB/GF指定部门)
                    String comfirmedSusp = null;//是否判定可疑(及由哪方判定)
                    for(int rowNum = 1;rowNum <= sheet.getLastRowNum();rowNum++){
                        if(!isBlankRow(sheet.getRow(rowNum))){
                    		Row row = sheet.getRow(rowNum);   
                            error_row = rowNum + 1;
                            //告警号
                            alertId = DataFormat.isEmpty(getCellStringValue3(row.getCell(1))) == true ? "" : getCellStringValue3(row.getCell(1)).trim();//第二列开始
                            if(alertId.length() > 40){
                            	errmsg = "\"告警号\"的长度不能超过40！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            if("@N".equals(alertId) || "".equals(alertId)){
                            	errmsg = "\"告警号\"字段不能为空！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            //查询告警号对应的记录
                            ArrayList<String> condList = new ArrayList<String>();
            				condList.add(alertId);
                            List<AStaffAcctTradRRB> taskList = rootDao.queryByCondition("from AStaffAcctTradRRB where 1=1 and alertId = ?", condList.toArray());
                            //判断数据库是否存在对应的记录
                            if(taskList.isEmpty()){
                            	errmsg = "\"告警号\"为" + alertId + "的记录不存在！";
                            	err_list.add(errmsg);
                            	break;
                            }
                            beanOld = taskList.get(0);
                            
                            //获取数据的员工编号是否为空
                            //员工编号
                            staffNumber = DataFormat.isEmpty(beanOld.getStaffNumber()) == true ? "":beanOld.getStaffNumber();
                            if("".equals(staffNumber)){
                            	continue;
    						}
                            
                            //记录修改人
                            recordUpdTlr = DataFormat.isEmpty(beanOld.getRecordUpdTlr()) == true ? "":beanOld.getRecordUpdTlr();
                            if("".equals(recordUpdTlr)){
                            	errmsg = "\"记录修改人\"不存在，您操作错误！";
                            	err_list.add(errmsg);
                            	break;
                            }
                            if(!tlrNo.equals(recordUpdTlr)){
                            	errmsg = "\"记录修改人\"与\"当前用户\"匹配不成功！";
                            	err_list.add(errmsg);
                            	break;
                            }
                            
                            //初步调查日期
                            checkDate = DataFormat.isEmpty(beanOld.getCheckDate()) == true ? "":beanOld.getCheckDate();
                            if("".equals(checkDate)){
                            	checkDate = currentTime.substring(0,8);
                            }
                            beanOld.setCheckDate(checkDate);
                            
                            //调查者
                            investigator = DataFormat.isEmpty(beanOld.getInvestigator()) == true ? "":beanOld.getInvestigator();
                            if("".equals(investigator)){
                            	investigator = recordUpdTlr;
                            }else{
                            	if(investigator.indexOf(recordUpdTlr) == -1){
            						investigator = investigator + "," + recordUpdTlr;
            					}
                            }
                            beanOld.setInvestigator(investigator);	
                            
                            //调查阶段
                            status = DataFormat.isEmpty(getCellStringValue3(row.getCell(17))) == true ? "" : getCellStringValue3(row.getCell(17)).split("\\-")[0].trim();
                            if("@N".equals(status)){
                            		status = "";
                            }
                            if("".equals(status)){
                            	errmsg = "\"调查阶段\"不可为空！";
                            	err_list.add(errmsg);
                            	break;
                            }
                            beanOld.setStatus(status);
                            
                            //直线经理姓名
                            managerName = DataFormat.isEmpty(getCellStringValue3(row.getCell(18))) == true ? "" : getCellStringValue3(row.getCell(18)).trim();
                            if(managerName.length() > 100){
                            	errmsg = "\"直线经理姓名\"的长度不能超过100！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            if("@N".equals(managerName)){
                            	managerName = "";
                            }
                            beanOld.setManagerName(managerName);
                            
                            //初步调查结论(by OPS)
                            invesResultByOps = DataFormat.isEmpty(getCellStringValue3(row.getCell(19))) == true ? "" : getCellStringValue3(row.getCell(19)).trim();
                            if(invesResultByOps.length() > 4000){
                            	errmsg = "\"初步调查结论(by OPS)\"的长度不能超过4000！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            if("@N".equals(invesResultByOps)){
                            	invesResultByOps = "";
                            }
                            if("".equals(invesResultByOps)){
                            	errmsg = "\"初步调查结论(by OPS)\"不可为空！";
                            	err_list.add(errmsg);
                            	break;
                            }
                            beanOld.setInvesResultByOps(invesResultByOps);
                            
                            //上报案件编号
                            caseId = DataFormat.isEmpty(getCellStringValue3(row.getCell(20))) == true ? "" : getCellStringValue3(row.getCell(20)).trim();
                            if(caseId.length() > 4000){
                            	errmsg = "\"上报案件编号\"的长度不能超过4000！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            if("@N".equals(caseId)){
                            	caseId = "";
                            }
                            beanOld.setCaseId(caseId);
                            
                            //上报日期
                            reportDate = DataFormat.isEmpty(getCellStringValue3(row.getCell(21))) == true ? "" : getCellStringValue3(row.getCell(21)).trim();
                            if("@N".equals(reportDate)){
                            	reportDate = "";
                            }else{
                            	if(!isValidDate(reportDate)){
                                	errmsg = "\"上报日期\"格式错误，正确格式为\"年年年年月月日日\"，请确认单元格格式与模板格式一致！";
                                	err_list.add(errmsg);
                                    break;
                                }
                            }
                            beanOld.setReportDate(reportDate);
                            
                            //(初步调查)上报的可疑类型
                            potentialCaseType = DataFormat.isEmpty(getCellStringValue3(row.getCell(22))) == true ? "" : getCellStringValue3(row.getCell(22)).split("\\-")[0].trim();
                            if("@N".equals(potentialCaseType)){
                            	potentialCaseType = "";
                            }
                            beanOld.setPotentialCaseType(potentialCaseType);
                            
                            //收到反馈时间
                            feedbackDate = DataFormat.isEmpty(getCellStringValue3(row.getCell(23))) == true ? "" : getCellStringValue3(row.getCell(23)).trim();
                            if("@N".equals(feedbackDate)){
                            	feedbackDate = "";
                            }else{
                            	if(!isValidDate(feedbackDate)){
                                	errmsg = "\"收到反馈时间\"格式错误，正确格式为\"年年年年月月日日\"，请确认单元格格式与模板格式一致！";
                                	err_list.add(errmsg);
                                	break;
        						}
                            }
                            beanOld.setFeedbackDate(feedbackDate);
                            
                            //(收到反馈)判定的可疑类型
                            concludedType = DataFormat.isEmpty(getCellStringValue3(row.getCell(24))) == true ? "" : getCellStringValue3(row.getCell(24)).split("\\-")[0].trim();
                            if("@N".equals(concludedType)){
                            	concludedType = "";
                            }
                            beanOld.setConcludedType(concludedType);
                            
                            //反馈结果(从FCTM或者President)
                            feedbackFrom = DataFormat.isEmpty(getCellStringValue3(row.getCell(25))) == true ? "" : getCellStringValue3(row.getCell(25)).trim();
                            if(feedbackFrom.length() > 4000){
                            	errmsg = "\"反馈结果(从FCTM或者President)\"的长度不能超过4000！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            if("@N".equals(feedbackFrom)){
                            	feedbackFrom = "";
                            }
                            beanOld.setFeedbackFrom(feedbackFrom);
                            
                            //是否判定可疑(及由哪方判定)
                            comfirmedSusp = DataFormat.isEmpty(getCellStringValue3(row.getCell(26))) == true ? "" : getCellStringValue3(row.getCell(26)).split("\\-")[0].trim();
                            if("@N".equals(comfirmedSusp)){
                            	comfirmedSusp = "";
                            }
                            beanOld.setComfirmedSusp(comfirmedSusp);
                            
                            //记录状态
                            approveStatus = DataFormat.isEmpty(beanOld.getApproveStatus()) == true ? "":beanOld.getApproveStatus();
                            if("00".equals(approveStatus)){
                            	errmsg = "记录状态不能为\"00-未处理\"，您操作错误！";
                            	err_list.add(errmsg);
                            	break;
                            }else if("01".equals(approveStatus)){//01-已下载
                            	approveStatus = "02";//已调研
                            }
                            beanOld.setApproveStatus(approveStatus);
                            
                            //初步调查日期必须早于或等于上报日期
            				if(!"".equals(reportDate)){
            					Long checkDateTime = sdfs.parse(checkDate).getTime();//初步调查日期
            					Long reportDateTime = sdfs.parse(reportDate).getTime();//上报日期
            					if(checkDateTime > reportDateTime){
            						errmsg = "初步调查日期必须早于或等于上报日期！";
                                	err_list.add(errmsg);
                                	break;
            					}
            				}
                            
            				//收到反馈时间不早于上报日期，且不能晚于当前系统时间
            				if(!"".equals(feedbackDate)){
            					if("".equals(reportDate)){
            						errmsg = "收到反馈时间有值时，上报日期不可为空！";
            						err_list.add(errmsg);
                                	break;
            					}
            					Long feedbackDateTime = sdfs.parse(feedbackDate).getTime();//收到反馈时间
            					Long reportDateTime = sdfs.parse(reportDate).getTime();//上报日期
            					Long dateTimes = sdfs.parse(currentTime.substring(0,8)).getTime();//系统时间
            					//收到反馈时间不早于上报日期
            					if(reportDateTime > feedbackDateTime){
            						errmsg = "收到反馈时间不早于上报日期！";
            						err_list.add(errmsg);
                                	break;
            					}
            					//收到反馈时间不能晚于当前系统时间
            					if(feedbackDateTime > dateTimes){
            						errmsg = "收到反馈时间不能晚于当前系统时间！";
            						err_list.add(errmsg);
                                	break;
            					}
            				}
            				
            				//(初步调查)上报的可疑类型与上报日期需要同时为空或者同时有值
            				if(!"".equals(reportDate) && "".equals(potentialCaseType)){
            					errmsg = "上报日期与(初步调查)上报的可疑类型需要同时为空或者同时有值！";
            					err_list.add(errmsg);
                                break;
            				}else if("".equals(reportDate) && !"".equals(potentialCaseType)){
            					errmsg = "上报日期与(初步调查)上报的可疑类型需要同时为空或者同时有值！";
            					err_list.add(errmsg);
                                break;
            				}
            				
            				//反馈结果(从FCTM或者President),是否判定可疑(及由哪方判定)三者同时为空或同时有值
            				boolean flag = false;
            				if("".equals(feedbackDate) && "".equals(feedbackFrom) && "".equals(comfirmedSusp)){
            					flag = true;
            				}
            				if(!"".equals(feedbackDate) && !"".equals(feedbackFrom) && !"".equals(comfirmedSusp)){
            					flag = true;
            				}
            				if(!flag){
            					errmsg = "收到反馈时间,反馈结果(从FCTM或者President),是否判定可疑(及由哪方判定)三者同时为空或同时有值！";
            					err_list.add(errmsg);
                                break;
            				}
            				//记录修改时间
            				beanOld.setRecordUpdTm(currentTime.substring(0,14));
                            beanlistRRB.add(beanOld);
                        }
                    }
            	}else{
            		if(!"日报交易信息".equals(sheet.getSheetName())){
            			ExceptionUtil.throwCommonException("员工交易监测调研日报模板错误，请检查！");
            		}
            	}
        	}
        }else{//月报入口
        	beanlistMRRB = new ArrayList<AStaffAcctTradMRRB>();
        	for(int i = 0; i < wb.getNumberOfSheets(); i++){
            	sheet = wb.getSheetAt(i);
            	if("月报客户信息".equals(sheet.getSheetName())){  
            		AStaffAcctTradMRRB beanOld = null;//数据库数据
            		String alertId = null;//告警号
                    String staffNumber = null;//员工编号
                    String approveStatus = null;//记录状态
                    String recordUpdTlr = null;//记录修改人
                    String checkDate = null;//初步调查日期
                    String investigator = null;//调查者
                    String status = null;//调查阶段
                    String managerName = null;//直线经理姓名
                    String invesResultByOps = null;//初步调查结论(by OPS)
                    String caseId = null;//上报案件编号
                    String reportDate = null;//上报日期
                    String potentialCaseType = null;//(初步调查)上报的可疑类型
                    String feedbackDate = null;//收到反馈时间
                    String concludedType = null;//(收到反馈)判定的可疑类型
                    String feedbackFrom = null;//反馈结果(从FCTM或者GB/GF指定部门)
                    String comfirmedSusp = null;//是否判定可疑(及由哪方判定)
                    String updatePerson = GlobalInfo.getCurrentInstance().getTlrno();//当前操作员
                    for(int rowNum = 1;rowNum <= sheet.getLastRowNum();rowNum++){
                        if(!isBlankRow(sheet.getRow(rowNum))){
                    		Row row = sheet.getRow(rowNum);   
                            error_row = rowNum + 1;
                            //告警号
                            alertId = DataFormat.isEmpty(getCellStringValue3(row.getCell(1))) == true ? "" : getCellStringValue3(row.getCell(1)).trim();//第二列开始
                            if(alertId.length() > 40){
                            	errmsg = "\"告警号\"的长度不能超过40！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            if("@N".equals(alertId) || "".equals(alertId)){
                            	errmsg = "\"告警号\"字段不能为空！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            
                            //查询告警号对应的记录
                            ArrayList<String> condList = new ArrayList<String>();
            				condList.add(alertId);
                            List<AStaffAcctTradMRRB> taskList = rootDao.queryByCondition("from AStaffAcctTradMRRB where 1=1 and alertId = ?", condList.toArray());
                            //判断数据库是否存在对应的记录
                            if(taskList.isEmpty()){
                            	errmsg = "\"告警号\"为" + alertId + "的记录不存在！";
                            	err_list.add(errmsg);
                            	break;
                            }
                            beanOld = taskList.get(0);
                            //获取数据的员工编号是否为空
                            //员工编号
                            staffNumber = DataFormat.isEmpty(beanOld.getStaffNumber()) == true ? "":beanOld.getStaffNumber();
                            if("".equals(staffNumber)){
                            	continue;
    						}
                            
                            //记录修改人
                            recordUpdTlr = DataFormat.isEmpty(beanOld.getRecordUpdTlr()) == true ? "":beanOld.getRecordUpdTlr();
                            if("".equals(recordUpdTlr)){
                            	errmsg = "\"记录修改人\"不存在，您操作错误！";
                            	err_list.add(errmsg);
                            	break;
                            }
                            if(!tlrNo.equals(recordUpdTlr)){
                            	errmsg = "\"记录修改人\"与\"当前用户\"匹配不成功！";
                            	err_list.add(errmsg);
                            	break;
                            }

                            //初步调查日期
                            checkDate = DataFormat.isEmpty(beanOld.getCheckDate()) == true ? "":beanOld.getCheckDate();
                            if("".equals(checkDate)){
                            	checkDate = currentTime.substring(0,8);
                            }
                            beanOld.setCheckDate(checkDate);
                            
                            //调查者
                            investigator = DataFormat.isEmpty(beanOld.getInvestigator()) == true ? "":beanOld.getInvestigator();
                            if("".equals(investigator)){
                            	investigator = recordUpdTlr;
                            }else{
                            	if(investigator.indexOf(recordUpdTlr) == -1){
            						investigator = investigator + "," + recordUpdTlr;
            					}
                            }
                            beanOld.setInvestigator(investigator);	
                            
                            //调查阶段
                            status = DataFormat.isEmpty(getCellStringValue3(row.getCell(17))) == true ? "" : getCellStringValue3(row.getCell(17)).split("\\-")[0].trim();
                            if("@N".equals(status)){
                            	status = "";
                            }
                            if("".equals(status)){
                            	errmsg = "\"调查阶段\"不可为空！";
                            	err_list.add(errmsg);
                            	break;
                            }
                            beanOld.setStatus(status);
                            
                            //直线经理姓名
                            managerName = DataFormat.isEmpty(getCellStringValue3(row.getCell(18))) == true ? "" : getCellStringValue3(row.getCell(18)).trim();
                            if(managerName.length() > 100){
                            	errmsg = "\"直线经理姓名\"的长度不能超过100！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            if("@N".equals(managerName)){
                            	managerName = "";
                            }
                            beanOld.setManagerName(managerName);
                            
                            //初步调查结论(by OPS)
                            invesResultByOps = DataFormat.isEmpty(getCellStringValue3(row.getCell(19))) == true ? "" : getCellStringValue3(row.getCell(19)).trim();
                            if(invesResultByOps.length() > 4000){
                            	errmsg = "\"初步调查结论(by OPS)\"的长度不能超过4000！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            if("@N".equals(invesResultByOps)){
                            	invesResultByOps = "";
                            }
                            if("".equals(invesResultByOps)){
                            	errmsg = "\"初步调查结论(by OPS)\"不可为空！";
                            	err_list.add(errmsg);
                            	break;
                            }
                            beanOld.setInvesResultByOps(invesResultByOps);
                            
                            //上报案件编号
                            caseId = DataFormat.isEmpty(getCellStringValue3(row.getCell(20))) == true ? "" : getCellStringValue3(row.getCell(20)).trim();
                            if(caseId.length() > 4000){
                            	errmsg = "\"上报案件编号\"的长度不能超过4000！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            if("@N".equals(caseId)){
                            	caseId = "";
                            }
                            beanOld.setCaseId(caseId);
                            
                            //上报日期
                            reportDate = DataFormat.isEmpty(getCellStringValue3(row.getCell(21))) == true ? "" : getCellStringValue3(row.getCell(21)).trim();
                            if("@N".equals(reportDate)){
                            	reportDate = "";
                            }else{
                            	if(!isValidDate(reportDate)){
                            		errmsg = "\"上报日期\"格式错误，正确格式为\"年年年年月月日日\"，请确认单元格格式与模板格式一致！";
                                	err_list.add(errmsg);
                                	break;
                            	}
                            }
                            beanOld.setReportDate(reportDate);
                            
                            //(初步调查)上报的可疑类型
                            potentialCaseType = DataFormat.isEmpty(getCellStringValue3(row.getCell(22))) == true ? "" : getCellStringValue3(row.getCell(22)).split("\\-")[0].trim();
                            if("@N".equals(potentialCaseType)){
                            	potentialCaseType = "";
                            }
                            beanOld.setPotentialCaseType(potentialCaseType);
                            
                            //收到反馈时间
                            feedbackDate = DataFormat.isEmpty(getCellStringValue3(row.getCell(23))) == true ? "" : getCellStringValue3(row.getCell(23)).trim();
                            if("@N".equals(feedbackDate)){
                            	feedbackDate = "";
                            }else{
                            	if(!isValidDate(feedbackDate)){
                            		errmsg = "\"收到反馈时间\"格式错误，正确格式为\"年年年年月月日日\"，请确认单元格格式与模板格式一致！";
                                	err_list.add(errmsg);
                                	break;
                            	}
                            }
                            beanOld.setFeedbackDate(feedbackDate);
                            
                            //(收到反馈)判定的可疑类型
                            concludedType = DataFormat.isEmpty(getCellStringValue3(row.getCell(24))) == true ? "" : getCellStringValue3(row.getCell(24)).split("\\-")[0].trim();
                            if("@N".equals(concludedType)){
                            	concludedType = "";
                            }
                            beanOld.setConcludedType(concludedType);
                            
                            //反馈结果(从FCTM或者President)
                            feedbackFrom = DataFormat.isEmpty(getCellStringValue3(row.getCell(25))) == true ? "" : getCellStringValue3(row.getCell(25)).trim();
                            if(feedbackFrom.length() > 4000){
                            	errmsg = "\"反馈结果(从FCTM或者President)\"的长度不能超过4000！";
                            	err_list.add(errmsg);
                            	break;
    						}
                            if("@N".equals(feedbackFrom)){
                            	feedbackFrom = "";
                            }
                            beanOld.setFeedbackFrom(feedbackFrom);
                            
                            //是否判定可疑(及由哪方判定)
                            comfirmedSusp = DataFormat.isEmpty(getCellStringValue3(row.getCell(26))) == true ? "" : getCellStringValue3(row.getCell(26)).split("\\-")[0].trim();
                            if("@N".equals(comfirmedSusp)){
                            	comfirmedSusp = "";
                            }
                            beanOld.setComfirmedSusp(comfirmedSusp);
                            
                            //记录状态
                            approveStatus = DataFormat.isEmpty(beanOld.getApproveStatus()) == true ? "":beanOld.getApproveStatus().toString();
                            if("00".equals(approveStatus)){
                            	errmsg = "记录状态不能为\"00-未处理\"，您操作错误！";
                            	err_list.add(errmsg);
                            	break;
                            }else if("01".equals(approveStatus)){//01-已下载
                            	approveStatus = "02";//已调研
                            }
                            beanOld.setApproveStatus(approveStatus);
                            
                            //初步调查日期必须早于或等于上报日期
            				if(!"".equals(reportDate)){
            					Long checkDateTime = sdfs.parse(checkDate).getTime();//初步调查日期
            					Long reportDateTime = sdfs.parse(reportDate).getTime();//上报日期
            					if(checkDateTime > reportDateTime){
            						errmsg = "初步调查日期必须早于或等于上报日期！";
                                	err_list.add(errmsg);
                                	break;
            					}
            				}
                            
            				//收到反馈时间不早于上报日期，且不能晚于当前系统时间
            				if(!"".equals(feedbackDate)){
            					if("".equals(reportDate)){
            						errmsg = "收到反馈时间有值时，上报日期不可为空！";
            						err_list.add(errmsg);
                                	break;
            					}
            					Long feedbackDateTime = sdfs.parse(feedbackDate).getTime();//收到反馈时间
            					Long reportDateTime = sdfs.parse(reportDate).getTime();//上报日期
            					Long dateTimes = sdfs.parse(currentTime.substring(0,8)).getTime();//系统时间
            					//收到反馈时间不早于上报日期
            					if(reportDateTime > feedbackDateTime){
            						errmsg = "收到反馈时间不早于上报日期！";
            						err_list.add(errmsg);
                                	break;
            					}
            					//收到反馈时间不能晚于当前系统时间
            					if(feedbackDateTime > dateTimes){
            						errmsg = "收到反馈时间不能晚于当前系统时间！";
            						err_list.add(errmsg);
                                	break;
            					}
            				}
            				
            				//(初步调查)上报的可疑类型与上报日期需要同时为空或者同时有值
            				if(!"".equals(reportDate) && "".equals(potentialCaseType)){
            					errmsg = "上报日期与(初步调查)上报的可疑类型需要同时为空或者同时有值！";
            					err_list.add(errmsg);
                                break;
            				}else if("".equals(reportDate) && !"".equals(potentialCaseType)){
            					errmsg = "上报日期与(初步调查)上报的可疑类型需要同时为空或者同时有值！";
            					err_list.add(errmsg);
                                break;
            				}
            				
            				//反馈结果(从FCTM或者President),是否判定可疑(及由哪方判定)三者同时为空或同时有值
            				boolean flag = false;
            				if("".equals(feedbackDate) && "".equals(feedbackFrom) && "".equals(comfirmedSusp)){
            					flag = true;
            				}
            				if(!"".equals(feedbackDate) && !"".equals(feedbackFrom) && !"".equals(comfirmedSusp)){
            					flag = true;
            				}
            				if(!flag){
            					errmsg = "收到反馈时间,反馈结果(从FCTM或者President),是否判定可疑(及由哪方判定)三者同时为空或同时有值！";
            					err_list.add(errmsg);
                                break;
            				}
            				//记录修改时间
            				beanOld.setRecordUpdTm(currentTime.substring(0,14));
                            beanlistMRRB.add(beanOld);
                        }
                    }
            	}else{
            		if(!"月报交易信息".equals(sheet.getSheetName())){
            			ExceptionUtil.throwCommonException("员工交易监测调研月报模板错误，请检查！");
            		}
            	}
        	}
        }
        if(!err_list.isEmpty()){
        	if("AStaffAcctTradRRB".equals(fileflag)) {//日报入口
        		beanlistRRB.clear();
        		throw new Exception("sheet[日报客户信息]第" + (error_row) + "行数据错误！错误原因："+ err_list.get(0));
        	}
        	if("AStaffAcctTradMRRB".equals(fileflag)){
        		beanlistMRRB.clear();
        		throw new Exception("sheet[月报客户信息]第" + (error_row) + "行数据错误！错误原因："+ err_list.get(0));
        	}
        }else{
        	if("AStaffAcctTradRRB".equals(fileflag)){
        		for(AStaffAcctTradRRB astRRB : beanlistRRB) {
        			rootDao.update(astRRB);
            	}
            	beanlistRRB.clear();
        	}else{
        		for(AStaffAcctTradMRRB astMRRB : beanlistMRRB) {
        			rootDao.update(astMRRB);//告警号
            	}
            	beanlistMRRB.clear();
        	}
        }
        System.out.println("=========================================================================");
        if("AStaffAcctTradRRB".equals(fileflag)){
        	System.out.println("===========RRB员工交易监测日报调研信息导入结束时间:" + sdfHMS.format(new Date()) + "=============");
        }else{
        	System.out.println("===========RRB员工交易监测月报调研信息导入结束时间:" + sdfHMS.format(new Date()) + "=============");
        }
        System.out.println("=========================================================================");
    }
    
}