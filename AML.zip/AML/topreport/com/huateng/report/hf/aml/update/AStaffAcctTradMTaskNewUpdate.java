package com.huateng.report.hf.aml.update;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import resources.bean.report.form.AStaffAcctTrad;
import resources.bean.report.form.AStaffAcctTradM;

import com.huateng.commquery.result.MultiUpdateResultBean;
import com.huateng.commquery.result.UpdateResultBean;
import com.huateng.commquery.result.UpdateReturnBean;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.web.commQuery.BaseUpdate;
import com.huateng.exception.AppException;

public class AStaffAcctTradMTaskNewUpdate extends BaseUpdate {
	private static final String DATASET_ID = "AStaffAcctTradMTaskNew";
	
	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request,
			HttpServletResponse respone) throws AppException {
		UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID(DATASET_ID);
		UpdateReturnBean updateReturnBean = new UpdateReturnBean();
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		String selectTlrno = updateResultBean.getParameter("selectTlrno");
		AStaffAcctTradM asfM = new AStaffAcctTradM();
		while (updateResultBean.hasNext()){	
			Map maps = updateResultBean.next();
			if("true".equals(maps.get("select"))){
				mapToObject(asfM, maps);
				asfM.setRecordUpdTlr(selectTlrno);
				rootdao.update(asfM);
			}
		}
		return updateReturnBean;
	}
}