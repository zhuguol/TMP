package com.huateng.report.hf.aml.update;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import resources.bean.report.form.AStaffAcctTradMRRB;

import com.huateng.commquery.result.MultiUpdateResultBean;
import com.huateng.commquery.result.UpdateResultBean;
import com.huateng.commquery.result.UpdateReturnBean;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.web.commQuery.BaseUpdate;
import com.huateng.exception.AppException;

public class AStaffAcctTradMRRBTaskNewUpdate extends BaseUpdate {
	private static final String DATASET_ID = "AStaffAcctTradMRRBTaskNew";
	
	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request,
			HttpServletResponse respone) throws AppException {
		UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID(DATASET_ID);
		UpdateReturnBean updateReturnBean = new UpdateReturnBean();
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		String selectTlrno = updateResultBean.getParameter("selectTlrno");
		AStaffAcctTradMRRB asfMRRB = new AStaffAcctTradMRRB();
		while (updateResultBean.hasNext()){	
			Map maps = updateResultBean.next();
			if("true".equals(maps.get("select"))){
				mapToObject(asfMRRB, maps);
				asfMRRB.setRecordUpdTlr(selectTlrno);
				rootdao.update(asfMRRB);
			}
		}
		return updateReturnBean;
	}
}