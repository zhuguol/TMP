package com.huateng.report.hf.aml.update;

import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import resources.bean.report.form.AStaffAcctTrad;

import com.huateng.common.err.Module;
import com.huateng.common.err.Rescode;
import com.huateng.commquery.result.MultiUpdateResultBean;
import com.huateng.commquery.result.UpdateResultBean;
import com.huateng.commquery.result.UpdateReturnBean;
import com.huateng.ebank.business.common.GlobalInfo;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.util.DataFormat;
import com.huateng.ebank.framework.util.ExceptionUtil;
import com.huateng.ebank.framework.web.commQuery.BaseUpdate;
import com.huateng.excel.imp.DataMyUtil;
import com.huateng.exception.AppException;

public class AStaffAcctTradUpdateSave extends BaseUpdate {
	private static final String DATASET_ID = "AStaffAcctTradUpdate";

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request,
			HttpServletResponse response) throws AppException {
		try {
			UpdateReturnBean updateReturnBean = new UpdateReturnBean();
			UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID(DATASET_ID);
			ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
			String dateTime = DataMyUtil.getFullDateTime();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			AStaffAcctTrad asf = new AStaffAcctTrad();
			//获取用户信息
			GlobalInfo gInfo = GlobalInfo.getCurrentInstance();
			while (updateResultBean.hasNext()) {
				mapToObject(asf, updateResultBean.next());
				//员工编号
				String staffNumber = asf.getStaffNumber().trim();
				if(DataFormat.isEmpty(staffNumber)){
					ExceptionUtil.throwCommonException("当前记录没有员工编号！");
				}
				
				//初步调查日期
				String checkDate = DataFormat.isEmpty(asf.getCheckDate()) == true ? "": asf.getCheckDate().trim();
				if("".equals(checkDate)){
					checkDate = dateTime.substring(0,8);
				}
				asf.setCheckDate(checkDate);
				
				//调查者
				String investigator = DataFormat.isEmpty(asf.getInvestigator()) == true ? "": asf.getInvestigator().trim();
				if("".equals(investigator)){
					investigator = gInfo.getTlrno();
				}else{
					if(investigator.indexOf(gInfo.getTlrno()) == -1){
						investigator = investigator + "," + gInfo.getTlrno();
					}
				}
				asf.setInvestigator(investigator);
				
				//调查阶段
				String status = DataFormat.isEmpty(asf.getStatus()) == true ? "": asf.getStatus().trim();
				if("".equals(status)){
					ExceptionUtil.throwCommonException("调查阶段不可为空！");
				}
						
				//初步调查结论(by OPS)
				String invesResultByOps = DataFormat.isEmpty(asf.getInvesResultByOps()) == true ? "": asf.getInvesResultByOps().trim();
				if("".equals(invesResultByOps)){
					ExceptionUtil.throwCommonException("初步调查结论(by OPS)不可为空！");
				}
				
				//上报日期
				String reportDate = DataFormat.isEmpty(asf.getReportDate()) == true ? "": asf.getReportDate().trim();
				
				//(初步调查)上报的可疑类型
				String potentialCaseType = DataFormat.isEmpty(asf.getPotentialCaseType()) == true ? "": asf.getPotentialCaseType().trim();
				
				//收到反馈时间
				String feedbackDate = DataFormat.isEmpty(asf.getFeedbackDate()) == true ? "": asf.getFeedbackDate().trim();
				
				//反馈结果(从FCTM或者GB/GF指定部门)
				String feedbackFrom = DataFormat.isEmpty(asf.getFeedbackFrom()) == true ? "": asf.getFeedbackFrom().trim();
				
				//是否判定可疑(及由哪方判定)
				String comfirmedSusp = DataFormat.isEmpty(asf.getComfirmedSusp()) == true ? "": asf.getComfirmedSusp().trim();
				
				//初步调查日期必须早于或等于上报日期
				if(!"".equals(reportDate)){
					Long checkDateTime = sdf.parse(checkDate).getTime();//初步调查日期
					Long reportDateTime = sdf.parse(reportDate).getTime();//上报日期
					if(checkDateTime > reportDateTime){
						ExceptionUtil.throwCommonException("初步调查日期必须早于或等于上报日期！");
					}
				}
				
				//收到反馈时间不早于上报日期，且不能晚于当前系统时间
				if(!"".equals(feedbackDate)){
					if("".equals(reportDate)){
						ExceptionUtil.throwCommonException("收到反馈时间有值时，上报日期不可为空！");
					}
					Long feedbackDateTime = sdf.parse(feedbackDate).getTime();//收到反馈时间
					Long reportDateTime = sdf.parse(reportDate).getTime();//上报日期
					Long dateTimes = sdf.parse(dateTime.substring(0,8)).getTime();//系统时间
					//收到反馈时间不早于上报日期
					if(reportDateTime > feedbackDateTime){
						ExceptionUtil.throwCommonException("收到反馈时间不早于上报日期！");
					}
					//收到反馈时间不能晚于当前系统时间
					if(feedbackDateTime > dateTimes){
						ExceptionUtil.throwCommonException("收到反馈时间不能晚于当前系统时间！");
					}
				}
				
				//(初步调查)上报的可疑类型与上报日期需要同时为空或者同时有值
				if(!"".equals(reportDate) && "".equals(potentialCaseType)){
					ExceptionUtil.throwCommonException("上报日期与(初步调查)上报的可疑类型需要同时为空或者同时有值！");
				}else if("".equals(reportDate) && !"".equals(potentialCaseType)){
					ExceptionUtil.throwCommonException("上报日期与(初步调查)上报的可疑类型需要同时为空或者同时有值！");
				}
				
				//收到反馈时间,反馈结果(从FCTM或者GB/GF指定部门),是否判定可疑(及由哪方判定)三者同时为空或同时有值
				boolean flag = false;
				if("".equals(feedbackDate) && "".equals(feedbackFrom) && "".equals(comfirmedSusp)){
					flag = true;
				}
				if(!"".equals(feedbackDate) && !"".equals(feedbackFrom) && !"".equals(comfirmedSusp)){
					flag = true;
				}
				if(!flag){
					ExceptionUtil.throwCommonException("收到反馈时间,反馈结果(从FCTM或者GB/GF指定部门),是否判定可疑(及由哪方判定)三者同时为空或同时有值！");
				}
				
				//记录状态
				String approveStatus = asf.getApproveStatus().trim();
				if("00".equals(approveStatus)){//未处理,直接设置-调查者-初步调查日期-记录修改人-记录修改时间-记录状态为已调研
					asf.setRecordUpdTlr(gInfo.getTlrno());
					asf.setRecordUpdTm(dateTime.substring(0,14));
					asf.setApproveStatus("02");
				}else if("01".equals(approveStatus)){//已下载,直接设置-调查者-初步调查日期-记录状态为已调研
					asf.setRecordUpdTm(dateTime.substring(0,14));
					asf.setApproveStatus("02");
				}else if("04".equals(approveStatus)){//审核失败，进入到自查已调研
					asf.setRecordUpdTm(dateTime.substring(0,14));
					asf.setApproveStatus("05");
				}
				rootdao.update(asf);
			}
			return updateReturnBean;
		} catch (AppException appEx) {
			throw appEx;
		} catch (Exception ex) {
			throw new AppException(Module.SYSTEM_MODULE, Rescode.DEFAULT_RESCODE, ex.getMessage(), ex);
		}
	}
}
