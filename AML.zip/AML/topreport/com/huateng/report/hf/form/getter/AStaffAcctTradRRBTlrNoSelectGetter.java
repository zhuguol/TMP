package com.huateng.report.hf.form.getter;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.orm.hibernate3.SessionFactoryUtils;

import resources.bean.report.form.AStaffAcctTradMRRB;

import com.huateng.commquery.result.Result;
import com.huateng.commquery.result.ResultMng;
import com.huateng.ebank.business.common.GlobalInfo;
import com.huateng.ebank.business.common.PageQueryCondition;
import com.huateng.ebank.business.common.PageQueryResult;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.entity.data.mng.TlrInfo;
import com.huateng.ebank.framework.exceptions.CommonException;
import com.huateng.ebank.framework.util.DataFormat;
import com.huateng.ebank.framework.util.ExceptionUtil;
import com.huateng.ebank.framework.web.commQuery.BaseGetter;
import com.huateng.exception.AppException;
import com.huateng.report.hf.aml.utils.HsbcAmlUtils;

public class AStaffAcctTradRRBTlrNoSelectGetter extends BaseGetter {
	/*
	 * 参数段编号下拉框(模糊筛选框)
	 * 
	 */
	@Override
	public Result call() throws AppException {
		String value = StringEscapeUtils.escapeHtml(this.getCommQueryServletRequest().getParameter("value"));
		int pageSize = this.getResult().getPage().getEveryPage();
		int pageIndex = this.getResult().getPage().getCurrentPage();
		PageQueryResult pageResult = paramgroupIdSelect(pageIndex, pageSize, value);
		ResultMng.fillResultByList(getCommonQueryBean(), getCommQueryServletRequest(), pageResult.getQueryResult(),
				getResult());
		result.setContent(pageResult.getQueryResult());
		result.getPage().setTotalPage(pageResult.getPageCount(getResult().getPage().getEveryPage()));
		result.init();
		result.setTotal(pageResult.getTotalCount());
		return result;
	}
	
	public PageQueryResult paramgroupIdSelect(int pageIndex, int pageSize, String value) {
		ROOTDAO rootDao = ROOTDAOUtils.getROOTDAO();
		List<String> condList = new ArrayList<String>();
		PageQueryResult pageQueryResult = new PageQueryResult();
		Connection connect = null;
		Statement st = null;
    	ResultSet rs = null;
		try {
			GlobalInfo gInfo = GlobalInfo.getCurrentInstance();
			//String tlrnosql = " select t.tlrno from tlr_info t left join tlr_role_rel b on t.tlrno = b.tlrno left join role_info c on b.role_id = c.role_id where c.role_name = 'STAFF#OPERATOR' and t.flag = '1' ";
			String tlrnosql = " select t.tlrno from tlr_info t "
					+ " left join tlr_role_rel b on t.tlrno = b.tlrno "
					+ " left join role_info c on b.role_id = c.role_id "
					+ " left join tlr_bctl_rel d on t.tlrno = d.tlr_no "
					+ " left join bctl e on d.br_no = e.brno "
					+ " where c.role_name = 'STAFF#OPERATOR' "
					+ " and t.flag = '1' "
					+ " and e.brno = '" + GlobalInfo.getCurrentInstance().getBrno() + "'";
			connect = SessionFactoryUtils.getDataSource(ROOTDAOUtils.getROOTDAO().getSessionFactory()).getConnection();
			st = connect.createStatement();
			rs = st.executeQuery(tlrnosql);
			String sql = "from TlrInfo t where 1 = 1 ";
			sql = sql + (" and t.tlrno in ( ");
			while(rs.next()){
				sql = sql + ("?,");
				condList.add(rs.getString("tlrno"));
			}
			if(!condList.isEmpty()){
				sql = sql.substring(0, sql.length()-1);
				sql = sql + (") ");
				if (!DataFormat.isEmpty(value.replaceAll("%", "").trim())){
					sql = sql + (" and t.tlrno like ? ");
					condList.add("%" + value + "%");
				}
				PageQueryCondition queryCondition = new PageQueryCondition();
				queryCondition.setQueryString(sql.toString());
				queryCondition.setPageIndex(pageIndex);
				queryCondition.setPageSize(pageSize);
				queryCondition.setObjArray(condList.toArray());
				
				List<TlrInfo> list = new ArrayList<TlrInfo>();
				
				pageQueryResult = rootDao.pageQueryByQL(queryCondition);
				
				Iterator it = pageQueryResult.getQueryResult().iterator();
				while(it.hasNext()) {
					Object[] queryArray = (Object[]) it.next();
					TlrInfo t = (TlrInfo) queryArray[0];
					list.add(t);
				}
				pageQueryResult.setQueryResult(list);
			}
    	}catch (CommonException e1) {
			e1.printStackTrace();
		}catch (Exception e) {
        	e.printStackTrace();
        }finally {
        	if(rs!=null){
        		try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
        	} 
        	if(st!=null){
        		try {
					st.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
        	} 
        	if(connect!=null){
        		try {
					connect.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
        	} 
        }
		return pageQueryResult;
	}
}