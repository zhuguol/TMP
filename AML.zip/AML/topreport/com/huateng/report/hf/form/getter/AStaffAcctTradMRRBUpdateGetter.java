package com.huateng.report.hf.form.getter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;

import resource.bean.report.AmlBhbsDs;
import resources.bean.report.form.AStaffAcctTradMRRB;

import com.huateng.common.err.Module;
import com.huateng.common.err.Rescode;
import com.huateng.commquery.result.Result;
import com.huateng.commquery.result.ResultMng;
import com.huateng.ebank.business.common.PageQueryResult;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.exceptions.CommonException;
import com.huateng.ebank.framework.web.commQuery.BaseGetter;
import com.huateng.exception.AppException;

public class AStaffAcctTradMRRBUpdateGetter extends BaseGetter {

	@Override
	public Result call() throws AppException {
		try {
			PageQueryResult pageResult = getData();
			ResultMng.fillResultByList(
				getCommonQueryBean(),
				getCommQueryServletRequest(),
				pageResult.getQueryResult(),
				getResult());
			result.setContent(pageResult.getQueryResult());
			result.getPage().setTotalPage(1);
			result.init();
			return result;
		}catch(AppException appEx){
			throw appEx;
		}catch(Exception ex){
			throw new AppException(Module.SYSTEM_MODULE,
					Rescode.DEFAULT_RESCODE, ex.getMessage(),ex);
		}
	}

	@SuppressWarnings("rawtypes")
	private PageQueryResult getData() throws CommonException {
		Map paramsMap = this.getCommQueryServletRequest().getParameterMap();
		ROOTDAO rootDao = ROOTDAOUtils.getROOTDAO();
		PageQueryResult pageQueryResult = new PageQueryResult();
		//告警号
		String alertIds = StringEscapeUtils.escapeHtml((String) paramsMap.get("alertIds"));//转义HTML,注意汉字
		if(StringUtils.isBlank(alertIds)) {
			throw new NullPointerException();
		}

		//查询告警号对应的记录
        ArrayList<String> condList = new ArrayList<String>();
		condList.add(alertIds);
        List<AStaffAcctTradMRRB> taskList = rootDao.queryByCondition("from AStaffAcctTradMRRB where 1=1 and alertId = ?", condList.toArray());

	    pageQueryResult.setQueryResult(taskList);
		return pageQueryResult;
		//}
	}
}