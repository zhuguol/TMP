package com.huateng.report.hf.form.getter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.huateng.common.err.Module;
import com.huateng.common.err.Rescode;
import com.huateng.commquery.result.Result;
import com.huateng.commquery.result.ResultMng;
import com.huateng.ebank.business.common.GlobalInfo;
import com.huateng.ebank.business.common.PageQueryCondition;
import com.huateng.ebank.business.common.PageQueryResult;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.exceptions.CommonException;
import com.huateng.ebank.framework.report.common.ReportConstant;
import com.huateng.ebank.framework.util.DataFormat;
import com.huateng.ebank.framework.web.commQuery.BaseGetter;
import com.huateng.exception.AppException;

public class AStaffAcctTradRRBGetter extends BaseGetter {
	public Result call() throws AppException {
		try {
			PageQueryResult pageResult = getData();
			ResultMng.fillResultByList(getCommonQueryBean(),
					getCommQueryServletRequest(), pageResult.getQueryResult(),
					getResult());
			result.setContent(pageResult.getQueryResult());
			result.getPage().setTotalPage(pageResult.getPageCount(getResult().getPage().getEveryPage()));
			result.init();
			result.setTotal(pageResult.getTotalCount());
			this.setValue2DataBus(ReportConstant.QUERY_LOG_BUSI_NAME,"AML报表管理");
			return result;
		} catch (AppException appEx) {
			throw appEx;
		} catch (Exception ex) {
			throw new AppException(Module.SYSTEM_MODULE,
					Rescode.DEFAULT_RESCODE, ex.getMessage(), ex);
		}
	}

	private PageQueryResult getData() throws CommonException {
		int pageSize = getResult().getPage().getEveryPage();
		int pageIndex = getResult().getPage().getCurrentPage();
		ROOTDAO rootDAO = ROOTDAOUtils.getROOTDAO();
		PageQueryResult pageQueryResult = null;
		PageQueryCondition queryCondition = new PageQueryCondition();
		GlobalInfo gInfo = GlobalInfo.getCurrentInstance();
		StringBuilder hql = new StringBuilder(" select model from AStaffAcctTradRRB model where 1 = 1 ");
		Map<String, String> map = getCommQueryServletRequest().getParameterMap();
		//交易起始日期
		String etlDateStart = map.get("etlDateStart");
		//交易结束日期
		String etlDateEnd = map.get("etlDateEnd");
		//客户号
		String custNos = map.get("custNos");
		//客户名称/姓名
		String custNames = map.get("custNames");
		//客户身份证件号码
		String custIdCertNos = map.get("custIdCertNos");
		//调查阶段
		String statuss = map.get("statuss");
		//告警号
		String alertIds = map.get("alertIds");
		//员工编号
		String staffNumbers = map.get("staffNumbers");
		//记录状态
		String approveStatuss = map.get("approveStatuss");
		List<Object> paramentList = new ArrayList<Object>();
		if(!DataFormat.isEmpty(etlDateStart)){
			hql.append(" and model.dataDate >= ? ");
			paramentList.add(etlDateStart);
		}
		if(!DataFormat.isEmpty(etlDateEnd)){
			hql.append(" and model.dataDate <= ? ");
			paramentList.add(etlDateEnd);
		}
		if(!DataFormat.isEmpty(custNos)){
			hql.append(" and model.custNo like ? ");
			paramentList.add("%" + custNos + "%");
		}
		if(!DataFormat.isEmpty(custNames)){
			hql.append(" and model.custName like ? ");
			paramentList.add("%" + custNames + "%");
		}
		if(!DataFormat.isEmpty(custIdCertNos)){
			hql.append(" and model.custIdCertNo like ? ");
			paramentList.add("%" + custIdCertNos + "%");
		}
		if(!DataFormat.isEmpty(statuss)){
			hql.append(" and model.status = ? ");
			paramentList.add(statuss);
		}
		if(StringUtils.isNotBlank(alertIds)){
			hql.append(" and model.alertId like ? ");
			paramentList.add("%" + alertIds + "%");
		}
		
		if("01".equals(staffNumbers)){//"01"查询员工编号存在的信息
			hql.append(" and model.staffNumber is not null ");
		}else if("00".equals(staffNumbers)){//"02"查询员工编号不存在的信息
			hql.append(" and model.staffNumber is null ");
		}//02全部-查询所有的信息
		if(StringUtils.isNotBlank(approveStatuss)){
			hql.append(" and model.approveStatus = ? ");
			paramentList.add(approveStatuss);
		}
		
		//机构号
		hql.append(" and model.branCode = ? ");
		paramentList.add(gInfo.getBrno());
		
		hql.append(" order by model.dataDate asc , model.alertId asc ");
		queryCondition.setQueryString(hql.toString());
		queryCondition.setPageIndex(pageIndex);
		queryCondition.setPageSize(pageSize);
		queryCondition.setObjArray(paramentList.toArray());
		pageQueryResult = rootDAO.pageQueryByQL(queryCondition);
	    return pageQueryResult;
	}
}