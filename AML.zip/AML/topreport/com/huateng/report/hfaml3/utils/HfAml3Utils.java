package com.huateng.report.hfaml3.utils;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import resource.bean.report.AmlBhbsDs;
import resource.bean.report.AmlBhbsDsBak;
import resource.bean.report.AmlBhbsDsHis;
import resource.bean.report.SysParams;
import cn.cncc.cjdp.common.utils.DateUtils;

import com.huateng.ebank.business.common.GlobalInfo;
import com.huateng.ebank.business.common.PageQueryResult;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.entity.data.mng.DataDic;
import com.huateng.ebank.entity.data.mng.RoleInfo;
import com.huateng.ebank.framework.exceptions.CommonException;
import com.huateng.ebank.framework.util.DataFormat;
import com.huateng.ebank.framework.util.ExceptionUtil;
import com.huateng.report.common.service.ReportCommonService;
import com.huateng.report.constants.AMLConstants;
import com.huateng.report.hf.aml.bean.BiTreeDataDic;
import com.huateng.report.hf.aml.bean.MtsInOutCode;
import com.huateng.report.hf.aml.bs.bean.AmlBsUpload;
import com.huateng.report.hf.aml.bs.bean.AmlBsUploadBak;
import com.huateng.report.hf.aml.bs.bean.AmlBsUploadHis;
import com.huateng.report.hf.aml.utils.HsbcAmlUtils;
import com.huateng.report.hfaml3.vaild.AmlBhColunmValid;
import com.huateng.report.utils.ReportUtils;

public class HfAml3Utils {
	/**客户地址分隔符**/
	public static final String AML_CTAR_SEP="~";
	/**客户电话分隔符**/
	public static final String AML_PHONE_SEP=",";
	/**大额客户基本信息字段*
	 * 客户国籍、客户职业（对私）或客户行业（对公）、联系电话、客户住址/经营地址、客户其他联系方式
	 */
	public static final String CBIF="CTNT,CTVC,CCTL,CTAR,CCEI";
	/**大额客户身份信息字段*
	* 客户姓名/名称、客户身份证件/证明文件类型、其他身份证件/证明文件类型、客户身份证件/证明文件号码
	 */
	public static final String CCIF="CTNM,CITP,AOITP,CTID";
	/**大额交易信息字段**/
	public static final String TSDT="FINC,RLFC,CATP,CTAC,OATM,CBCT,OCBT,CBCN,TBNM,TBID,TBIT,BOITP,TBNT,TRCD,TRCDSUFFIX,RPMT,RPMN,TSTP,OCTT,OOCT,OCEC,BPTC,TSCT,TSDR,CRTP,CRAT,CRPP,CFIN,CFCT,CFIC,TCNM,CFRC,CFRCSUFFIX,TCIT,COITP,TCID,TCAT,TCAC,ROTF1,ROTF2";
	
	/**CIU部门编号**/
	public static final String ROLENAME="CIU";
	
	//获取部门名称 目前已角色名称作为部门名称
	public static String getDepartByUserId(String tlrno) throws CommonException {
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		String roleName = "";
		String sql = "select ROLE_ID from Tlr_Role_Rel where TLRNO = '" + tlrno
				+ "'";
		List<Object> list = rootdao.queryListBySql(sql);
		if (list.size() > 0) {
			roleName = rootdao.query(RoleInfo.class,
					Integer.valueOf(list.get(0).toString())).getRoleName();
		}
		if (roleName.indexOf(AMLConstants.AML_ROLE_SEP) != -1) {
			roleName = roleName.split(AMLConstants.AML_ROLE_SEP)[0];
		}
		return roleName;
	}
	
	//获取部门
	public static String getDepartByUserId() throws CommonException {
		GlobalInfo gi = GlobalInfo.getCurrentInstance();
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		String roleName = "";
		String sql = "select ROLE_ID from Tlr_Role_Rel where TLRNO = '" + gi.getTlrno()+"'";
		List<Object> list = rootdao.queryListBySql(sql);
		if (list.size() > 0) {
			roleName = rootdao.query(RoleInfo.class,Integer.valueOf(list.get(0).toString())).getRoleName();
		}
		if(roleName.indexOf(AMLConstants.AML_ROLE_SEP)!=-1){
			roleName = roleName.split(AMLConstants.AML_ROLE_SEP)[0];
		}
		return roleName;
	}
	
	//获取用户权限
	public static boolean[] getPowerByUserId() throws CommonException {
//		GlobalInfo gi = GlobalInfo.getCurrentInstance();
//		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
//		String rolePowerName = "";
//		String sql = "select ROLE_ID from Tlr_Role_Rel where TLRNO = '" + gi.getTlrno()+"'";
//		List<Object> list = rootdao.queryListBySql(sql);
//		if (list.size() > 0) {
//			rolePowerName = rootdao.query(RoleInfo.class,Integer.valueOf(list.get(0).toString())).getRoleName();
//		}
//		if(rolePowerName.indexOf(AMLConstants.AML_ROLE_SEP)!=-1){
//			rolePowerName = rolePowerName.split(AMLConstants.AML_ROLE_SEP)[1];
//		}
//		return rolePowerName;
		GlobalInfo gi = GlobalInfo.getCurrentInstance();
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		String sql = " SELECT A.FUNCID FROM TLR_ROLE_REL T LEFT JOIN ROLE_FUNC_REL A ON T.ROLE_ID = A.ROLE_ID WHERE T.TLRNO = '" + gi.getTlrno()+"'";
		List<String> list = rootdao.queryListBySql(sql);
		String[] todoBhStr = ReportCommonService.getInstance().getSysparamsByPk("AML3", "TODO_BH").getParamVal().split(",");
		String[] todoBhZcStr = ReportCommonService.getInstance().getSysparamsByPk("AML3", "TODO_BH_ZC").getParamVal().split(",");
		String[] todoBsZcStr = ReportCommonService.getInstance().getSysparamsByPk("AML3", "TODO_BS_ZC").getParamVal().split(",");
		//20200513 zgl 
		//汇丰中国HSBC员工交易调研情况
		String[] todoStaffStr = ReportCommonService.getInstance().getSysparamsByPk("AML3", "TODO_STAFF").getParamVal().split(",");
		//汇丰中国HSBC员工交易自查情况
		String[] todoStaffAStr = ReportCommonService.getInstance().getSysparamsByPk("AML3", "TODO_STAFS").getParamVal().split(",");
		//村镇行RRB员工交易调研情况
		String[] todoStaffARRB = ReportCommonService.getInstance().getSysparamsByPk("AML3", "TODO_STRRB").getParamVal().split(",");
		
		boolean[] bool = {false,false,false,false,false,false};
		//大额新增报文补录funid、大额修改报文补录funid、大额报文批量补录funid
		//操作员代办、部门代办
		for(int i=0;i<todoBhStr.length;i++){
			if(list.contains(todoBhStr[i])){
				bool[0] = true;
				break;
			}
		}
		//大额交易自查手工抽取funid、大额交易自查审核funid
		//大额交易自查
		for(int i=0;i<todoBhZcStr.length;i++){
			if(list.contains(todoBhZcStr[i])){
				bool[1] = true;
				break;
			}
		}
		//可疑交易自查手工抽取funid、可疑交易自查审核funid
		//可疑交易自查
		for(int i=0;i<todoBsZcStr.length;i++){
			if(list.contains(todoBsZcStr[i])){
				bool[2] = true;
				break;
			}
		}
		
		//员工交易监测日报funid、员工交易监测月报funid
		//汇丰中国HSBC员工交易监测调研
		for(int i=0;i<todoStaffStr.length;i++){
			if(list.contains(todoStaffStr[i])){
				bool[3] = true;
				break;
			}
		}
		
		//汇丰中国HSBC员工交易自查
		for(int i=0;i<todoStaffAStr.length;i++){
			if(list.contains(todoStaffAStr[i])){
				bool[4] = true;
				break;
			}
		}
		
		//村镇行RRB员工交易监测调研
		for(int i=0;i<todoStaffARRB.length;i++){
			if(list.contains(todoStaffARRB[i])){
				bool[5] = true;
				break;
			}
		}
		return bool;
	}
	
	// 根据交易金额、日期和币种计算对应的人民币和美元金额
	public static AmlBhbsDs calAmounyt(AmlBhbsDs amlBH) throws CommonException {
		String tstm = amlBH.getTstm();//交易时间
		String crtp = amlBH.getCrtp();//币种
		BigDecimal crat = amlBH.getCrat();//交易金额
		DecimalFormat df = new DecimalFormat("#.000");
		if (crtp != null && crtp.trim().length() > 0 && crat != null&& tstm != null && tstm.trim().length() > 0) {
			String exchangeRate = getExchangeRate(tstm.substring(0, 8), crtp);//获取汇率相对美元汇率
			if (exchangeRate.length() > 0) {
				BigDecimal traAmountUsd = crat.multiply(new BigDecimal(exchangeRate));//相乘，汇率
				amlBH.setTraAmountUsd(new BigDecimal(df.format(traAmountUsd.doubleValue())));//交易金额转美元
				if ("CNY".equals(crtp)) {
					amlBH.setTraAmountCny(crat);
				} else {
					exchangeRate = getExchangeRate(tstm.substring(0, 8), "CNY");//汇率
					if (exchangeRate.length() > 0) {
						BigDecimal traAmountCny = traAmountUsd.divide(new BigDecimal(exchangeRate), 8, BigDecimal.ROUND_HALF_UP);//相除， 8为要返回的 BigDecimal 商的标度，BigDecimal.ROUND_HALF_UP为要应用的舍入模式
						amlBH.setTraAmountCny(new BigDecimal(df.format(traAmountCny.doubleValue())));//交易金额转人民币
					}
				}
			}
		}
		return amlBH;
	}
	
	// 获取汇率 相对美元汇率
	public static String getExchangeRate(String date, String crtp) throws CommonException {
		String exchangeRate = "";
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		String sql = " SELECT YHDS50 FROM AML_HUB_SSSTDPP WHERE TO_CHAR(ETL_DATE,'YYYYMMDD')='"
				+ date + "' AND YHCODE='" + crtp + "' AND YHTBID='X4' ";
		List list = rootdao.queryListBySql(sql);
		if (list.size() > 0) {
			exchangeRate = list.get(0).toString();
		} else {
			throw new CommonException("缺少交易日的汇率信息！");
		}
		return exchangeRate;
	}

	/**
	 * 3号令补录查询页面  - 批量上报
	 * 
	 */
	public static boolean amlBHValid(AmlBhbsDs amlBhbsDs,AmlBhColunmValid amlBhColunmValid) throws CommonException {
		Map<String, String> reulst = amlBhColunmValid.executeDataVaild(amlBhbsDs);
		if (reulst != null && reulst.size() > 0) {
			return false;
		} else {
			return true;
		}
	}
	
	/**
	 * 3号令补录详细页面 -  确认补录完成和上报时的校验
	 * 
	 */
	public static String[] amlBHValid2(AmlBhbsDs amlBhbsDs) throws CommonException {
		AmlBhColunmValid amlBhColunmValid = new AmlBhColunmValid();
		Map<String, String> reulst = amlBhColunmValid.executeDataVaild(amlBhbsDs);//3号令大额验证规则
		StringBuffer result1=new StringBuffer();
		StringBuffer result2=new StringBuffer();
		for (String key : reulst.keySet()) {
			result1.append(key).append("    ");
			result1.append(reulst.get(key)).append("    ");
			result2.append(reulst.get(key));
		}
		return new String[]{result1.toString(),result2.toString()};
	}
	
	/**
	 * 3号令页面新增数据转换
	 * 
	 * @param type
	 *            新增、复制新增后操作类型 0-暂存 1-确认补录完成 2-上报
	 */
	public static AmlBhbsDs amlBHDsInsertSetValue(AmlBhbsDs amlBH, String type) throws CommonException {
		ROOTDAO rootDao = ROOTDAOUtils.getROOTDAO();
		String guid = ReportUtils.getUUID();
		GlobalInfo globalInfo = GlobalInfo.getCurrentInstance();
		// 基础信息
		amlBH.setId(guid);//获取新增ID
		amlBH.setCrtTm(new Date());
		amlBH.setBrNo(globalInfo.getBrno()); // 机构编号
		amlBH.setRoleName(HsbcAmlUtils.getDepartByUserId(globalInfo.getTlrno())); // 部门编号
		amlBH.setWorkDate(amlBH.getHtdt() == null ? "" : amlBH.getHtdt());
		amlBH.setApptype(AMLConstants.REPORT_APP_TYPE_AML);
		amlBH.setRepStatus(AMLConstants.AML_REPSTATUS_01);
		amlBH.setSubSuccess(AMLConstants.REPORT_IS_SUB_SUCCESS_NO);
		amlBH.setCurrentfile(AMLConstants.REPORT_FILE_TYPE_AML_BH);
		amlBH.setIsDel("0");// 删除标示设置为 0-未删除
		if ("1".equals(type)) {
			amlBH.setRecStatus(AMLConstants.REPORT_RECSTATUS_02);//02-已补录待上报
			amlBH.setIsComp("1");//完整性
		} else if ("2".equals(type)) {
			// 补录详细页面上报普通报文记录状态03，特殊报文记录状态05
			if ("N".equals(amlBH.getReportType())) {
				amlBH.setRecStatus(AMLConstants.REPORT_RECSTATUS_03);//03-已上报待校验
			} else {
				amlBH.setRecStatus(AMLConstants.REPORT_RECSTATUS_05);//05-校验通过
			}
			amlBH.setIsComp("1");//完整性
		} else {
			amlBH.setRecStatus(AMLConstants.REPORT_RECSTATUS_99);//暂存
			amlBH.setIsComp("0");//完整性
		}
		amlBH.setSourceType("1"); // 数据来源 1-手工新增
		amlBH.setRecordUpdTlr(globalInfo.getTlrno());
		amlBH.setRecordUpdTm(new Date());
		amlBH.setLstUpdTlr(globalInfo.getTlrno());
		amlBH.setLstUpdTm(new Date());	
		// 业务标识拼接（手工新增的后拼M）
		amlBH.setTicd(amlBH.getTicd() + "M");
		// 添加校验业务标识号是否重复 
		String[] para = new String[1];
		para[0] = amlBH.getTicd();
		StringBuffer hql = new StringBuffer("from AmlBhbsDs s where 1=1 AND s.ticd = ?");
		List<AmlBhbsDs> result = rootDao.queryByQL2List(hql.toString(), para);
		if (result != null && result.size() > 0) {
			ExceptionUtil.throwCommonException("该业务标识号已经存在",AMLConstants.REPORT_APP_TYPE_AML + "_"+ AMLConstants.REPORT_FILE_TYPE_AML_BH + "_ERR");
		}
		return amlBH;
	}
	
	/**
	 * 3号令页面补录数据转换
	 * 
	 * @param type
	 *            补录后操作类型 0-暂存 1-确认补录完成 2-上报
	 */
	public static AmlBhbsDs amlBHDsUpdateSetValue(AmlBhbsDs amlBH, String type) throws CommonException {
		GlobalInfo globalInfo = GlobalInfo.getCurrentInstance();
		amlBH.setWorkDate(amlBH.getHtdt() == null ? "" : amlBH.getHtdt());
		amlBH.setRecordUpdTlr(globalInfo.getTlrno());
		amlBH.setRecordUpdTm(new Date());
		amlBH.setLstUpdTlr(globalInfo.getTlrno());
		amlBH.setLstUpdTm(new Date());
		if ("1".equals(type)) {
			amlBH.setRecStatus(AMLConstants.REPORT_RECSTATUS_02);
			amlBH.setIsComp("1");
		} else if ("2".equals(type)) {
			// 补录详细页面上报普通报文记录状态03，特殊报文记录状态05
			if ("N".equals(amlBH.getReportType())) {
				amlBH.setRecStatus(AMLConstants.REPORT_RECSTATUS_03);
			} else {
				amlBH.setRecStatus(AMLConstants.REPORT_RECSTATUS_05);
			}
			amlBH.setIsComp("1");
		} else {
			amlBH.setRecStatus(AMLConstants.REPORT_RECSTATUS_99);
			amlBH.setIsComp("0");
		}
		return amlBH;
	}
	
	
	/**
	 * 3号令 - 批量更新客户信息（补录详细页面的确认补录完成和上报用到）
	 */
	public static void updateCustInfo(AmlBhbsDs amlBH, GlobalInfo globalInfo,ROOTDAO rootDao) throws CommonException {
		// 修改时改动了客户信息，则更新当天所有交易的客户信息
		String csnm = amlBH.getCsnm();// 客户号
		String htdt = amlBH.getHtdt();// 交易发生日期
		// 需要更新的字段
		String ctnm = amlBH.getCtnm();// 客户名称
		String citp = amlBH.getCitp();// 客户身份证件/证明文件类型
		String ctid = amlBH.getCtid();// 客户身份证件/证明文件号码
		String aoitp = amlBH.getAoitp();// 客户其他证明类型/证件类型进一步说明
		String ctnt = amlBH.getCtnt();// 客户国籍
		String ctvc = amlBH.getCtvc();// 客户职业（对私）或客户行业（对公）
		String cctl = amlBH.getCctl();// 客户联系电话
		String ctar = amlBH.getCtar();// 客户住址
		String ccei = amlBH.getCcei();// 客户其他联系方式
		SessionFactory sessionFactory = rootDao.getSessionFactory();
		Session session = sessionFactory.openSession();
		Query query = session
				.createQuery(" update AmlBhbsDs data set data.ctnm = :ctnm ,data.citp = :citp ,data.ctid = :ctid ,data.aoitp = :aoitp ,data.ctnt = :ctnt ,"
						+ "data.ctvc = :ctvc ,data.cctl = :cctl ,data.ctar = :ctar ,data.ccei = :ccei where data.csnm = :csnm and data.htdt = :htdt and data.brNo = :brNo and data.lstUpdTlr = :lstUpdTlr  and data.recStatus in ('01','99')");
		query.setString("ctnm", ctnm);
		query.setString("citp", citp);
		query.setString("ctid", ctid);
		query.setString("aoitp", aoitp);
		query.setString("ctnt", ctnt);
		query.setString("ctvc", ctvc);
		query.setString("cctl", cctl);
		query.setString("ctar", ctar);
		query.setString("ccei", ccei);
		query.setString("csnm", csnm);
		query.setString("htdt", htdt);
		query.setString("brNo", globalInfo.getBrno());
		query.setString("lstUpdTlr", globalInfo.getTlrno());
		query.executeUpdate();
		session.close();
	}
	
	
	/**
	 * 3号令 - 大额对象需要比对的属性（修改报文和批量补录用到）
	 */
	public static Map<String, String> getBHClos() throws CommonException {
		Map<String, String> cols = new HashMap<String, String>();
		cols.put("ctnm", "CTNM");//客户名称
		cols.put("citp", "CITP");//客户身份证件类型
		cols.put("aoitp", "AOITP");//客户其他身份证件类型
		cols.put("ctnt", "CTNT");//客户国籍
		cols.put("ctvc", "CTVC");//客户职业（对私）或客户行业（对公）
		cols.put("cctl", "CCTL");//联系电话
		cols.put("ctar", "CTAR");//客户住址/经营地址
		cols.put("ccei", "CCEI");//客户其他联系方式
		cols.put("ctid", "CTID");//客户证件号码
		
		cols.put("finc", "FINC");//金融机构网点代码
		cols.put("rlfc", "RLFC");//金融机构与客户的关系
		
		cols.put("catp", "CATP");//账户类型
		cols.put("ctac", "CTAC");//账号
		cols.put("oatm", "OATM");//客户账户开户时间
		cols.put("cbct", "CBCT");//客户银行卡类型
		cols.put("ocbt", "OCBT");//客户银行卡其他类型
		cols.put("cbcn", "CBCN");//客户银行卡号码
		
		cols.put("tbnm", "TBNM");//交易代办人姓名
		cols.put("tbid", "TBID");//代办人身份证件/证明文件号码
		cols.put("tbit", "TBIT");//交易代办人身份证件/证明文件类型
		cols.put("boitp", "BOITP");//交易代办人其他身份证件/证明文件类型
		cols.put("tbnt", "TBNT");//代办人国籍
		
		
		cols.put("trcd", "TRCD");//交易发生地
		cols.put("trcdSuffix", "TRCDSUFFIX");//交易发生地
		cols.put("rpmt", "RPMT");//收付款方匹配号类型
		cols.put("rpmn", "RPMN");//收付款方匹配号
		cols.put("tstp", "TSTP");//交易方式
		cols.put("octt", "OCTT");//非柜台交易方式
		cols.put("ooct", "OOCT");//其他非柜台交易方式
		cols.put("ocec", "OCEC");//非柜台交易方式的设备代码
		cols.put("bptc", "BPTC");//银行与支付机构之间的业务交易编码
		cols.put("tsct", "TSCT");//涉外收支交易分类与代码
		cols.put("tsdr", "TSDR");//资金收付
		cols.put("crtp", "CRTP");//币种
		cols.put("crat", "CRAT");//金额
		cols.put("crpp", "CRPP");//资金用途
		
		cols.put("cfin", "CFIN");//对方金融机构网点名称
		cols.put("cfct", "CFCT");//对方金融机构代码网点类型
		cols.put("cfic", "CFIC");//对方金融机构网点代码
		cols.put("tcnm", "TCNM");//交易对手姓名/名称
		cols.put("cfrc", "CFRC");//对方金融机构网点行政区划代码
		cols.put("cfrcSuffix", "CFRCSUFFIX");//对方金融机构网点行政区划代码
		cols.put("tcit", "TCIT");//交易对手身份证件/证明文件类型
		cols.put("coitp", "COITP");//交易对手其他身份证件/证明文件类型
		cols.put("tcid", "TCID");//交易对手身份证件/证明文件号码
		cols.put("tcat", "TCAT");//交易对手账户类型
		cols.put("tcac", "TCAC");//交易对手账号
		cols.put("rotf1", "ROTF1");//交易信息备注
		cols.put("rotf2", "ROTF2");//交易信息备注
		return cols;
	}
	
	 //获取证件类型Map
    public static Map getZjlxMap() throws CommonException{
    	Map map = new HashMap();
    	ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
    	String hql = "from DataDic where dataTypeNo = '158'";
		List<DataDic> list = rootdao.queryByQL2List(hql);
		for(DataDic bean:list){
			map.put(bean.getDataNo(), bean.getDataName());
		}
    	return map;
    }
	
	 //获取账户类型Map
    public static Map getZhlxMap() throws CommonException{
    	Map map = new HashMap();
    	ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
    	String hql = "from DataDic where dataTypeNo = '3004'";
		List<DataDic> list = rootdao.queryByQL2List(hql);
		for(DataDic bean:list){
			map.put(bean.getDataNo(), bean.getDataName());
		}
    	return map;
    }
    
    //获取交易方式Map
    public static Map getJyfsMap() throws CommonException{
    	Map map = new HashMap();
    	ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
    	String hql = "from BiTreeDataDic where codetype ='TSTP'";;
		List<BiTreeDataDic> list = rootdao.queryByQL2List(hql);
		for(BiTreeDataDic bean:list){
			map.put(bean.getDatacode(), bean.getDatacode()+"-"+bean.getDataname());
		}
    	return map;
    }
    
    //获取涉外收支Map
    public static Map getSwszMap() throws CommonException{
    	Map map = new HashMap();
    	ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
    	String hql = "from MtsInOutCode ";;
		List<MtsInOutCode> list = rootdao.queryByQL2List(hql);
		for(MtsInOutCode bean:list){
			map.put(bean.getId().getId(), bean.getName());
		}
    	return map;
    }
    
    /**
	 * null判断
	 */
	public static String isNull(String str){
		if(str==null){
			return "";
		}
		return str;
	}
	
	/**
	 * null判断  日期装换
	 */
	public static String isNullDate(Date date){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		if(date==null){
			return "";
		}
		return sdf.format(date);
	}
	
	/**
	 * null判断  时间装换
	 */
	public static String isNullTime(Date date){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		if(date==null){
			return "";
		}
		return sdf.format(date);
	}

	/**
	 * 导出的数据字典项转换
	 */
	public static String getDataDic(String dataNo, String dataTypeNo) {
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		String dataName = null;
		if (StringUtils.isEmpty(dataNo) || StringUtils.isEmpty(dataTypeNo)) {
			return dataNo;
		}
		String hql = "from DataDic where dataTypeNo = '" + dataTypeNo+ "' and dataNo ='" + dataNo + "'";
		List<DataDic> list = null;
		try {
			list = rootdao.queryByQL2List(hql);
		} catch (CommonException e) {
			e.printStackTrace();
		}
		if (list.size() > 0) {
			dataName = list.get(0).getDataName();
		} else {
			dataName = dataNo;
		}
		return dataName;
	}
	
	/**
	 * MTS_IN_OUT_CODE  涉外收支代码转换
	 */
	public static String getTreeDataDic(String tableName, String id) {
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		String dataName = null;
		if (StringUtils.isEmpty(tableName) || StringUtils.isEmpty(id)) {
			return id;
		}
		String sql = "SELECT c.ID||'-'||c.CODE_NAME from " + tableName + " c where c.ID = '" + id + "'";
		List<String> list = null;
		try {
			list = rootdao.queryListBySql(sql);
		} catch (CommonException e) {
			e.printStackTrace();
		}
		if (list.size() > 0) {
			dataName = list.get(0);
		} else {
			dataName = id;
		}
		return dataName;
	}

	/**
	 * SYS_CURRENCY  币种转换
	 */
	public static String getTreeDataDic2(String tableName, String currencyCode) {
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		String dataName = null;
		if (StringUtils.isEmpty(tableName) || StringUtils.isEmpty(currencyCode)) {
			return currencyCode;
		}
		String sql = "SELECT c.CURRENCY_CODE||'-'||c.CURRENCY_NAME from " + tableName + " c where c.CURRENCY_CODE = '" + currencyCode + "'";
		List<String> list = null;
		try {
			list = rootdao.queryListBySql(sql);
		} catch (CommonException e) {
			e.printStackTrace();
		}
		if (list.size() > 0) {
			dataName = list.get(0);
		} else {
			dataName = currencyCode;
		}
		return dataName;
	}
	
	/**
	 * 大额备份表数据copy到补录表（用于生成大额纠错报文/删除报文）
	 * 
	 */
	public static AmlBhbsDs amlBHbakToBH(GlobalInfo gi ,String specialType,AmlBhbsDsBak amlBhbsDsBak) throws CommonException {
		SysParams param = ReportCommonService.getInstance().getSysparamsByPk("RoleName", gi.getBrno());
		String RoleName = param == null ? amlBhbsDsBak.getRoleName() : param.getParamVal();
		AmlBhbsDs amlBhbsDs = new AmlBhbsDs();
		amlBhbsDs.setId(ReportUtils.getUUID()); // 设置主键
		amlBhbsDs.setApptype(amlBhbsDsBak.getApptype());
		amlBhbsDs.setCurrentfile(amlBhbsDsBak.getCurrentfile());
		amlBhbsDs.setBrNo(amlBhbsDsBak.getBrNo());
		amlBhbsDs.setRoleName(RoleName);
		amlBhbsDs.setWorkDate(amlBhbsDsBak.getWorkDate());
		amlBhbsDs.setReportType(specialType); // 设置报文类型 C-纠错 D-删除
		amlBhbsDs.setRinm(amlBhbsDsBak.getRinm());
		amlBhbsDs.setRicd(amlBhbsDsBak.getRicd());
		amlBhbsDs.setRpdt(amlBhbsDsBak.getRpdt());
		amlBhbsDs.setCsnm(amlBhbsDsBak.getCsnm());
		amlBhbsDs.setCtnm(amlBhbsDsBak.getCtnm());
		amlBhbsDs.setCitp(amlBhbsDsBak.getCitp());
		amlBhbsDs.setCtid(amlBhbsDsBak.getCtid());
		amlBhbsDs.setAoitp(amlBhbsDsBak.getAoitp());
		amlBhbsDs.setCtnt(amlBhbsDsBak.getCtnt());
		amlBhbsDs.setCtvc(amlBhbsDsBak.getCtvc());
		amlBhbsDs.setCctl(amlBhbsDsBak.getCctl());
		amlBhbsDs.setCtar(amlBhbsDsBak.getCtar());
		amlBhbsDs.setCcei(amlBhbsDsBak.getCcei());
		amlBhbsDs.setCbct(amlBhbsDsBak.getCbct());
		amlBhbsDs.setOcbt(amlBhbsDsBak.getOcbt());
		amlBhbsDs.setCbcn(amlBhbsDsBak.getCbcn());
		amlBhbsDs.setHtdt(amlBhbsDsBak.getHtdt());
		amlBhbsDs.setCrcd(amlBhbsDsBak.getCrcd());
		amlBhbsDs.setFinn(amlBhbsDsBak.getFinn());
		amlBhbsDs.setFirc(amlBhbsDsBak.getFirc());
		amlBhbsDs.setRltp(amlBhbsDsBak.getRltp());
		amlBhbsDs.setFict(amlBhbsDsBak.getFict());
		amlBhbsDs.setFinc(amlBhbsDsBak.getFinc());
		amlBhbsDs.setRlfc(amlBhbsDsBak.getRlfc());
		amlBhbsDs.setCatp(amlBhbsDsBak.getCatp());
		amlBhbsDs.setCtac(amlBhbsDsBak.getCtac());
		amlBhbsDs.setOatm(amlBhbsDsBak.getOatm());
		amlBhbsDs.setTbnm(amlBhbsDsBak.getTbnm());
		amlBhbsDs.setTbit(amlBhbsDsBak.getTbit());
		amlBhbsDs.setTbid(amlBhbsDsBak.getTbid());
		amlBhbsDs.setBoitp(amlBhbsDsBak.getBoitp());
		amlBhbsDs.setTbnt(amlBhbsDsBak.getTbnt());
		amlBhbsDs.setTstm(amlBhbsDsBak.getTstm());
		amlBhbsDs.setTicd(amlBhbsDsBak.getTicd());
		amlBhbsDs.setRpmt(amlBhbsDsBak.getRpmt());
		amlBhbsDs.setRpmn(amlBhbsDsBak.getRpmn());
		amlBhbsDs.setTstp(amlBhbsDsBak.getTstp());
		amlBhbsDs.setOctt(amlBhbsDsBak.getOctt());
		amlBhbsDs.setOoct(amlBhbsDsBak.getOoct());
		amlBhbsDs.setOcec(amlBhbsDsBak.getOcec());
		amlBhbsDs.setBptc(amlBhbsDsBak.getBptc());
		amlBhbsDs.setTsct(amlBhbsDsBak.getTsct());
		amlBhbsDs.setTsdr(amlBhbsDsBak.getTsdr());
		amlBhbsDs.setTdrc(amlBhbsDsBak.getTdrc());
		amlBhbsDs.setTrcd(amlBhbsDsBak.getTrcd());
		amlBhbsDs.setTrcdSuffix(amlBhbsDsBak.getTrcdSuffix());
		amlBhbsDs.setCrpp(amlBhbsDsBak.getCrpp());
		amlBhbsDs.setCrtp(amlBhbsDsBak.getCrtp());
		amlBhbsDs.setCrat(amlBhbsDsBak.getCrat());
		amlBhbsDs.setTraAmountCny(amlBhbsDsBak.getTraAmountCny());
		amlBhbsDs.setTraAmountUsd(amlBhbsDsBak.getTraAmountUsd());
		amlBhbsDs.setCfin(amlBhbsDsBak.getCfin());
		amlBhbsDs.setCfct(amlBhbsDsBak.getCfct());
		amlBhbsDs.setCfic(amlBhbsDsBak.getCfic());
		amlBhbsDs.setCfrc(amlBhbsDsBak.getCfrc());
		amlBhbsDs.setCfrcSuffix(amlBhbsDsBak.getCfrcSuffix());
		amlBhbsDs.setTcnm(amlBhbsDsBak.getTcnm());
		amlBhbsDs.setTcit(amlBhbsDsBak.getTcit());
		amlBhbsDs.setTcid(amlBhbsDsBak.getTcid());
		amlBhbsDs.setCoitp(amlBhbsDsBak.getCoitp());
		amlBhbsDs.setTcat(amlBhbsDsBak.getTcat());
		amlBhbsDs.setTcac(amlBhbsDsBak.getTcac());
		amlBhbsDs.setRotf1(amlBhbsDsBak.getRotf1());
		amlBhbsDs.setRotf2(amlBhbsDsBak.getRotf2());
		amlBhbsDs.setMirs(amlBhbsDsBak.getMirs());
		amlBhbsDs.setTmlm(amlBhbsDsBak.getTmlm());
		amlBhbsDs.setRqds(amlBhbsDsBak.getRqds());
//		amlBhbsDs.setNumber1(amlBhbsDsBak.getNumber1());
//		amlBhbsDs.setNumber2(amlBhbsDsBak.getNumber2());
//		amlBhbsDs.setNumber3(amlBhbsDsBak.getNumber3());
//		amlBhbsDs.setXmlfilename(amlBhbsDsBak.getXmlfilename());
//		amlBhbsDs.setZipfilename(amlBhbsDsBak.getZipfilename());
//		amlBhbsDs.setErrmsg(amlBhbsDsBak.getErrmsg());
		amlBhbsDs.setSubSuccess(amlBhbsDsBak.getSubSuccess());
		amlBhbsDs.setIsDel(amlBhbsDsBak.getIsDel());
		amlBhbsDs.setIsComp(amlBhbsDsBak.getIsComp());
		amlBhbsDs.setSourceType(amlBhbsDsBak.getSourceType());
		if (AMLConstants.AML_REPORT_TYPE_DBH.equals(specialType)) {
			amlBhbsDs.setRecStatus(AMLConstants.REPORT_RECSTATUS_05); // 删除报文初始化
		} else {
			amlBhbsDs.setRecStatus(AMLConstants.REPORT_RECSTATUS_01); // 纠错报文初始化
		}
		amlBhbsDs.setRepStatus(AMLConstants.AML_REPSTATUS_01); // 回执状态01-未返回
		amlBhbsDs.setCrtTm(new Date());
		amlBhbsDs.setLstUpdTlr(amlBhbsDsBak.getLstUpdTlr());
		amlBhbsDs.setLstUpdTm(amlBhbsDsBak.getLstUpdTm());
		amlBhbsDs.setFiller1(amlBhbsDsBak.getFiller1());
		amlBhbsDs.setFiller2(amlBhbsDsBak.getFiller2());
		amlBhbsDs.setFiller3(amlBhbsDsBak.getFiller3());
		amlBhbsDs.setExtractPerson(amlBhbsDsBak.getExtractPerson());
		//20171213 add by ywc 
		amlBhbsDs.setApproveUpdTlr(amlBhbsDsBak.getApproveUpdTlr());
		amlBhbsDs.setApproveUpdTm(amlBhbsDsBak.getApproveUpdTm());
		//20191031 原客户号
		amlBhbsDs.setCsnmold(amlBhbsDsBak.getCsnmold());
		return amlBhbsDs;

	}
	
	/**
	 * 可疑备份表数据copy到补录表（用于生成可疑纠错报文）
	 * 
	 * @param specialType
	 *            生成报文类型 C-纠错AmlBsUploadBak 备份表对象
	 */
	public static AmlBsUpload amlBSbakToBS(String specialType,
			AmlBsUploadBak amlBsUploadBak,ROOTDAO rootdao) throws CommonException {
		int newreportId = getMaxBatchNo() + 1;
        String newworkDate = DateUtils.getDateTime("yyyyMMdd", new Date());
		AmlBsUpload amlBsUpload = new AmlBsUpload();
		amlBsUpload.setId(ReportUtils.getUUID()); // 设置主键
		amlBsUpload.setReportId(newreportId);
		amlBsUpload.setBrno(amlBsUploadBak.getBrno());
		amlBsUpload.setReportType(specialType);//报文类型
		amlBsUpload.setFinm(amlBsUploadBak.getFinm());
		amlBsUpload.setFirc(amlBsUploadBak.getFirc());
		amlBsUpload.setFict(amlBsUploadBak.getFict());
		amlBsUpload.setFicd(amlBsUploadBak.getFicd());
		amlBsUpload.setWorkDate(newworkDate);
		amlBsUpload.setStcr(amlBsUploadBak.getStcr());
		amlBsUpload.setSsdg(amlBsUploadBak.getSsdg());
		amlBsUpload.setTkms(amlBsUploadBak.getTkms());
		amlBsUpload.setSsds(amlBsUploadBak.getSsds());
		amlBsUpload.setXmlnm(amlBsUploadBak.getXmlnm());
		amlBsUpload.setZipnm(amlBsUploadBak.getZipnm());
		amlBsUpload.setRecStatus(AMLConstants.REPORT_RECSTATUS_01);// 纠错报文初始化 01-待补录
		amlBsUpload.setRepStatus(AMLConstants.AML_REPSTATUS_01);// 回执状态01-未返回
		//amlBsUpload.setApproveStatus(amlBsUploadBak.getApproveStatus());
		amlBsUpload.setIssubsuccess(AMLConstants.REPORT_IS_SUB_SUCCESS_NO);// 是否成功上报  0-否
		//amlBsUpload.setApproveResult(amlBsUploadBak.getApproveResult());
		amlBsUpload.setLstUpdTlr(amlBsUploadBak.getLstUpdTlr());
		amlBsUpload.setLstUpdTm(amlBsUploadBak.getLstUpdTm());
		amlBsUpload.setIscomp(amlBsUploadBak.getIscomp());
//		amlBsUpload.setErrmsg(amlBsUploadBak.getErrmsg());
//		amlBsUpload.setMirs(amlBsUploadBak.getMirs());
//		amlBsUpload.setTmlm(amlBsUploadBak.getTmlm());
//		amlBsUpload.setRqds(amlBsUploadBak.getRqds());
		amlBsUpload.setCusNum(amlBsUploadBak.getCusNum());
		amlBsUpload.setTransNum(amlBsUploadBak.getTransNum());
		amlBsUpload.setRicd(amlBsUploadBak.getRicd());
		amlBsUpload.setRpnc(amlBsUploadBak.getRpnc());
		amlBsUpload.setDetr(amlBsUploadBak.getDetr());
		amlBsUpload.setTorp(amlBsUploadBak.getTorp());
		amlBsUpload.setDorp(amlBsUploadBak.getDorp());
		amlBsUpload.setOdrp(amlBsUploadBak.getOdrp());
		amlBsUpload.setTptr(amlBsUploadBak.getTptr());
		amlBsUpload.setOtpr(amlBsUploadBak.getOtpr());
		amlBsUpload.setStcb(amlBsUploadBak.getStcb());
		amlBsUpload.setStcb2(amlBsUploadBak.getStcb2());
		amlBsUpload.setStcb3(amlBsUploadBak.getStcb3());
		amlBsUpload.setAosp(amlBsUploadBak.getAosp());
		amlBsUpload.setAosp2(amlBsUploadBak.getAosp2());
		amlBsUpload.setAosp3(amlBsUploadBak.getAosp3());
		amlBsUpload.setTosc(amlBsUploadBak.getTosc());
		amlBsUpload.setFiller1(amlBsUploadBak.getFiller1());
		amlBsUpload.setFiller2(amlBsUploadBak.getFiller2());
		amlBsUpload.setFiller3(amlBsUploadBak.getFiller3());
		amlBsUpload.setFiller4(amlBsUploadBak.getFiller4());
		amlBsUpload.setFiller5(amlBsUploadBak.getFiller5());
		amlBsUpload.setFiller6(amlBsUploadBak.getFiller6());
		amlBsUpload.setOrxn(amlBsUploadBak.getOrxn());
		amlBsUpload.setBsid(amlBsUploadBak.getBsid());//可疑案件编号
		amlBsUpload.setRpnm(amlBsUploadBak.getRpnm());//填报人
		reSetCusAndTrad (newreportId,newworkDate,rootdao,amlBsUploadBak);
		return amlBsUpload;
	}
	
	public static void reSetCusAndTrad (int newReportId,String newworkDate,ROOTDAO rootdao,AmlBsUploadBak amlBsUploadBak) throws CommonException {
		String cust = "insert into Aml_Bs_Cus_Upload t " +
    			"    (t.REC_ID,t.report_id,t.work_date,t.SENM,t.SETP,t.OITP,t.CITPDESC,t.SEID," +
    			"    t.CSNM,t.CTTP,t.SCTL,t.SEAR,t.SEEI,t.STNT,t.SEVC,t.RGCP,t.SRNM,t.SRIT,t.ORIT," +
    			"    t.CRITDESC,t.SRID,t.SCNM,t.SCIT,t.OCIT,t.SCID,t.NUM,t.IS_COMP,t.ERRMSG,t.YWTX) "+
    			"    select sys_guid() as REC_ID,'"+newReportId+"' as report_id,'"+newworkDate+"' as work_date," +
    			"   a.SENM,a.SETP,a.OITP,a.CITPDESC,a.SEID,a.CSNM,a.CTTP,a.SCTL,a.SEAR,a.SEEI," +
    			"   a.STNT,a.SEVC,a.RGCP,a.SRNM,a.SRIT,a.ORIT,a.CRITDESC,a.SRID,a.SCNM,a.SCIT," +
    			"   a.OCIT,a.SCID,a.NUM,a.IS_COMP,a.ERRMSG,a.YWTX from Aml_Bs_Cus_Upload_his a "+
    			"   where a.report_id="+amlBsUploadBak.getReportId()+" and a.work_date='"+amlBsUploadBak.getWorkDate()+"'";
    	
    	
    	String trans = "insert into Aml_Bs_Trans_Upload t " +
    			"    (t.REC_ID,t.report_id,t.work_date,t.FINC,t.RLFC,t.CSNM,t.CTNM,t.CITP,t.AOITP,t.CITPDESC,t.CTID,t.CATP,t.CTAC,t.OATM," +
    			"    t.CATM,t.CBCT,t.OCBT,t.CBCN,t.TBNM,t.TBIT,t.BOITP,t.BITPDESC,t.TBID,t.TBNT,t.TSTM," +
    			"    t.TRCD,t.TRCDSUFFIX,t.TICD,t.RPMT,t.RPMN,t.TSTP,t.OCTT,t.OOCT,t.OCEC,t.BPTC,t.TSCT," +
    			"    t.TSDR,t.CRSP,t.CRTP,t.CRAT,t.CFIN,t.CFCT,t.CFIC,t.CFRC,t.CFRCSUFFIX,t.TCNM,t.TCIT," +
    			"    t.COITP,t.TCITDESC,t.TCID,t.TCAT,t.TCAC,t.ROTF1,t.ROTF2,t.NUM,t.IS_COMP,t.ERRMSG) "+
    			"    select sys_guid() as REC_ID,'"+newReportId+"' as report_id,'"+newworkDate+"' as work_date," +
    			"    a.FINC,a.RLFC,a.CSNM,a.CTNM,a.CITP,a.AOITP,a.CITPDESC,a.CTID,a.CATP,a.CTAC,a.OATM," +
    			"    a.CATM,a.CBCT,a.OCBT,a.CBCN,a.TBNM,a.TBIT,a.BOITP,a.BITPDESC,a.TBID,a.TBNT,a.TSTM," +
    			"    a.TRCD,a.TRCDSUFFIX,a.TICD,a.RPMT,a.RPMN,a.TSTP,a.OCTT,a.OOCT,a.OCEC,a.BPTC,a.TSCT," +
    			"    a.TSDR,a.CRSP,a.CRTP,a.CRAT,a.CFIN,a.CFCT,a.CFIC,a.CFRC,a.CFRCSUFFIX,a.TCNM,a.TCIT," +
    			"    a.COITP,a.TCITDESC,a.TCID,a.TCAT,a.TCAC,a.ROTF1,a.ROTF2,a.NUM,a.IS_COMP,a.ERRMSG from Aml_Bs_Trans_Upload_His a "+
    			"   where a.report_id="+amlBsUploadBak.getReportId()+" and a.work_date='"+amlBsUploadBak.getWorkDate()+"'";
    	
    	rootdao.executeSql(cust);
    	rootdao.executeSql(trans);
	}
	
	public static int getMaxBatchNo() throws CommonException {
		int batchNo = 0;
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		String workDate = DateUtils.getDateTime("yyyyMMdd", new Date());
		StringBuffer sql = new StringBuffer(
				"select max(reportId) from AmlBsUpload  where 1=1 ");
		if (workDate != null && workDate != "") {
			sql.append(" and workDate ='" + workDate + "'");
			List batchNoList = rootdao.queryByQL2List(sql.toString());
			if (batchNoList != null && batchNoList.size() > 0
					&& batchNoList.get(0) != null) {
				batchNo = (Integer) batchNoList.get(0);
			}
		}
		return batchNo;
	}
	
	
	/**
	 * 大额历史表数据copy到补录表（导入人工补正通知时生成大额修改报文）
	 * 
	 */
	public static AmlBhbsDs amlBHHisToBH(GlobalInfo gi ,AmlBhbsDsHis amlBhbsDsHis,String TMLM,String RQDS,String MIRS,String ERRMSG) throws CommonException {
		
		SysParams param = ReportCommonService.getInstance().getSysparamsByPk("RoleName", gi.getBrno());
		String RoleName = param == null ? amlBhbsDsHis.getRoleName() : param.getParamVal();
		AmlBhbsDs amlBhbsDs = new AmlBhbsDs();
		amlBhbsDs.setId(ReportUtils.getUUID()); // 设置主键
		amlBhbsDs.setApptype(amlBhbsDsHis.getApptype());
		amlBhbsDs.setCurrentfile(amlBhbsDsHis.getCurrentfile());
		amlBhbsDs.setBrNo(amlBhbsDsHis.getBrNo());
		amlBhbsDs.setRoleName(RoleName);
		amlBhbsDs.setWorkDate(amlBhbsDsHis.getWorkDate());
		amlBhbsDs.setReportType("C"); // 设置报文类型 C-修改
		amlBhbsDs.setRinm(amlBhbsDsHis.getRinm());
		amlBhbsDs.setRicd(amlBhbsDsHis.getRicd());
		amlBhbsDs.setRpdt(amlBhbsDsHis.getRpdt());
		amlBhbsDs.setCsnm(amlBhbsDsHis.getCsnm());
		amlBhbsDs.setCtnm(amlBhbsDsHis.getCtnm());
		amlBhbsDs.setCitp(amlBhbsDsHis.getCitp());
		amlBhbsDs.setCtid(amlBhbsDsHis.getCtid());
		amlBhbsDs.setAoitp(amlBhbsDsHis.getAoitp());
		amlBhbsDs.setCtnt(amlBhbsDsHis.getCtnt());
		amlBhbsDs.setCtvc(amlBhbsDsHis.getCtvc());
		amlBhbsDs.setCctl(amlBhbsDsHis.getCctl());
		amlBhbsDs.setCtar(amlBhbsDsHis.getCtar());
		amlBhbsDs.setCcei(amlBhbsDsHis.getCcei());
		amlBhbsDs.setCbct(amlBhbsDsHis.getCbct());
		amlBhbsDs.setOcbt(amlBhbsDsHis.getOcbt());
		amlBhbsDs.setCbcn(amlBhbsDsHis.getCbcn());
		amlBhbsDs.setHtdt(amlBhbsDsHis.getHtdt());
		amlBhbsDs.setCrcd(amlBhbsDsHis.getCrcd());
		amlBhbsDs.setFinn(amlBhbsDsHis.getFinn());
		amlBhbsDs.setFirc(amlBhbsDsHis.getFirc());
		amlBhbsDs.setRltp(amlBhbsDsHis.getRltp());
		amlBhbsDs.setFict(amlBhbsDsHis.getFict());
		amlBhbsDs.setFinc(amlBhbsDsHis.getFinc());
		amlBhbsDs.setRlfc(amlBhbsDsHis.getRlfc());
		amlBhbsDs.setCatp(amlBhbsDsHis.getCatp());
		amlBhbsDs.setCtac(amlBhbsDsHis.getCtac());
		amlBhbsDs.setOatm(amlBhbsDsHis.getOatm());
		amlBhbsDs.setTbnm(amlBhbsDsHis.getTbnm());
		amlBhbsDs.setTbit(amlBhbsDsHis.getTbit());
		amlBhbsDs.setTbid(amlBhbsDsHis.getTbid());
		amlBhbsDs.setBoitp(amlBhbsDsHis.getBoitp());
		amlBhbsDs.setTbnt(amlBhbsDsHis.getTbnt());
		amlBhbsDs.setTstm(amlBhbsDsHis.getTstm());
		amlBhbsDs.setTicd(amlBhbsDsHis.getTicd());
		amlBhbsDs.setRpmt(amlBhbsDsHis.getRpmt());
		amlBhbsDs.setRpmn(amlBhbsDsHis.getRpmn());
		amlBhbsDs.setTstp(amlBhbsDsHis.getTstp());
		amlBhbsDs.setOctt(amlBhbsDsHis.getOctt());
		amlBhbsDs.setOoct(amlBhbsDsHis.getOoct());
		amlBhbsDs.setOcec(amlBhbsDsHis.getOcec());
		amlBhbsDs.setBptc(amlBhbsDsHis.getBptc());
		amlBhbsDs.setTsct(amlBhbsDsHis.getTsct());
		amlBhbsDs.setTsdr(amlBhbsDsHis.getTsdr());
		amlBhbsDs.setTdrc(amlBhbsDsHis.getTdrc());
		amlBhbsDs.setTrcd(amlBhbsDsHis.getTrcd());
		amlBhbsDs.setTrcdSuffix(amlBhbsDsHis.getTrcdSuffix());
		amlBhbsDs.setCrpp(amlBhbsDsHis.getCrpp());
		amlBhbsDs.setCrtp(amlBhbsDsHis.getCrtp());
		amlBhbsDs.setCrat(amlBhbsDsHis.getCrat());
		amlBhbsDs.setTraAmountCny(amlBhbsDsHis.getTraAmountCny());
		amlBhbsDs.setTraAmountUsd(amlBhbsDsHis.getTraAmountUsd());
		amlBhbsDs.setCfin(amlBhbsDsHis.getCfin());
		amlBhbsDs.setCfct(amlBhbsDsHis.getCfct());
		amlBhbsDs.setCfic(amlBhbsDsHis.getCfic());
		amlBhbsDs.setCfrc(amlBhbsDsHis.getCfrc());
		amlBhbsDs.setCfrcSuffix(amlBhbsDsHis.getCfrcSuffix());
		amlBhbsDs.setTcnm(amlBhbsDsHis.getTcnm());
		amlBhbsDs.setTcit(amlBhbsDsHis.getTcit());
		amlBhbsDs.setTcid(amlBhbsDsHis.getTcid());
		amlBhbsDs.setCoitp(amlBhbsDsHis.getCoitp());
		amlBhbsDs.setTcat(amlBhbsDsHis.getTcat());
		amlBhbsDs.setTcac(amlBhbsDsHis.getTcac());
		amlBhbsDs.setRotf1(amlBhbsDsHis.getRotf1());
		amlBhbsDs.setRotf2(amlBhbsDsHis.getRotf2());
		amlBhbsDs.setMirs(MIRS);//人工补正标识
		amlBhbsDs.setTmlm(TMLM);//更正完成时限
		amlBhbsDs.setRqds(RQDS);//人工补正填写要求
//		amlBhbsDs.setNumber1(amlBhbsDsHis.getNumber1());
//		amlBhbsDs.setNumber2(amlBhbsDsHis.getNumber2());
//		amlBhbsDs.setNumber3(amlBhbsDsHis.getNumber3());
//		amlBhbsDs.setXmlfilename(amlBhbsDsHis.getXmlfilename());
//		amlBhbsDs.setZipfilename(amlBhbsDsHis.getZipfilename());
		amlBhbsDs.setErrmsg(ERRMSG);//待更正字段
		amlBhbsDs.setSubSuccess(amlBhbsDsHis.getSubSuccess());
		amlBhbsDs.setIsDel(amlBhbsDsHis.getIsDel());
		amlBhbsDs.setIsComp(amlBhbsDsHis.getIsComp());
		amlBhbsDs.setSourceType(amlBhbsDsHis.getSourceType());
		amlBhbsDs.setRecStatus(AMLConstants.REPORT_RECSTATUS_01); // 修改报文初始化
		amlBhbsDs.setRepStatus(AMLConstants.AML_REPSTATUS_01); // 回执状态01-未返回
		amlBhbsDs.setCrtTm(new Date());
		amlBhbsDs.setLstUpdTlr(amlBhbsDsHis.getLstUpdTlr());
		amlBhbsDs.setLstUpdTm(amlBhbsDsHis.getLstUpdTm());
		amlBhbsDs.setFiller1(amlBhbsDsHis.getFiller1());
		amlBhbsDs.setFiller2(amlBhbsDsHis.getFiller2());
		amlBhbsDs.setFiller3(amlBhbsDsHis.getFiller3());
		amlBhbsDs.setExtractPerson(amlBhbsDsHis.getExtractPerson());
		//20171213 add by ywc 
		amlBhbsDs.setApproveUpdTlr(amlBhbsDsHis.getApproveUpdTlr());
		amlBhbsDs.setApproveUpdTm(amlBhbsDsHis.getApproveUpdTm());
		return amlBhbsDs;

	}
	
	/**
	 * 可疑历史表数据copy到补录表（导入人工补正通知时生成可疑修改报文）
	 * 
	 * @param specialType
	 *            生成报文类型 C-纠错AmlBsUploadBak 备份表对象
	 */
	public static AmlBsUpload amlBShisToBS(AmlBsUploadHis amlBsUploadHis,ROOTDAO rootdao,int newreportId,
			String newworkDate,String TMLM,String RQDS,String MIRS) throws CommonException {
		AmlBsUpload amlBsUpload = new AmlBsUpload();
		amlBsUpload.setId(ReportUtils.getUUID()); // 设置主键
		amlBsUpload.setReportId(newreportId);
		amlBsUpload.setBrno(amlBsUploadHis.getBrno());
		amlBsUpload.setReportType("C");//报文类型
		amlBsUpload.setFinm(amlBsUploadHis.getFinm());
		amlBsUpload.setFirc(amlBsUploadHis.getFirc());
		amlBsUpload.setFict(amlBsUploadHis.getFict());
		amlBsUpload.setFicd(amlBsUploadHis.getFicd());
		amlBsUpload.setWorkDate(newworkDate);
		amlBsUpload.setStcr(amlBsUploadHis.getStcr());
		amlBsUpload.setSsdg(amlBsUploadHis.getSsdg());
		amlBsUpload.setTkms(amlBsUploadHis.getTkms());
		amlBsUpload.setSsds(amlBsUploadHis.getSsds());
		amlBsUpload.setXmlnm(amlBsUploadHis.getXmlnm());
		amlBsUpload.setZipnm(amlBsUploadHis.getZipnm());
		amlBsUpload.setRecStatus(AMLConstants.REPORT_RECSTATUS_01);// 纠错报文初始化 01-待补录
		amlBsUpload.setRepStatus(AMLConstants.AML_REPSTATUS_01);// 回执状态01-未返回
		//amlBsUpload.setApproveStatus(amlBsUploadHis.getApproveStatus());
		amlBsUpload.setIssubsuccess("0");
		//amlBsUpload.setApproveResult(amlBsUploadHis.getApproveResult());
		amlBsUpload.setLstUpdTlr(amlBsUploadHis.getLstUpdTlr());
		amlBsUpload.setLstUpdTm(amlBsUploadHis.getLstUpdTm());
		amlBsUpload.setIscomp("0");
		//amlBsUpload.setErrMsg(amlBsUploadHis.getErrMsg());
		amlBsUpload.setMirs(MIRS);
		amlBsUpload.setTmlm(TMLM);
		amlBsUpload.setRqds(RQDS);
		amlBsUpload.setCusNum(amlBsUploadHis.getCusNum());
		amlBsUpload.setTransNum(amlBsUploadHis.getTransNum());
		amlBsUpload.setRicd(amlBsUploadHis.getRicd());
		amlBsUpload.setRpnc(amlBsUploadHis.getRpnc());
		amlBsUpload.setDetr(amlBsUploadHis.getDetr());
		amlBsUpload.setTorp(amlBsUploadHis.getTorp());
		amlBsUpload.setDorp(amlBsUploadHis.getDorp());
		amlBsUpload.setOdrp(amlBsUploadHis.getOdrp());
		amlBsUpload.setTptr(amlBsUploadHis.getTptr());
		amlBsUpload.setOtpr(amlBsUploadHis.getOtpr());
		amlBsUpload.setStcb(amlBsUploadHis.getStcb());
		amlBsUpload.setStcb2(amlBsUploadHis.getStcb2());
		amlBsUpload.setStcb3(amlBsUploadHis.getStcb3());
		amlBsUpload.setAosp(amlBsUploadHis.getAosp());
		amlBsUpload.setAosp2(amlBsUploadHis.getAosp2());
		amlBsUpload.setAosp3(amlBsUploadHis.getAosp3());
		amlBsUpload.setTosc(amlBsUploadHis.getTosc());
		amlBsUpload.setFiller1(amlBsUploadHis.getFiller1());
		amlBsUpload.setFiller2(amlBsUploadHis.getFiller2());
		amlBsUpload.setFiller3(amlBsUploadHis.getFiller3());
		amlBsUpload.setFiller4(amlBsUploadHis.getFiller4());
		amlBsUpload.setFiller5(amlBsUploadHis.getFiller5());
		amlBsUpload.setFiller6(amlBsUploadHis.getFiller6());
		amlBsUpload.setOrxn(amlBsUploadHis.getOrxn());
		reSetCusAndTrad (newreportId,newworkDate,rootdao,amlBsUploadHis);
		return amlBsUpload;
	}
	
	public static void reSetCusAndTrad (int newReportId,String newworkDate,ROOTDAO rootdao,AmlBsUploadHis amlBsUploadHis) throws CommonException {
		String cust = "insert into Aml_Bs_Cus_Upload t " +
    			"    (t.REC_ID,t.report_id,t.work_date,t.SENM,t.SETP,t.OITP,t.CITPDESC,t.SEID," +
    			"    t.CSNM,t.CTTP,t.SCTL,t.SEAR,t.SEEI,t.STNT,t.SEVC,t.RGCP,t.SRNM,t.SRIT,t.ORIT," +
    			"    t.CRITDESC,t.SRID,t.SCNM,t.SCIT,t.OCIT,t.SCID,t.NUM,t.IS_COMP,t.ERRMSG,t.YWTX ) "+
    			"    select sys_guid() as REC_ID,'"+newReportId+"' as report_id,'"+newworkDate+"' as work_date," +
    			"   a.SENM,a.SETP,a.OITP,a.CITPDESC,a.SEID,a.CSNM,a.CTTP,a.SCTL,a.SEAR,a.SEEI," +
    			"   a.STNT,a.SEVC,a.RGCP,a.SRNM,a.SRIT,a.ORIT,a.CRITDESC,a.SRID,a.SCNM,a.SCIT," +
    			"   a.OCIT,a.SCID,a.NUM,a.IS_COMP,a.ERRMSG,a.YWTX from Aml_Bs_Cus_Upload_his a "+
    			"   where a.report_id="+amlBsUploadHis.getReportId()+" and a.work_date='"+amlBsUploadHis.getWorkDate()+"'";
    	
    	
    	String trans = "insert into Aml_Bs_Trans_Upload t " +
    			"    (t.REC_ID,t.report_id,t.work_date,t.FINC,t.RLFC,t.CSNM,t.CTNM,t.CITP,t.AOITP,t.CITPDESC,t.CTID,t.CATP,t.CTAC,t.OATM," +
    			"    t.CATM,t.CBCT,t.OCBT,t.CBCN,t.TBNM,t.TBIT,t.BOITP,t.BITPDESC,t.TBID,t.TBNT,t.TSTM," +
    			"    t.TRCD,t.TRCDSUFFIX,t.TICD,t.RPMT,t.RPMN,t.TSTP,t.OCTT,t.OOCT,t.OCEC,t.BPTC,t.TSCT," +
    			"    t.TSDR,t.CRSP,t.CRTP,t.CRAT,t.CFIN,t.CFCT,t.CFIC,t.CFRC,t.CFRCSUFFIX,t.TCNM,t.TCIT," +
    			"    t.COITP,t.TCITDESC,t.TCID,t.TCAT,t.TCAC,t.ROTF1,t.ROTF2,t.NUM,t.IS_COMP,t.ERRMSG) "+
    			"    select sys_guid() as REC_ID,'"+newReportId+"' as report_id,'"+newworkDate+"' as work_date," +
    			"    a.FINC,a.RLFC,a.CSNM,a.CTNM,a.CITP,a.AOITP,a.CITPDESC,a.CTID,a.CATP,a.CTAC,a.OATM," +
    			"    a.CATM,a.CBCT,a.OCBT,a.CBCN,a.TBNM,a.TBIT,a.BOITP,a.BITPDESC,a.TBID,a.TBNT,a.TSTM," +
    			"    a.TRCD,a.TRCDSUFFIX,a.TICD,a.RPMT,a.RPMN,a.TSTP,a.OCTT,a.OOCT,a.OCEC,a.BPTC,a.TSCT," +
    			"    a.TSDR,a.CRSP,a.CRTP,a.CRAT,a.CFIN,a.CFCT,a.CFIC,a.CFRC,a.CFRCSUFFIX,a.TCNM,a.TCIT," +
    			"    a.COITP,a.TCITDESC,a.TCID,a.TCAT,a.TCAC,a.ROTF1,a.ROTF2,a.NUM,a.IS_COMP,a.ERRMSG from Aml_Bs_Trans_Upload_His a "+
    			"   where a.report_id="+amlBsUploadHis.getReportId()+" and a.work_date='"+amlBsUploadHis.getWorkDate()+"'";
    	
    	rootdao.executeSql(cust);
    	rootdao.executeSql(trans);
	}
	
	/**
	 * 大额查询页面（大额新增报文查询、大额修改报文查询、大额交易查询、大额不上报审核4个页面的查询方法）
	 * 
	 * @param quertType  查询类型：大额新增报文查询AML_NBH_QUERY、大额修改报文查询AML_CBH_QUERY、大额交易查询AML_QUERY、大额不上报审核AML_APPROVE_QUERY
	 * @param map        查询条件的集合
	 * @return 
	 * @throws CommonException 
	 *            
	 */
	public static PageQueryResult QueryBH(String quertType ,Map<String, String> map , int pageIndex, int pageSize) throws CommonException {
		PageQueryResult queryResult = new PageQueryResult();
		GlobalInfo gInfo = GlobalInfo.getCurrentInstance();
		String roleName = HsbcAmlUtils.getDepartByUserId(gInfo.getTlrno());
		String tableName ;
		if("AML_QUERY".equalsIgnoreCase(quertType)) {
			tableName = "AML_BHBS_DS_AND_HIS";//大额交易查询需要查询全量的视图
		}else {
			tableName = "AML_BHBS_DS";//大额报文补录/审核查询只需要查询当前表
		}
		StringBuilder hql = new StringBuilder("SELECT REC_ID, APPTYPE, CURRENTFILE, RINM, RICD, RPDT, CTNM, CITP, CTID, AOITP, CSNM, CTNT, HTDT, CRCD, FINN, FINM, FIRC, RLTP, FICT, FINC, RLFC, CATP, CTAC, TBNM, TBIT, TBID, TBNT, BOITP, TSTM, TICD, RPMT, RPMN, OCTT, OOCT, OCEC, BPTC, TSTP, TSCT, TSDR, TDRC, TRCD, trcdSuffix, CRPP, CRTP, CRAT, CFIN, CFCT, CFIC, TCNM, TCIT, TCID, COITP, ROTF1, ROTF2, MIRS, TMLM, RQDS, TCAT, TCAC, STCR, SSDG, TKMS, SSDS, RPNM, CTTP, CCTL, CTAR, CCEI, CBCT, OCBT, CBCN, CTVC, RGCP, CRNM, CRIT, CRID, OATM, CATM, FILLER1, FILLER2, FILLER3, BR_NO, REC_STATUS, REP_STATUS, APPROVE_STATUS, APPROVE_RESULT, WORK_DATE, IS_SUB_SUCCESS, CRT_TM, LST_UPD_TLR, LST_UPD_TM, FICD, BKNM, BITP, BKID, BKNT, CRSP, CFRC, cfrcSuffix, EXTRACTION_SIGN, XMLFILENAME, ZIPFILENAME, RECORD_UPD_TLR, RECORD_UPD_TM, APPROVE_UPD_TLR, APPROVE_UPD_TM, ISDEL, REPORT_TYPE, ERRMSG, TRA_AMOUNT_USD, TRA_AMOUNT_CNY, SOURCE_TYPE, IS_COMP, ROLE_NAME, EXTRACT_PERSON, TRADNO, modifyCBIF, modifyCCIF, modifyTSDT ,CSNM_OLD FROM (SELECT ROWNUM AS RN,b.* FROM (select model.* from "+tableName+" model WHERE 1 = 1 ");
		StringBuilder count = new StringBuilder("select count(*) as count from "+tableName+" model WHERE 1 = 1");
		String qworkDateStart = map.get("qworkDateStart");
		String qworkDateEnd = map.get("qworkDateEnd");
		String qrecStatus = map.get("qrecStatus");
		String qrepStatus = map.get("qrepStatus");
		String crcd = map.get("crcd");//大额交易特征代码
		String ticd = map.get("ticd");//业务标识号
		String csnm = map.get("csnm");//客户号
		String ctnm = map.get("ctnm");//客户名称
		String ctnt = map.get("ctnt");//客户国籍
		String catp = map.get("catp");//账户类型
		String ctac = map.get("ctac");//账号
		String citp = map.get("citp");//客户身份证件/证明文件类型
		String ctid = map.get("ctid");//客户证件号码
		String finc = map.get("finc");//金融机构网点代码
		String cbct = map.get("cbct");//客户银行卡类型
		String cbcn = map.get("cbcn");//客户银行卡号码
		String rlfc = map.get("rlfc");//金融机构与客户的关系
		String tbnm = map.get("tbnm");//交易代办人姓名
		String tbit = map.get("tbit");//交易代办人身份证件/证明文件类型
		String tbid = map.get("tbid");//代办人身份证件/证明文件号码
		String tbnt = map.get("tbnt");//代办人国籍
		String cfin = map.get("cfin");//对方金融机构网点名称
		String cfct = map.get("cfct");//对方金融机构代码网点类型
		String cfic = map.get("cfic");//对方金融机构网点代码
		String tcnm = map.get("tcnm");//交易对手姓名
		String tcat = map.get("tcat");//交易对手账户类型
		String tcac = map.get("tcac");//交易对手账号
		String tcit = map.get("tcit");//交易对手证件类型
		String tcid = map.get("tcid");//交易对手证件号码
		String tstm = map.get("tstm");//交易日期
		String tstp = map.get("tstp");//交易方式
		String tsct = map.get("tsct");//涉外收支交易分类与代码
		String tsdr = map.get("tsdr");//资金收付标识
		String crtp = map.get("crtp");//币种
		String cratUp = map.get("cratUp");//交易金额上限
		String cratDown = map.get("cratDown");//交易金额下限
		String crpp = map.get("crpp");//资金用途
		String trcd = map.get("trcd");//交易发生地国别
		String trcdSuffix = map.get("trcdSuffix");//交易发生地区域
		String reportType = map.get("reportType");//报文类型
		String qsourceType = map.get("qsourceType");//数据来源
		String qlstUpdTlr = map.get("qlstUpdTlr");//最后更新人
		
		String qcsnmold = map.get("qcsnmold");//原客户号
		if (!DataFormat.isEmpty(qworkDateStart)) {
			hql.append(" AND work_Date >= '"+qworkDateStart+"'");
			count.append(" AND work_Date >= '"+qworkDateStart+"'");
		}
		if (!DataFormat.isEmpty(qworkDateEnd)) {
			hql.append(" AND work_Date <= '"+qworkDateEnd+"'");
			count.append(" AND work_Date <= '"+qworkDateEnd+"'");
		}
		if (StringUtils.isNotBlank(qrepStatus)) {
			hql.append(" AND rep_Status = '"+qrepStatus+"' ");
			count.append(" AND rep_Status = '"+qrepStatus+"' ");
		}
	    if(StringUtils.isNotBlank(crcd)){//大额交易特征代码
			hql.append(" AND crcd = '"+crcd+"'");
			count.append(" AND crcd = '"+crcd+"'");
		}
	    if (StringUtils.isNotBlank(ticd)) {//业务标识号
			hql.append(" AND ticd like '%"+ticd+"%'");
			count.append(" AND ticd like '%"+ticd+"%'");
		}
    	if(StringUtils.isNotBlank(csnm)) {//客户号
			hql.append(" AND csnm ='"+csnm+"'");
			count.append(" AND csnm ='"+csnm+"'");
		}
    	if(StringUtils.isNotBlank(ctnm)){//客户名称
    		hql.append(" AND ctnm ='"+ctnm+"'");
    		count.append(" AND ctnm ='"+ctnm+"'");
    	}
     	if(StringUtils.isNotBlank(ctnt)){//客户国籍
			hql.append(" AND ctnt = '"+ctnt+"'");
			count.append(" AND ctnt = '"+ctnt+"'");
		}
    	if(StringUtils.isNotEmpty(catp)){//账户类型
			hql.append(" AND catp = '"+catp+"'");
			count.append(" AND catp = '"+catp+"'");
		}
		if(StringUtils.isNotBlank(ctac)) {//账号
			hql.append(" AND ctac = '"+ctac+"'");
			count.append(" AND ctac = '"+ctac+"'");
		}
    	if(StringUtils.isNotEmpty(citp)){//客户身份证件/证明文件类型
			hql.append(" AND citp = '"+citp+"'");
			count.append(" AND citp = '"+citp+"'");
		}
    	if(StringUtils.isNotBlank(ctid)) {//客户证件号码
			hql.append(" AND ctid = '"+ctid+"'");
			count.append(" AND ctid = '"+ctid+"'");
		}
    	if(StringUtils.isNotEmpty(finc)){//金融机构网点代码
			hql.append(" AND finc = '"+finc+"'");
			count.append(" AND finc = '"+finc+"'");
		}
		if(StringUtils.isNotBlank(cbct)) {//客户银行卡类型
			hql.append(" AND cbct = '"+cbct+"'");
			count.append(" AND cbct = '"+cbct+"'");
		}
		if(StringUtils.isNotEmpty(cbcn)){//客户银行卡号码
			hql.append(" AND cbcn = '"+cbcn+"'");
			count.append(" AND cbcn = '"+cbcn+"'");
		}
		if(StringUtils.isNotBlank(rlfc)) {//金融机构与客户的关系
			hql.append(" AND rlfc = '"+rlfc+"'");
			count.append(" AND rlfc = '"+rlfc+"'");
		}
		if(StringUtils.isNotEmpty(tbnm)){//交易代办人姓名
			hql.append(" AND tbnm = '"+tbnm+"'");
			count.append(" AND tbnm = '"+tbnm+"'");
		}
		if(StringUtils.isNotBlank(tbit)) {//交易代办人身份证件/证明文件类型
			hql.append(" AND tbit = '"+tbit+"'");
			count.append(" AND tbit = '"+tbit+"'");
		}
		if(StringUtils.isNotEmpty(tbid)){//代办人身份证件/证明文件号码
			hql.append(" AND tbid = '"+tbid+"'");
			count.append(" AND tbid = '"+tbid+"'");
		}
		if(StringUtils.isNotBlank(tbnt)) {//代办人国籍
			hql.append(" AND tbnt = '"+tbnt+"'");
			count.append(" AND tbnt = '"+tbnt+"'");
		}
		if(StringUtils.isNotEmpty(cfin)){//对方金融机构网点名称
			hql.append(" AND cfin like '%"+cfin+"%'");
			count.append(" AND cfin like '%"+cfin+"%'");
		}
		if(StringUtils.isNotEmpty(cfct)){//对方金融机构代码网点类型
			hql.append(" AND cfct = '"+cfct+"'");
			count.append(" AND cfct = '"+cfct+"'");
		}
		if(StringUtils.isNotEmpty(cfic)){//对方金融机构网点代码
			hql.append(" AND cfic like '%"+cfic+"%'");
			count.append(" AND cfic like '%"+cfic+"%'");
		}
		if(StringUtils.isNotEmpty(tcnm)){//交易对手姓名
			hql.append(" AND tcnm = '"+tcnm+"'");
			count.append(" AND tcnm = '"+tcnm+"'");
		}
		if(StringUtils.isNotEmpty(tcat)){//交易对手账户类型
			hql.append(" AND tcat = '"+tcat+"'");
			count.append(" AND tcat = '"+tcat+"'");
		}
		if(StringUtils.isNotEmpty(tcac)){//交易对手账号
			hql.append(" AND tcac = '"+tcac+"'");
			count.append(" AND tcac = '"+tcac+"'");
		}
		if(StringUtils.isNotEmpty(tcit)){//交易对手证件类型
			hql.append(" AND tcit = '"+tcit+"'");
			count.append(" AND tcit = '"+tcit+"'");
		}
		if(StringUtils.isNotEmpty(tcid)){//交易对手证件号码
			hql.append(" AND tcid = '"+tcid+"'");
			count.append(" AND tcid = '"+tcid+"'");
		}
		if(!DataFormat.isEmpty(tstm)){//交易日期
			hql.append(" AND tstm like '"+tstm+"%'");
			count.append(" AND tstm like '"+tstm+"%'");
		}
		if(StringUtils.isNotEmpty(tstp)){//交易方式
			hql.append(" AND tstp = '"+tstp+"'");
			count.append(" AND tstp = '"+tstp+"'");
		}
		if(StringUtils.isNotEmpty(tsct)){//涉外收支交易分类与代码
			hql.append(" AND tsct = '"+tsct+"'");
			count.append(" AND tsct = '"+tsct+"'");
		}
		if(StringUtils.isNotEmpty(tsdr)){//资金收付标识
			hql.append(" AND tsdr = '"+tsdr+"'");
			count.append(" AND tsdr = '"+tsdr+"'");
		}
		if(StringUtils.isNotEmpty(crtp)){//币种
			hql.append(" AND crtp = '"+crtp+"'");
			count.append(" AND crtp = '"+crtp+"'");
		}
		if(StringUtils.isNotBlank(cratUp)) {//交易金额上限
			hql.append(" AND crat <= '"+cratUp+"'");
			count.append(" AND crat <= '"+cratUp+"'");
		}
		if(StringUtils.isNotBlank(cratDown)) {//交易金额下限
			hql.append(" AND crat >= '"+cratDown+"'");
			count.append(" AND crat >= '"+cratDown+"'");
		}
		if(StringUtils.isNotEmpty(crpp)){//资金用途
			hql.append(" AND crpp like '%"+crpp+"%'");
			count.append(" AND crpp like '%"+crpp+"%'");
		}
		if(StringUtils.isNotEmpty(trcd)){//交易发生地国别
			hql.append(" AND trcd = '"+trcd+"'");
			count.append(" AND trcd = '"+trcd+"'");
		}
		if(StringUtils.isNotEmpty(trcdSuffix)){//交易发生地区域
			hql.append(" AND trcdSuffix = '"+trcdSuffix+"'");
			count.append(" AND trcdSuffix = '"+trcdSuffix+"'");
		}
		if(StringUtils.isNotBlank(reportType)){
			hql.append(" AND report_Type = '"+reportType+"'");
			count.append(" AND report_Type = '"+reportType+"'");
		}
		if(StringUtils.isNotBlank(qsourceType)){
			hql.append(" AND source_Type = '"+qsourceType+"'");
			count.append(" AND source_Type = '"+qsourceType+"'");
		}
		if(StringUtils.isNotBlank(qlstUpdTlr)){
			hql.append(" AND lst_Upd_Tlr = '"+qlstUpdTlr+"'");
			count.append(" AND lst_Upd_Tlr = '"+qlstUpdTlr+"'");
		}
		
		//add 20191119
		if(StringUtils.isNotBlank(qcsnmold)){
			hql.append(" AND CSNM_OLD = '"+qcsnmold+"'");
			count.append(" AND CSNM_OLD = '"+qcsnmold+"'");
		}
		
		hql.append(" AND br_No = '"+gInfo.getBrno()+"' ");
		count.append(" AND br_No = '"+gInfo.getBrno()+"' ");
		
		
		if("AML_QUERY".equalsIgnoreCase(quertType)) {
			if(!HfAml3Utils.ROLENAME.equals(roleName)){
				hql.append(" AND role_Name = '"+roleName+"' ");//大额交易查询CIU部门可以查看其他部门的数据
	    		count.append(" AND role_Name = '"+roleName+"' ");
			}
			if(StringUtils.isNotBlank(qrecStatus)){			
				hql.append(" AND  rec_Status = '"+qrecStatus+"' ");
				count.append(" AND  rec_Status = '"+qrecStatus+"' ");
			}
		}else {
			hql.append(" AND role_Name = '"+roleName+"' ");//大额补录查询只可以查询自己部门的
    		count.append(" AND role_Name = '"+roleName+"' ");
    		
    		//modify by zqq 20190625 特殊报文 特殊角色可见
//    		if(HfAml3Utils.ROLENAME.equals(roleName)&&"AML_NBH_QUERY".equalsIgnoreCase(quertType)){//大额新增补录查询CIU部门需要区分到申领人
//    			hql.append(" AND lst_Upd_Tlr = '"+gInfo.getTlrno()+"' ");
//    			count.append(" AND lst_Upd_Tlr = '"+gInfo.getTlrno()+"' ");
//    		}
    		String fullRoleName = HsbcAmlUtils.getDepartByUserId(gInfo.getTlrno(),"");
			boolean rsp = getHasPermissionSpecialReport(fullRoleName);
			if("AML_NBH_QUERY".equalsIgnoreCase(quertType)){
				if(HfAml3Utils.ROLENAME.equals(roleName)){
					if(rsp){
	    				hql.append(" AND (lst_Upd_Tlr = '"+gInfo.getTlrno()+"' OR REP_STATUS='04') ");
		    			count.append(" AND (lst_Upd_Tlr = '"+gInfo.getTlrno()+"' OR REP_STATUS='04') ");
	    			}else{//如果角色没有特殊报文权限
		    			hql.append(" AND lst_Upd_Tlr = '"+gInfo.getTlrno()+"' ");
		    			count.append(" AND lst_Upd_Tlr = '"+gInfo.getTlrno()+"' ");
		    			hql.append(" AND REP_STATUS<>'04' ");
	    				count.append(" AND REP_STATUS<>'04' ");
	    			}
				}else{
					if(!rsp){
						hql.append(" AND REP_STATUS<>'04' ");
	    				count.append(" AND REP_STATUS<>'04' ");
					}
				}
			}
    		
    		if(StringUtils.isNotBlank(qrecStatus)){			
    			hql.append(" AND  rec_Status = '"+qrecStatus+"' ");
    			count.append(" AND  rec_Status = '"+qrecStatus+"' ");
    		}else {
    			hql.append(" AND  rec_Status in ('01','02','99') ");//大额补录查询默认查询01，02，99的数据
    			count.append(" AND  rec_Status in ('01','02','99') ");
    		}
    		
    		
		}
        
		//add by zqq 20190821  和2号令一样能够按照公司排序
//		if(roleName!=null&&roleName.indexOf("TSC")!=-1){
			hql.append(" order by model.REC_STATUS,model.WORK_DATE,model.CSNM,model.TICD ");//modify by zqq 201901010 添加排序REC_STATUS、WORK_DATE
//		}
		
		hql.append(" ) b WHERE ROWNUM<="+pageIndex*pageSize +"  ) T where RN > "+(pageIndex-1)*pageSize+"");
		SessionFactory sessionFactory = ROOTDAOUtils.getROOTDAO().getSessionFactory();
		Session session = sessionFactory.openSession();
		SQLQuery query = session.createSQLQuery(hql.toString());
		SQLQuery queryCount = session.createSQLQuery(count.toString());
		//设置结果集转换器
		query.setResultTransformer(new EscColumnToBeanUtils(AmlBhbsDs.class)); 
		queryResult.setQueryResult(query.list());
		queryResult.setTotalCount(Integer.parseInt(queryCount.list().get(0).toString()));
		if(session!=null) {
			session.close();
		}
		return queryResult;
	}
	
	
	/**
	 * 用于可疑报文 资金交易及客户行为情况 、疑点分析的字段截取
	 * 这2个字段接口为10000位，数据库分为3个字段存储
	 * 
	 *            
	 */
	public static String[] subStringByByte(String strAll)  {
		String[] str = new String[3];
		try {
			int length = strAll.getBytes("UTF-8").length ;//中文字符转为3位字节，和数据库编码保持一致
			if(length<=4000) {//数据库长度小于等于4000，直接存第一个字段
				str[0] = strAll;
				str[1] = "";
				str[2] = "";
				return str;
			}else if(4000<length && length<=8000) {//数据库长度大于4000小等于8000，存前2个字段
				int num = 0;
				for(int i=0;i<strAll.length();i++) {
					num = num + (strAll.charAt(i)+"").getBytes("UTF-8").length;
					if(num>4000) {//找到第一次到4000位的那个点截取
						str[0] = strAll.substring(0, i);//前i位截取后放入第一个字段（不包括第i位，第i位加上字节就超过4000了）
						str[1] = strAll.substring(i, strAll.length());
						str[2] = "";
						return str;
					}
				}
			}else if(8000<length) {//数据库长度大于8000，存3个字段
				int num1 = 0;
				for(int i=0;i<strAll.length();i++) {
					num1 = num1 + (strAll.charAt(i)+"").getBytes("UTF-8").length;
					if(num1>4000) {//找到第一次到4000位的那个点截取
						str[0] = strAll.substring(0, i);//前i位截取后放入第一个字段（不包括第i位，第i位加上字节就超过4000了）
						String strOthers = strAll.substring(i, strAll.length());
						int num2 = 0;
						for(int j=0;j<strOthers.length();j++) {//再将剩下的字段按照同样的方式截取（不去找8000位的点，防止中间一段超长）
							num2 = num2 + (strOthers.charAt(j)+"").getBytes("UTF-8").length;
							if(num2>4000) {//找到第一次到4000位的那个点截取
								str[1] = strOthers.substring(0, j);//前j位截取后放入第一个字段（不包括第j位，第j位加上字节就超过4000了）
								str[2] = strOthers.substring(j, strOthers.length());
								return str;
							}
						}
					}
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return str;
	}
	
	private static boolean getHasPermissionSpecialReport(String roleName) throws CommonException{
		SysParams param = ReportCommonService.getInstance().getSysparamsByPk("AML3", "SRP_BH");
		String roles = param.getParamVal();
		String[] arr = roles.split(";");
		for(String s:arr){
			if(s.equals(roleName)){
				return true;
			}
		}
		return false;
	}
}
