package com.huateng.report.common.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.huateng.common.log.HtLog;
import com.huateng.common.log.HtLogFactory;
import com.huateng.ebank.business.common.GlobalInfo;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.entity.data.mng.DataDic;
import com.huateng.ebank.framework.exceptions.CommonException;
import com.huateng.ebank.framework.report.common.ReportConstant;
import com.huateng.ebank.framework.util.ApplicationContextUtils;
import com.huateng.ebank.framework.util.DateUtil;
import com.huateng.report.aml.feedback.service.AmlFeedBackservice;
import com.huateng.report.common.bean.UndoConfirmTaskBean;
import com.huateng.report.constants.AMLConstants;
import com.huateng.report.hf.aml.bean.BiDataProcessLog;
import com.huateng.report.hf.aml.utils.HsbcAmlUtils;
import com.huateng.report.utils.ReportUtils;

import resource.bean.report.BiQuartzJobLog;
import resource.bean.report.BiTlrFavt;
import resource.bean.report.SysParams;
import resource.bean.report.SysParamsPK;
import resources.bean.report.form.AmlLarUnfinishForm;
import resources.bean.report.form.ViHomePageTodo;
import resources.bean.report.form.ViHomePageTodo02;
import resources.bean.report.form.ViHomePageTodo03;
import resources.bean.report.form.ViHomePageTodo04;
import resources.bean.report.form.ViHomePageTodo05;
import resources.bean.report.form.ViHomePageTodo06;
import resources.bean.report.form.ViHomePageTodo07;

public class ReportCommonService {
	private static final HtLog htlog = HtLogFactory.getLogger(ReportCommonService.class);
	public static final String JOB_OK = "01";
	public static final String JOB_FAILED = "02";
	
	protected ReportCommonService() {
	}

	/**
	 * get instance.
	 *
	 * @return
	 */
	public synchronized static ReportCommonService getInstance() {
		return (ReportCommonService) ApplicationContextUtils.getBean(ReportCommonService.class.getName());
	}

	public DataDic getDataDic(int dataTypeNo, String dataNo) throws CommonException {
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		String hql = " from DataDic model where model.dataTypeNo=" + dataTypeNo + " and model.dataNo='" + dataNo.trim()
				+ "'";
		List<DataDic> list = rootdao.queryByQL2List(hql);
		if (list.size() == 1) {
			return list.get(0);
		}
		return null;
	}

	public List getDataDicList(int dataTypeNo) throws CommonException {
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		String hql = " from DataDic model where model.dataTypeNo=" + dataTypeNo;

		List<DataDic> list = rootdao.queryByQL2List(hql);

		return list;
	}

	/**
	 * @author zengqinag.yang 2013-2-26-下午8:16:42
	 * @param highLimit
	 * @return
	 * @throws CommonException
	 */
	public DataDic getDataDicByHighLimit(int dataTypeNo, String highLimit) throws CommonException {
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		String hql = " from DataDic model where model.dataTypeNo=" + dataTypeNo + " and upper(model.highLimit)='"
				+ highLimit + "'";
		List<DataDic> list = rootdao.queryByQL2List(hql);
		if (list.size() == 1) {
			return list.get(0);
		}
		return null;
	}

	public List<DataDic> getDataDic(int dataTypeNo) throws CommonException {
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		String hql = " from DataDic model where model.dataTypeNo=" + dataTypeNo;
		List<DataDic> list = rootdao.queryByQL2List(hql);
		return list;
	}

	public List getConfList(String code) throws CommonException {
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		List list = rootdao.queryByQL2List(
				" from SysBusinavConf model where model.parentCode='" + code + "' order by model.showSeq");
		return list;
	}

	public int getImportLogByWorkDate(String workDate) throws CommonException {
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		return rootdao.queryByHqlToCount("select count(model) from BiImportLog model where model.workDate='" + workDate
				+ "' and model.importStatus='1'");
	}

	public SysParams getSysparamsByPk(String groupId, String paramId) throws CommonException {
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		return (SysParams) rootdao.query(SysParams.class, new SysParamsPK(groupId, paramId));
	}

	public List<DataDic> getBusinessByTypeNo() throws CommonException {
		List<DataDic> busiList = getDataDicList(ReportConstant.DATA_DIC_BUSI_TYPE_NO, null);
		return busiList;
	}



	public List<DataDic> getDataDicList(int typeNo, String dataNo) throws CommonException {
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		String hql = " from DataDic model where model.dataTypeNo=" + typeNo;
		if (dataNo != null && dataNo.trim().length() > 0) {
			hql += " and model.dataNo='" + dataNo.trim() + "'";
		}
		hql += " order by model.dataNo";
		List<DataDic> list = rootdao.queryByQL2List(hql);
		return list;
	}


	/**
	 * 保存定时任务执行日志
	 *
	 * @param startTm
	 * @param endTm
	 * @param quartId
	 * @param result
	 * @param jobName
	 * @param remarak
	 * @throws CommonException
	 */
	public void saveJobLog(Date startTm, Date endTm, String quartId, String result, String jobName, String remark) {
		BiQuartzJobLog joblog = new BiQuartzJobLog();
		joblog.setId(ReportUtils.getUUID());
		joblog.setExecTm(startTm);
		joblog.setEndTm(endTm == null ? new Date() : endTm);
		joblog.setQuartzId(quartId);
		joblog.setQuartzResult(result);
		joblog.setQuartzName(jobName);
		joblog.setRemark(remark);

		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		try {
			rootdao.save(joblog);
		} catch (CommonException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 首页主管确认信息
	 *
	 * @return
	 * @throws CommonException
	 */
	public List<UndoConfirmTaskBean> getUndoConfirmTask(HttpSession httpSession) throws CommonException {
		GlobalInfo globalInfo = (GlobalInfo) httpSession.getAttribute(GlobalInfo.KEY_GLOBAL_INFO);
		GlobalInfo.setCurrentInstance(globalInfo);
		List confrimCodeList = globalInfo.getConfrimCodeList();
		List<UndoConfirmTaskBean> list = new ArrayList<UndoConfirmTaskBean>();
		if (confrimCodeList != null && confrimCodeList.size() > 0) {
			String codes = ReportUtils.getConfrimCodes(confrimCodeList);
			ROOTDAO rootDao = ROOTDAOUtils.getROOTDAO();
			String hql = "select new com.huateng.report.common.bean.UndoConfirmTaskBean(dd.intInsId,count(dd)) from SysTaskInfo dd where dd.intInsId in "
					+ codes + " group by dd.intInsId";
			list = rootDao.queryByQL2List(hql);
			List<DataDic> dds = getDataDicList(300001, null);
			Map<String, String> ddMap = new HashMap<String, String>();
			for (DataDic dd : dds) {
				ddMap.put(dd.getDataNo(), dd.getDataName());
			}
			for (UndoConfirmTaskBean bean : list) {
				bean.setIntInsIdName(ddMap.get(bean.getIntInsId()));
			}
		}
		return list;
	}

	public List getFunctionInfoListByFavt(HttpSession httpSession) throws CommonException {
		GlobalInfo globalInfo = (GlobalInfo) httpSession.getAttribute(GlobalInfo.KEY_GLOBAL_INFO);
		GlobalInfo.setCurrentInstance(globalInfo);
		Map funmap = globalInfo.getAllFunctions();
		List<Object> funcList = new ArrayList<Object>();
		ROOTDAO dao = ROOTDAOUtils.getROOTDAO();
		List favtList = dao.queryByQL2List(" from BiTlrFavt model where model.tlrNo='" + globalInfo.getTlrno()
				+ "' and model.funcType='" + globalInfo.getMenuCode() + "' order by model.showSeq");
		for (int i = 0; i < favtList.size(); i++) {
			BiTlrFavt favt = (BiTlrFavt) favtList.get(i);
			if (funmap.containsKey(favt.getFuncId().trim())) {
				funcList.add(funmap.get(favt.getFuncId().trim()));
			}
		}
		return funcList;
	}

	public void saveOrUpdateFavt(String tlrNo, String funcType, List<String> funcId) throws CommonException {
		ROOTDAO dao = ROOTDAOUtils.getROOTDAO();
		List oldList = dao.queryByQL2List(
				" from BiTlrFavt model where model.tlrNo='" + tlrNo + "' and model.funcType='" + funcType + "'");
		if (oldList != null) {
			for (int i = 0; i < oldList.size(); i++) {
				dao.delete(oldList.get(i));
			}
		}
		for (int i = 0; i < funcId.size(); i++) {
			BiTlrFavt ft = new BiTlrFavt();
			ft.setId(ReportUtils.getUUID());
			ft.setFuncId(funcId.get(i).trim());
			ft.setTlrNo(tlrNo);
			ft.setShowSeq(i);
			ft.setFuncType(funcType);
			dao.saveOrUpdate(ft);
		}

	}


	/**
	 * 首页显示定时任务日志
	 *
	 * @return
	 * @throws CommonException
	 */
	public List<BiQuartzJobLog> getQuartzJobLog() throws CommonException {
		StringBuffer hql = new StringBuffer(
				"select model from BiQuartzJobLog model where model.execTm>=? and model.execTm<=? order by model.execTm desc");
		List<Object> objlist = new ArrayList<Object>();
		String curDateStr = DateUtil.dateToNumber(new Date());
		objlist.add(DateUtil.getStartDateByDays(DateUtil.stringToDate2(curDateStr), +1));
		objlist.add(DateUtil.getStartDateByDays(DateUtil.stringToDate2(curDateStr), -1));
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		return rootdao.queryByQL2List(hql.toString(), objlist.toArray(), null);
	}

	public List getReportBopJshList() throws CommonException {
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		List list = rootdao.queryByQL2List(" from BiBopjshRetNo");
		return list;
	}

	public List getFunctionNavList(String parentCode) throws CommonException {
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		List list = rootdao.queryByQL2List(
				" from FunctionInfo model where model.lastdirectory='" + parentCode + "' order by model.showseq");
		return list;
	}

	public int getFunctionCountByTlrNo(String tlrNo, String parentCode) throws CommonException {

		String funcIds = ReportUtils.getConfrimCodes(getFunctionNavList(parentCode));

		StringBuffer hql = new StringBuffer();
		hql.append("select count(rr) from TlrRoleRel tr,RoleFuncRel rr");
		hql.append(" where tr.roleId=rr.roleId ");
		hql.append("and tr.tlrno='").append(tlrNo).append("' and rr.funcid in " + funcIds);
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		return rootdao.queryByHqlToCount(hql.toString());
	}
	
	/**
	 * 从数据字典查询所有应用类型及文件类型
	 *
	 * @return
	 * @throws CommonException
	 */
	public Map<String, List<DataDic>> getAppAndFileTypeByDataDic(String busiType, String appType, String fileType)
			throws CommonException {
		Map<String, List<DataDic>> map = new LinkedHashMap<String, List<DataDic>>();
		List<DataDic> busiList = getDataDicList(AMLConstants.DATA_DIC_BUSI_TYPE_NO, busiType);
		if (busiList.size() == 1) {
			int typeNo = Integer.parseInt(busiList.get(0).getMiscflgs().trim());
			List<DataDic> list = getDataDicList(typeNo, appType);
			for (int i = 0; i < list.size(); i++) {
				DataDic dd = list.get(i);
				String mf = dd.getMiscflgs();
				if (mf != null && mf.trim().length() > 0) {
					List<DataDic> fileList = getDataDicList(Integer.parseInt(mf.trim()), fileType);
					map.put(dd.getDataNo().trim(), fileList);
				}
			}
		}
		return map;
	}
	
	/**
	 * 数据处理记录表保存
	 *
	 * @param appType
	 *            应用类型 如 外汇账户 ACC: TopReportConstants.REPORT_APP_TYPE_ACC
	 * @param currentFile
	 *            文件类型 如 CA 账户开关户信息 CB 账户收支余信息 等
	 * @param recId
	 *            记录主键
	 * @param busiNo
	 *            业务编号
	 * @param execType
	 *            执行类型 如 00-删除
	 *            TopReportConstants.REPORT_DATAPROCESS_EXECTYPE_DEL
	 * @param execResult
	 *            执行结果
	 * @param execRemark
	 *            执行说明
	 * @throws CommonException
	 */
	public void saveBiDataProcessLog(String appType, String currentFile, String recId, String busiNo, String execType,
			String execResult, String execRemark) throws CommonException {

		GlobalInfo gi = GlobalInfo.getCurrentInstance();

		BiDataProcessLog biDataProcessLog = new BiDataProcessLog();
		biDataProcessLog.setApptype(appType);
		biDataProcessLog.setBusiNo(busiNo);
		biDataProcessLog.setCurrentfile(currentFile);
		biDataProcessLog.setExecRemark(execRemark);
		biDataProcessLog.setExecResult(execResult);
		biDataProcessLog.setExecTlr(gi.getTlrno());
		biDataProcessLog.setExecTm(new Date());
		biDataProcessLog.setExecType(execType);
		biDataProcessLog.setId(ReportUtils.getUUID());
		biDataProcessLog.setRecId(recId);

		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		rootdao.save(biDataProcessLog);
	}
	
	
	/**
	 * 首页操作员待完成任务信息
	 *
	 * @return
	 * @throws CommonException
	 */
	public List<ViHomePageTodo> getUndoTask1(HttpSession httpSession) throws CommonException {
		GlobalInfo globalInfo = (GlobalInfo) httpSession.getAttribute(GlobalInfo.KEY_GLOBAL_INFO);
		List<ViHomePageTodo> list = new ArrayList<ViHomePageTodo>();
		List<ViHomePageTodo> backlist = new ArrayList<ViHomePageTodo>();
		ROOTDAO rootDao = ROOTDAOUtils.getROOTDAO();
		String roleName = HsbcAmlUtils.getDepartByUserId(globalInfo.getTlrno());
		String hql = " from ViHomePageTodo where  brNo ='"+globalInfo.getBrno()+"' and roleName='"+roleName+"' and lstUpdTlr='"+globalInfo.getTlrno()+"' order by workDate";
		list = rootDao.queryByQL2List(hql);
		if(list!=null&&list.size()>0){
			for(ViHomePageTodo bean : list){
				String workDate = bean.getWorkDate();
				String sql = "select count(1) from AML_SSHLDYP a where a.natural_date>to_date('"+workDate+"','yyyymmdd') and a.natural_date<=sysdate and a.is_holiday='0'";
				int count = rootDao.queryBySqlToCount(sql);
				if(Integer.valueOf(AmlFeedBackservice.getInstance().getParentDir("REPORTTYBH", "AML"))<count){
					bean.setT5Flag("1");//超过5天添加标志
				}
				backlist.add(bean);
			}
		}
		return backlist;
	}
	
	
	/**
	 * 首页操作员所在部门待完成任务信息
	 *
	 * @return
	 * @throws CommonException
	 */
	public List<ViHomePageTodo02> getUndoTask2(HttpSession httpSession) throws CommonException {
		GlobalInfo globalInfo = (GlobalInfo) httpSession.getAttribute(GlobalInfo.KEY_GLOBAL_INFO);
		List<ViHomePageTodo02> list = new ArrayList<ViHomePageTodo02>();
		List<ViHomePageTodo02> backlist = new ArrayList<ViHomePageTodo02>();
		ROOTDAO rootDao = ROOTDAOUtils.getROOTDAO();
		String roleName = HsbcAmlUtils.getDepartByUserId(globalInfo.getTlrno());
		String hql = " from ViHomePageTodo02 where  brNo ='"+globalInfo.getBrno()+"' and roleName='"+roleName+"'"+
				" and (blNum<>0 or sbNum<>0 or noPackageNum<>0) order by workDate";
		list = rootDao.queryByQL2List(hql);
		if(list!=null&&list.size()>0){
			for(ViHomePageTodo02 bean : list){
				String workDate = bean.getWorkDate();
				String sql = "select count(1) from AML_SSHLDYP a where a.natural_date>to_date('"+workDate+"','yyyymmdd') and a.natural_date<=sysdate and a.is_holiday='0'";
				int count = rootDao.queryBySqlToCount(sql);
				if(Integer.valueOf(AmlFeedBackservice.getInstance().getParentDir("REPORTTYBH", "AML"))<count){
					bean.setT5Flag("1");//超过5天添加标志
				}
				backlist.add(bean);
			}
		}
		return backlist;
	}
	
	
	/**
	 * 首页操作员所在部门事后审查信息
	 * @author lu.gao 2018-3-13
	 * @return
	 * @throws CommonException
	 * @throws ParseException 
	 */
	public List<ViHomePageTodo03> getUndoTask3(HttpSession httpSession) throws CommonException, ParseException {
		GlobalInfo globalInfo = (GlobalInfo) httpSession.getAttribute(GlobalInfo.KEY_GLOBAL_INFO);
		List<ViHomePageTodo03> list = new ArrayList<ViHomePageTodo03>();
		List<ViHomePageTodo03> backlist = new ArrayList<ViHomePageTodo03>();
		ROOTDAO rootDao = ROOTDAOUtils.getROOTDAO();
		String roleName = HsbcAmlUtils.getDepartByUserId(globalInfo.getTlrno());
		String hql = " from ViHomePageTodo03 where  brNo ='"+globalInfo.getBrno()+"' and roleName='"+roleName+"'"+
				"order by workDate";
		list = rootDao.queryByQL2List(hql);
		if(list!=null&&list.size()>0){
			for(ViHomePageTodo03 bean : list){
				String workDate = bean.getWorkDate();
				SimpleDateFormat s= new SimpleDateFormat("yyyyMMdd");
				Date work = (Date)s.parse(workDate);
				Calendar  calendar = new GregorianCalendar(); 
				calendar.setTime(work); 
				calendar.add(calendar.DATE,17); //把日期往后增加一天,整数往后推,负数往前移动 
				work=calendar.getTime();
				if(new Date().compareTo(work)==1){
					bean.setT17Flag("1");//超过17天添加标志
				}
				backlist.add(bean);
			}
		}
		return backlist;
	}
	
	/**
	 * 首页操作员所在部门事后审查信息
	 * @author zhuguoliang 2019-07-03
	 * @return
	 * @throws CommonException
	 * @throws ParseException 
	 */
	public List<ViHomePageTodo04> getUndoTask4(HttpSession httpSession) throws CommonException, ParseException {
		GlobalInfo globalInfo = (GlobalInfo) httpSession.getAttribute(GlobalInfo.KEY_GLOBAL_INFO);
		List<ViHomePageTodo04> list = new ArrayList<ViHomePageTodo04>();
		List<ViHomePageTodo04> backlist = new ArrayList<ViHomePageTodo04>();
		ROOTDAO rootDao = ROOTDAOUtils.getROOTDAO();
		String roleName = HsbcAmlUtils.getDepartByUserId(globalInfo.getTlrno());
		String hql = " from ViHomePageTodo04 where brno ='"+globalInfo.getBrno()+"'order by workDate";
		list = rootDao.queryByQL2List(hql);
		if(list!=null&&list.size()>0){
			for(ViHomePageTodo04 bean : list){
				String workDate = bean.getWorkDate();
				SimpleDateFormat s= new SimpleDateFormat("yyyyMMdd");
				Date work = (Date)s.parse(workDate);
				Calendar  calendar = new GregorianCalendar(); 
				calendar.setTime(work); 
				calendar.add(calendar.DATE,17); //把日期往后增加一天,整数往后推,负数往前移动 
				work=calendar.getTime();
				if(new Date().compareTo(work)==1){
					bean.setT17Flag("1");//超过17天添加标志
				}
				backlist.add(bean);
			}
		}
		return backlist;
	}
	
	/**
	 * 首页汇丰中国HSBC员工交易监测调研任务信息
	 *
	 * @return
	 * @throws CommonException
	 */
	public List<ViHomePageTodo05> getUndoTask5(HttpSession httpSession) throws CommonException {
		List<ViHomePageTodo05> list = new ArrayList<ViHomePageTodo05>();
		ROOTDAO rootDao = ROOTDAOUtils.getROOTDAO();
		String hql = " from ViHomePageTodo05 where 1 = 1";
		return list = rootDao.queryByQL2List(hql);
	}
	
	/**
	 * 首页汇丰中国HSBC员工交易监测自查任务信息
	 *
	 * @return
	 * @throws CommonException
	 */
	public List<ViHomePageTodo06> getUndoTask6(HttpSession httpSession) throws CommonException {
		List<ViHomePageTodo06> list = new ArrayList<ViHomePageTodo06>();
		ROOTDAO rootDao = ROOTDAOUtils.getROOTDAO();
		String hql = " from ViHomePageTodo06 where 1 = 1 ";
		return list = rootDao.queryByQL2List(hql);
	}
	
	/**
	 * 首页村镇行RRB员工交易监测自查任务信息
	 *
	 * @return
	 * @throws CommonException
	 */
	public List<ViHomePageTodo07> getUndoTask7(HttpSession httpSession) throws CommonException {
		GlobalInfo globalInfo = (GlobalInfo) httpSession.getAttribute(GlobalInfo.KEY_GLOBAL_INFO);
		List<ViHomePageTodo07> list = new ArrayList<ViHomePageTodo07>();
		ROOTDAO rootDao = ROOTDAOUtils.getROOTDAO();
		String hql = " from ViHomePageTodo07 where 1 = 1 and brNo ='"+globalInfo.getBrno()+"'";
		return list = rootDao.queryByQL2List(hql);
	}
}
