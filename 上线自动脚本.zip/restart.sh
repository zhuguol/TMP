#!/bin/bash

WAR=HBCNAML
WAR2=.war
WARPATH=/opt/IBM/wlp/usr/servers/defaultServer/dropins
TMPPATH=/tmp/PLUS
BACKUPPATH=/home/wasadm/warbackup

day=`date +%Y%m%d`
time=`date +%Y%m%d%H%M%S`

#ͣ����
echo stop server > restart$time.log
/opt/IBM/wlp/bin/server stop defaultServer
#����
echo cp $WARPATH/$WAR$WAR2 $BACKUPPATH/$WAR"_"$day$WAR2 > restart$time.log
cp $WARPATH/$WAR$WAR2 $BACKUPPATH/$WAR"_"$day$WAR2
#��ȡ����WAR��
echo mv $TMPPATH/$WAR$WAR2 $WARPATH/ > restart$time.log
mv $TMPPATH/$WAR$WAR2 $WARPATH/
#������
echo start server > restart$time.log
/opt/IBM/wlp/bin/server start defaultServer