#!/bin/bash

WAR=HBCNAML
WAR2=.war
WARPATH=/opt/IBM/wlp/usr/servers/defaultServer/dropins
TMPPATH=/tmp/PLUS

time=`date +%Y%m%d%H%M%S`

if [ ! -d $TMPPATH ];then
echo mkdir $TMPPATH > download$time.log
mkdir $TMPPATH 
echo chmod 775 $TMPPATH > download$time.log
chmod 775 $TMPPATH
fi
echo cp $WARPATH/$WAR$WAR2 $TMPPATH/$WAR$WAR2 > download$time.log
cp $WARPATH/$WAR$WAR2 $TMPPATH/$WAR$WAR2

echo chmod 777 $TMPPATH/$WAR$WAR2 > download$time.log
chmod 777 $TMPPATH/$WAR$WAR2 