package com.huateng.ebank.framework.proxool;

import org.bouncycastle.util.encoders.Hex;

import com.huateng.ebank.business.common.SystemConstant;
import com.huateng.ebank.framework.util.encrypt.CryptoUtil;
import com.huateng.report.utils.InitParams;

public class EbankProxoolDataSource extends org.logicalcobwebs.proxool.ProxoolDataSource {

	@Override
	public void setPassword(String password) {
//		super.setPassword(new String(CryptoUtil.decrypt(Hex.decode(password), SystemConstant.DEFAULT_PASSWORD_KEY)));
		
		String oracle_password = InitParams.getParam("oracle_password");
    	String new_password = new String(CryptoUtil.decrypt(Hex.decode(oracle_password), SystemConstant.DEFAULT_PASSWORD_KEY));
    	super.setPassword(new_password);
	}
	
	@Override
    public void setDriverUrl(String url) {
    	String oracle_url = InitParams.getParam("oracle_url");
    	super.setDriverUrl(oracle_url);
    }
	
	@Override
	public void setUser(String username) {
		String oracle_username = InitParams.getParam("oracle_username");
		super.setUser(oracle_username);
	}
}
