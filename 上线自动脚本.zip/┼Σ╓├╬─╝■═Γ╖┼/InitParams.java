package com.huateng.report.utils;

import java.io.FileReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

public class InitParams {
	private static String  HSBC_PLUS_CONFIG_PATH = "/home/wasadm/conf/hsbc_aml.properties";
	private static Properties properties = new Properties();
	
	static{
		try {
			init();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void init() throws Exception {
		Properties proper = new Properties();
		proper.load(new FileReader(HSBC_PLUS_CONFIG_PATH)); // 配置文件读取uri

		Map<String, String> map = new HashMap<String, String>();
		Iterator<Object> keys = proper.keySet().iterator();
		while (keys.hasNext()) {
			String key = (String) keys.next();
			if (proper.getProperty(key) != null) {
				map.put(key, proper.getProperty(key).toString());
			}
		}
		proper.putAll(map);
		properties.putAll(proper);
	}
	
	public static String getParam(String key){
		return (String)properties.get(key);
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}
}
