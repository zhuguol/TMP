--�������ù������
delete from bi_nationregion;
insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('@N', '��', null, '��', null, null, '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ABW', '��³��', '533', '��³��', 'Aruba', 'ARUBA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('AFG', '��������˹����', '004', '������', 'Islamic State of Afghanistan', 'AFGHA NISTAN', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('AGO', '���������͹�', '024', '������', 'Republic of Angola', 'ANGOL A', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('AIA', '������', '660', '������', 'Anguilla', 'ANGUIL LA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ALB', '���������ǹ��͹�', '008', '����������', 'Republic of Albania', 'ALBANI A', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('AND', '����������', '020', '������', 'Principalit y of Andorra', 'ANDOR RA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ANT', '����������˹', '530', '����������˹', 'Netherlan ds Antilles', 'NETHER LANDS ANTILLE S', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ARE', '��������������', '784', '������', 'United Arab Emirates', 'UNITED ARAB EMIRAT ES', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ARG', '����͢���͹�', '032', '����͢', 'Republic of Argentina', 'ARGENT INA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ARM', '�������ǹ��͹�', '051', '��������', 'Republic of Armenia', 'ARMENI A', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ASM', '������Ħ��', '016', '������Ħ��', 'American Samoa', 'AMERIC AN SAMOA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ATA', '�ϼ���', '010', '�ϼ���', 'Antarctic a', 'ANTAR CTICA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ATF', '�����ϲ�����', '260', '�����ϲ�����', 'French Southern Territories', 'FRENCH SOUTHE RN TERRIT O-RIES', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ATG', '����ϺͰͲ���', '028', '����ϺͰͲ���', 'Antigua and Barbuda', 'ANTIGU A AND BARBUD A', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('AUS', '�Ĵ���������', '036', '�Ĵ�����', 'Common wealth of Australia', 'AUSTRA LIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('AUT', '�µ������͹�', '040', '�µ���', 'Republic of Austria', 'AUSTRI A', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('AZE', '�����ݽ����͹�', '031', '�����ݽ�', 'Republic of Azerbaijan', 'AZERBA IJAN', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('BDI', '��¡�Ϲ��͹�', '108', '��¡��', 'Republic of Burundi', 'BURUN DI', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('BEL', '����ʱ����', '056', '����ʱ', 'Kingdom of belgium', 'BELGIU M', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('BEN', '�������͹�', '204', '����', 'Republic of Benin', 'BENIN', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('BFA', '�����ɷ���', '854', '�����ɷ���', 'Burkina Faso', 'BURKIN A FASO', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('BGD', '�ϼ������񹲺͹�', '050', '�ϼ�����', 'Peoples Republic of Bangladesh', 'BANGLA DESH', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('BGR', '�������ǹ��͹�', '100', '��������', 'Republic ov Bulgaria', 'BULGAR IA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('BHR', '���ֹ�', '048', '����', 'State of Bahrain', 'BAHRAI N', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('BHS', '�͹�������', '044', '�͹���', 'Common wealth of the Bahamas', 'BAHAM AS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('BIH', '��˹���Ǻͺ�����ά��', '070', '����', 'Bosnia and Herzegovina', 'BOSNIA AND HERZEG OVINA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('BLR', '�׶���˹���͹�', '112', '�׶���˹', 'Republic of Belarus', 'BELARU S', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('BLZ', '������', '084', '������', 'Belize', 'BELIZE', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('BMU', '��Ľ��Ⱥ��', '060', '��Ľ��', 'Bermuda Islands', 'BERMU DA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('BOL', '����ά�ǹ��͹�', '068', '����ά��', 'Republic of Bolivia', 'BOLIVIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('BRA', '��������͹�', '076', '����', 'Federative Republic of Brazil', 'BRAZIL', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('BRB', '�ͰͶ�˹', '052', '�ͰͶ�˹', 'Barbados', 'BARBAD OS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('BRN', '������³������', '096', '����', 'Brunei Darussalam', 'BRUNEI DARUSS ALAM', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('BTN', '��������', '064', '����', 'Kingdom of Bhutan', 'BHUTA N', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('BVT', '��ά��', '074', '��ά��', 'Bouvet Island', 'BOUVET ISLAND', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('BWA', '�������ɹ��͹�', '072', '��������', 'Republic of Botswana', 'BOTSW ANA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('CAF', '�зǹ��͹�', '140', '�з�', 'Central African Republic', 'CENTRA L AFRICA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('CAN', '���ô�', '124', '���ô�', 'Canada', 'CANAD A', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('CCK', '�ƿ�˹ (����)Ⱥ��', '166', '�ƿ�˹ (����)Ⱥ��', 'Cocos(Ke eling) Islands', 'COCOS( KEELIN G) ISLANDS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('CHE', '��ʿ����', '756', '��ʿ', 'Swiss Confeder ation', 'SWITZE RLAND', '4', 'F', 'F', '20140515', '20140515152618', '1234567');

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('CHL', '�������͹�', '152', '����', 'Republic of Chile', 'CHILE', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('CHN', '�л����񹲺͹�', '156', '�й�', 'Peoples Republic of China', 'CHINA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('CIV', '���ص��߹��͹�', '384', '���ص���', 'Republic of Cote dIvire', 'COTE DIVOIR E', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('CMR', '����¡���͹�', '120', '����¡', 'Republic of Cameroon', 'CAMER OON', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('COD', '�չ��������͹�', '180', '�չ����� ��', 'Democrat ic Republic of Congo', 'CONGO, THE DEMOC RATIC REPUBLI C OF THE', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('COG', '�չ����͹�', '178', '�չ����� ��', 'Republic of Congo', 'CONGO', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('COK', '���Ⱥ��', '184', '���Ⱥ��', 'Cook Islands', 'COOK ISLANDS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('COL', '���ױ��ǹ��͹�', '170', '���ױ���', 'Republic of Colombia', 'COLOM BIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('COM', '��Ħ����˹������͹�', '174', '��Ħ��', 'Federal Islamic Republic of the Comoros', 'COMOR OS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('CPV', '��ýǹ��͹�', '132', '��ý�', 'Republic of Cape Verde', 'CAPEVERDE', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('CR', '��˹����ӹ��͹�', '188', '��˹�����', 'Republic of Costa Rica', 'COSTA RICA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('CSR', 'ʥ����', '162', 'ʥ����', 'Christmas Island', 'CHRIST MAS ISLAND', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('CUB', '�Ű͹��͹�', '192', '�Ű�', 'Republic of Cuba', 'CUBA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('CYM', '����Ⱥ��', '136', '����Ⱥ��', 'Cayman Islands', 'CAYMA N ISLANDS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('CYP', '����·˹���͹�', '196', '����·˹', 'Republic of Cyprus', 'CYPRUS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('CZE', '�ݿ˹��͹�', '203', '�ݿ�', 'Czech Republic', 'CZECH REPOUB LIC', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('DEU', '����־����͹�', '276', '�¹�', 'Federal Republic of Germany', 'GERMA NY', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('DJI', '�����Ṳ�͹�', '262', '������', 'Republic of Djibouti', 'DJIBOU TI', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('DMA', '�����������', '212', '�������', 'Common wealth of Dominica', 'DOMINI CA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('DNK', '��������', '208', '����', 'Kingdom of Denmark', 'DENMA RK', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('DOM', '������ӹ��͹�', '214', '������ӹ��͹�', 'Dominica n Republic', 'DOMINI CAN REPUBLI C', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('DZA', '�����������������񹲺͹�', '012', '����������', 'Democrat ic Peoples Republic of Algeria', 'ALGERI A', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ECU', '��϶�����͹�', '218', '��϶��', 'Republic of Ecuador', 'ECUAD OR', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('EGY', '�������������͹�', '818', '����', 'Arab Republic of Egypt', 'EGYPT', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ERI', '���������ǹ�', '232', '����������', 'State of Eritrea', 'ERITREA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ESH', '��������', '732', '��������', 'Western Sahara', 'WESTER N SAHARA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ESP', '������', '724', '������', 'Spain', 'SPAIN', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('EST', '��ɳ���ǹ��͹�', '233', '��ɳ����', 'Republic of Estonia', 'ESTONI A', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ETH', '����������', '231', '����������', 'Ethiopia', 'ETHIOPI A', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('FIN', '�������͹�', '246', '����', 'Republic of Finland', 'FINLAN D', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('FJI', '쳼ù��͹�', '242', '쳼�', 'Republic of Fiji', 'FIJI', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('FLK', '������Ⱥ��(����ά��˹)', '238', '������Ⱥ��(����ά��˹)', 'Falkland Islands(Malvinas)', 'FALKLA ND ISLANDS (MALVI NAS)', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('FRA', '���������͹�', '250', '����', 'French Republic', 'FRANCE', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('FRO', '����Ⱥ��', '234', '����Ⱥ��', 'Faroe Islands', 'FAROE ISLANDS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('FSM', '�ܿ�������������', '583', '�ܿ�������������', 'Federated States of Micronesia', 'MICRO NESIA, FEDERA TED STATES OF', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('GAB', '����͹�', '266', '����', 'Gabonese Republic', 'GABON', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('GBR', '���е߼�����������������', '826', 'Ӣ��', 'United Kingdom of Great Britain and Northern ireland', 'UNITED KINGDO M', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('GEO', '��³���ǹ��͹�', '268', '��³����', 'Republic of Georgia', 'GEORGI A', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('GHA', '���ɹ��͹�', '288', '����', 'Republic of Ghana', 'GHANA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('GIB', 'ֱ������', '292', 'ֱ������', 'Gibraltar', 'GIBRAL TAR', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('GIN', '�����ǹ��͹�', '324', '������', 'Republic of Guinea', 'GUINEA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('GLP', '�ϵ�����', '312', '�ϵ�����', 'Guadeloupe', 'GUADEL OUPE', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('GMB', '�Ա��ǹ��͹�', '270', '�Ա���', 'Republic of Gambia', 'GAMBIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('GNB', '�����Ǳ��ܹ��͹�', '624', '�����Ǳ���', 'Republic of Guinebissau', 'GUINEBISSAU', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('GNQ', '��������ǹ��͹�', '226', '���������', 'Republic of Equatoria l Guinea', 'EQUAT ORIAL GUINEA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('GRC', 'ϣ�����͹�', '300', 'ϣ��', 'Hellenic Republic', 'GREECE', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('GRD', '�����ɴ�', '308', '�����ɴ�', 'Grenada', 'GRENA DA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('GRL', '������', '304', '������', 'Greenland', 'GREENL AND', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('GTM', 'Σ���������͹�', '320', 'Σ������', 'Republic of Guatemala', 'GUATE MALA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('GUF', '����������', '254', '����������', 'French Guiana', 'FRENCH GUIANA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('GUM', '�ص�', '316', '�ص�', 'Guam', 'GUAM', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('GUY', '�����Ǻ������͹�', '328', '������', 'Cooperati ve Republic of Guyana', 'GUYAN A', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('HKG', '���', '344', '���', 'Hong Kong', 'HONG KONG', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('HMD', '�յµ���������ɵ�', '334', '�յµ���������ɵ�', 'Heard islands and Mc Donald Islands', 'HEARD ISLANDS AND MC DONAL D ISLANDS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('HND', '�鶼��˹���͹�', '340', '�鶼��˹', 'Republic of honduras', 'HONDU RAS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('HRV', '���޵��ǹ��͹�', '191', '���޵���', 'Republic of Croatia', 'CROATI A', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('HTI', '���ع��͹�', '332', '����', 'Republic of Haiti', 'HAITI', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('HUN', '���������͹�', '348', '������', 'Republic of Hungary', 'HUNGA RY', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('IDN', 'ӡ�������ǹ��͹�', '360', 'ӡ��������', 'Republic of Indonesia', 'INDONE SIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('IND', 'ӡ�ȹ��͹�', '356', 'ӡ��', 'Republic of India', 'INDIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('IOT', 'Ӣ��ӡ��������', '086', 'Ӣ��ӡ��������', 'British Indian Ocean Territory', 'BRITISH INDIAN OCEAN TERRITORY', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('IRL', '������', '372', '������', 'Ireland', 'IRELAN D', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('IRN', '������˹�����͹�', '364', '����', 'Islamic Rupublic of Iran', 'IRAN', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('IRQ', '�����˹��͹�', '368', '������', 'Republic of Iraq', 'IRAQ', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ISL', '�������͹�', '352', '����', 'Republic of Iceland', 'ICELAN D', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ISR', '��ɫ�й�', '376', '��ɫ��', 'State of Israel', 'ISRAEL', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ITA', '��������͹�', '380', '�����', 'Republic of Italy', 'ITALY', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('JAM', '�����', '388', '�����', 'Jamaica', 'JAMAIC A', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('JOR', 'Լ����ϣķ����', '400', 'Լ��', 'Hashemit e Kingdom of Jordan', 'JORDAN', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('JPN', '�ձ���', '392', '�ձ�', 'Japan', 'JAPAN', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('KAZ', '������˹̹���͹�', '398', '������˹̹', 'Republic of Kazakhsta n', 'KAZAK HSTAN', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('KEN', '�����ǹ��͹�', '404', '������', 'Republic of Kenya', 'KENYA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('KGZ', '������˹���͹�', '417', '������˹˹̹', 'Kyrgyz Republic', 'KYRGYZ STAN', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('KHM', '����կ����', '116', '����կ', 'Kingdom of Cambodia', 'CAMBO DIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('KIR', '�����˹���͹�', '296', '�����˹', 'Republic of Kiribati', 'KIRIBAT I', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('KNA', 'ʥ��ĺ���ά˹����', '659', 'ʥ���ĺ���ά˹', 'Federatio n of Saint Kitts and nevis', 'SAINT KITTS AND NEVIS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('KOR', '�����', '410', '����', 'Republic of Korea', 'KOREA, REPUBLI C OF', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('KWT', '�����ع�', '414', '������', 'State of Kuwait', 'KUWAIT', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('LAO', '���������������͹�', '418', '����', 'Lao Peoples Democrat ic Republic', 'LAOS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('LBN', '����۹��͹�', '422', '�����', 'Republic of Lebanon', 'LEBANO N', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('LBR', '�������ǹ��͹�', '430', '��������', 'Republic of Liberia', 'LIBERIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('LBY', '��������������������������ڹ�', '434', '������', 'Great Socialist Peoples Libyan Arab jamahiriya', 'LIBYA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('LCA', 'ʥ¬����', '662', 'ʥ¬����', 'Saint Lucia', 'SAINT LUCIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('LIE', '��֧��ʿ�ǹ���', '438', '��֧��ʿ��', 'Principalit y of Liechtenst ein', 'LIECHT ENSTEI N', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('LKA', '˹����������������干�͹�', '144', '˹������', 'Democrat ic Socialist Republic of Srilanka', 'SRI LANKA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('LSO', '����������', '426', '������', 'Kingdom of Lesoto', 'LESOTH O', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('LTU', '�����𹲺͹�', '440', '������', 'Republic of Lithuania', 'LITHUA NIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('LUX', '¬ɭ���󹫹�', '442', '¬ɭ��', 'Grand Duchy of Luxembo urg', 'LUXEMB OURG', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('LVA', '����ά�ǹ��͹�', '428', '����ά��', 'Republic of Latvia', 'LATVIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MAC', '����', '446', '����', 'Macau', 'MACAU', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MAR', 'Ħ�������', '504', 'Ħ���', 'Kingdom of Morocco', 'MOROC CO', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MCO', 'Ħ�ɸ繫��', '492', 'Ħ�ɸ�', 'Principalit y of Monaco', 'MONAC O', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MDA', 'Ħ�����߹��͹�', '498', 'Ħ������', 'Republic of Moldova', 'MOLDO VA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MDG', '�����˹�ӹ��͹�', '450', '�����˹��', 'Republic of Madagasc ar', 'MADAG ASCAR', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MDV', '�������򹲺͹�', '462', '��������', 'Republic of maldives', 'MALDIV ES', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MEX', 'ī������ڹ�', '484', 'ī����', 'United States of Mexico', 'MEXICO', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MHL', '���ܶ�Ⱥ�����͹�', '584', '���ܶ�Ⱥ��', 'Republic of the marshall Islands', 'MARSH ALL ISLANDS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MKD', 'ǰ��˹��������ٹ��͹�', '807', 'ǰ�������', 'The Former Yu, goslav Republic of Macedonia', 'MACED ONIA, THE FORMER YUGOSL AV REPUBLI C OF', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MLI', '���ﹲ�͹�', '466', '����', 'Republic of Mali', 'MALI', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MLT', '���������͹�', '470', '������', 'Republic of Malta', 'MALTA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MMR', '�������', '104', '���', 'Union of Myanmar', 'MYANM AR', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MNG', '�ɹŹ�', '496', '�ɹ�', 'Mongolia', 'MONGO LIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MNP', '������������������', '580', '����������', 'Common wealth of the Northern Marianas', 'NORTH ERN MARIAN AS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MOZ', 'Īɣ�ȿ˹��͹�', '508', 'Īɣ�ȿ�', 'Republic of Mozambique', 'MOZAM BIQUE', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MRT', 'ë����˹���͹�', '478', 'ë��������', 'Republic of Mauritius', 'MAURIT ANIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MSR', '����������', '500', '����������', 'Montserr at', 'MONTS ERRAT', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MTQ', '�������', '474', '�������', 'Martiniqu e', 'MARTIN IQUE', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MUS', 'ë����˹���͹�', '480', 'ë����˹', 'Republic of Mauritius', 'MAURIT IUS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MWI', '����ά���͹�', '454', '����ά', 'Republic of Malawi', 'MALAW I', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MYS', '��������', '458', '��������', 'Malaysia', 'MALAYS IA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('MYT', '��Լ��', '175', '��Լ��', 'Mayotte', 'MAYOT TE', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('NAM', '���ױ��ǹ��͹�', '516', '���ױ���', 'Republic of Namibia', 'NAMIBI A', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('NCL', '�¿��������', '540', '�¿��������', 'New Caledonia', 'NEW CALEDO NIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('NER', '���ն����͹�', '562', '���ն�', 'Republic of Niger', 'NIGER', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('NFK', 'ŵ���˵�', '574', 'ŵ���˵�', 'Norfolk Island', 'NORFOL K ISLAND', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('NGA', '������������͹�', '566', '��������', 'Federal Republic of Nigeria', 'NIGERIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('NIC', '������Ϲ��͹�', '558', '�������', 'Republic of Nicaragua', 'NICARA GUA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('NIU', 'Ŧ��', '570', 'Ŧ��', 'Niue', 'NIUE', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('NLD', '��������', '528', '����', 'Kingdom of the Netherlands', 'NETHER LANDS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('NOR', 'Ų������', '578', 'Ų��', 'Kingdom of Norway', 'NORWA Y', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('NPL', '�Ჴ������', '524', '�Ჴ��', 'Kingdom of Nepal', 'NEPAL', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('NRU', '�³���͹�', '520', '�³', 'Republic of Nauru', 'NAURU', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('NZL', '������', '554', '������', 'New Zealand', 'NEW ZEALAN D', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('OMN', '�����յ���', '512', '����', 'Sultanate of Oman', 'OMAN', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('PAK', '�ͻ�˹̹��˹�����͹�', '586', '�ͻ�˹̹', 'Islamic Republic of Pakistan', 'PAKISTA N', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('PAN', '���������͹�', '591', '������', 'Republic of Panama', 'PANAM A', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('PCN', 'Ƥ�ÿ���Ⱥ��', '612', 'Ƥ�ؿ���Ⱥ��', 'Pitcairn Islands Group', 'PITCAIR N ISLANDS GROUP', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('PER', '��³���͹�', '604', '��³', 'Republic of Peru', 'PERU', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('PHL', '���ɱ����͹�', '608', '���ɱ�', 'Republic of the Philippines', 'PHILIPPI NES', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('PLW', '���͹��͹�', '585', '����', 'Republic of Palau', 'PALAU', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('PNG', '�Ͳ����¼����Ƕ�����', '598', '�Ͳ����¼�����', 'Independ ent State of Papua New Guinea', 'PAPUA NEW GUINEA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('POL', '�������͹�', '616', '����', 'Republic of Poland', 'POLAND', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('PRI', '���������������', '630', '�������', 'Common wealth of Puerto Rico', 'PUERTO RICO', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('PRK', '���������������񹲺͹�', '408', '����', 'Democrat ic Peoples Republic of Ko-rea', 'KOREA, DEMOC RATIC PEOPLES REPUBLI C OF', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('PRT', '���������͹�', '620', '������', 'Pirtugues e Republic', 'PORTU GAL', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('PRY', '�����繲�͹�', '600', '������', 'Republic of Paraguay', 'PARAGU AY', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('PST', '����˹̹��', '374', '����˹̹', 'State of Palestine', 'PALESTI NE', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('PYF', '��������������', '258', '��������������', 'French Polynesia', 'FRENCH POLYNE SIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('QAT', '��������', '634', '������', 'State of Qatar', 'QATAR', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('REU', '������', '638', '������', 'Reunion', 'REUNIO N', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ROM', '��������', '642', '��������', 'Romania', 'ROMAN IA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('RUS', '����˹����', '643', '����˹����', 'Russian Federation', 'RUSSIA N FEDERA TION', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('RWA', '¬���ﹲ�͹�', '646', '¬����', 'Republic of Rwanda', 'RWAND A', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('SAU', 'ɳ�ذ���������', '682', 'ɳ�ذ�����', 'Kingdom of Saudi Arabia', 'SAUDI ARABIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('SDN', '�յ����͹�', '736', '�յ�', 'Republic of the Sudan', 'SUDAN', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('SEN', '���ڼӶ����͹�', '686', '���ڼӶ�', 'Republic of Senegal', 'SENEGA L', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('SGP', '�¼��¹��͹�', '702', '�¼���', 'Republic of Singapore', 'SINGAP ORE', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('SGS', '�������ǵ�����ɣ��Τ�浺', '239', '�������ǵ�����ɣ��Τ�浺', 'South Georgia and South Sandwich Islands', 'SOUTH GEORGI A AND SOUTH SANDWI CH ISLANDS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('SHN', '�Ժ�����', '654', 'ʥ������', 'Saint Helena', 'SAINT HELENA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('SJM', '˹�߶���Ⱥ��', '744', '˹�߶���Ⱥ��', 'Svalbard and Jan mayen islands', 'SVALBA RD AND JAN MAYEN ISLANDS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('SLB', '������Ⱥ��', '090', '������Ⱥ��', 'Solomon Islands', 'SOLOM ON ISLANDS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('SLE', '�����������͹�', '694', '��������', 'Republic of Sierra Leone', 'SIERRA LEONE', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('SLV', '�����߶๲�͹�', '222', '�����߶�', 'Republic of El Salvador', 'EL SALVAD OR', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('SMR', 'ʥ����ŵ���͹�', '674', 'ʥ����ŵ', 'Republic of San Marino', 'SAN MARIO N', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('SOM', '�����ﹲ�͹�', '706', '������', 'Somali Republic', 'SOMALI A', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('SPM', 'ʥƤ�������ܿ�¡', '666', 'ʥƤ�������ܿ�¡', 'Saint Pierre and Miquelon', 'SAINT PIERRE AND MIQUEL ON', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('STp', 'ʥ���������������������͹�', '678', 'ʥ��������������', 'Democrat ic Republic of Sao Tome and Principe', 'SAO TOME AND PRINCIP E', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('SUR', '�����Ϲ��͹�', '740', '������', 'Republic of Suriname', 'SURINA ME', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('SVK', '˹�工�˹��͹�', '703', '˹�工��', 'Slovak Republic', 'SLOVAK IA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('SVN', '˹�������ǹ��͹�', '705', '˹��������', 'Republic of Slovenia', 'SLOVEN IA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('SWE', '�������', '752', '���', 'Kingdom of Sweden', 'SWEDE N', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('SWZ', '˹��ʿ������', '748', '˹��ʿ��', 'Kingdom of Swaziland', 'SWAZIL AND', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('SYC', '��������͹�', '690', '�����', 'Republic of Seychelles', 'SEYCHE LLS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('SYR', '�����������ǹ��͹�', '760', '������', 'Syrian Arab Republic', 'SYRIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('TCA', '�ؿ�˹�Ϳ���˹Ⱥ��', '796', '�ؿ�˹��˹Ⱥ��', 'Turks and Caicos Islands', 'TURKS AND CAICOS ISLANDS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('TCD', 'է�ù��͹�', '148', 'է��', 'Republic of Chad', 'CHAD', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('TGO', '��繲�͹�', '768', '���', 'Republic of Tago', 'TOGO', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('THA', '̩����', '764', '̩��', 'Kingdom of Thailand', 'THAILA ND', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('TJK', '������˹̹���͹�', '762', '������˹̹', 'Republic of Tajikistan', 'TAJIKIST AN', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('TKL', '�п���', '772', '�п���', 'Tokelau', 'TOKELA U', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('TKM', '������˹̹', '795', '������˹̹', 'Turkmeni stan', 'TURKM ENISTA N', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('TMP', '������', '626', '������', 'East Timor', 'EAST TIMOR', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('TON', '��������', '776', '����', 'Kingdom of Tonga', 'TONGA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('TTO', '�������Ͷ�͸繲�͹�', '780', '�������Ͷ�͸�', 'Republic of Trinidad and Tobago', 'TRINID AD AND TOBAG O', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('TUN', 'ͻ��˹���͹�', '788', 'ͻ��˹', 'Republic of Tunisia', 'TUNISIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('TUR', '�����乲�͹�', '792', '������', 'Republic of Turkey', 'TURKEY', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('TUV', 'ͼ��¬', '798', 'ͼ��¬', 'Tuvalu', 'TUVAL U', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('TWN', '�й�̨��', '158', '̨��', 'Taiwan, Province of China', 'TAIWAN , PROVIN CE OF CHINA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('TZA', '̹ɣ�������Ϲ��͹�', '834', '̹ɣ����', 'United Republic of Tanzania', 'TANZA NIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('UGA', '�ڸɴﹲ�͹�', '800', '�ڸɴ�', 'Republic of Uganda', 'UGAND A', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('UKR', '�ڿ���', '804', '�ڿ���', 'Ukraine', 'UKRAIN E', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('UMI', '����������С����', '581', '����������С����', 'United States Minor Outlying Islands', 'UNITED STATES MINOR OUTLYI NG ISLANDS', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('URY', '�����綫�����͹�', '858', '������', 'Oriental Republic of Uruguay', 'URUGU AY', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('USA', '��������ڹ�', '840', '����', 'United States of America', 'UNITED STATES', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('UZB', '���ȱ��˹̹���͹�', '860', '���ȱ��˹̹', 'Republic of Uzbekistan', 'UZBEKIS TAN', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('VAT', '��ٸԳǹ�', '336', '��ٸ�', 'Vatican City State', 'VATICA N', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('VCT', 'ʥ��ɭ�غ͸����ɶ�˹', '670', 'ʥ��ɭ�غ͸����ɶ�˹', 'Saint Vincent and the Grenadines', 'SAINT VINCEN T AND THE GRENA DINES', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('VEN', 'ί���������͹�', '862', 'ί������', 'Republic of Venezuela', 'VENEZU ELA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('VGB', 'Ӣ��ά����Ⱥ��', '092', 'Ӣ��ά����Ⱥ��', 'British Virgin Islands', 'VIRGIN ISLANDS , BRITISH', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('VIR', 'Ӣ��ά����Ⱥ��', '850', '����ά����Ⱥ��', 'Virgin Islands of the United States', 'VIRGIN ISLANDS ,U.S.', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('VNM', 'Խ�������ϯ���͹�', '704', 'Խ��', 'Socialist Republic of Viet Nam', 'VIET NAM', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('VUT', '��Ŭ��ͼ���͹�', '548', '��Ŭ��ͼ', 'Republic of Vanuatu', 'VANUA TU', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('WLF', '����˹�͸�ͼ��Ⱥ��', '876', '����˹�͸�ͼ��', 'Wallis and Futuna', 'WALLIS AND FUTUN A', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('WSM', '��Ħ�Ƕ�����', '882', '��Ħ��', 'Independ ent State of Samoa', 'SAMOA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('YEM', 'Ҳ�Ź��͹�', '887', 'Ҳ��', 'Republic of Yemen', 'YEMEN', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('YUG', '��˹�������˹��͹�', '891', '��˹����', 'Federal Republic of Yugoslavia', 'YUGOSL AVIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('Z01', '�й���½������˰��', null, '�й���½������˰��', null, null, '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('Z02', '�й���½�����ӹ���', null, '�й���½�����ӹ���', null, null, '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('Z03', '�й���½������ʯ������', null, '�й���½������ʯ������', null, null, '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ZAF', '�Ϸǹ��͹�', '710', '�Ϸ�', 'Republic of South Africa', 'SOUTH AFRICA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ZMB', '�ޱ��ǹ��͹�', '894', '�ޱ���', 'Republic of Zambia', 'ZAMBIA', '4', 'F', 'F', null, null, null);

insert into bi_nationregion (NATIONREGION_CODE, CHINA_NAME, NATIONREGION_NUMBER, CHINA_SHORT_NAME, ENG_NAME, ENG_SHORT_NAME, ST, IS_LOCK, IS_DEL, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER)
values ('ZWE', '��Ͳ�Τ���͹�', '716', '��Ͳ�Τ', 'Republic of Zimbabwe', 'ZIMBAB WE', '4', 'F', 'F', null, null, null);