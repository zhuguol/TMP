--�������õ�������
delete from BI_AREAOFCHINA;
insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('110000', '110000-������', '4', null, null, '4', null, null, null, '1');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('110100', '110100-��Ͻ��', '4', null, null, '4', null, null, null, '2');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('110101', '110101-������', '4', null, null, '4', null, null, null, '3');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('110102', '110102-������', '4', null, null, '4', null, null, null, '4');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('110105', '110105-������', '4', null, null, '4', null, null, null, '5');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('110106', '110106-��̨��', '4', null, null, '4', null, null, null, '6');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('110107', '110107-ʯ��ɽ��', '4', null, null, '4', null, null, null, '7');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('110108', '110108-������', '4', null, null, '4', null, null, null, '8');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('110109', '110109-��ͷ����', '4', null, null, '4', null, null, null, '9');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('110111', '110111-��ɽ��', '4', null, null, '4', null, null, null, '10');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('110112', '110112-ͨ����', '4', null, null, '4', null, null, null, '11');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('110113', '110113-˳����', '4', null, null, '4', null, null, null, '12');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('110114', '110114-��ƽ��', '4', null, null, '4', null, null, null, '13');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('110115', '110115-������', '4', null, null, '4', null, null, null, '14');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('110116', '110116-������', '4', null, null, '4', null, null, null, '15');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('110117', '110117-ƽ����', '4', null, null, '4', null, null, null, '16');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('110118', '110118-������', '4', null, null, '4', null, null, null, '17');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('110119', '110119-������', '4', null, null, '4', null, null, null, '18');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('120000', '120000-�����', '4', null, null, '4', null, null, null, '19');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('120100', '120100-��Ͻ��', '4', null, null, '4', null, null, null, '20');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('120101', '120101-��ƽ��', '4', null, null, '4', null, null, null, '21');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('120102', '120102-�Ӷ���', '4', null, null, '4', null, null, null, '22');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('120103', '120103-������', '4', null, null, '4', null, null, null, '23');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('120104', '120104-�Ͽ���', '4', null, null, '4', null, null, null, '24');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('120105', '120105-�ӱ���', '4', null, null, '4', null, null, null, '25');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('120106', '120106-������', '4', null, null, '4', null, null, null, '26');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('120110', '120110-������', '4', null, null, '4', null, null, null, '27');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('120111', '120111-������', '4', null, null, '4', null, null, null, '28');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('120112', '120112-������', '4', null, null, '4', null, null, null, '29');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('120113', '120113-������', '4', null, null, '4', null, null, null, '30');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('120114', '120114-������', '4', null, null, '4', null, null, null, '31');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('120115', '120115-������', '4', null, null, '4', null, null, null, '32');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('120116', '120116-��������', '4', null, null, '4', null, null, null, '33');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('120117', '120117-������', '4', null, null, '4', null, null, null, '34');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('120118', '120118-������', '4', null, null, '4', null, null, null, '35');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('120119', '120119-������', '4', null, null, '4', null, null, null, '36');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130000', '130000-�ӱ�ʡ', '4', null, null, '4', null, null, null, '37');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130100', '130100-ʯ��ׯ��', '4', null, null, '4', null, null, null, '38');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130101', '130101-��Ͻ��', '4', null, null, '4', null, null, null, '39');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130102', '130102-������', '4', null, null, '4', null, null, null, '40');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130104', '130104-������', '4', null, null, '4', null, null, null, '41');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130105', '130105-�»���', '4', null, null, '4', null, null, null, '42');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130107', '130107-�������', '4', null, null, '4', null, null, null, '43');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130108', '130108-ԣ����', '4', null, null, '4', null, null, null, '44');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130109', '130109-޻����', '4', null, null, '4', null, null, null, '45');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130110', '130110-¹Ȫ��', '4', null, null, '4', null, null, null, '46');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130111', '130111-�����', '4', null, null, '4', null, null, null, '47');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130121', '130121-������', '4', null, null, '4', null, null, null, '48');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130123', '130123-������', '4', null, null, '4', null, null, null, '49');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130125', '130125-������', '4', null, null, '4', null, null, null, '50');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130126', '130126-������', '4', null, null, '4', null, null, null, '51');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130127', '130127-������', '4', null, null, '4', null, null, null, '52');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130128', '130128-������', '4', null, null, '4', null, null, null, '53');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130129', '130129-�޻���', '4', null, null, '4', null, null, null, '54');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130130', '130130-�޼���', '4', null, null, '4', null, null, null, '55');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130131', '130131-ƽɽ��', '4', null, null, '4', null, null, null, '56');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130132', '130132-Ԫ����', '4', null, null, '4', null, null, null, '57');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130133', '130133-����', '4', null, null, '4', null, null, null, '58');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130183', '130183-������', '4', null, null, '4', null, null, null, '59');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130184', '130184-������', '4', null, null, '4', null, null, null, '60');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130200', '130200-��ɽ��', '4', null, null, '4', null, null, null, '61');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130201', '130201-��Ͻ��', '4', null, null, '4', null, null, null, '62');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130202', '130202-·����', '4', null, null, '4', null, null, null, '63');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130203', '130203-·����', '4', null, null, '4', null, null, null, '64');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130204', '130204-��ұ��', '4', null, null, '4', null, null, null, '65');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130205', '130205-��ƽ��', '4', null, null, '4', null, null, null, '66');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130207', '130207-������', '4', null, null, '4', null, null, null, '67');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130208', '130208-������', '4', null, null, '4', null, null, null, '68');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130209', '130209-��������', '4', null, null, '4', null, null, null, '69');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130223', '130223-����', '4', null, null, '4', null, null, null, '70');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130224', '130224-������', '4', null, null, '4', null, null, null, '71');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130225', '130225-��ͤ��', '4', null, null, '4', null, null, null, '72');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130227', '130227-Ǩ����', '4', null, null, '4', null, null, null, '73');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130229', '130229-������', '4', null, null, '4', null, null, null, '74');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130281', '130281-����', '4', null, null, '4', null, null, null, '75');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130283', '130283-Ǩ����', '4', null, null, '4', null, null, null, '76');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130300', '130300-�ػʵ���', '4', null, null, '4', null, null, null, '77');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130301', '130301-��Ͻ��', '4', null, null, '4', null, null, null, '78');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130302', '130302-������', '4', null, null, '4', null, null, null, '79');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130303', '130303-ɽ������', '4', null, null, '4', null, null, null, '80');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130304', '130304-��������', '4', null, null, '4', null, null, null, '81');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130306', '130306-������', '4', null, null, '4', null, null, null, '82');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130321', '130321-��������������', '4', null, null, '4', null, null, null, '83');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130322', '130322-������', '4', null, null, '4', null, null, null, '84');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130324', '130324-¬����', '4', null, null, '4', null, null, null, '85');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130400', '130400-������', '4', null, null, '4', null, null, null, '86');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130401', '130401-��Ͻ��', '4', null, null, '4', null, null, null, '87');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130402', '130402-��ɽ��', '4', null, null, '4', null, null, null, '88');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130403', '130403-��̨��', '4', null, null, '4', null, null, null, '89');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130404', '130404-������', '4', null, null, '4', null, null, null, '90');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130406', '130406-������', '4', null, null, '4', null, null, null, '91');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130421', '130421-������', '4', null, null, '4', null, null, null, '92');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130423', '130423-������', '4', null, null, '4', null, null, null, '93');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130424', '130424-�ɰ���', '4', null, null, '4', null, null, null, '94');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130425', '130425-������', '4', null, null, '4', null, null, null, '95');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130426', '130426-����', '4', null, null, '4', null, null, null, '96');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130427', '130427-����', '4', null, null, '4', null, null, null, '97');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130428', '130428-������', '4', null, null, '4', null, null, null, '98');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130429', '130429-������', '4', null, null, '4', null, null, null, '99');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130430', '130430-����', '4', null, null, '4', null, null, null, '100');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130431', '130431-������', '4', null, null, '4', null, null, null, '101');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130432', '130432-��ƽ��', '4', null, null, '4', null, null, null, '102');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130433', '130433-������', '4', null, null, '4', null, null, null, '103');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130434', '130434-κ��', '4', null, null, '4', null, null, null, '104');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130435', '130435-������', '4', null, null, '4', null, null, null, '105');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130481', '130481-�䰲��', '4', null, null, '4', null, null, null, '106');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130500', '130500-��̨��', '4', null, null, '4', null, null, null, '107');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130501', '130501-��Ͻ��', '4', null, null, '4', null, null, null, '108');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130502', '130502-�Ŷ���', '4', null, null, '4', null, null, null, '109');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130503', '130503-������', '4', null, null, '4', null, null, null, '110');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130521', '130521-��̨��', '4', null, null, '4', null, null, null, '111');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130522', '130522-�ٳ���', '4', null, null, '4', null, null, null, '112');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130523', '130523-������', '4', null, null, '4', null, null, null, '113');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130524', '130524-������', '4', null, null, '4', null, null, null, '114');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130525', '130525-¡Ң��', '4', null, null, '4', null, null, null, '115');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130526', '130526-����', '4', null, null, '4', null, null, null, '116');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130527', '130527-�Ϻ���', '4', null, null, '4', null, null, null, '117');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130528', '130528-������', '4', null, null, '4', null, null, null, '118');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130529', '130529-��¹��', '4', null, null, '4', null, null, null, '119');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130530', '130530-�º���', '4', null, null, '4', null, null, null, '120');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130531', '130531-������', '4', null, null, '4', null, null, null, '121');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130532', '130532-ƽ����', '4', null, null, '4', null, null, null, '122');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130533', '130533-����', '4', null, null, '4', null, null, null, '123');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130534', '130534-�����', '4', null, null, '4', null, null, null, '124');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130535', '130535-������', '4', null, null, '4', null, null, null, '125');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130581', '130581-�Ϲ���', '4', null, null, '4', null, null, null, '126');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130582', '130582-ɳ����', '4', null, null, '4', null, null, null, '127');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130600', '130600-������', '4', null, null, '4', null, null, null, '128');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130601', '130601-��Ͻ��', '4', null, null, '4', null, null, null, '129');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130602', '130602-������', '4', null, null, '4', null, null, null, '130');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130606', '130606-������', '4', null, null, '4', null, null, null, '131');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130607', '130607-������', '4', null, null, '4', null, null, null, '132');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130608', '130608-��Է��', '4', null, null, '4', null, null, null, '133');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130609', '130609-��ˮ��', '4', null, null, '4', null, null, null, '134');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130623', '130623-�ˮ��', '4', null, null, '4', null, null, null, '135');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130624', '130624-��ƽ��', '4', null, null, '4', null, null, null, '136');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130626', '130626-������', '4', null, null, '4', null, null, null, '137');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130627', '130627-����', '4', null, null, '4', null, null, null, '138');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130628', '130628-������', '4', null, null, '4', null, null, null, '139');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130629', '130629-�ݳ���', '4', null, null, '4', null, null, null, '140');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130630', '130630-�Դ��', '4', null, null, '4', null, null, null, '141');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130631', '130631-������', '4', null, null, '4', null, null, null, '142');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130632', '130632-������', '4', null, null, '4', null, null, null, '143');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130633', '130633-����', '4', null, null, '4', null, null, null, '144');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130634', '130634-������', '4', null, null, '4', null, null, null, '145');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130635', '130635-���', '4', null, null, '4', null, null, null, '146');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130636', '130636-˳ƽ��', '4', null, null, '4', null, null, null, '147');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130637', '130637-��Ұ��', '4', null, null, '4', null, null, null, '148');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130638', '130638-����', '4', null, null, '4', null, null, null, '149');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130681', '130681-������', '4', null, null, '4', null, null, null, '150');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130683', '130683-������', '4', null, null, '4', null, null, null, '151');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130684', '130684-�߱�����', '4', null, null, '4', null, null, null, '152');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130700', '130700-�żҿ���', '4', null, null, '4', null, null, null, '153');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130701', '130701-��Ͻ��', '4', null, null, '4', null, null, null, '154');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130702', '130702-�Ŷ���', '4', null, null, '4', null, null, null, '155');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130703', '130703-������', '4', null, null, '4', null, null, null, '156');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130705', '130705-������', '4', null, null, '4', null, null, null, '157');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130706', '130706-�»�԰��', '4', null, null, '4', null, null, null, '158');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130708', '130708-��ȫ��', '4', null, null, '4', null, null, null, '159');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130709', '130709-������', '4', null, null, '4', null, null, null, '160');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130722', '130722-�ű���', '4', null, null, '4', null, null, null, '161');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130723', '130723-������', '4', null, null, '4', null, null, null, '162');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130724', '130724-��Դ��', '4', null, null, '4', null, null, null, '163');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130725', '130725-������', '4', null, null, '4', null, null, null, '164');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130726', '130726-ε��', '4', null, null, '4', null, null, null, '165');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130727', '130727-��ԭ��', '4', null, null, '4', null, null, null, '166');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130728', '130728-������', '4', null, null, '4', null, null, null, '167');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130730', '130730-������', '4', null, null, '4', null, null, null, '168');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130731', '130731-��¹��', '4', null, null, '4', null, null, null, '169');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130732', '130732-�����', '4', null, null, '4', null, null, null, '170');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130800', '130800-�е���', '4', null, null, '4', null, null, null, '171');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130801', '130801-��Ͻ��', '4', null, null, '4', null, null, null, '172');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130802', '130802-˫����', '4', null, null, '4', null, null, null, '173');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130803', '130803-˫����', '4', null, null, '4', null, null, null, '174');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130804', '130804-ӥ��Ӫ�ӿ���', '4', null, null, '4', null, null, null, '175');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130821', '130821-�е���', '4', null, null, '4', null, null, null, '176');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130822', '130822-��¡��', '4', null, null, '4', null, null, null, '177');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130823', '130823-ƽȪ��', '4', null, null, '4', null, null, null, '178');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130824', '130824-��ƽ��', '4', null, null, '4', null, null, null, '179');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130825', '130825-¡����', '4', null, null, '4', null, null, null, '180');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130826', '130826-��������������', '4', null, null, '4', null, null, null, '181');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130827', '130827-��������������', '4', null, null, '4', null, null, null, '182');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130828', '130828-Χ�������ɹ���������', '4', null, null, '4', null, null, null, '183');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130900', '130900-������', '4', null, null, '4', null, null, null, '184');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130901', '130901-��Ͻ��', '4', null, null, '4', null, null, null, '185');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130902', '130902-�»���', '4', null, null, '4', null, null, null, '186');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130903', '130903-�˺���', '4', null, null, '4', null, null, null, '187');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130921', '130921-����', '4', null, null, '4', null, null, null, '188');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130922', '130922-����', '4', null, null, '4', null, null, null, '189');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130923', '130923-������', '4', null, null, '4', null, null, null, '190');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130924', '130924-������', '4', null, null, '4', null, null, null, '191');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130925', '130925-��ɽ��', '4', null, null, '4', null, null, null, '192');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130926', '130926-������', '4', null, null, '4', null, null, null, '193');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130927', '130927-��Ƥ��', '4', null, null, '4', null, null, null, '194');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130928', '130928-������', '4', null, null, '4', null, null, null, '195');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130929', '130929-����', '4', null, null, '4', null, null, null, '196');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130930', '130930-�ϴ����������', '4', null, null, '4', null, null, null, '197');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130981', '130981-��ͷ��', '4', null, null, '4', null, null, null, '198');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130982', '130982-������', '4', null, null, '4', null, null, null, '199');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130983', '130983-������', '4', null, null, '4', null, null, null, '200');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('130984', '130984-�Ӽ���', '4', null, null, '4', null, null, null, '201');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131000', '131000-�ȷ���', '4', null, null, '4', null, null, null, '202');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131001', '131001-��Ͻ��', '4', null, null, '4', null, null, null, '203');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131002', '131002-������', '4', null, null, '4', null, null, null, '204');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131003', '131003-������', '4', null, null, '4', null, null, null, '205');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131022', '131022-�̰���', '4', null, null, '4', null, null, null, '206');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131023', '131023-������', '4', null, null, '4', null, null, null, '207');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131024', '131024-�����', '4', null, null, '4', null, null, null, '208');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131025', '131025-�����', '4', null, null, '4', null, null, null, '209');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131026', '131026-�İ���', '4', null, null, '4', null, null, null, '210');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131028', '131028-�󳧻���������', '4', null, null, '4', null, null, null, '211');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131081', '131081-������', '4', null, null, '4', null, null, null, '212');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131082', '131082-������', '4', null, null, '4', null, null, null, '213');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131100', '131100-��ˮ��', '4', null, null, '4', null, null, null, '214');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131101', '131101-��Ͻ��', '4', null, null, '4', null, null, null, '215');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131102', '131102-�ҳ���', '4', null, null, '4', null, null, null, '216');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131103', '131103-������', '4', null, null, '4', null, null, null, '217');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131121', '131121-��ǿ��', '4', null, null, '4', null, null, null, '218');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131122', '131122-������', '4', null, null, '4', null, null, null, '219');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131123', '131123-��ǿ��', '4', null, null, '4', null, null, null, '220');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131124', '131124-������', '4', null, null, '4', null, null, null, '221');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131125', '131125-��ƽ��', '4', null, null, '4', null, null, null, '222');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131126', '131126-�ʳ���', '4', null, null, '4', null, null, null, '223');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131127', '131127-����', '4', null, null, '4', null, null, null, '224');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131128', '131128-������', '4', null, null, '4', null, null, null, '225');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('131182', '131182-������', '4', null, null, '4', null, null, null, '226');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('139000', '139000-ʡֱϽ�ؼ���������', '4', null, null, '4', null, null, null, '227');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('139001', '139001-������', '4', null, null, '4', null, null, null, '228');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('139002', '139002-������', '4', null, null, '4', null, null, null, '229');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140000', '140000-ɽ��ʡ', '4', null, null, '4', null, null, null, '230');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140100', '140100-̫ԭ��', '4', null, null, '4', null, null, null, '231');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140101', '140101-��Ͻ��', '4', null, null, '4', null, null, null, '232');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140105', '140105-С����', '4', null, null, '4', null, null, null, '233');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140106', '140106-ӭ����', '4', null, null, '4', null, null, null, '234');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140107', '140107-�ӻ�����', '4', null, null, '4', null, null, null, '235');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140108', '140108-���ƺ��', '4', null, null, '4', null, null, null, '236');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140109', '140109-�������', '4', null, null, '4', null, null, null, '237');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140110', '140110-��Դ��', '4', null, null, '4', null, null, null, '238');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140121', '140121-������', '4', null, null, '4', null, null, null, '239');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140122', '140122-������', '4', null, null, '4', null, null, null, '240');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140123', '140123-¦����', '4', null, null, '4', null, null, null, '241');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140181', '140181-�Ž���', '4', null, null, '4', null, null, null, '242');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140200', '140200-��ͬ��', '4', null, null, '4', null, null, null, '243');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140201', '140201-��Ͻ��', '4', null, null, '4', null, null, null, '244');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140202', '140202-����', '4', null, null, '4', null, null, null, '245');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140203', '140203-����', '4', null, null, '4', null, null, null, '246');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140211', '140211-�Ͻ���', '4', null, null, '4', null, null, null, '247');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140212', '140212-������', '4', null, null, '4', null, null, null, '248');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140221', '140221-������', '4', null, null, '4', null, null, null, '249');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140222', '140222-������', '4', null, null, '4', null, null, null, '250');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140223', '140223-������', '4', null, null, '4', null, null, null, '251');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140224', '140224-������', '4', null, null, '4', null, null, null, '252');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140225', '140225-��Դ��', '4', null, null, '4', null, null, null, '253');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140226', '140226-������', '4', null, null, '4', null, null, null, '254');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140227', '140227-��ͬ��', '4', null, null, '4', null, null, null, '255');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140300', '140300-��Ȫ��', '4', null, null, '4', null, null, null, '256');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140301', '140301-��Ͻ��', '4', null, null, '4', null, null, null, '257');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140302', '140302-����', '4', null, null, '4', null, null, null, '258');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140303', '140303-����', '4', null, null, '4', null, null, null, '259');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140311', '140311-����', '4', null, null, '4', null, null, null, '260');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140321', '140321-ƽ����', '4', null, null, '4', null, null, null, '261');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140322', '140322-����', '4', null, null, '4', null, null, null, '262');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140400', '140400-������', '4', null, null, '4', null, null, null, '263');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140401', '140401-��Ͻ��', '4', null, null, '4', null, null, null, '264');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140402', '140402-����', '4', null, null, '4', null, null, null, '265');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140411', '140411-����', '4', null, null, '4', null, null, null, '266');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140421', '140421-������', '4', null, null, '4', null, null, null, '267');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140423', '140423-��ԫ��', '4', null, null, '4', null, null, null, '268');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140424', '140424-������', '4', null, null, '4', null, null, null, '269');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140425', '140425-ƽ˳��', '4', null, null, '4', null, null, null, '270');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140426', '140426-�����', '4', null, null, '4', null, null, null, '271');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140427', '140427-������', '4', null, null, '4', null, null, null, '272');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140428', '140428-������', '4', null, null, '4', null, null, null, '273');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140429', '140429-������', '4', null, null, '4', null, null, null, '274');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140430', '140430-����', '4', null, null, '4', null, null, null, '275');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140431', '140431-��Դ��', '4', null, null, '4', null, null, null, '276');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140481', '140481-º����', '4', null, null, '4', null, null, null, '277');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140500', '140500-������', '4', null, null, '4', null, null, null, '278');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140501', '140501-��Ͻ��', '4', null, null, '4', null, null, null, '279');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140502', '140502-����', '4', null, null, '4', null, null, null, '280');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140521', '140521-��ˮ��', '4', null, null, '4', null, null, null, '281');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140522', '140522-������', '4', null, null, '4', null, null, null, '282');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140524', '140524-�괨��', '4', null, null, '4', null, null, null, '283');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140525', '140525-������', '4', null, null, '4', null, null, null, '284');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140581', '140581-��ƽ��', '4', null, null, '4', null, null, null, '285');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140600', '140600-˷����', '4', null, null, '4', null, null, null, '286');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140601', '140601-��Ͻ��', '4', null, null, '4', null, null, null, '287');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140602', '140602-˷����', '4', null, null, '4', null, null, null, '288');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140603', '140603-ƽ³��', '4', null, null, '4', null, null, null, '289');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140621', '140621-ɽ����', '4', null, null, '4', null, null, null, '290');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140622', '140622-Ӧ��', '4', null, null, '4', null, null, null, '291');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140623', '140623-������', '4', null, null, '4', null, null, null, '292');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140624', '140624-������', '4', null, null, '4', null, null, null, '293');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140700', '140700-������', '4', null, null, '4', null, null, null, '294');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140701', '140701-��Ͻ��', '4', null, null, '4', null, null, null, '295');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140702', '140702-�ܴ���', '4', null, null, '4', null, null, null, '296');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140721', '140721-������', '4', null, null, '4', null, null, null, '297');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140722', '140722-��Ȩ��', '4', null, null, '4', null, null, null, '298');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140723', '140723-��˳��', '4', null, null, '4', null, null, null, '299');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140724', '140724-������', '4', null, null, '4', null, null, null, '300');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140725', '140725-������', '4', null, null, '4', null, null, null, '301');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140726', '140726-̫����', '4', null, null, '4', null, null, null, '302');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140727', '140727-����', '4', null, null, '4', null, null, null, '303');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140728', '140728-ƽң��', '4', null, null, '4', null, null, null, '304');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140729', '140729-��ʯ��', '4', null, null, '4', null, null, null, '305');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140781', '140781-������', '4', null, null, '4', null, null, null, '306');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140800', '140800-�˳���', '4', null, null, '4', null, null, null, '307');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140801', '140801-��Ͻ��', '4', null, null, '4', null, null, null, '308');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140802', '140802-�κ���', '4', null, null, '4', null, null, null, '309');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140821', '140821-�����', '4', null, null, '4', null, null, null, '310');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140822', '140822-������', '4', null, null, '4', null, null, null, '311');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140823', '140823-��ϲ��', '4', null, null, '4', null, null, null, '312');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140824', '140824-�ɽ��', '4', null, null, '4', null, null, null, '313');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140825', '140825-�����', '4', null, null, '4', null, null, null, '314');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140826', '140826-���', '4', null, null, '4', null, null, null, '315');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140827', '140827-ԫ����', '4', null, null, '4', null, null, null, '316');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140828', '140828-����', '4', null, null, '4', null, null, null, '317');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140829', '140829-ƽ½��', '4', null, null, '4', null, null, null, '318');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140830', '140830-�ǳ���', '4', null, null, '4', null, null, null, '319');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140881', '140881-������', '4', null, null, '4', null, null, null, '320');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140882', '140882-�ӽ���', '4', null, null, '4', null, null, null, '321');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140900', '140900-������', '4', null, null, '4', null, null, null, '322');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140901', '140901-��Ͻ��', '4', null, null, '4', null, null, null, '323');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140902', '140902-�ø���', '4', null, null, '4', null, null, null, '324');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140921', '140921-������', '4', null, null, '4', null, null, null, '325');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140922', '140922-��̨��', '4', null, null, '4', null, null, null, '326');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140923', '140923-����', '4', null, null, '4', null, null, null, '327');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140924', '140924-������', '4', null, null, '4', null, null, null, '328');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140925', '140925-������', '4', null, null, '4', null, null, null, '329');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140926', '140926-������', '4', null, null, '4', null, null, null, '330');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140927', '140927-�����', '4', null, null, '4', null, null, null, '331');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140928', '140928-��կ��', '4', null, null, '4', null, null, null, '332');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140929', '140929-����', '4', null, null, '4', null, null, null, '333');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140930', '140930-������', '4', null, null, '4', null, null, null, '334');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140931', '140931-������', '4', null, null, '4', null, null, null, '335');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140932', '140932-ƫ����', '4', null, null, '4', null, null, null, '336');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('140981', '140981-ԭƽ��', '4', null, null, '4', null, null, null, '337');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141000', '141000-�ٷ���', '4', null, null, '4', null, null, null, '338');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141001', '141001-��Ͻ��', '4', null, null, '4', null, null, null, '339');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141002', '141002-Ң����', '4', null, null, '4', null, null, null, '340');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141021', '141021-������', '4', null, null, '4', null, null, null, '341');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141022', '141022-������', '4', null, null, '4', null, null, null, '342');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141023', '141023-�����', '4', null, null, '4', null, null, null, '343');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141024', '141024-�鶴��', '4', null, null, '4', null, null, null, '344');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141025', '141025-����', '4', null, null, '4', null, null, null, '345');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141026', '141026-������', '4', null, null, '4', null, null, null, '346');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141027', '141027-��ɽ��', '4', null, null, '4', null, null, null, '347');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141028', '141028-����', '4', null, null, '4', null, null, null, '348');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141029', '141029-������', '4', null, null, '4', null, null, null, '349');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141030', '141030-������', '4', null, null, '4', null, null, null, '350');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141031', '141031-����', '4', null, null, '4', null, null, null, '351');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141032', '141032-������', '4', null, null, '4', null, null, null, '352');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141033', '141033-����', '4', null, null, '4', null, null, null, '353');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141034', '141034-������', '4', null, null, '4', null, null, null, '354');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141081', '141081-������', '4', null, null, '4', null, null, null, '355');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141082', '141082-������', '4', null, null, '4', null, null, null, '356');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141100', '141100-������', '4', null, null, '4', null, null, null, '357');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141101', '141101-��Ͻ��', '4', null, null, '4', null, null, null, '358');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141102', '141102-��ʯ��', '4', null, null, '4', null, null, null, '359');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141121', '141121-��ˮ��', '4', null, null, '4', null, null, null, '360');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141122', '141122-������', '4', null, null, '4', null, null, null, '361');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141123', '141123-����', '4', null, null, '4', null, null, null, '362');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141124', '141124-����', '4', null, null, '4', null, null, null, '363');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141125', '141125-������', '4', null, null, '4', null, null, null, '364');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141126', '141126-ʯ¥��', '4', null, null, '4', null, null, null, '365');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141127', '141127-���', '4', null, null, '4', null, null, null, '366');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141128', '141128-��ɽ��', '4', null, null, '4', null, null, null, '367');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141129', '141129-������', '4', null, null, '4', null, null, null, '368');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141130', '141130-������', '4', null, null, '4', null, null, null, '369');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141181', '141181-Т����', '4', null, null, '4', null, null, null, '370');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('141182', '141182-������', '4', null, null, '4', null, null, null, '371');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150000', '150000-���ɹ�������', '4', null, null, '4', null, null, null, '372');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150100', '150100-���ͺ�����', '4', null, null, '4', null, null, null, '373');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150101', '150101-��Ͻ��', '4', null, null, '4', null, null, null, '374');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150102', '150102-�³���', '4', null, null, '4', null, null, null, '375');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150103', '150103-������', '4', null, null, '4', null, null, null, '376');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150104', '150104-��Ȫ��', '4', null, null, '4', null, null, null, '377');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150105', '150105-������', '4', null, null, '4', null, null, null, '378');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150121', '150121-��Ĭ������', '4', null, null, '4', null, null, null, '379');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150122', '150122-�п�����', '4', null, null, '4', null, null, null, '380');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150123', '150123-���ָ����', '4', null, null, '4', null, null, null, '381');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150124', '150124-��ˮ����', '4', null, null, '4', null, null, null, '382');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150125', '150125-�䴨��', '4', null, null, '4', null, null, null, '383');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150200', '150200-��ͷ��', '4', null, null, '4', null, null, null, '384');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150201', '150201-��Ͻ��', '4', null, null, '4', null, null, null, '385');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150202', '150202-������', '4', null, null, '4', null, null, null, '386');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150203', '150203-��������', '4', null, null, '4', null, null, null, '387');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150204', '150204-��ɽ��', '4', null, null, '4', null, null, null, '388');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150205', '150205-ʯ����', '4', null, null, '4', null, null, null, '389');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150206', '150206-���ƶ�������', '4', null, null, '4', null, null, null, '390');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150207', '150207-��ԭ��', '4', null, null, '4', null, null, null, '391');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150221', '150221-��Ĭ������', '4', null, null, '4', null, null, null, '392');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150222', '150222-������', '4', null, null, '4', null, null, null, '393');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150223', '150223-�����ï����������', '4', null, null, '4', null, null, null, '394');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150300', '150300-�ں���', '4', null, null, '4', null, null, null, '395');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150301', '150301-��Ͻ��', '4', null, null, '4', null, null, null, '396');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150302', '150302-��������', '4', null, null, '4', null, null, null, '397');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150303', '150303-������', '4', null, null, '4', null, null, null, '398');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150304', '150304-�ڴ���', '4', null, null, '4', null, null, null, '399');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150400', '150400-�����', '4', null, null, '4', null, null, null, '400');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150401', '150401-��Ͻ��', '4', null, null, '4', null, null, null, '401');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150402', '150402-��ɽ��', '4', null, null, '4', null, null, null, '402');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150403', '150403-Ԫ��ɽ��', '4', null, null, '4', null, null, null, '403');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150404', '150404-��ɽ��', '4', null, null, '4', null, null, null, '404');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150421', '150421-��³�ƶ�����', '4', null, null, '4', null, null, null, '405');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150422', '150422-��������', '4', null, null, '4', null, null, null, '406');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150423', '150423-��������', '4', null, null, '4', null, null, null, '407');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150424', '150424-������', '4', null, null, '4', null, null, null, '408');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150425', '150425-��ʲ������', '4', null, null, '4', null, null, null, '409');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150426', '150426-��ţ����', '4', null, null, '4', null, null, null, '410');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150428', '150428-��������', '4', null, null, '4', null, null, null, '411');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150429', '150429-������', '4', null, null, '4', null, null, null, '412');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150430', '150430-������', '4', null, null, '4', null, null, null, '413');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150500', '150500-ͨ����', '4', null, null, '4', null, null, null, '414');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150501', '150501-��Ͻ��', '4', null, null, '4', null, null, null, '415');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150502', '150502-�ƶ�����', '4', null, null, '4', null, null, null, '416');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150521', '150521-�ƶ�����������', '4', null, null, '4', null, null, null, '417');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150522', '150522-�ƶ�����������', '4', null, null, '4', null, null, null, '418');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150523', '150523-��³��', '4', null, null, '4', null, null, null, '419');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150524', '150524-������', '4', null, null, '4', null, null, null, '420');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150525', '150525-������', '4', null, null, '4', null, null, null, '421');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150526', '150526-��³����', '4', null, null, '4', null, null, null, '422');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150581', '150581-���ֹ�����', '4', null, null, '4', null, null, null, '423');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150600', '150600-������˹��', '4', null, null, '4', null, null, null, '424');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150601', '150601-��Ͻ��', '4', null, null, '4', null, null, null, '425');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150602', '150602-��ʤ��', '4', null, null, '4', null, null, null, '426');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150603', '150603-����ʲ��', '4', null, null, '4', null, null, null, '427');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150621', '150621-��������', '4', null, null, '4', null, null, null, '428');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150622', '150622-׼�����', '4', null, null, '4', null, null, null, '429');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150623', '150623-���п�ǰ��', '4', null, null, '4', null, null, null, '430');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150624', '150624-���п���', '4', null, null, '4', null, null, null, '431');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150625', '150625-������', '4', null, null, '4', null, null, null, '432');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150626', '150626-������', '4', null, null, '4', null, null, null, '433');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150627', '150627-���������', '4', null, null, '4', null, null, null, '434');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150700', '150700-���ױ�����', '4', null, null, '4', null, null, null, '435');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150701', '150701-��Ͻ��', '4', null, null, '4', null, null, null, '436');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150702', '150702-��������', '4', null, null, '4', null, null, null, '437');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150703', '150703-����ŵ����', '4', null, null, '4', null, null, null, '438');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150721', '150721-������', '4', null, null, '4', null, null, null, '439');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150722', '150722-Ī�����ߴ��Ӷ���������', '4', null, null, '4', null, null, null, '440');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150723', '150723-���״�������', '4', null, null, '4', null, null, null, '441');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150724', '150724-���¿���������', '4', null, null, '4', null, null, null, '442');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150725', '150725-�°Ͷ�����', '4', null, null, '4', null, null, null, '443');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150726', '150726-�°Ͷ�������', '4', null, null, '4', null, null, null, '444');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150727', '150727-�°Ͷ�������', '4', null, null, '4', null, null, null, '445');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150781', '150781-��������', '4', null, null, '4', null, null, null, '446');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150782', '150782-����ʯ��', '4', null, null, '4', null, null, null, '447');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150783', '150783-��������', '4', null, null, '4', null, null, null, '448');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150784', '150784-���������', '4', null, null, '4', null, null, null, '449');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150785', '150785-������', '4', null, null, '4', null, null, null, '450');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150800', '150800-�����׶���', '4', null, null, '4', null, null, null, '451');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150801', '150801-��Ͻ��', '4', null, null, '4', null, null, null, '452');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150802', '150802-�ٺ���', '4', null, null, '4', null, null, null, '453');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150821', '150821-��ԭ��', '4', null, null, '4', null, null, null, '454');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150822', '150822-�����', '4', null, null, '4', null, null, null, '455');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150823', '150823-������ǰ��', '4', null, null, '4', null, null, null, '456');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150824', '150824-����������', '4', null, null, '4', null, null, null, '457');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150825', '150825-�����غ���', '4', null, null, '4', null, null, null, '458');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150826', '150826-��������', '4', null, null, '4', null, null, null, '459');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150900', '150900-�����첼��', '4', null, null, '4', null, null, null, '460');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150901', '150901-��Ͻ��', '4', null, null, '4', null, null, null, '461');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150902', '150902-������', '4', null, null, '4', null, null, null, '462');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150921', '150921-׿����', '4', null, null, '4', null, null, null, '463');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150922', '150922-������', '4', null, null, '4', null, null, null, '464');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150923', '150923-�̶���', '4', null, null, '4', null, null, null, '465');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150924', '150924-�˺���', '4', null, null, '4', null, null, null, '466');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150925', '150925-������', '4', null, null, '4', null, null, null, '467');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150926', '150926-���������ǰ��', '4', null, null, '4', null, null, null, '468');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150927', '150927-�������������', '4', null, null, '4', null, null, null, '469');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150928', '150928-�������������', '4', null, null, '4', null, null, null, '470');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150929', '150929-��������', '4', null, null, '4', null, null, null, '471');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('150981', '150981-������', '4', null, null, '4', null, null, null, '472');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152200', '152200-�˰���', '4', null, null, '4', null, null, null, '473');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152201', '152201-����������', '4', null, null, '4', null, null, null, '474');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152202', '152202-����ɽ��', '4', null, null, '4', null, null, null, '475');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152221', '152221-�ƶ�������ǰ��', '4', null, null, '4', null, null, null, '476');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152222', '152222-�ƶ�����������', '4', null, null, '4', null, null, null, '477');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152223', '152223-��������', '4', null, null, '4', null, null, null, '478');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152224', '152224-ͻȪ��', '4', null, null, '4', null, null, null, '479');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152500', '152500-���ֹ�����', '4', null, null, '4', null, null, null, '480');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152501', '152501-����������', '4', null, null, '4', null, null, null, '481');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152502', '152502-���ֺ�����', '4', null, null, '4', null, null, null, '482');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152522', '152522-���͸���', '4', null, null, '4', null, null, null, '483');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152523', '152523-����������', '4', null, null, '4', null, null, null, '484');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152524', '152524-����������', '4', null, null, '4', null, null, null, '485');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152525', '152525-������������', '4', null, null, '4', null, null, null, '486');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152526', '152526-������������', '4', null, null, '4', null, null, null, '487');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152527', '152527-̫������', '4', null, null, '4', null, null, null, '488');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152528', '152528-�����', '4', null, null, '4', null, null, null, '489');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152529', '152529-�������', '4', null, null, '4', null, null, null, '490');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152530', '152530-������', '4', null, null, '4', null, null, null, '491');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152531', '152531-������', '4', null, null, '4', null, null, null, '492');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152900', '152900-��������', '4', null, null, '4', null, null, null, '493');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152921', '152921-����������', '4', null, null, '4', null, null, null, '494');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152922', '152922-����������', '4', null, null, '4', null, null, null, '495');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('152923', '152923-�������', '4', null, null, '4', null, null, null, '496');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210000', '210000-����ʡ', '4', null, null, '4', null, null, null, '497');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210100', '210100-������', '4', null, null, '4', null, null, null, '498');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210101', '210101-��Ͻ��', '4', null, null, '4', null, null, null, '499');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210102', '210102-��ƽ��', '4', null, null, '4', null, null, null, '500');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210103', '210103-�����', '4', null, null, '4', null, null, null, '501');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210104', '210104-����', '4', null, null, '4', null, null, null, '502');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210105', '210105-�ʹ���', '4', null, null, '4', null, null, null, '503');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210106', '210106-������', '4', null, null, '4', null, null, null, '504');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210111', '210111-�ռ�����', '4', null, null, '4', null, null, null, '505');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210112', '210112-������', '4', null, null, '4', null, null, null, '506');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210113', '210113-������', '4', null, null, '4', null, null, null, '507');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210114', '210114-�ں���', '4', null, null, '4', null, null, null, '508');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210115', '210115-������', '4', null, null, '4', null, null, null, '509');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210123', '210123-��ƽ��', '4', null, null, '4', null, null, null, '510');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210124', '210124-������', '4', null, null, '4', null, null, null, '511');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210181', '210181-������', '4', null, null, '4', null, null, null, '512');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210200', '210200-������', '4', null, null, '4', null, null, null, '513');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210201', '210201-��Ͻ��', '4', null, null, '4', null, null, null, '514');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210202', '210202-��ɽ��', '4', null, null, '4', null, null, null, '515');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210203', '210203-������', '4', null, null, '4', null, null, null, '516');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210204', '210204-ɳ�ӿ���', '4', null, null, '4', null, null, null, '517');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210211', '210211-�ʾ�����', '4', null, null, '4', null, null, null, '518');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210212', '210212-��˳����', '4', null, null, '4', null, null, null, '519');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210213', '210213-������', '4', null, null, '4', null, null, null, '520');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210214', '210214-��������', '4', null, null, '4', null, null, null, '521');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210224', '210224-������', '4', null, null, '4', null, null, null, '522');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210281', '210281-�߷�����', '4', null, null, '4', null, null, null, '523');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210283', '210283-ׯ����', '4', null, null, '4', null, null, null, '524');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210300', '210300-��ɽ��', '4', null, null, '4', null, null, null, '525');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210301', '210301-��Ͻ��', '4', null, null, '4', null, null, null, '526');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210302', '210302-������', '4', null, null, '4', null, null, null, '527');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210303', '210303-������', '4', null, null, '4', null, null, null, '528');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210304', '210304-��ɽ��', '4', null, null, '4', null, null, null, '529');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210311', '210311-ǧɽ��', '4', null, null, '4', null, null, null, '530');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210321', '210321-̨����', '4', null, null, '4', null, null, null, '531');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210323', '210323-�������������', '4', null, null, '4', null, null, null, '532');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210381', '210381-������', '4', null, null, '4', null, null, null, '533');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210400', '210400-��˳��', '4', null, null, '4', null, null, null, '534');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210401', '210401-��Ͻ��', '4', null, null, '4', null, null, null, '535');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210402', '210402-�¸���', '4', null, null, '4', null, null, null, '536');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210403', '210403-������', '4', null, null, '4', null, null, null, '537');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210404', '210404-������', '4', null, null, '4', null, null, null, '538');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210411', '210411-˳����', '4', null, null, '4', null, null, null, '539');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210421', '210421-��˳��', '4', null, null, '4', null, null, null, '540');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210422', '210422-�±�����������', '4', null, null, '4', null, null, null, '541');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210423', '210423-��ԭ����������', '4', null, null, '4', null, null, null, '542');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210500', '210500-��Ϫ��', '4', null, null, '4', null, null, null, '543');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210501', '210501-��Ͻ��', '4', null, null, '4', null, null, null, '544');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210502', '210502-ƽɽ��', '4', null, null, '4', null, null, null, '545');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210503', '210503-Ϫ����', '4', null, null, '4', null, null, null, '546');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210504', '210504-��ɽ��', '4', null, null, '4', null, null, null, '547');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210505', '210505-�Ϸ���', '4', null, null, '4', null, null, null, '548');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210521', '210521-��Ϫ����������', '4', null, null, '4', null, null, null, '549');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210522', '210522-��������������', '4', null, null, '4', null, null, null, '550');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210600', '210600-������', '4', null, null, '4', null, null, null, '551');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210601', '210601-��Ͻ��', '4', null, null, '4', null, null, null, '552');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210602', '210602-Ԫ����', '4', null, null, '4', null, null, null, '553');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210603', '210603-������', '4', null, null, '4', null, null, null, '554');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210604', '210604-����', '4', null, null, '4', null, null, null, '555');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210624', '210624-��������������', '4', null, null, '4', null, null, null, '556');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210681', '210681-������', '4', null, null, '4', null, null, null, '557');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210682', '210682-�����', '4', null, null, '4', null, null, null, '558');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210700', '210700-������', '4', null, null, '4', null, null, null, '559');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210701', '210701-��Ͻ��', '4', null, null, '4', null, null, null, '560');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210702', '210702-������', '4', null, null, '4', null, null, null, '561');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210703', '210703-�����', '4', null, null, '4', null, null, null, '562');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210711', '210711-̫����', '4', null, null, '4', null, null, null, '563');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210726', '210726-��ɽ��', '4', null, null, '4', null, null, null, '564');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210727', '210727-����', '4', null, null, '4', null, null, null, '565');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210781', '210781-�躣��', '4', null, null, '4', null, null, null, '566');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210782', '210782-������', '4', null, null, '4', null, null, null, '567');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210800', '210800-Ӫ����', '4', null, null, '4', null, null, null, '568');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210801', '210801-��Ͻ��', '4', null, null, '4', null, null, null, '569');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210802', '210802-վǰ��', '4', null, null, '4', null, null, null, '570');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210803', '210803-������', '4', null, null, '4', null, null, null, '571');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210804', '210804-����Ȧ��', '4', null, null, '4', null, null, null, '572');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210811', '210811-�ϱ���', '4', null, null, '4', null, null, null, '573');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210881', '210881-������', '4', null, null, '4', null, null, null, '574');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210882', '210882-��ʯ����', '4', null, null, '4', null, null, null, '575');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210900', '210900-������', '4', null, null, '4', null, null, null, '576');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210901', '210901-��Ͻ��', '4', null, null, '4', null, null, null, '577');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210902', '210902-������', '4', null, null, '4', null, null, null, '578');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210903', '210903-������', '4', null, null, '4', null, null, null, '579');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210904', '210904-̫ƽ��', '4', null, null, '4', null, null, null, '580');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210905', '210905-�������', '4', null, null, '4', null, null, null, '581');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210911', '210911-ϸ����', '4', null, null, '4', null, null, null, '582');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210921', '210921-�����ɹ���������', '4', null, null, '4', null, null, null, '583');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('210922', '210922-������', '4', null, null, '4', null, null, null, '584');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211000', '211000-������', '4', null, null, '4', null, null, null, '585');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211001', '211001-��Ͻ��', '4', null, null, '4', null, null, null, '586');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211002', '211002-������', '4', null, null, '4', null, null, null, '587');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211003', '211003-��ʥ��', '4', null, null, '4', null, null, null, '588');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211004', '211004-��ΰ��', '4', null, null, '4', null, null, null, '589');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211005', '211005-��������', '4', null, null, '4', null, null, null, '590');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211011', '211011-̫�Ӻ���', '4', null, null, '4', null, null, null, '591');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211021', '211021-������', '4', null, null, '4', null, null, null, '592');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211081', '211081-������', '4', null, null, '4', null, null, null, '593');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211100', '211100-�̽���', '4', null, null, '4', null, null, null, '594');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211101', '211101-��Ͻ��', '4', null, null, '4', null, null, null, '595');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211102', '211102-˫̨����', '4', null, null, '4', null, null, null, '596');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211103', '211103-��¡̨��', '4', null, null, '4', null, null, null, '597');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211104', '211104-������', '4', null, null, '4', null, null, null, '598');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211122', '211122-��ɽ��', '4', null, null, '4', null, null, null, '599');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211200', '211200-������', '4', null, null, '4', null, null, null, '600');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211201', '211201-��Ͻ��', '4', null, null, '4', null, null, null, '601');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211202', '211202-������', '4', null, null, '4', null, null, null, '602');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211204', '211204-�����', '4', null, null, '4', null, null, null, '603');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211221', '211221-������', '4', null, null, '4', null, null, null, '604');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211223', '211223-������', '4', null, null, '4', null, null, null, '605');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211224', '211224-��ͼ��', '4', null, null, '4', null, null, null, '606');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211281', '211281-����ɽ��', '4', null, null, '4', null, null, null, '607');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211282', '211282-��ԭ��', '4', null, null, '4', null, null, null, '608');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211300', '211300-������', '4', null, null, '4', null, null, null, '609');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211301', '211301-��Ͻ��', '4', null, null, '4', null, null, null, '610');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211302', '211302-˫����', '4', null, null, '4', null, null, null, '611');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211303', '211303-������', '4', null, null, '4', null, null, null, '612');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211321', '211321-������', '4', null, null, '4', null, null, null, '613');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211322', '211322-��ƽ��', '4', null, null, '4', null, null, null, '614');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211324', '211324-�����������ɹ���������', '4', null, null, '4', null, null, null, '615');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211381', '211381-��Ʊ��', '4', null, null, '4', null, null, null, '616');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211382', '211382-��Դ��', '4', null, null, '4', null, null, null, '617');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211400', '211400-��«����', '4', null, null, '4', null, null, null, '618');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211401', '211401-��Ͻ��', '4', null, null, '4', null, null, null, '619');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211402', '211402-��ɽ��', '4', null, null, '4', null, null, null, '620');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211403', '211403-������', '4', null, null, '4', null, null, null, '621');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211404', '211404-��Ʊ��', '4', null, null, '4', null, null, null, '622');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211421', '211421-������', '4', null, null, '4', null, null, null, '623');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211422', '211422-������', '4', null, null, '4', null, null, null, '624');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('211481', '211481-�˳���', '4', null, null, '4', null, null, null, '625');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220000', '220000-����ʡ', '4', null, null, '4', null, null, null, '626');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220100', '220100-������', '4', null, null, '4', null, null, null, '627');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220101', '220101-��Ͻ��', '4', null, null, '4', null, null, null, '628');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220102', '220102-�Ϲ���', '4', null, null, '4', null, null, null, '629');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220103', '220103-������', '4', null, null, '4', null, null, null, '630');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220104', '220104-������', '4', null, null, '4', null, null, null, '631');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220105', '220105-������', '4', null, null, '4', null, null, null, '632');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220106', '220106-��԰��', '4', null, null, '4', null, null, null, '633');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220112', '220112-˫����', '4', null, null, '4', null, null, null, '634');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220113', '220113-��̨��', '4', null, null, '4', null, null, null, '635');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220122', '220122-ũ����', '4', null, null, '4', null, null, null, '636');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220182', '220182-������', '4', null, null, '4', null, null, null, '637');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220183', '220183-�»���', '4', null, null, '4', null, null, null, '638');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220200', '220200-������', '4', null, null, '4', null, null, null, '639');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220201', '220201-��Ͻ��', '4', null, null, '4', null, null, null, '640');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220202', '220202-������', '4', null, null, '4', null, null, null, '641');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220203', '220203-��̶��', '4', null, null, '4', null, null, null, '642');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220204', '220204-��Ӫ��', '4', null, null, '4', null, null, null, '643');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220211', '220211-������', '4', null, null, '4', null, null, null, '644');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220221', '220221-������', '4', null, null, '4', null, null, null, '645');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220281', '220281-�Ժ���', '4', null, null, '4', null, null, null, '646');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220282', '220282-�����', '4', null, null, '4', null, null, null, '647');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220283', '220283-������', '4', null, null, '4', null, null, null, '648');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220284', '220284-��ʯ��', '4', null, null, '4', null, null, null, '649');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220300', '220300-��ƽ��', '4', null, null, '4', null, null, null, '650');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220301', '220301-��Ͻ��', '4', null, null, '4', null, null, null, '651');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220302', '220302-������', '4', null, null, '4', null, null, null, '652');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220303', '220303-������', '4', null, null, '4', null, null, null, '653');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220322', '220322-������', '4', null, null, '4', null, null, null, '654');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220323', '220323-��ͨ����������', '4', null, null, '4', null, null, null, '655');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220381', '220381-��������', '4', null, null, '4', null, null, null, '656');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220382', '220382-˫����', '4', null, null, '4', null, null, null, '657');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220400', '220400-��Դ��', '4', null, null, '4', null, null, null, '658');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220401', '220401-��Ͻ��', '4', null, null, '4', null, null, null, '659');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220402', '220402-��ɽ��', '4', null, null, '4', null, null, null, '660');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220403', '220403-������', '4', null, null, '4', null, null, null, '661');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220421', '220421-������', '4', null, null, '4', null, null, null, '662');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220422', '220422-������', '4', null, null, '4', null, null, null, '663');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220500', '220500-ͨ����', '4', null, null, '4', null, null, null, '664');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220501', '220501-��Ͻ��', '4', null, null, '4', null, null, null, '665');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220502', '220502-������', '4', null, null, '4', null, null, null, '666');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220503', '220503-��������', '4', null, null, '4', null, null, null, '667');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220521', '220521-ͨ����', '4', null, null, '4', null, null, null, '668');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220523', '220523-������', '4', null, null, '4', null, null, null, '669');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220524', '220524-������', '4', null, null, '4', null, null, null, '670');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220581', '220581-÷�ӿ���', '4', null, null, '4', null, null, null, '671');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220582', '220582-������', '4', null, null, '4', null, null, null, '672');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220600', '220600-��ɽ��', '4', null, null, '4', null, null, null, '673');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220601', '220601-��Ͻ��', '4', null, null, '4', null, null, null, '674');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220602', '220602-�뽭��', '4', null, null, '4', null, null, null, '675');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220605', '220605-��Դ��', '4', null, null, '4', null, null, null, '676');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220621', '220621-������', '4', null, null, '4', null, null, null, '677');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220622', '220622-������', '4', null, null, '4', null, null, null, '678');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220623', '220623-���׳�����������', '4', null, null, '4', null, null, null, '679');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220681', '220681-�ٽ���', '4', null, null, '4', null, null, null, '680');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220700', '220700-��ԭ��', '4', null, null, '4', null, null, null, '681');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220701', '220701-��Ͻ��', '4', null, null, '4', null, null, null, '682');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220702', '220702-������', '4', null, null, '4', null, null, null, '683');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220721', '220721-ǰ������˹�ɹ���������', '4', null, null, '4', null, null, null, '684');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220722', '220722-������', '4', null, null, '4', null, null, null, '685');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220723', '220723-Ǭ����', '4', null, null, '4', null, null, null, '686');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220781', '220781-������', '4', null, null, '4', null, null, null, '687');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220800', '220800-�׳���', '4', null, null, '4', null, null, null, '688');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220801', '220801-��Ͻ��', '4', null, null, '4', null, null, null, '689');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220802', '220802-䬱���', '4', null, null, '4', null, null, null, '690');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220821', '220821-������', '4', null, null, '4', null, null, null, '691');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220822', '220822-ͨ����', '4', null, null, '4', null, null, null, '692');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220881', '220881-�����', '4', null, null, '4', null, null, null, '693');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('220882', '220882-����', '4', null, null, '4', null, null, null, '694');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('222400', '222400-�ӱ߳�����������', '4', null, null, '4', null, null, null, '695');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('222401', '222401-�Ӽ���', '4', null, null, '4', null, null, null, '696');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('222402', '222402-ͼ����', '4', null, null, '4', null, null, null, '697');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('222403', '222403-�ػ���', '4', null, null, '4', null, null, null, '698');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('222404', '222404-������', '4', null, null, '4', null, null, null, '699');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('222405', '222405-������', '4', null, null, '4', null, null, null, '700');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('222406', '222406-������', '4', null, null, '4', null, null, null, '701');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('222424', '222424-������', '4', null, null, '4', null, null, null, '702');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('222426', '222426-��ͼ��', '4', null, null, '4', null, null, null, '703');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230000', '230000-������ʡ', '4', null, null, '4', null, null, null, '704');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230100', '230100-��������', '4', null, null, '4', null, null, null, '705');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230101', '230101-��Ͻ��', '4', null, null, '4', null, null, null, '706');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230102', '230102-������', '4', null, null, '4', null, null, null, '707');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230103', '230103-�ϸ���', '4', null, null, '4', null, null, null, '708');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230104', '230104-������', '4', null, null, '4', null, null, null, '709');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230108', '230108-ƽ����', '4', null, null, '4', null, null, null, '710');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230109', '230109-�ɱ���', '4', null, null, '4', null, null, null, '711');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230110', '230110-�㷻��', '4', null, null, '4', null, null, null, '712');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230111', '230111-������', '4', null, null, '4', null, null, null, '713');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230112', '230112-������', '4', null, null, '4', null, null, null, '714');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230113', '230113-˫����', '4', null, null, '4', null, null, null, '715');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230123', '230123-������', '4', null, null, '4', null, null, null, '716');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230124', '230124-������', '4', null, null, '4', null, null, null, '717');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230125', '230125-����', '4', null, null, '4', null, null, null, '718');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230126', '230126-������', '4', null, null, '4', null, null, null, '719');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230127', '230127-ľ����', '4', null, null, '4', null, null, null, '720');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230128', '230128-ͨ����', '4', null, null, '4', null, null, null, '721');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230129', '230129-������', '4', null, null, '4', null, null, null, '722');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230183', '230183-��־��', '4', null, null, '4', null, null, null, '723');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230184', '230184-�峣��', '4', null, null, '4', null, null, null, '724');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230200', '230200-���������', '4', null, null, '4', null, null, null, '725');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230201', '230201-��Ͻ��', '4', null, null, '4', null, null, null, '726');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230202', '230202-��ɳ��', '4', null, null, '4', null, null, null, '727');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230203', '230203-������', '4', null, null, '4', null, null, null, '728');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230204', '230204-������', '4', null, null, '4', null, null, null, '729');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230205', '230205-����Ϫ��', '4', null, null, '4', null, null, null, '730');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230206', '230206-����������', '4', null, null, '4', null, null, null, '731');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230207', '230207-����ɽ��', '4', null, null, '4', null, null, null, '732');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230208', '230208-÷��˹���Ӷ�����', '4', null, null, '4', null, null, null, '733');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230221', '230221-������', '4', null, null, '4', null, null, null, '734');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230223', '230223-������', '4', null, null, '4', null, null, null, '735');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230224', '230224-̩����', '4', null, null, '4', null, null, null, '736');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230225', '230225-������', '4', null, null, '4', null, null, null, '737');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230227', '230227-��ԣ��', '4', null, null, '4', null, null, null, '738');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230229', '230229-��ɽ��', '4', null, null, '4', null, null, null, '739');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230230', '230230-�˶���', '4', null, null, '4', null, null, null, '740');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230231', '230231-��Ȫ��', '4', null, null, '4', null, null, null, '741');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230281', '230281-ګ����', '4', null, null, '4', null, null, null, '742');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230300', '230300-������', '4', null, null, '4', null, null, null, '743');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230301', '230301-��Ͻ��', '4', null, null, '4', null, null, null, '744');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230302', '230302-������', '4', null, null, '4', null, null, null, '745');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230303', '230303-��ɽ��', '4', null, null, '4', null, null, null, '746');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230304', '230304-�ε���', '4', null, null, '4', null, null, null, '747');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230305', '230305-������', '4', null, null, '4', null, null, null, '748');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230306', '230306-���Ӻ���', '4', null, null, '4', null, null, null, '749');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230307', '230307-��ɽ��', '4', null, null, '4', null, null, null, '750');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230321', '230321-������', '4', null, null, '4', null, null, null, '751');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230381', '230381-������', '4', null, null, '4', null, null, null, '752');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230382', '230382-��ɽ��', '4', null, null, '4', null, null, null, '753');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230400', '230400-�׸���', '4', null, null, '4', null, null, null, '754');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230401', '230401-��Ͻ��', '4', null, null, '4', null, null, null, '755');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230402', '230402-������', '4', null, null, '4', null, null, null, '756');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230403', '230403-��ũ��', '4', null, null, '4', null, null, null, '757');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230404', '230404-��ɽ��', '4', null, null, '4', null, null, null, '758');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230405', '230405-�˰���', '4', null, null, '4', null, null, null, '759');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230406', '230406-��ɽ��', '4', null, null, '4', null, null, null, '760');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230407', '230407-��ɽ��', '4', null, null, '4', null, null, null, '761');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230421', '230421-�ܱ���', '4', null, null, '4', null, null, null, '762');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230422', '230422-�����', '4', null, null, '4', null, null, null, '763');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230500', '230500-˫Ѽɽ��', '4', null, null, '4', null, null, null, '764');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230501', '230501-��Ͻ��', '4', null, null, '4', null, null, null, '765');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230502', '230502-��ɽ��', '4', null, null, '4', null, null, null, '766');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230503', '230503-�붫��', '4', null, null, '4', null, null, null, '767');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230505', '230505-�ķ�̨��', '4', null, null, '4', null, null, null, '768');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230506', '230506-��ɽ��', '4', null, null, '4', null, null, null, '769');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230521', '230521-������', '4', null, null, '4', null, null, null, '770');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230522', '230522-������', '4', null, null, '4', null, null, null, '771');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230523', '230523-������', '4', null, null, '4', null, null, null, '772');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230524', '230524-�ĺ���', '4', null, null, '4', null, null, null, '773');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230600', '230600-������', '4', null, null, '4', null, null, null, '774');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230601', '230601-��Ͻ��', '4', null, null, '4', null, null, null, '775');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230602', '230602-����ͼ��', '4', null, null, '4', null, null, null, '776');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230603', '230603-������', '4', null, null, '4', null, null, null, '777');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230604', '230604-�ú�·��', '4', null, null, '4', null, null, null, '778');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230605', '230605-�����', '4', null, null, '4', null, null, null, '779');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230606', '230606-��ͬ��', '4', null, null, '4', null, null, null, '780');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230621', '230621-������', '4', null, null, '4', null, null, null, '781');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230622', '230622-��Դ��', '4', null, null, '4', null, null, null, '782');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230623', '230623-�ֵ���', '4', null, null, '4', null, null, null, '783');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230624', '230624-�Ŷ������ɹ���������', '4', null, null, '4', null, null, null, '784');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230700', '230700-������', '4', null, null, '4', null, null, null, '785');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230701', '230701-��Ͻ��', '4', null, null, '4', null, null, null, '786');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230702', '230702-������', '4', null, null, '4', null, null, null, '787');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230703', '230703-�ϲ���', '4', null, null, '4', null, null, null, '788');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230704', '230704-�Ѻ���', '4', null, null, '4', null, null, null, '789');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230705', '230705-������', '4', null, null, '4', null, null, null, '790');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230706', '230706-������', '4', null, null, '4', null, null, null, '791');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230707', '230707-������', '4', null, null, '4', null, null, null, '792');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230708', '230708-��Ϫ��', '4', null, null, '4', null, null, null, '793');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230709', '230709-��ɽ����', '4', null, null, '4', null, null, null, '794');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230710', '230710-��Ӫ��', '4', null, null, '4', null, null, null, '795');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230711', '230711-��������', '4', null, null, '4', null, null, null, '796');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230712', '230712-��������', '4', null, null, '4', null, null, null, '797');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230713', '230713-������', '4', null, null, '4', null, null, null, '798');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230714', '230714-��������', '4', null, null, '4', null, null, null, '799');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230715', '230715-������', '4', null, null, '4', null, null, null, '800');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230716', '230716-�ϸ�����', '4', null, null, '4', null, null, null, '801');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230722', '230722-������', '4', null, null, '4', null, null, null, '802');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230781', '230781-������', '4', null, null, '4', null, null, null, '803');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230800', '230800-��ľ˹��', '4', null, null, '4', null, null, null, '804');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230801', '230801-��Ͻ��', '4', null, null, '4', null, null, null, '805');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230803', '230803-������', '4', null, null, '4', null, null, null, '806');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230804', '230804-ǰ����', '4', null, null, '4', null, null, null, '807');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230805', '230805-������', '4', null, null, '4', null, null, null, '808');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230811', '230811-����', '4', null, null, '4', null, null, null, '809');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230822', '230822-������', '4', null, null, '4', null, null, null, '810');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230826', '230826-�봨��', '4', null, null, '4', null, null, null, '811');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230828', '230828-��ԭ��', '4', null, null, '4', null, null, null, '812');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230881', '230881-ͬ����', '4', null, null, '4', null, null, null, '813');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230882', '230882-������', '4', null, null, '4', null, null, null, '814');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230883', '230883-��Զ��', '4', null, null, '4', null, null, null, '815');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230900', '230900-��̨����', '4', null, null, '4', null, null, null, '816');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230901', '230901-��Ͻ��', '4', null, null, '4', null, null, null, '817');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230902', '230902-������', '4', null, null, '4', null, null, null, '818');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230903', '230903-��ɽ��', '4', null, null, '4', null, null, null, '819');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230904', '230904-���Ӻ���', '4', null, null, '4', null, null, null, '820');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('230921', '230921-������', '4', null, null, '4', null, null, null, '821');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231000', '231000-ĵ������', '4', null, null, '4', null, null, null, '822');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231001', '231001-��Ͻ��', '4', null, null, '4', null, null, null, '823');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231002', '231002-������', '4', null, null, '4', null, null, null, '824');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231003', '231003-������', '4', null, null, '4', null, null, null, '825');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231004', '231004-������', '4', null, null, '4', null, null, null, '826');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231005', '231005-������', '4', null, null, '4', null, null, null, '827');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231025', '231025-�ֿ���', '4', null, null, '4', null, null, null, '828');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231081', '231081-��Һ���', '4', null, null, '4', null, null, null, '829');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231083', '231083-������', '4', null, null, '4', null, null, null, '830');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231084', '231084-������', '4', null, null, '4', null, null, null, '831');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231085', '231085-������', '4', null, null, '4', null, null, null, '832');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231086', '231086-������', '4', null, null, '4', null, null, null, '833');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231100', '231100-�ں���', '4', null, null, '4', null, null, null, '834');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231101', '231101-��Ͻ��', '4', null, null, '4', null, null, null, '835');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231102', '231102-������', '4', null, null, '4', null, null, null, '836');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231121', '231121-�۽���', '4', null, null, '4', null, null, null, '837');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231123', '231123-ѷ����', '4', null, null, '4', null, null, null, '838');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231124', '231124-������', '4', null, null, '4', null, null, null, '839');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231181', '231181-������', '4', null, null, '4', null, null, null, '840');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231182', '231182-���������', '4', null, null, '4', null, null, null, '841');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231200', '231200-�绯��', '4', null, null, '4', null, null, null, '842');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231201', '231201-��Ͻ��', '4', null, null, '4', null, null, null, '843');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231202', '231202-������', '4', null, null, '4', null, null, null, '844');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231221', '231221-������', '4', null, null, '4', null, null, null, '845');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231222', '231222-������', '4', null, null, '4', null, null, null, '846');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231223', '231223-�����', '4', null, null, '4', null, null, null, '847');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231224', '231224-�찲��', '4', null, null, '4', null, null, null, '848');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231225', '231225-��ˮ��', '4', null, null, '4', null, null, null, '849');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231226', '231226-������', '4', null, null, '4', null, null, null, '850');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231281', '231281-������', '4', null, null, '4', null, null, null, '851');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231282', '231282-�ض���', '4', null, null, '4', null, null, null, '852');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('231283', '231283-������', '4', null, null, '4', null, null, null, '853');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('232700', '232700-���˰������', '4', null, null, '4', null, null, null, '854');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('232721', '232721-������', '4', null, null, '4', null, null, null, '855');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('232722', '232722-������', '4', null, null, '4', null, null, null, '856');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('232723', '232723-Į����', '4', null, null, '4', null, null, null, '857');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('310000', '310000-�Ϻ���', '4', null, null, '4', null, null, null, '858');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('310100', '310100-��Ͻ��', '4', null, null, '4', null, null, null, '859');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('310101', '310101-������', '4', null, null, '4', null, null, null, '860');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('310104', '310104-�����', '4', null, null, '4', null, null, null, '861');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('310105', '310105-������', '4', null, null, '4', null, null, null, '862');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('310106', '310106-������', '4', null, null, '4', null, null, null, '863');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('310107', '310107-������', '4', null, null, '4', null, null, null, '864');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('310109', '310109-�����', '4', null, null, '4', null, null, null, '865');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('310110', '310110-������', '4', null, null, '4', null, null, null, '866');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('310112', '310112-������', '4', null, null, '4', null, null, null, '867');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('310113', '310113-��ɽ��', '4', null, null, '4', null, null, null, '868');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('310114', '310114-�ζ���', '4', null, null, '4', null, null, null, '869');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('310115', '310115-�ֶ�����', '4', null, null, '4', null, null, null, '870');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('310116', '310116-��ɽ��', '4', null, null, '4', null, null, null, '871');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('310117', '310117-�ɽ���', '4', null, null, '4', null, null, null, '872');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('310118', '310118-������', '4', null, null, '4', null, null, null, '873');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('310120', '310120-������', '4', null, null, '4', null, null, null, '874');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('310151', '310151-������', '4', null, null, '4', null, null, null, '875');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320000', '320000-����ʡ', '4', null, null, '4', null, null, null, '876');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320100', '320100-�Ͼ���', '4', null, null, '4', null, null, null, '877');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320101', '320101-��Ͻ��', '4', null, null, '4', null, null, null, '878');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320102', '320102-������', '4', null, null, '4', null, null, null, '879');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320104', '320104-�ػ���', '4', null, null, '4', null, null, null, '880');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320105', '320105-������', '4', null, null, '4', null, null, null, '881');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320106', '320106-��¥��', '4', null, null, '4', null, null, null, '882');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320111', '320111-�ֿ���', '4', null, null, '4', null, null, null, '883');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320113', '320113-��ϼ��', '4', null, null, '4', null, null, null, '884');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320114', '320114-�껨̨��', '4', null, null, '4', null, null, null, '885');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320115', '320115-������', '4', null, null, '4', null, null, null, '886');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320116', '320116-������', '4', null, null, '4', null, null, null, '887');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320117', '320117-��ˮ��', '4', null, null, '4', null, null, null, '888');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320118', '320118-�ߴ���', '4', null, null, '4', null, null, null, '889');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320200', '320200-������', '4', null, null, '4', null, null, null, '890');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320201', '320201-��Ͻ��', '4', null, null, '4', null, null, null, '891');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320205', '320205-��ɽ��', '4', null, null, '4', null, null, null, '892');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320206', '320206-��ɽ��', '4', null, null, '4', null, null, null, '893');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320211', '320211-������', '4', null, null, '4', null, null, null, '894');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320213', '320213-��Ϫ��', '4', null, null, '4', null, null, null, '895');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320214', '320214-������', '4', null, null, '4', null, null, null, '896');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320281', '320281-������', '4', null, null, '4', null, null, null, '897');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320282', '320282-������', '4', null, null, '4', null, null, null, '898');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320300', '320300-������', '4', null, null, '4', null, null, null, '899');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320301', '320301-��Ͻ��', '4', null, null, '4', null, null, null, '900');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320302', '320302-��¥��', '4', null, null, '4', null, null, null, '901');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320303', '320303-������', '4', null, null, '4', null, null, null, '902');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320305', '320305-������', '4', null, null, '4', null, null, null, '903');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320311', '320311-Ȫɽ��', '4', null, null, '4', null, null, null, '904');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320312', '320312-ͭɽ��', '4', null, null, '4', null, null, null, '905');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320321', '320321-����', '4', null, null, '4', null, null, null, '906');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320322', '320322-����', '4', null, null, '4', null, null, null, '907');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320324', '320324-�����', '4', null, null, '4', null, null, null, '908');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320381', '320381-������', '4', null, null, '4', null, null, null, '909');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320382', '320382-������', '4', null, null, '4', null, null, null, '910');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320400', '320400-������', '4', null, null, '4', null, null, null, '911');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320401', '320401-��Ͻ��', '4', null, null, '4', null, null, null, '912');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320402', '320402-������', '4', null, null, '4', null, null, null, '913');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320404', '320404-��¥��', '4', null, null, '4', null, null, null, '914');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320411', '320411-�±���', '4', null, null, '4', null, null, null, '915');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320412', '320412-�����', '4', null, null, '4', null, null, null, '916');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320413', '320413-��̳��', '4', null, null, '4', null, null, null, '917');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320481', '320481-������', '4', null, null, '4', null, null, null, '918');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320500', '320500-������', '4', null, null, '4', null, null, null, '919');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320501', '320501-��Ͻ��', '4', null, null, '4', null, null, null, '920');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320505', '320505-������', '4', null, null, '4', null, null, null, '921');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320506', '320506-������', '4', null, null, '4', null, null, null, '922');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320507', '320507-�����', '4', null, null, '4', null, null, null, '923');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320508', '320508-������', '4', null, null, '4', null, null, null, '924');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320509', '320509-�⽭��', '4', null, null, '4', null, null, null, '925');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320581', '320581-������', '4', null, null, '4', null, null, null, '926');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320582', '320582-�żҸ���', '4', null, null, '4', null, null, null, '927');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320583', '320583-��ɽ��', '4', null, null, '4', null, null, null, '928');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320585', '320585-̫����', '4', null, null, '4', null, null, null, '929');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320600', '320600-��ͨ��', '4', null, null, '4', null, null, null, '930');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320601', '320601-��Ͻ��', '4', null, null, '4', null, null, null, '931');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320602', '320602-�紨��', '4', null, null, '4', null, null, null, '932');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320611', '320611-��բ��', '4', null, null, '4', null, null, null, '933');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320612', '320612-ͨ����', '4', null, null, '4', null, null, null, '934');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320621', '320621-������', '4', null, null, '4', null, null, null, '935');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320623', '320623-�綫��', '4', null, null, '4', null, null, null, '936');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320681', '320681-������', '4', null, null, '4', null, null, null, '937');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320682', '320682-�����', '4', null, null, '4', null, null, null, '938');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320684', '320684-������', '4', null, null, '4', null, null, null, '939');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320700', '320700-���Ƹ���', '4', null, null, '4', null, null, null, '940');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320701', '320701-��Ͻ��', '4', null, null, '4', null, null, null, '941');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320703', '320703-������', '4', null, null, '4', null, null, null, '942');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320706', '320706-������', '4', null, null, '4', null, null, null, '943');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320707', '320707-������', '4', null, null, '4', null, null, null, '944');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320722', '320722-������', '4', null, null, '4', null, null, null, '945');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320723', '320723-������', '4', null, null, '4', null, null, null, '946');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320724', '320724-������', '4', null, null, '4', null, null, null, '947');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320800', '320800-������', '4', null, null, '4', null, null, null, '948');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320801', '320801-��Ͻ��', '4', null, null, '4', null, null, null, '949');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320803', '320803-������', '4', null, null, '4', null, null, null, '950');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320804', '320804-������', '4', null, null, '4', null, null, null, '951');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320812', '320812-�彭����', '4', null, null, '4', null, null, null, '952');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320813', '320813-������', '4', null, null, '4', null, null, null, '953');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320826', '320826-��ˮ��', '4', null, null, '4', null, null, null, '954');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320830', '320830-������', '4', null, null, '4', null, null, null, '955');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320831', '320831-�����', '4', null, null, '4', null, null, null, '956');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320900', '320900-�γ���', '4', null, null, '4', null, null, null, '957');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320901', '320901-��Ͻ��', '4', null, null, '4', null, null, null, '958');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320902', '320902-ͤ����', '4', null, null, '4', null, null, null, '959');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320903', '320903-�ζ���', '4', null, null, '4', null, null, null, '960');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320904', '320904-�����', '4', null, null, '4', null, null, null, '961');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320921', '320921-��ˮ��', '4', null, null, '4', null, null, null, '962');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320922', '320922-������', '4', null, null, '4', null, null, null, '963');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320923', '320923-������', '4', null, null, '4', null, null, null, '964');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320924', '320924-������', '4', null, null, '4', null, null, null, '965');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320925', '320925-������', '4', null, null, '4', null, null, null, '966');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('320981', '320981-��̨��', '4', null, null, '4', null, null, null, '967');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321000', '321000-������', '4', null, null, '4', null, null, null, '968');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321001', '321001-��Ͻ��', '4', null, null, '4', null, null, null, '969');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321002', '321002-������', '4', null, null, '4', null, null, null, '970');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321003', '321003-������', '4', null, null, '4', null, null, null, '971');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321012', '321012-������', '4', null, null, '4', null, null, null, '972');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321023', '321023-��Ӧ��', '4', null, null, '4', null, null, null, '973');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321081', '321081-������', '4', null, null, '4', null, null, null, '974');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321084', '321084-������', '4', null, null, '4', null, null, null, '975');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321100', '321100-����', '4', null, null, '4', null, null, null, '976');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321101', '321101-��Ͻ��', '4', null, null, '4', null, null, null, '977');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321102', '321102-������', '4', null, null, '4', null, null, null, '978');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321111', '321111-������', '4', null, null, '4', null, null, null, '979');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321112', '321112-��ͽ��', '4', null, null, '4', null, null, null, '980');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321181', '321181-������', '4', null, null, '4', null, null, null, '981');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321182', '321182-������', '4', null, null, '4', null, null, null, '982');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321183', '321183-������', '4', null, null, '4', null, null, null, '983');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321200', '321200-̩����', '4', null, null, '4', null, null, null, '984');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321201', '321201-��Ͻ��', '4', null, null, '4', null, null, null, '985');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321202', '321202-������', '4', null, null, '4', null, null, null, '986');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321203', '321203-�߸���', '4', null, null, '4', null, null, null, '987');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321204', '321204-������', '4', null, null, '4', null, null, null, '988');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321281', '321281-�˻���', '4', null, null, '4', null, null, null, '989');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321282', '321282-������', '4', null, null, '4', null, null, null, '990');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321283', '321283-̩����', '4', null, null, '4', null, null, null, '991');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321300', '321300-��Ǩ��', '4', null, null, '4', null, null, null, '992');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321301', '321301-��Ͻ��', '4', null, null, '4', null, null, null, '993');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321302', '321302-�޳���', '4', null, null, '4', null, null, null, '994');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321311', '321311-��ԥ��', '4', null, null, '4', null, null, null, '995');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321322', '321322-������', '4', null, null, '4', null, null, null, '996');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321323', '321323-������', '4', null, null, '4', null, null, null, '997');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('321324', '321324-������', '4', null, null, '4', null, null, null, '998');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330000', '330000-�㽭ʡ', '4', null, null, '4', null, null, null, '999');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330100', '330100-������', '4', null, null, '4', null, null, null, '1000');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330101', '330101-��Ͻ��', '4', null, null, '4', null, null, null, '1001');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330102', '330102-�ϳ���', '4', null, null, '4', null, null, null, '1002');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330103', '330103-�³���', '4', null, null, '4', null, null, null, '1003');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330104', '330104-������', '4', null, null, '4', null, null, null, '1004');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330105', '330105-������', '4', null, null, '4', null, null, null, '1005');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330106', '330106-������', '4', null, null, '4', null, null, null, '1006');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330108', '330108-������', '4', null, null, '4', null, null, null, '1007');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330109', '330109-��ɽ��', '4', null, null, '4', null, null, null, '1008');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330110', '330110-�ຼ��', '4', null, null, '4', null, null, null, '1009');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330111', '330111-������', '4', null, null, '4', null, null, null, '1010');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330122', '330122-ͩ®��', '4', null, null, '4', null, null, null, '1011');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330127', '330127-������', '4', null, null, '4', null, null, null, '1012');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330182', '330182-������', '4', null, null, '4', null, null, null, '1013');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330185', '330185-�ٰ���', '4', null, null, '4', null, null, null, '1014');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330200', '330200-������', '4', null, null, '4', null, null, null, '1015');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330201', '330201-��Ͻ��', '4', null, null, '4', null, null, null, '1016');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330203', '330203-������', '4', null, null, '4', null, null, null, '1017');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330204', '330204-������', '4', null, null, '4', null, null, null, '1018');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330205', '330205-������', '4', null, null, '4', null, null, null, '1019');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330206', '330206-������', '4', null, null, '4', null, null, null, '1020');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330211', '330211-����', '4', null, null, '4', null, null, null, '1021');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330212', '330212-۴����', '4', null, null, '4', null, null, null, '1022');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330225', '330225-��ɽ��', '4', null, null, '4', null, null, null, '1023');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330226', '330226-������', '4', null, null, '4', null, null, null, '1024');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330281', '330281-��Ҧ��', '4', null, null, '4', null, null, null, '1025');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330282', '330282-��Ϫ��', '4', null, null, '4', null, null, null, '1026');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330283', '330283-���', '4', null, null, '4', null, null, null, '1027');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330300', '330300-������', '4', null, null, '4', null, null, null, '1028');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330301', '330301-��Ͻ��', '4', null, null, '4', null, null, null, '1029');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330302', '330302-¹����', '4', null, null, '4', null, null, null, '1030');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330303', '330303-������', '4', null, null, '4', null, null, null, '1031');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330304', '330304-걺���', '4', null, null, '4', null, null, null, '1032');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330305', '330305-��ͷ��', '4', null, null, '4', null, null, null, '1033');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330324', '330324-������', '4', null, null, '4', null, null, null, '1034');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330326', '330326-ƽ����', '4', null, null, '4', null, null, null, '1035');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330327', '330327-������', '4', null, null, '4', null, null, null, '1036');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330328', '330328-�ĳ���', '4', null, null, '4', null, null, null, '1037');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330329', '330329-̩˳��', '4', null, null, '4', null, null, null, '1038');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330381', '330381-����', '4', null, null, '4', null, null, null, '1039');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330382', '330382-������', '4', null, null, '4', null, null, null, '1040');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330400', '330400-������', '4', null, null, '4', null, null, null, '1041');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330401', '330401-��Ͻ��', '4', null, null, '4', null, null, null, '1042');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330402', '330402-�Ϻ���', '4', null, null, '4', null, null, null, '1043');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330411', '330411-������', '4', null, null, '4', null, null, null, '1044');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330421', '330421-������', '4', null, null, '4', null, null, null, '1045');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330424', '330424-������', '4', null, null, '4', null, null, null, '1046');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330481', '330481-������', '4', null, null, '4', null, null, null, '1047');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330482', '330482-ƽ����', '4', null, null, '4', null, null, null, '1048');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330483', '330483-ͩ����', '4', null, null, '4', null, null, null, '1049');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330500', '330500-������', '4', null, null, '4', null, null, null, '1050');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330501', '330501-��Ͻ��', '4', null, null, '4', null, null, null, '1051');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330502', '330502-������', '4', null, null, '4', null, null, null, '1052');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330503', '330503-�����', '4', null, null, '4', null, null, null, '1053');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330521', '330521-������', '4', null, null, '4', null, null, null, '1054');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330522', '330522-������', '4', null, null, '4', null, null, null, '1055');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330523', '330523-������', '4', null, null, '4', null, null, null, '1056');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330600', '330600-������', '4', null, null, '4', null, null, null, '1057');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330601', '330601-��Ͻ��', '4', null, null, '4', null, null, null, '1058');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330602', '330602-Խ����', '4', null, null, '4', null, null, null, '1059');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330603', '330603-������', '4', null, null, '4', null, null, null, '1060');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330604', '330604-������', '4', null, null, '4', null, null, null, '1061');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330624', '330624-�²���', '4', null, null, '4', null, null, null, '1062');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330681', '330681-������', '4', null, null, '4', null, null, null, '1063');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330683', '330683-������', '4', null, null, '4', null, null, null, '1064');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330700', '330700-����', '4', null, null, '4', null, null, null, '1065');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330701', '330701-��Ͻ��', '4', null, null, '4', null, null, null, '1066');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330702', '330702-�ĳ���', '4', null, null, '4', null, null, null, '1067');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330703', '330703-����', '4', null, null, '4', null, null, null, '1068');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330723', '330723-������', '4', null, null, '4', null, null, null, '1069');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330726', '330726-�ֽ���', '4', null, null, '4', null, null, null, '1070');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330727', '330727-�Ͱ���', '4', null, null, '4', null, null, null, '1071');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330781', '330781-��Ϫ��', '4', null, null, '4', null, null, null, '1072');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330782', '330782-������', '4', null, null, '4', null, null, null, '1073');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330783', '330783-������', '4', null, null, '4', null, null, null, '1074');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330784', '330784-������', '4', null, null, '4', null, null, null, '1075');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330800', '330800-������', '4', null, null, '4', null, null, null, '1076');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330801', '330801-��Ͻ��', '4', null, null, '4', null, null, null, '1077');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330802', '330802-�³���', '4', null, null, '4', null, null, null, '1078');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330803', '330803-�齭��', '4', null, null, '4', null, null, null, '1079');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330822', '330822-��ɽ��', '4', null, null, '4', null, null, null, '1080');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330824', '330824-������', '4', null, null, '4', null, null, null, '1081');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330825', '330825-������', '4', null, null, '4', null, null, null, '1082');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330881', '330881-��ɽ��', '4', null, null, '4', null, null, null, '1083');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330900', '330900-��ɽ��', '4', null, null, '4', null, null, null, '1084');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330901', '330901-��Ͻ��', '4', null, null, '4', null, null, null, '1085');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330902', '330902-������', '4', null, null, '4', null, null, null, '1086');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330903', '330903-������', '4', null, null, '4', null, null, null, '1087');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330921', '330921-�ɽ��', '4', null, null, '4', null, null, null, '1088');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('330922', '330922-������', '4', null, null, '4', null, null, null, '1089');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331000', '331000-̨����', '4', null, null, '4', null, null, null, '1090');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331001', '331001-��Ͻ��', '4', null, null, '4', null, null, null, '1091');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331002', '331002-������', '4', null, null, '4', null, null, null, '1092');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331003', '331003-������', '4', null, null, '4', null, null, null, '1093');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331004', '331004-·����', '4', null, null, '4', null, null, null, '1094');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331021', '331021-����', '4', null, null, '4', null, null, null, '1095');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331022', '331022-������', '4', null, null, '4', null, null, null, '1096');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331023', '331023-��̨��', '4', null, null, '4', null, null, null, '1097');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331024', '331024-�ɾ���', '4', null, null, '4', null, null, null, '1098');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331081', '331081-������', '4', null, null, '4', null, null, null, '1099');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331082', '331082-�ٺ���', '4', null, null, '4', null, null, null, '1100');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331100', '331100-��ˮ��', '4', null, null, '4', null, null, null, '1101');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331101', '331101-��Ͻ��', '4', null, null, '4', null, null, null, '1102');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331102', '331102-������', '4', null, null, '4', null, null, null, '1103');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331121', '331121-������', '4', null, null, '4', null, null, null, '1104');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331122', '331122-������', '4', null, null, '4', null, null, null, '1105');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331123', '331123-�����', '4', null, null, '4', null, null, null, '1106');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331124', '331124-������', '4', null, null, '4', null, null, null, '1107');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331125', '331125-�ƺ���', '4', null, null, '4', null, null, null, '1108');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331126', '331126-��Ԫ��', '4', null, null, '4', null, null, null, '1109');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331127', '331127-�������������', '4', null, null, '4', null, null, null, '1110');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('331181', '331181-��Ȫ��', '4', null, null, '4', null, null, null, '1111');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340000', '340000-����ʡ', '4', null, null, '4', null, null, null, '1112');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340100', '340100-�Ϸ���', '4', null, null, '4', null, null, null, '1113');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340101', '340101-��Ͻ��', '4', null, null, '4', null, null, null, '1114');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340102', '340102-������', '4', null, null, '4', null, null, null, '1115');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340103', '340103-®����', '4', null, null, '4', null, null, null, '1116');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340104', '340104-��ɽ��', '4', null, null, '4', null, null, null, '1117');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340111', '340111-������', '4', null, null, '4', null, null, null, '1118');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340121', '340121-������', '4', null, null, '4', null, null, null, '1119');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340122', '340122-�ʶ���', '4', null, null, '4', null, null, null, '1120');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340123', '340123-������', '4', null, null, '4', null, null, null, '1121');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340124', '340124-®����', '4', null, null, '4', null, null, null, '1122');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340181', '340181-������', '4', null, null, '4', null, null, null, '1123');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340200', '340200-�ߺ���', '4', null, null, '4', null, null, null, '1124');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340201', '340201-��Ͻ��', '4', null, null, '4', null, null, null, '1125');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340202', '340202-������', '4', null, null, '4', null, null, null, '1126');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340203', '340203-߮����', '4', null, null, '4', null, null, null, '1127');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340207', '340207-𯽭��', '4', null, null, '4', null, null, null, '1128');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340208', '340208-��ɽ��', '4', null, null, '4', null, null, null, '1129');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340221', '340221-�ߺ���', '4', null, null, '4', null, null, null, '1130');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340222', '340222-������', '4', null, null, '4', null, null, null, '1131');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340223', '340223-������', '4', null, null, '4', null, null, null, '1132');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340225', '340225-��Ϊ��', '4', null, null, '4', null, null, null, '1133');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340300', '340300-������', '4', null, null, '4', null, null, null, '1134');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340301', '340301-��Ͻ��', '4', null, null, '4', null, null, null, '1135');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340302', '340302-���Ӻ���', '4', null, null, '4', null, null, null, '1136');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340303', '340303-��ɽ��', '4', null, null, '4', null, null, null, '1137');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340304', '340304-������', '4', null, null, '4', null, null, null, '1138');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340311', '340311-������', '4', null, null, '4', null, null, null, '1139');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340321', '340321-��Զ��', '4', null, null, '4', null, null, null, '1140');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340322', '340322-�����', '4', null, null, '4', null, null, null, '1141');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340323', '340323-������', '4', null, null, '4', null, null, null, '1142');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340400', '340400-������', '4', null, null, '4', null, null, null, '1143');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340401', '340401-��Ͻ��', '4', null, null, '4', null, null, null, '1144');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340402', '340402-��ͨ��', '4', null, null, '4', null, null, null, '1145');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340403', '340403-�������', '4', null, null, '4', null, null, null, '1146');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340404', '340404-л�Ҽ���', '4', null, null, '4', null, null, null, '1147');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340405', '340405-�˹�ɽ��', '4', null, null, '4', null, null, null, '1148');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340406', '340406-�˼���', '4', null, null, '4', null, null, null, '1149');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340421', '340421-��̨��', '4', null, null, '4', null, null, null, '1150');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340422', '340422-����', '4', null, null, '4', null, null, null, '1151');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340500', '340500-����ɽ��', '4', null, null, '4', null, null, null, '1152');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340501', '340501-��Ͻ��', '4', null, null, '4', null, null, null, '1153');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340503', '340503-��ɽ��', '4', null, null, '4', null, null, null, '1154');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340504', '340504-��ɽ��', '4', null, null, '4', null, null, null, '1155');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340506', '340506-������', '4', null, null, '4', null, null, null, '1156');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340521', '340521-��Ϳ��', '4', null, null, '4', null, null, null, '1157');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340522', '340522-��ɽ��', '4', null, null, '4', null, null, null, '1158');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340523', '340523-����', '4', null, null, '4', null, null, null, '1159');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340600', '340600-������', '4', null, null, '4', null, null, null, '1160');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340601', '340601-��Ͻ��', '4', null, null, '4', null, null, null, '1161');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340602', '340602-�ż���', '4', null, null, '4', null, null, null, '1162');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340603', '340603-��ɽ��', '4', null, null, '4', null, null, null, '1163');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340604', '340604-��ɽ��', '4', null, null, '4', null, null, null, '1164');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340621', '340621-�Ϫ��', '4', null, null, '4', null, null, null, '1165');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340700', '340700-ͭ����', '4', null, null, '4', null, null, null, '1166');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340701', '340701-��Ͻ��', '4', null, null, '4', null, null, null, '1167');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340705', '340705-ͭ����', '4', null, null, '4', null, null, null, '1168');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340706', '340706-�尲��', '4', null, null, '4', null, null, null, '1169');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340711', '340711-����', '4', null, null, '4', null, null, null, '1170');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340722', '340722-������', '4', null, null, '4', null, null, null, '1171');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340800', '340800-������', '4', null, null, '4', null, null, null, '1172');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340801', '340801-��Ͻ��', '4', null, null, '4', null, null, null, '1173');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340802', '340802-ӭ����', '4', null, null, '4', null, null, null, '1174');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340803', '340803-�����', '4', null, null, '4', null, null, null, '1175');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340811', '340811-������', '4', null, null, '4', null, null, null, '1176');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340822', '340822-������', '4', null, null, '4', null, null, null, '1177');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340824', '340824-Ǳɽ��', '4', null, null, '4', null, null, null, '1178');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340825', '340825-̫����', '4', null, null, '4', null, null, null, '1179');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340826', '340826-������', '4', null, null, '4', null, null, null, '1180');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340827', '340827-������', '4', null, null, '4', null, null, null, '1181');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340828', '340828-������', '4', null, null, '4', null, null, null, '1182');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('340881', '340881-ͩ����', '4', null, null, '4', null, null, null, '1183');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341000', '341000-��ɽ��', '4', null, null, '4', null, null, null, '1184');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341001', '341001-��Ͻ��', '4', null, null, '4', null, null, null, '1185');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341002', '341002-��Ϫ��', '4', null, null, '4', null, null, null, '1186');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341003', '341003-��ɽ��', '4', null, null, '4', null, null, null, '1187');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341004', '341004-������', '4', null, null, '4', null, null, null, '1188');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341021', '341021-���', '4', null, null, '4', null, null, null, '1189');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341022', '341022-������', '4', null, null, '4', null, null, null, '1190');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341023', '341023-����', '4', null, null, '4', null, null, null, '1191');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341024', '341024-������', '4', null, null, '4', null, null, null, '1192');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341100', '341100-������', '4', null, null, '4', null, null, null, '1193');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341101', '341101-��Ͻ��', '4', null, null, '4', null, null, null, '1194');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341102', '341102-������', '4', null, null, '4', null, null, null, '1195');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341103', '341103-������', '4', null, null, '4', null, null, null, '1196');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341122', '341122-������', '4', null, null, '4', null, null, null, '1197');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341124', '341124-ȫ����', '4', null, null, '4', null, null, null, '1198');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341125', '341125-��Զ��', '4', null, null, '4', null, null, null, '1199');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341126', '341126-������', '4', null, null, '4', null, null, null, '1200');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341181', '341181-�쳤��', '4', null, null, '4', null, null, null, '1201');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341182', '341182-������', '4', null, null, '4', null, null, null, '1202');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341200', '341200-������', '4', null, null, '4', null, null, null, '1203');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341201', '341201-��Ͻ��', '4', null, null, '4', null, null, null, '1204');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341202', '341202-�����', '4', null, null, '4', null, null, null, '1205');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341203', '341203-򣶫��', '4', null, null, '4', null, null, null, '1206');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341204', '341204-�Ȫ��', '4', null, null, '4', null, null, null, '1207');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341221', '341221-��Ȫ��', '4', null, null, '4', null, null, null, '1208');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341222', '341222-̫����', '4', null, null, '4', null, null, null, '1209');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341225', '341225-������', '4', null, null, '4', null, null, null, '1210');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341226', '341226-�����', '4', null, null, '4', null, null, null, '1211');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341282', '341282-������', '4', null, null, '4', null, null, null, '1212');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341300', '341300-������', '4', null, null, '4', null, null, null, '1213');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341301', '341301-��Ͻ��', '4', null, null, '4', null, null, null, '1214');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341302', '341302-������', '4', null, null, '4', null, null, null, '1215');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341321', '341321-��ɽ��', '4', null, null, '4', null, null, null, '1216');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341322', '341322-����', '4', null, null, '4', null, null, null, '1217');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341323', '341323-�����', '4', null, null, '4', null, null, null, '1218');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341324', '341324-����', '4', null, null, '4', null, null, null, '1219');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341500', '341500-������', '4', null, null, '4', null, null, null, '1220');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341501', '341501-��Ͻ��', '4', null, null, '4', null, null, null, '1221');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341502', '341502-����', '4', null, null, '4', null, null, null, '1222');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341503', '341503-ԣ����', '4', null, null, '4', null, null, null, '1223');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341504', '341504-Ҷ����', '4', null, null, '4', null, null, null, '1224');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341522', '341522-������', '4', null, null, '4', null, null, null, '1225');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341523', '341523-�����', '4', null, null, '4', null, null, null, '1226');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341524', '341524-��կ��', '4', null, null, '4', null, null, null, '1227');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341525', '341525-��ɽ��', '4', null, null, '4', null, null, null, '1228');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341600', '341600-������', '4', null, null, '4', null, null, null, '1229');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341601', '341601-��Ͻ��', '4', null, null, '4', null, null, null, '1230');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341602', '341602-�۳���', '4', null, null, '4', null, null, null, '1231');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341621', '341621-������', '4', null, null, '4', null, null, null, '1232');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341622', '341622-�ɳ���', '4', null, null, '4', null, null, null, '1233');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341623', '341623-������', '4', null, null, '4', null, null, null, '1234');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341700', '341700-������', '4', null, null, '4', null, null, null, '1235');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341701', '341701-��Ͻ��', '4', null, null, '4', null, null, null, '1236');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341702', '341702-�����', '4', null, null, '4', null, null, null, '1237');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341721', '341721-������', '4', null, null, '4', null, null, null, '1238');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341722', '341722-ʯ̨��', '4', null, null, '4', null, null, null, '1239');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341723', '341723-������', '4', null, null, '4', null, null, null, '1240');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341800', '341800-������', '4', null, null, '4', null, null, null, '1241');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341801', '341801-��Ͻ��', '4', null, null, '4', null, null, null, '1242');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341802', '341802-������', '4', null, null, '4', null, null, null, '1243');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341821', '341821-��Ϫ��', '4', null, null, '4', null, null, null, '1244');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341822', '341822-�����', '4', null, null, '4', null, null, null, '1245');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341823', '341823-����', '4', null, null, '4', null, null, null, '1246');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341824', '341824-��Ϫ��', '4', null, null, '4', null, null, null, '1247');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341825', '341825-캵���', '4', null, null, '4', null, null, null, '1248');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('341881', '341881-������', '4', null, null, '4', null, null, null, '1249');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350000', '350000-����ʡ', '4', null, null, '4', null, null, null, '1250');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350100', '350100-������', '4', null, null, '4', null, null, null, '1251');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350101', '350101-��Ͻ��', '4', null, null, '4', null, null, null, '1252');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350102', '350102-��¥��', '4', null, null, '4', null, null, null, '1253');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350103', '350103-̨����', '4', null, null, '4', null, null, null, '1254');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350104', '350104-��ɽ��', '4', null, null, '4', null, null, null, '1255');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350105', '350105-��β��', '4', null, null, '4', null, null, null, '1256');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350111', '350111-������', '4', null, null, '4', null, null, null, '1257');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350121', '350121-������', '4', null, null, '4', null, null, null, '1258');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350122', '350122-������', '4', null, null, '4', null, null, null, '1259');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350123', '350123-��Դ��', '4', null, null, '4', null, null, null, '1260');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350124', '350124-������', '4', null, null, '4', null, null, null, '1261');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350125', '350125-��̩��', '4', null, null, '4', null, null, null, '1262');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350128', '350128-ƽ̶��', '4', null, null, '4', null, null, null, '1263');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350181', '350181-������', '4', null, null, '4', null, null, null, '1264');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350182', '350182-������', '4', null, null, '4', null, null, null, '1265');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350200', '350200-������', '4', null, null, '4', null, null, null, '1266');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350201', '350201-��Ͻ��', '4', null, null, '4', null, null, null, '1267');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350203', '350203-˼����', '4', null, null, '4', null, null, null, '1268');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350205', '350205-������', '4', null, null, '4', null, null, null, '1269');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350206', '350206-������', '4', null, null, '4', null, null, null, '1270');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350211', '350211-������', '4', null, null, '4', null, null, null, '1271');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350212', '350212-ͬ����', '4', null, null, '4', null, null, null, '1272');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350213', '350213-�谲��', '4', null, null, '4', null, null, null, '1273');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350300', '350300-������', '4', null, null, '4', null, null, null, '1274');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350301', '350301-��Ͻ��', '4', null, null, '4', null, null, null, '1275');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350302', '350302-������', '4', null, null, '4', null, null, null, '1276');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350303', '350303-������', '4', null, null, '4', null, null, null, '1277');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350304', '350304-�����', '4', null, null, '4', null, null, null, '1278');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350305', '350305-������', '4', null, null, '4', null, null, null, '1279');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350322', '350322-������', '4', null, null, '4', null, null, null, '1280');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350400', '350400-������', '4', null, null, '4', null, null, null, '1281');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350401', '350401-��Ͻ��', '4', null, null, '4', null, null, null, '1282');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350402', '350402-÷����', '4', null, null, '4', null, null, null, '1283');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350403', '350403-��Ԫ��', '4', null, null, '4', null, null, null, '1284');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350421', '350421-��Ϫ��', '4', null, null, '4', null, null, null, '1285');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350423', '350423-������', '4', null, null, '4', null, null, null, '1286');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350424', '350424-������', '4', null, null, '4', null, null, null, '1287');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350425', '350425-������', '4', null, null, '4', null, null, null, '1288');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350426', '350426-��Ϫ��', '4', null, null, '4', null, null, null, '1289');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350427', '350427-ɳ��', '4', null, null, '4', null, null, null, '1290');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350428', '350428-������', '4', null, null, '4', null, null, null, '1291');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350429', '350429-̩����', '4', null, null, '4', null, null, null, '1292');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350430', '350430-������', '4', null, null, '4', null, null, null, '1293');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350481', '350481-������', '4', null, null, '4', null, null, null, '1294');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350500', '350500-Ȫ����', '4', null, null, '4', null, null, null, '1295');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350501', '350501-��Ͻ��', '4', null, null, '4', null, null, null, '1296');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350502', '350502-�����', '4', null, null, '4', null, null, null, '1297');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350503', '350503-������', '4', null, null, '4', null, null, null, '1298');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350504', '350504-�彭��', '4', null, null, '4', null, null, null, '1299');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350505', '350505-Ȫ����', '4', null, null, '4', null, null, null, '1300');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350521', '350521-�ݰ���', '4', null, null, '4', null, null, null, '1301');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350524', '350524-��Ϫ��', '4', null, null, '4', null, null, null, '1302');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350525', '350525-������', '4', null, null, '4', null, null, null, '1303');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350526', '350526-�»���', '4', null, null, '4', null, null, null, '1304');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350527', '350527-������', '4', null, null, '4', null, null, null, '1305');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350581', '350581-ʯʨ��', '4', null, null, '4', null, null, null, '1306');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350582', '350582-������', '4', null, null, '4', null, null, null, '1307');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350583', '350583-�ϰ���', '4', null, null, '4', null, null, null, '1308');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350600', '350600-������', '4', null, null, '4', null, null, null, '1309');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350601', '350601-��Ͻ��', '4', null, null, '4', null, null, null, '1310');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350602', '350602-ܼ����', '4', null, null, '4', null, null, null, '1311');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350603', '350603-������', '4', null, null, '4', null, null, null, '1312');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350622', '350622-������', '4', null, null, '4', null, null, null, '1313');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350623', '350623-������', '4', null, null, '4', null, null, null, '1314');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350624', '350624-گ����', '4', null, null, '4', null, null, null, '1315');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350625', '350625-��̩��', '4', null, null, '4', null, null, null, '1316');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350626', '350626-��ɽ��', '4', null, null, '4', null, null, null, '1317');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350627', '350627-�Ͼ���', '4', null, null, '4', null, null, null, '1318');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350628', '350628-ƽ����', '4', null, null, '4', null, null, null, '1319');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350629', '350629-������', '4', null, null, '4', null, null, null, '1320');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350681', '350681-������', '4', null, null, '4', null, null, null, '1321');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350700', '350700-��ƽ��', '4', null, null, '4', null, null, null, '1322');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350701', '350701-��Ͻ��', '4', null, null, '4', null, null, null, '1323');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350702', '350702-��ƽ��', '4', null, null, '4', null, null, null, '1324');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350703', '350703-������', '4', null, null, '4', null, null, null, '1325');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350721', '350721-˳����', '4', null, null, '4', null, null, null, '1326');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350722', '350722-�ֳ���', '4', null, null, '4', null, null, null, '1327');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350723', '350723-������', '4', null, null, '4', null, null, null, '1328');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350724', '350724-��Ϫ��', '4', null, null, '4', null, null, null, '1329');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350725', '350725-������', '4', null, null, '4', null, null, null, '1330');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350781', '350781-������', '4', null, null, '4', null, null, null, '1331');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350782', '350782-����ɽ��', '4', null, null, '4', null, null, null, '1332');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350783', '350783-�����', '4', null, null, '4', null, null, null, '1333');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350800', '350800-������', '4', null, null, '4', null, null, null, '1334');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350801', '350801-��Ͻ��', '4', null, null, '4', null, null, null, '1335');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350802', '350802-������', '4', null, null, '4', null, null, null, '1336');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350803', '350803-������', '4', null, null, '4', null, null, null, '1337');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350821', '350821-��͡��', '4', null, null, '4', null, null, null, '1338');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350823', '350823-�Ϻ���', '4', null, null, '4', null, null, null, '1339');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350824', '350824-��ƽ��', '4', null, null, '4', null, null, null, '1340');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350825', '350825-������', '4', null, null, '4', null, null, null, '1341');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350881', '350881-��ƽ��', '4', null, null, '4', null, null, null, '1342');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350900', '350900-������', '4', null, null, '4', null, null, null, '1343');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350901', '350901-��Ͻ��', '4', null, null, '4', null, null, null, '1344');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350902', '350902-������', '4', null, null, '4', null, null, null, '1345');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350921', '350921-ϼ����', '4', null, null, '4', null, null, null, '1346');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350922', '350922-������', '4', null, null, '4', null, null, null, '1347');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350923', '350923-������', '4', null, null, '4', null, null, null, '1348');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350924', '350924-������', '4', null, null, '4', null, null, null, '1349');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350925', '350925-������', '4', null, null, '4', null, null, null, '1350');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350926', '350926-������', '4', null, null, '4', null, null, null, '1351');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350981', '350981-������', '4', null, null, '4', null, null, null, '1352');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('350982', '350982-������', '4', null, null, '4', null, null, null, '1353');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360000', '360000-����ʡ', '4', null, null, '4', null, null, null, '1354');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360100', '360100-�ϲ���', '4', null, null, '4', null, null, null, '1355');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360101', '360101-��Ͻ��', '4', null, null, '4', null, null, null, '1356');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360102', '360102-������', '4', null, null, '4', null, null, null, '1357');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360103', '360103-������', '4', null, null, '4', null, null, null, '1358');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360104', '360104-��������', '4', null, null, '4', null, null, null, '1359');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360105', '360105-������', '4', null, null, '4', null, null, null, '1360');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360111', '360111-��ɽ����', '4', null, null, '4', null, null, null, '1361');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360112', '360112-�½���', '4', null, null, '4', null, null, null, '1362');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360121', '360121-�ϲ���', '4', null, null, '4', null, null, null, '1363');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360123', '360123-������', '4', null, null, '4', null, null, null, '1364');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360124', '360124-������', '4', null, null, '4', null, null, null, '1365');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360200', '360200-��������', '4', null, null, '4', null, null, null, '1366');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360201', '360201-��Ͻ��', '4', null, null, '4', null, null, null, '1367');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360202', '360202-������', '4', null, null, '4', null, null, null, '1368');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360203', '360203-��ɽ��', '4', null, null, '4', null, null, null, '1369');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360222', '360222-������', '4', null, null, '4', null, null, null, '1370');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360281', '360281-��ƽ��', '4', null, null, '4', null, null, null, '1371');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360300', '360300-Ƽ����', '4', null, null, '4', null, null, null, '1372');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360301', '360301-��Ͻ��', '4', null, null, '4', null, null, null, '1373');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360302', '360302-��Դ��', '4', null, null, '4', null, null, null, '1374');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360313', '360313-�涫��', '4', null, null, '4', null, null, null, '1375');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360321', '360321-������', '4', null, null, '4', null, null, null, '1376');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360322', '360322-������', '4', null, null, '4', null, null, null, '1377');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360323', '360323-«Ϫ��', '4', null, null, '4', null, null, null, '1378');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360400', '360400-�Ž���', '4', null, null, '4', null, null, null, '1379');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360401', '360401-��Ͻ��', '4', null, null, '4', null, null, null, '1380');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360402', '360402-�Ϫ��', '4', null, null, '4', null, null, null, '1381');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360403', '360403-�����', '4', null, null, '4', null, null, null, '1382');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360421', '360421-�Ž���', '4', null, null, '4', null, null, null, '1383');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360423', '360423-������', '4', null, null, '4', null, null, null, '1384');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360424', '360424-��ˮ��', '4', null, null, '4', null, null, null, '1385');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360425', '360425-������', '4', null, null, '4', null, null, null, '1386');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360426', '360426-�°���', '4', null, null, '4', null, null, null, '1387');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360428', '360428-������', '4', null, null, '4', null, null, null, '1388');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360429', '360429-������', '4', null, null, '4', null, null, null, '1389');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360430', '360430-������', '4', null, null, '4', null, null, null, '1390');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360481', '360481-�����', '4', null, null, '4', null, null, null, '1391');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360482', '360482-�������', '4', null, null, '4', null, null, null, '1392');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360483', '360483-®ɽ��', '4', null, null, '4', null, null, null, '1393');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360500', '360500-������', '4', null, null, '4', null, null, null, '1394');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360501', '360501-��Ͻ��', '4', null, null, '4', null, null, null, '1395');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360502', '360502-��ˮ��', '4', null, null, '4', null, null, null, '1396');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360521', '360521-������', '4', null, null, '4', null, null, null, '1397');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360600', '360600-ӥ̶��', '4', null, null, '4', null, null, null, '1398');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360601', '360601-��Ͻ��', '4', null, null, '4', null, null, null, '1399');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360602', '360602-�º���', '4', null, null, '4', null, null, null, '1400');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360622', '360622-�཭��', '4', null, null, '4', null, null, null, '1401');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360681', '360681-��Ϫ��', '4', null, null, '4', null, null, null, '1402');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360700', '360700-������', '4', null, null, '4', null, null, null, '1403');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360701', '360701-��Ͻ��', '4', null, null, '4', null, null, null, '1404');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360702', '360702-�¹���', '4', null, null, '4', null, null, null, '1405');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360703', '360703-�Ͽ���', '4', null, null, '4', null, null, null, '1406');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360721', '360721-����', '4', null, null, '4', null, null, null, '1407');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360722', '360722-�ŷ���', '4', null, null, '4', null, null, null, '1408');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360723', '360723-������', '4', null, null, '4', null, null, null, '1409');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360724', '360724-������', '4', null, null, '4', null, null, null, '1410');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360725', '360725-������', '4', null, null, '4', null, null, null, '1411');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360726', '360726-��Զ��', '4', null, null, '4', null, null, null, '1412');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360727', '360727-������', '4', null, null, '4', null, null, null, '1413');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360728', '360728-������', '4', null, null, '4', null, null, null, '1414');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360729', '360729-ȫ����', '4', null, null, '4', null, null, null, '1415');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360730', '360730-������', '4', null, null, '4', null, null, null, '1416');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360731', '360731-�ڶ���', '4', null, null, '4', null, null, null, '1417');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360732', '360732-�˹���', '4', null, null, '4', null, null, null, '1418');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360733', '360733-�����', '4', null, null, '4', null, null, null, '1419');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360734', '360734-Ѱ����', '4', null, null, '4', null, null, null, '1420');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360735', '360735-ʯ����', '4', null, null, '4', null, null, null, '1421');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360781', '360781-�����', '4', null, null, '4', null, null, null, '1422');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360800', '360800-������', '4', null, null, '4', null, null, null, '1423');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360801', '360801-��Ͻ��', '4', null, null, '4', null, null, null, '1424');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360802', '360802-������', '4', null, null, '4', null, null, null, '1425');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360803', '360803-��ԭ��', '4', null, null, '4', null, null, null, '1426');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360821', '360821-������', '4', null, null, '4', null, null, null, '1427');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360822', '360822-��ˮ��', '4', null, null, '4', null, null, null, '1428');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360823', '360823-Ͽ����', '4', null, null, '4', null, null, null, '1429');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360824', '360824-�¸���', '4', null, null, '4', null, null, null, '1430');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360825', '360825-������', '4', null, null, '4', null, null, null, '1431');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360826', '360826-̩����', '4', null, null, '4', null, null, null, '1432');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360827', '360827-�촨��', '4', null, null, '4', null, null, null, '1433');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360828', '360828-����', '4', null, null, '4', null, null, null, '1434');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360829', '360829-������', '4', null, null, '4', null, null, null, '1435');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360830', '360830-������', '4', null, null, '4', null, null, null, '1436');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360881', '360881-����ɽ��', '4', null, null, '4', null, null, null, '1437');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360900', '360900-�˴���', '4', null, null, '4', null, null, null, '1438');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360901', '360901-��Ͻ��', '4', null, null, '4', null, null, null, '1439');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360902', '360902-Ԭ����', '4', null, null, '4', null, null, null, '1440');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360921', '360921-������', '4', null, null, '4', null, null, null, '1441');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360922', '360922-������', '4', null, null, '4', null, null, null, '1442');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360923', '360923-�ϸ���', '4', null, null, '4', null, null, null, '1443');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360924', '360924-�˷���', '4', null, null, '4', null, null, null, '1444');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360925', '360925-������', '4', null, null, '4', null, null, null, '1445');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360926', '360926-ͭ����', '4', null, null, '4', null, null, null, '1446');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360981', '360981-�����', '4', null, null, '4', null, null, null, '1447');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360982', '360982-������', '4', null, null, '4', null, null, null, '1448');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('360983', '360983-�߰���', '4', null, null, '4', null, null, null, '1449');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361000', '361000-������', '4', null, null, '4', null, null, null, '1450');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361001', '361001-��Ͻ��', '4', null, null, '4', null, null, null, '1451');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361002', '361002-�ٴ���', '4', null, null, '4', null, null, null, '1452');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361021', '361021-�ϳ���', '4', null, null, '4', null, null, null, '1453');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361022', '361022-�质��', '4', null, null, '4', null, null, null, '1454');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361023', '361023-�Ϸ���', '4', null, null, '4', null, null, null, '1455');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361024', '361024-������', '4', null, null, '4', null, null, null, '1456');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361025', '361025-�ְ���', '4', null, null, '4', null, null, null, '1457');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361026', '361026-�˻���', '4', null, null, '4', null, null, null, '1458');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361027', '361027-��Ϫ��', '4', null, null, '4', null, null, null, '1459');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361028', '361028-��Ϫ��', '4', null, null, '4', null, null, null, '1460');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361029', '361029-������', '4', null, null, '4', null, null, null, '1461');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361030', '361030-�����', '4', null, null, '4', null, null, null, '1462');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361100', '361100-������', '4', null, null, '4', null, null, null, '1463');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361101', '361101-��Ͻ��', '4', null, null, '4', null, null, null, '1464');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361102', '361102-������', '4', null, null, '4', null, null, null, '1465');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361103', '361103-�����', '4', null, null, '4', null, null, null, '1466');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361121', '361121-������', '4', null, null, '4', null, null, null, '1467');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361123', '361123-��ɽ��', '4', null, null, '4', null, null, null, '1468');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361124', '361124-Ǧɽ��', '4', null, null, '4', null, null, null, '1469');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361125', '361125-�����', '4', null, null, '4', null, null, null, '1470');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361126', '361126-߮����', '4', null, null, '4', null, null, null, '1471');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361127', '361127-�����', '4', null, null, '4', null, null, null, '1472');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361128', '361128-۶����', '4', null, null, '4', null, null, null, '1473');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361129', '361129-������', '4', null, null, '4', null, null, null, '1474');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361130', '361130-��Դ��', '4', null, null, '4', null, null, null, '1475');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('361181', '361181-������', '4', null, null, '4', null, null, null, '1476');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370000', '370000-ɽ��ʡ', '4', null, null, '4', null, null, null, '1477');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370100', '370100-������', '4', null, null, '4', null, null, null, '1478');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370101', '370101-��Ͻ��', '4', null, null, '4', null, null, null, '1479');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370102', '370102-������', '4', null, null, '4', null, null, null, '1480');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370103', '370103-������', '4', null, null, '4', null, null, null, '1481');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370104', '370104-������', '4', null, null, '4', null, null, null, '1482');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370105', '370105-������', '4', null, null, '4', null, null, null, '1483');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370112', '370112-������', '4', null, null, '4', null, null, null, '1484');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370113', '370113-������', '4', null, null, '4', null, null, null, '1485');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370124', '370124-ƽ����', '4', null, null, '4', null, null, null, '1486');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370125', '370125-������', '4', null, null, '4', null, null, null, '1487');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370126', '370126-�̺���', '4', null, null, '4', null, null, null, '1488');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370181', '370181-������', '4', null, null, '4', null, null, null, '1489');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370200', '370200-�ൺ��', '4', null, null, '4', null, null, null, '1490');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370201', '370201-��Ͻ��', '4', null, null, '4', null, null, null, '1491');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370202', '370202-������', '4', null, null, '4', null, null, null, '1492');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370203', '370203-�б���', '4', null, null, '4', null, null, null, '1493');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370211', '370211-�Ƶ���', '4', null, null, '4', null, null, null, '1494');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370212', '370212-��ɽ��', '4', null, null, '4', null, null, null, '1495');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370213', '370213-�����', '4', null, null, '4', null, null, null, '1496');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370214', '370214-������', '4', null, null, '4', null, null, null, '1497');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370281', '370281-������', '4', null, null, '4', null, null, null, '1498');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370282', '370282-��ī��', '4', null, null, '4', null, null, null, '1499');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370283', '370283-ƽ����', '4', null, null, '4', null, null, null, '1500');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370285', '370285-������', '4', null, null, '4', null, null, null, '1501');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370300', '370300-�Ͳ���', '4', null, null, '4', null, null, null, '1502');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370301', '370301-��Ͻ��', '4', null, null, '4', null, null, null, '1503');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370302', '370302-�ʹ���', '4', null, null, '4', null, null, null, '1504');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370303', '370303-�ŵ���', '4', null, null, '4', null, null, null, '1505');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370304', '370304-��ɽ��', '4', null, null, '4', null, null, null, '1506');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370305', '370305-������', '4', null, null, '4', null, null, null, '1507');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370306', '370306-�ܴ���', '4', null, null, '4', null, null, null, '1508');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370321', '370321-��̨��', '4', null, null, '4', null, null, null, '1509');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370322', '370322-������', '4', null, null, '4', null, null, null, '1510');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370323', '370323-��Դ��', '4', null, null, '4', null, null, null, '1511');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370400', '370400-��ׯ��', '4', null, null, '4', null, null, null, '1512');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370401', '370401-��Ͻ��', '4', null, null, '4', null, null, null, '1513');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370402', '370402-������', '4', null, null, '4', null, null, null, '1514');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370403', '370403-Ѧ����', '4', null, null, '4', null, null, null, '1515');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370404', '370404-ỳ���', '4', null, null, '4', null, null, null, '1516');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370405', '370405-̨��ׯ��', '4', null, null, '4', null, null, null, '1517');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370406', '370406-ɽͤ��', '4', null, null, '4', null, null, null, '1518');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370481', '370481-������', '4', null, null, '4', null, null, null, '1519');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370500', '370500-��Ӫ��', '4', null, null, '4', null, null, null, '1520');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370501', '370501-��Ͻ��', '4', null, null, '4', null, null, null, '1521');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370502', '370502-��Ӫ��', '4', null, null, '4', null, null, null, '1522');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370503', '370503-�ӿ���', '4', null, null, '4', null, null, null, '1523');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370505', '370505-������', '4', null, null, '4', null, null, null, '1524');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370522', '370522-������', '4', null, null, '4', null, null, null, '1525');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370523', '370523-������', '4', null, null, '4', null, null, null, '1526');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370600', '370600-��̨��', '4', null, null, '4', null, null, null, '1527');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370601', '370601-��Ͻ��', '4', null, null, '4', null, null, null, '1528');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370602', '370602-֥���', '4', null, null, '4', null, null, null, '1529');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370611', '370611-��ɽ��', '4', null, null, '4', null, null, null, '1530');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370612', '370612-Ĳƽ��', '4', null, null, '4', null, null, null, '1531');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370613', '370613-��ɽ��', '4', null, null, '4', null, null, null, '1532');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370634', '370634-������', '4', null, null, '4', null, null, null, '1533');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370681', '370681-������', '4', null, null, '4', null, null, null, '1534');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370682', '370682-������', '4', null, null, '4', null, null, null, '1535');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370683', '370683-������', '4', null, null, '4', null, null, null, '1536');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370684', '370684-������', '4', null, null, '4', null, null, null, '1537');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370685', '370685-��Զ��', '4', null, null, '4', null, null, null, '1538');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370686', '370686-��ϼ��', '4', null, null, '4', null, null, null, '1539');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370687', '370687-������', '4', null, null, '4', null, null, null, '1540');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370700', '370700-Ϋ����', '4', null, null, '4', null, null, null, '1541');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370701', '370701-��Ͻ��', '4', null, null, '4', null, null, null, '1542');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370702', '370702-Ϋ����', '4', null, null, '4', null, null, null, '1543');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370703', '370703-��ͤ��', '4', null, null, '4', null, null, null, '1544');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370704', '370704-������', '4', null, null, '4', null, null, null, '1545');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370705', '370705-������', '4', null, null, '4', null, null, null, '1546');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370724', '370724-������', '4', null, null, '4', null, null, null, '1547');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370725', '370725-������', '4', null, null, '4', null, null, null, '1548');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370781', '370781-������', '4', null, null, '4', null, null, null, '1549');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370782', '370782-�����', '4', null, null, '4', null, null, null, '1550');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370783', '370783-�ٹ���', '4', null, null, '4', null, null, null, '1551');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370784', '370784-������', '4', null, null, '4', null, null, null, '1552');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370785', '370785-������', '4', null, null, '4', null, null, null, '1553');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370786', '370786-������', '4', null, null, '4', null, null, null, '1554');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370800', '370800-������', '4', null, null, '4', null, null, null, '1555');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370801', '370801-��Ͻ��', '4', null, null, '4', null, null, null, '1556');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370811', '370811-�γ���', '4', null, null, '4', null, null, null, '1557');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370812', '370812-������', '4', null, null, '4', null, null, null, '1558');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370826', '370826-΢ɽ��', '4', null, null, '4', null, null, null, '1559');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370827', '370827-��̨��', '4', null, null, '4', null, null, null, '1560');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370828', '370828-������', '4', null, null, '4', null, null, null, '1561');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370829', '370829-������', '4', null, null, '4', null, null, null, '1562');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370830', '370830-������', '4', null, null, '4', null, null, null, '1563');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370831', '370831-��ˮ��', '4', null, null, '4', null, null, null, '1564');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370832', '370832-��ɽ��', '4', null, null, '4', null, null, null, '1565');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370881', '370881-������', '4', null, null, '4', null, null, null, '1566');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370883', '370883-�޳���', '4', null, null, '4', null, null, null, '1567');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370900', '370900-̩����', '4', null, null, '4', null, null, null, '1568');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370901', '370901-��Ͻ��', '4', null, null, '4', null, null, null, '1569');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370902', '370902-̩ɽ��', '4', null, null, '4', null, null, null, '1570');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370911', '370911-�����', '4', null, null, '4', null, null, null, '1571');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370921', '370921-������', '4', null, null, '4', null, null, null, '1572');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370923', '370923-��ƽ��', '4', null, null, '4', null, null, null, '1573');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370982', '370982-��̩��', '4', null, null, '4', null, null, null, '1574');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('370983', '370983-�ʳ���', '4', null, null, '4', null, null, null, '1575');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371000', '371000-������', '4', null, null, '4', null, null, null, '1576');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371001', '371001-��Ͻ��', '4', null, null, '4', null, null, null, '1577');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371002', '371002-������', '4', null, null, '4', null, null, null, '1578');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371003', '371003-�ĵ���', '4', null, null, '4', null, null, null, '1579');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371082', '371082-�ٳ���', '4', null, null, '4', null, null, null, '1580');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371083', '371083-��ɽ��', '4', null, null, '4', null, null, null, '1581');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371100', '371100-������', '4', null, null, '4', null, null, null, '1582');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371101', '371101-��Ͻ��', '4', null, null, '4', null, null, null, '1583');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371102', '371102-������', '4', null, null, '4', null, null, null, '1584');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371103', '371103-�ɽ��', '4', null, null, '4', null, null, null, '1585');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371121', '371121-������', '4', null, null, '4', null, null, null, '1586');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371122', '371122-����', '4', null, null, '4', null, null, null, '1587');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371200', '371200-������', '4', null, null, '4', null, null, null, '1588');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371201', '371201-��Ͻ��', '4', null, null, '4', null, null, null, '1589');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371202', '371202-������', '4', null, null, '4', null, null, null, '1590');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371203', '371203-�ֳ���', '4', null, null, '4', null, null, null, '1591');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371300', '371300-������', '4', null, null, '4', null, null, null, '1592');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371301', '371301-��Ͻ��', '4', null, null, '4', null, null, null, '1593');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371302', '371302-��ɽ��', '4', null, null, '4', null, null, null, '1594');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371311', '371311-��ׯ��', '4', null, null, '4', null, null, null, '1595');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371312', '371312-�Ӷ���', '4', null, null, '4', null, null, null, '1596');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371321', '371321-������', '4', null, null, '4', null, null, null, '1597');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371322', '371322-۰����', '4', null, null, '4', null, null, null, '1598');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371323', '371323-��ˮ��', '4', null, null, '4', null, null, null, '1599');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371324', '371324-������', '4', null, null, '4', null, null, null, '1600');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371325', '371325-����', '4', null, null, '4', null, null, null, '1601');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371326', '371326-ƽ����', '4', null, null, '4', null, null, null, '1602');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371327', '371327-������', '4', null, null, '4', null, null, null, '1603');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371328', '371328-������', '4', null, null, '4', null, null, null, '1604');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371329', '371329-������', '4', null, null, '4', null, null, null, '1605');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371400', '371400-������', '4', null, null, '4', null, null, null, '1606');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371401', '371401-��Ͻ��', '4', null, null, '4', null, null, null, '1607');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371402', '371402-�³���', '4', null, null, '4', null, null, null, '1608');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371403', '371403-�����', '4', null, null, '4', null, null, null, '1609');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371422', '371422-������', '4', null, null, '4', null, null, null, '1610');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371423', '371423-������', '4', null, null, '4', null, null, null, '1611');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371424', '371424-������', '4', null, null, '4', null, null, null, '1612');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371425', '371425-�����', '4', null, null, '4', null, null, null, '1613');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371426', '371426-ƽԭ��', '4', null, null, '4', null, null, null, '1614');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371427', '371427-�Ľ���', '4', null, null, '4', null, null, null, '1615');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371428', '371428-�����', '4', null, null, '4', null, null, null, '1616');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371481', '371481-������', '4', null, null, '4', null, null, null, '1617');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371482', '371482-������', '4', null, null, '4', null, null, null, '1618');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371500', '371500-�ĳ���', '4', null, null, '4', null, null, null, '1619');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371501', '371501-��Ͻ��', '4', null, null, '4', null, null, null, '1620');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371502', '371502-��������', '4', null, null, '4', null, null, null, '1621');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371521', '371521-������', '4', null, null, '4', null, null, null, '1622');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371522', '371522-ݷ��', '4', null, null, '4', null, null, null, '1623');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371523', '371523-��ƽ��', '4', null, null, '4', null, null, null, '1624');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371524', '371524-������', '4', null, null, '4', null, null, null, '1625');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371525', '371525-����', '4', null, null, '4', null, null, null, '1626');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371526', '371526-������', '4', null, null, '4', null, null, null, '1627');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371581', '371581-������', '4', null, null, '4', null, null, null, '1628');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371600', '371600-������', '4', null, null, '4', null, null, null, '1629');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371601', '371601-��Ͻ��', '4', null, null, '4', null, null, null, '1630');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371602', '371602-������', '4', null, null, '4', null, null, null, '1631');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371603', '371603-մ����', '4', null, null, '4', null, null, null, '1632');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371621', '371621-������', '4', null, null, '4', null, null, null, '1633');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371622', '371622-������', '4', null, null, '4', null, null, null, '1634');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371623', '371623-�����', '4', null, null, '4', null, null, null, '1635');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371625', '371625-������', '4', null, null, '4', null, null, null, '1636');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371626', '371626-��ƽ��', '4', null, null, '4', null, null, null, '1637');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371700', '371700-������', '4', null, null, '4', null, null, null, '1638');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371701', '371701-��Ͻ��', '4', null, null, '4', null, null, null, '1639');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371702', '371702-ĵ����', '4', null, null, '4', null, null, null, '1640');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371703', '371703-������', '4', null, null, '4', null, null, null, '1641');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371721', '371721-����', '4', null, null, '4', null, null, null, '1642');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371722', '371722-����', '4', null, null, '4', null, null, null, '1643');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371723', '371723-������', '4', null, null, '4', null, null, null, '1644');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371724', '371724-��Ұ��', '4', null, null, '4', null, null, null, '1645');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371725', '371725-۩����', '4', null, null, '4', null, null, null, '1646');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371726', '371726-۲����', '4', null, null, '4', null, null, null, '1647');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('371728', '371728-������', '4', null, null, '4', null, null, null, '1648');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410000', '410000-����ʡ', '4', null, null, '4', null, null, null, '1649');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410100', '410100-֣����', '4', null, null, '4', null, null, null, '1650');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410101', '410101-��Ͻ��', '4', null, null, '4', null, null, null, '1651');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410102', '410102-��ԭ��', '4', null, null, '4', null, null, null, '1652');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410103', '410103-������', '4', null, null, '4', null, null, null, '1653');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410104', '410104-�ܳǻ�����', '4', null, null, '4', null, null, null, '1654');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410105', '410105-��ˮ��', '4', null, null, '4', null, null, null, '1655');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410106', '410106-�Ͻ���', '4', null, null, '4', null, null, null, '1656');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410108', '410108-�ݼ���', '4', null, null, '4', null, null, null, '1657');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410122', '410122-��Ĳ��', '4', null, null, '4', null, null, null, '1658');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410181', '410181-������', '4', null, null, '4', null, null, null, '1659');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410182', '410182-������', '4', null, null, '4', null, null, null, '1660');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410183', '410183-������', '4', null, null, '4', null, null, null, '1661');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410184', '410184-��֣��', '4', null, null, '4', null, null, null, '1662');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410185', '410185-�Ƿ���', '4', null, null, '4', null, null, null, '1663');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410200', '410200-������', '4', null, null, '4', null, null, null, '1664');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410201', '410201-��Ͻ��', '4', null, null, '4', null, null, null, '1665');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410202', '410202-��ͤ��', '4', null, null, '4', null, null, null, '1666');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410203', '410203-˳�ӻ�����', '4', null, null, '4', null, null, null, '1667');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410204', '410204-��¥��', '4', null, null, '4', null, null, null, '1668');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410205', '410205-����̨��', '4', null, null, '4', null, null, null, '1669');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410211', '410211-������', '4', null, null, '4', null, null, null, '1670');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410212', '410212-�����', '4', null, null, '4', null, null, null, '1671');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410221', '410221-���', '4', null, null, '4', null, null, null, '1672');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410222', '410222-ͨ����', '4', null, null, '4', null, null, null, '1673');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410223', '410223-ξ����', '4', null, null, '4', null, null, null, '1674');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410225', '410225-������', '4', null, null, '4', null, null, null, '1675');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410300', '410300-������', '4', null, null, '4', null, null, null, '1676');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410301', '410301-��Ͻ��', '4', null, null, '4', null, null, null, '1677');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410302', '410302-�ϳ���', '4', null, null, '4', null, null, null, '1678');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410303', '410303-������', '4', null, null, '4', null, null, null, '1679');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410304', '410304-�e�ӻ�����', '4', null, null, '4', null, null, null, '1680');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410305', '410305-������', '4', null, null, '4', null, null, null, '1681');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410306', '410306-������', '4', null, null, '4', null, null, null, '1682');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410311', '410311-������', '4', null, null, '4', null, null, null, '1683');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410322', '410322-�Ͻ���', '4', null, null, '4', null, null, null, '1684');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410323', '410323-�°���', '4', null, null, '4', null, null, null, '1685');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410324', '410324-�ﴨ��', '4', null, null, '4', null, null, null, '1686');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410325', '410325-����', '4', null, null, '4', null, null, null, '1687');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410326', '410326-������', '4', null, null, '4', null, null, null, '1688');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410327', '410327-������', '4', null, null, '4', null, null, null, '1689');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410328', '410328-������', '4', null, null, '4', null, null, null, '1690');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410329', '410329-������', '4', null, null, '4', null, null, null, '1691');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410381', '410381-��ʦ��', '4', null, null, '4', null, null, null, '1692');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410400', '410400-ƽ��ɽ��', '4', null, null, '4', null, null, null, '1693');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410401', '410401-��Ͻ��', '4', null, null, '4', null, null, null, '1694');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410402', '410402-�»���', '4', null, null, '4', null, null, null, '1695');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410403', '410403-������', '4', null, null, '4', null, null, null, '1696');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410404', '410404-ʯ����', '4', null, null, '4', null, null, null, '1697');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410411', '410411-տ����', '4', null, null, '4', null, null, null, '1698');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410421', '410421-������', '4', null, null, '4', null, null, null, '1699');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410422', '410422-Ҷ��', '4', null, null, '4', null, null, null, '1700');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410423', '410423-³ɽ��', '4', null, null, '4', null, null, null, '1701');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410425', '410425-ۣ��', '4', null, null, '4', null, null, null, '1702');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410481', '410481-�����', '4', null, null, '4', null, null, null, '1703');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410482', '410482-������', '4', null, null, '4', null, null, null, '1704');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410500', '410500-������', '4', null, null, '4', null, null, null, '1705');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410501', '410501-��Ͻ��', '4', null, null, '4', null, null, null, '1706');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410502', '410502-�ķ���', '4', null, null, '4', null, null, null, '1707');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410503', '410503-������', '4', null, null, '4', null, null, null, '1708');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410505', '410505-����', '4', null, null, '4', null, null, null, '1709');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410506', '410506-������', '4', null, null, '4', null, null, null, '1710');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410522', '410522-������', '4', null, null, '4', null, null, null, '1711');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410523', '410523-������', '4', null, null, '4', null, null, null, '1712');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410526', '410526-����', '4', null, null, '4', null, null, null, '1713');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410527', '410527-�ڻ���', '4', null, null, '4', null, null, null, '1714');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410581', '410581-������', '4', null, null, '4', null, null, null, '1715');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410600', '410600-�ױ���', '4', null, null, '4', null, null, null, '1716');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410601', '410601-��Ͻ��', '4', null, null, '4', null, null, null, '1717');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410602', '410602-��ɽ��', '4', null, null, '4', null, null, null, '1718');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410603', '410603-ɽ����', '4', null, null, '4', null, null, null, '1719');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410611', '410611-俱���', '4', null, null, '4', null, null, null, '1720');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410621', '410621-����', '4', null, null, '4', null, null, null, '1721');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410622', '410622-���', '4', null, null, '4', null, null, null, '1722');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410700', '410700-������', '4', null, null, '4', null, null, null, '1723');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410701', '410701-��Ͻ��', '4', null, null, '4', null, null, null, '1724');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410702', '410702-������', '4', null, null, '4', null, null, null, '1725');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410703', '410703-������', '4', null, null, '4', null, null, null, '1726');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410704', '410704-��Ȫ��', '4', null, null, '4', null, null, null, '1727');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410711', '410711-��Ұ��', '4', null, null, '4', null, null, null, '1728');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410721', '410721-������', '4', null, null, '4', null, null, null, '1729');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410724', '410724-�����', '4', null, null, '4', null, null, null, '1730');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410725', '410725-ԭ����', '4', null, null, '4', null, null, null, '1731');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410726', '410726-�ӽ���', '4', null, null, '4', null, null, null, '1732');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410727', '410727-������', '4', null, null, '4', null, null, null, '1733');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410728', '410728-��ԫ��', '4', null, null, '4', null, null, null, '1734');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410781', '410781-������', '4', null, null, '4', null, null, null, '1735');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410782', '410782-������', '4', null, null, '4', null, null, null, '1736');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410800', '410800-������', '4', null, null, '4', null, null, null, '1737');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410801', '410801-��Ͻ��', '4', null, null, '4', null, null, null, '1738');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410802', '410802-�����', '4', null, null, '4', null, null, null, '1739');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410803', '410803-��վ��', '4', null, null, '4', null, null, null, '1740');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410804', '410804-������', '4', null, null, '4', null, null, null, '1741');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410811', '410811-ɽ����', '4', null, null, '4', null, null, null, '1742');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410821', '410821-������', '4', null, null, '4', null, null, null, '1743');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410822', '410822-������', '4', null, null, '4', null, null, null, '1744');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410823', '410823-������', '4', null, null, '4', null, null, null, '1745');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410825', '410825-����', '4', null, null, '4', null, null, null, '1746');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410882', '410882-������', '4', null, null, '4', null, null, null, '1747');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410883', '410883-������', '4', null, null, '4', null, null, null, '1748');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410900', '410900-�����', '4', null, null, '4', null, null, null, '1749');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410901', '410901-��Ͻ��', '4', null, null, '4', null, null, null, '1750');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410902', '410902-������', '4', null, null, '4', null, null, null, '1751');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410922', '410922-�����', '4', null, null, '4', null, null, null, '1752');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410923', '410923-������', '4', null, null, '4', null, null, null, '1753');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410926', '410926-����', '4', null, null, '4', null, null, null, '1754');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410927', '410927-̨ǰ��', '4', null, null, '4', null, null, null, '1755');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('410928', '410928-�����', '4', null, null, '4', null, null, null, '1756');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411000', '411000-������', '4', null, null, '4', null, null, null, '1757');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411001', '411001-��Ͻ��', '4', null, null, '4', null, null, null, '1758');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411002', '411002-κ����', '4', null, null, '4', null, null, null, '1759');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411023', '411023-������', '4', null, null, '4', null, null, null, '1760');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411024', '411024-۳����', '4', null, null, '4', null, null, null, '1761');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411025', '411025-�����', '4', null, null, '4', null, null, null, '1762');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411081', '411081-������', '4', null, null, '4', null, null, null, '1763');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411082', '411082-������', '4', null, null, '4', null, null, null, '1764');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411100', '411100-�����', '4', null, null, '4', null, null, null, '1765');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411101', '411101-��Ͻ��', '4', null, null, '4', null, null, null, '1766');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411102', '411102-Դ����', '4', null, null, '4', null, null, null, '1767');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411103', '411103-۱����', '4', null, null, '4', null, null, null, '1768');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411104', '411104-������', '4', null, null, '4', null, null, null, '1769');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411121', '411121-������', '4', null, null, '4', null, null, null, '1770');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411122', '411122-�����', '4', null, null, '4', null, null, null, '1771');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411200', '411200-����Ͽ��', '4', null, null, '4', null, null, null, '1772');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411201', '411201-��Ͻ��', '4', null, null, '4', null, null, null, '1773');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411202', '411202-������', '4', null, null, '4', null, null, null, '1774');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411203', '411203-������', '4', null, null, '4', null, null, null, '1775');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411221', '411221-�ų���', '4', null, null, '4', null, null, null, '1776');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411224', '411224-¬����', '4', null, null, '4', null, null, null, '1777');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411281', '411281-������', '4', null, null, '4', null, null, null, '1778');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411282', '411282-�鱦��', '4', null, null, '4', null, null, null, '1779');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411300', '411300-������', '4', null, null, '4', null, null, null, '1780');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411301', '411301-��Ͻ��', '4', null, null, '4', null, null, null, '1781');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411302', '411302-�����', '4', null, null, '4', null, null, null, '1782');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411303', '411303-������', '4', null, null, '4', null, null, null, '1783');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411321', '411321-������', '4', null, null, '4', null, null, null, '1784');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411322', '411322-������', '4', null, null, '4', null, null, null, '1785');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411323', '411323-��Ͽ��', '4', null, null, '4', null, null, null, '1786');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411324', '411324-��ƽ��', '4', null, null, '4', null, null, null, '1787');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411325', '411325-������', '4', null, null, '4', null, null, null, '1788');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411326', '411326-������', '4', null, null, '4', null, null, null, '1789');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411327', '411327-������', '4', null, null, '4', null, null, null, '1790');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411328', '411328-�ƺ���', '4', null, null, '4', null, null, null, '1791');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411329', '411329-��Ұ��', '4', null, null, '4', null, null, null, '1792');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411330', '411330-ͩ����', '4', null, null, '4', null, null, null, '1793');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411381', '411381-������', '4', null, null, '4', null, null, null, '1794');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411400', '411400-������', '4', null, null, '4', null, null, null, '1795');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411401', '411401-��Ͻ��', '4', null, null, '4', null, null, null, '1796');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411402', '411402-��԰��', '4', null, null, '4', null, null, null, '1797');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411403', '411403-�����', '4', null, null, '4', null, null, null, '1798');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411421', '411421-��Ȩ��', '4', null, null, '4', null, null, null, '1799');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411422', '411422-���', '4', null, null, '4', null, null, null, '1800');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411423', '411423-������', '4', null, null, '4', null, null, null, '1801');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411424', '411424-�ϳ���', '4', null, null, '4', null, null, null, '1802');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411425', '411425-�ݳ���', '4', null, null, '4', null, null, null, '1803');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411426', '411426-������', '4', null, null, '4', null, null, null, '1804');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411481', '411481-������', '4', null, null, '4', null, null, null, '1805');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411500', '411500-������', '4', null, null, '4', null, null, null, '1806');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411501', '411501-��Ͻ��', '4', null, null, '4', null, null, null, '1807');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411502', '411502-������', '4', null, null, '4', null, null, null, '1808');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411503', '411503-ƽ����', '4', null, null, '4', null, null, null, '1809');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411521', '411521-��ɽ��', '4', null, null, '4', null, null, null, '1810');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411522', '411522-��ɽ��', '4', null, null, '4', null, null, null, '1811');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411523', '411523-����', '4', null, null, '4', null, null, null, '1812');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411524', '411524-�̳���', '4', null, null, '4', null, null, null, '1813');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411525', '411525-��ʼ��', '4', null, null, '4', null, null, null, '1814');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411526', '411526-�괨��', '4', null, null, '4', null, null, null, '1815');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411527', '411527-������', '4', null, null, '4', null, null, null, '1816');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411528', '411528-Ϣ��', '4', null, null, '4', null, null, null, '1817');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411600', '411600-�ܿ���', '4', null, null, '4', null, null, null, '1818');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411601', '411601-��Ͻ��', '4', null, null, '4', null, null, null, '1819');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411602', '411602-������', '4', null, null, '4', null, null, null, '1820');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411621', '411621-������', '4', null, null, '4', null, null, null, '1821');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411622', '411622-������', '4', null, null, '4', null, null, null, '1822');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411623', '411623-��ˮ��', '4', null, null, '4', null, null, null, '1823');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411624', '411624-������', '4', null, null, '4', null, null, null, '1824');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411625', '411625-������', '4', null, null, '4', null, null, null, '1825');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411626', '411626-������', '4', null, null, '4', null, null, null, '1826');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411627', '411627-̫����', '4', null, null, '4', null, null, null, '1827');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411628', '411628-¹����', '4', null, null, '4', null, null, null, '1828');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411681', '411681-�����', '4', null, null, '4', null, null, null, '1829');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411700', '411700-פ������', '4', null, null, '4', null, null, null, '1830');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411701', '411701-��Ͻ��', '4', null, null, '4', null, null, null, '1831');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411702', '411702-�����', '4', null, null, '4', null, null, null, '1832');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411721', '411721-��ƽ��', '4', null, null, '4', null, null, null, '1833');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411722', '411722-�ϲ���', '4', null, null, '4', null, null, null, '1834');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411723', '411723-ƽ����', '4', null, null, '4', null, null, null, '1835');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411724', '411724-������', '4', null, null, '4', null, null, null, '1836');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411725', '411725-ȷɽ��', '4', null, null, '4', null, null, null, '1837');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411726', '411726-������', '4', null, null, '4', null, null, null, '1838');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411727', '411727-������', '4', null, null, '4', null, null, null, '1839');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411728', '411728-��ƽ��', '4', null, null, '4', null, null, null, '1840');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('411729', '411729-�²���', '4', null, null, '4', null, null, null, '1841');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('419000', '419000-ʡֱϽ�ؼ���������', '4', null, null, '4', null, null, null, '1842');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('419001', '419001-��Դ��', '4', null, null, '4', null, null, null, '1843');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420000', '420000-����ʡ', '4', null, null, '4', null, null, null, '1844');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420100', '420100-�人��', '4', null, null, '4', null, null, null, '1845');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420101', '420101-��Ͻ��', '4', null, null, '4', null, null, null, '1846');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420102', '420102-������', '4', null, null, '4', null, null, null, '1847');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420103', '420103-������', '4', null, null, '4', null, null, null, '1848');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420104', '420104-�~����', '4', null, null, '4', null, null, null, '1849');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420105', '420105-������', '4', null, null, '4', null, null, null, '1850');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420106', '420106-�����', '4', null, null, '4', null, null, null, '1851');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420107', '420107-��ɽ��', '4', null, null, '4', null, null, null, '1852');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420111', '420111-��ɽ��', '4', null, null, '4', null, null, null, '1853');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420112', '420112-��������', '4', null, null, '4', null, null, null, '1854');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420113', '420113-������', '4', null, null, '4', null, null, null, '1855');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420114', '420114-�̵���', '4', null, null, '4', null, null, null, '1856');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420115', '420115-������', '4', null, null, '4', null, null, null, '1857');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420116', '420116-������', '4', null, null, '4', null, null, null, '1858');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420117', '420117-������', '4', null, null, '4', null, null, null, '1859');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420200', '420200-��ʯ��', '4', null, null, '4', null, null, null, '1860');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420201', '420201-��Ͻ��', '4', null, null, '4', null, null, null, '1861');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420202', '420202-��ʯ����', '4', null, null, '4', null, null, null, '1862');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420203', '420203-����ɽ��', '4', null, null, '4', null, null, null, '1863');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420204', '420204-��½��', '4', null, null, '4', null, null, null, '1864');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420205', '420205-��ɽ��', '4', null, null, '4', null, null, null, '1865');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420222', '420222-������', '4', null, null, '4', null, null, null, '1866');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420281', '420281-��ұ��', '4', null, null, '4', null, null, null, '1867');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420300', '420300-ʮ����', '4', null, null, '4', null, null, null, '1868');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420301', '420301-��Ͻ��', '4', null, null, '4', null, null, null, '1869');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420302', '420302-é����', '4', null, null, '4', null, null, null, '1870');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420303', '420303-������', '4', null, null, '4', null, null, null, '1871');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420304', '420304-������', '4', null, null, '4', null, null, null, '1872');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420322', '420322-������', '4', null, null, '4', null, null, null, '1873');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420323', '420323-��ɽ��', '4', null, null, '4', null, null, null, '1874');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420324', '420324-��Ϫ��', '4', null, null, '4', null, null, null, '1875');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420325', '420325-����', '4', null, null, '4', null, null, null, '1876');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420381', '420381-��������', '4', null, null, '4', null, null, null, '1877');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420500', '420500-�˲���', '4', null, null, '4', null, null, null, '1878');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420501', '420501-��Ͻ��', '4', null, null, '4', null, null, null, '1879');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420502', '420502-������', '4', null, null, '4', null, null, null, '1880');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420503', '420503-��Ҹ���', '4', null, null, '4', null, null, null, '1881');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420504', '420504-�����', '4', null, null, '4', null, null, null, '1882');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420505', '420505-�Vͤ��', '4', null, null, '4', null, null, null, '1883');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420506', '420506-������', '4', null, null, '4', null, null, null, '1884');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420525', '420525-Զ����', '4', null, null, '4', null, null, null, '1885');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420526', '420526-��ɽ��', '4', null, null, '4', null, null, null, '1886');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420527', '420527-������', '4', null, null, '4', null, null, null, '1887');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420528', '420528-����������������', '4', null, null, '4', null, null, null, '1888');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420529', '420529-���������������', '4', null, null, '4', null, null, null, '1889');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420581', '420581-�˶���', '4', null, null, '4', null, null, null, '1890');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420582', '420582-������', '4', null, null, '4', null, null, null, '1891');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420583', '420583-֦����', '4', null, null, '4', null, null, null, '1892');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420600', '420600-������', '4', null, null, '4', null, null, null, '1893');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420601', '420601-��Ͻ��', '4', null, null, '4', null, null, null, '1894');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420602', '420602-�����', '4', null, null, '4', null, null, null, '1895');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420606', '420606-������', '4', null, null, '4', null, null, null, '1896');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420607', '420607-������', '4', null, null, '4', null, null, null, '1897');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420624', '420624-������', '4', null, null, '4', null, null, null, '1898');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420625', '420625-�ȳ���', '4', null, null, '4', null, null, null, '1899');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420626', '420626-������', '4', null, null, '4', null, null, null, '1900');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420682', '420682-�Ϻӿ���', '4', null, null, '4', null, null, null, '1901');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420683', '420683-������', '4', null, null, '4', null, null, null, '1902');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420684', '420684-�˳���', '4', null, null, '4', null, null, null, '1903');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420700', '420700-������', '4', null, null, '4', null, null, null, '1904');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420701', '420701-��Ͻ��', '4', null, null, '4', null, null, null, '1905');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420702', '420702-���Ӻ���', '4', null, null, '4', null, null, null, '1906');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420703', '420703-������', '4', null, null, '4', null, null, null, '1907');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420704', '420704-������', '4', null, null, '4', null, null, null, '1908');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420800', '420800-������', '4', null, null, '4', null, null, null, '1909');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420801', '420801-��Ͻ��', '4', null, null, '4', null, null, null, '1910');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420802', '420802-������', '4', null, null, '4', null, null, null, '1911');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420804', '420804-�޵���', '4', null, null, '4', null, null, null, '1912');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420821', '420821-��ɽ��', '4', null, null, '4', null, null, null, '1913');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420822', '420822-ɳ����', '4', null, null, '4', null, null, null, '1914');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420881', '420881-������', '4', null, null, '4', null, null, null, '1915');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420900', '420900-Т����', '4', null, null, '4', null, null, null, '1916');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420901', '420901-��Ͻ��', '4', null, null, '4', null, null, null, '1917');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420902', '420902-Т����', '4', null, null, '4', null, null, null, '1918');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420921', '420921-Т����', '4', null, null, '4', null, null, null, '1919');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420922', '420922-������', '4', null, null, '4', null, null, null, '1920');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420923', '420923-������', '4', null, null, '4', null, null, null, '1921');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420981', '420981-Ӧ����', '4', null, null, '4', null, null, null, '1922');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420982', '420982-��½��', '4', null, null, '4', null, null, null, '1923');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('420984', '420984-������', '4', null, null, '4', null, null, null, '1924');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421000', '421000-������', '4', null, null, '4', null, null, null, '1925');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421001', '421001-��Ͻ��', '4', null, null, '4', null, null, null, '1926');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421002', '421002-ɳ����', '4', null, null, '4', null, null, null, '1927');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421003', '421003-������', '4', null, null, '4', null, null, null, '1928');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421022', '421022-������', '4', null, null, '4', null, null, null, '1929');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421023', '421023-������', '4', null, null, '4', null, null, null, '1930');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421024', '421024-������', '4', null, null, '4', null, null, null, '1931');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421081', '421081-ʯ����', '4', null, null, '4', null, null, null, '1932');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421083', '421083-�����', '4', null, null, '4', null, null, null, '1933');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421087', '421087-������', '4', null, null, '4', null, null, null, '1934');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421100', '421100-�Ƹ���', '4', null, null, '4', null, null, null, '1935');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421101', '421101-��Ͻ��', '4', null, null, '4', null, null, null, '1936');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421102', '421102-������', '4', null, null, '4', null, null, null, '1937');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421121', '421121-�ŷ���', '4', null, null, '4', null, null, null, '1938');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421122', '421122-�찲��', '4', null, null, '4', null, null, null, '1939');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421123', '421123-������', '4', null, null, '4', null, null, null, '1940');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421124', '421124-Ӣɽ��', '4', null, null, '4', null, null, null, '1941');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421125', '421125-�ˮ��', '4', null, null, '4', null, null, null, '1942');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421126', '421126-ޭ����', '4', null, null, '4', null, null, null, '1943');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421127', '421127-��÷��', '4', null, null, '4', null, null, null, '1944');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421181', '421181-�����', '4', null, null, '4', null, null, null, '1945');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421182', '421182-��Ѩ��', '4', null, null, '4', null, null, null, '1946');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421200', '421200-������', '4', null, null, '4', null, null, null, '1947');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421201', '421201-��Ͻ��', '4', null, null, '4', null, null, null, '1948');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421202', '421202-�̰���', '4', null, null, '4', null, null, null, '1949');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421221', '421221-������', '4', null, null, '4', null, null, null, '1950');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421222', '421222-ͨ����', '4', null, null, '4', null, null, null, '1951');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421223', '421223-������', '4', null, null, '4', null, null, null, '1952');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421224', '421224-ͨɽ��', '4', null, null, '4', null, null, null, '1953');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421281', '421281-�����', '4', null, null, '4', null, null, null, '1954');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421300', '421300-������', '4', null, null, '4', null, null, null, '1955');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421301', '421301-��Ͻ��', '4', null, null, '4', null, null, null, '1956');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421303', '421303-������', '4', null, null, '4', null, null, null, '1957');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421321', '421321-����', '4', null, null, '4', null, null, null, '1958');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('421381', '421381-��ˮ��', '4', null, null, '4', null, null, null, '1959');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('422800', '422800-��ʩ����������������', '4', null, null, '4', null, null, null, '1960');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('422801', '422801-��ʩ��', '4', null, null, '4', null, null, null, '1961');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('422802', '422802-������', '4', null, null, '4', null, null, null, '1962');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('422822', '422822-��ʼ��', '4', null, null, '4', null, null, null, '1963');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('422823', '422823-�Ͷ���', '4', null, null, '4', null, null, null, '1964');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('422825', '422825-������', '4', null, null, '4', null, null, null, '1965');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('422826', '422826-�̷���', '4', null, null, '4', null, null, null, '1966');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('422827', '422827-������', '4', null, null, '4', null, null, null, '1967');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('422828', '422828-�׷���', '4', null, null, '4', null, null, null, '1968');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('429000', '429000-ʡֱϽ�ؼ���������', '4', null, null, '4', null, null, null, '1969');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('429004', '429004-������', '4', null, null, '4', null, null, null, '1970');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('429005', '429005-Ǳ����', '4', null, null, '4', null, null, null, '1971');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('429006', '429006-������', '4', null, null, '4', null, null, null, '1972');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('429021', '429021-��ũ������', '4', null, null, '4', null, null, null, '1973');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430000', '430000-����ʡ', '4', null, null, '4', null, null, null, '1974');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430100', '430100-��ɳ��', '4', null, null, '4', null, null, null, '1975');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430101', '430101-��Ͻ��', '4', null, null, '4', null, null, null, '1976');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430102', '430102-ܽ����', '4', null, null, '4', null, null, null, '1977');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430103', '430103-������', '4', null, null, '4', null, null, null, '1978');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430104', '430104-��´��', '4', null, null, '4', null, null, null, '1979');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430105', '430105-������', '4', null, null, '4', null, null, null, '1980');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430111', '430111-�껨��', '4', null, null, '4', null, null, null, '1981');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430112', '430112-������', '4', null, null, '4', null, null, null, '1982');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430121', '430121-��ɳ��', '4', null, null, '4', null, null, null, '1983');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430124', '430124-������', '4', null, null, '4', null, null, null, '1984');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430181', '430181-�����', '4', null, null, '4', null, null, null, '1985');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430200', '430200-������', '4', null, null, '4', null, null, null, '1986');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430201', '430201-��Ͻ��', '4', null, null, '4', null, null, null, '1987');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430202', '430202-������', '4', null, null, '4', null, null, null, '1988');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430203', '430203-«����', '4', null, null, '4', null, null, null, '1989');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430204', '430204-ʯ����', '4', null, null, '4', null, null, null, '1990');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430211', '430211-��Ԫ��', '4', null, null, '4', null, null, null, '1991');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430221', '430221-������', '4', null, null, '4', null, null, null, '1992');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430223', '430223-����', '4', null, null, '4', null, null, null, '1993');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430224', '430224-������', '4', null, null, '4', null, null, null, '1994');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430225', '430225-������', '4', null, null, '4', null, null, null, '1995');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430281', '430281-������', '4', null, null, '4', null, null, null, '1996');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430300', '430300-��̶��', '4', null, null, '4', null, null, null, '1997');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430301', '430301-��Ͻ��', '4', null, null, '4', null, null, null, '1998');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430302', '430302-�����', '4', null, null, '4', null, null, null, '1999');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430304', '430304-������', '4', null, null, '4', null, null, null, '2000');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430321', '430321-��̶��', '4', null, null, '4', null, null, null, '2001');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430381', '430381-������', '4', null, null, '4', null, null, null, '2002');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430382', '430382-��ɽ��', '4', null, null, '4', null, null, null, '2003');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430400', '430400-������', '4', null, null, '4', null, null, null, '2004');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430401', '430401-��Ͻ��', '4', null, null, '4', null, null, null, '2005');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430405', '430405-������', '4', null, null, '4', null, null, null, '2006');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430406', '430406-�����', '4', null, null, '4', null, null, null, '2007');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430407', '430407-ʯ����', '4', null, null, '4', null, null, null, '2008');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430408', '430408-������', '4', null, null, '4', null, null, null, '2009');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430412', '430412-������', '4', null, null, '4', null, null, null, '2010');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430421', '430421-������', '4', null, null, '4', null, null, null, '2011');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430422', '430422-������', '4', null, null, '4', null, null, null, '2012');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430423', '430423-��ɽ��', '4', null, null, '4', null, null, null, '2013');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430424', '430424-�ⶫ��', '4', null, null, '4', null, null, null, '2014');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430426', '430426-���', '4', null, null, '4', null, null, null, '2015');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430481', '430481-������', '4', null, null, '4', null, null, null, '2016');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430482', '430482-������', '4', null, null, '4', null, null, null, '2017');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430500', '430500-������', '4', null, null, '4', null, null, null, '2018');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430501', '430501-��Ͻ��', '4', null, null, '4', null, null, null, '2019');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430502', '430502-˫����', '4', null, null, '4', null, null, null, '2020');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430503', '430503-������', '4', null, null, '4', null, null, null, '2021');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430511', '430511-������', '4', null, null, '4', null, null, null, '2022');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430521', '430521-�۶���', '4', null, null, '4', null, null, null, '2023');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430522', '430522-������', '4', null, null, '4', null, null, null, '2024');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430523', '430523-������', '4', null, null, '4', null, null, null, '2025');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430524', '430524-¡����', '4', null, null, '4', null, null, null, '2026');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430525', '430525-������', '4', null, null, '4', null, null, null, '2027');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430527', '430527-������', '4', null, null, '4', null, null, null, '2028');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430528', '430528-������', '4', null, null, '4', null, null, null, '2029');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430529', '430529-�ǲ�����������', '4', null, null, '4', null, null, null, '2030');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430581', '430581-�����', '4', null, null, '4', null, null, null, '2031');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430600', '430600-������', '4', null, null, '4', null, null, null, '2032');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430601', '430601-��Ͻ��', '4', null, null, '4', null, null, null, '2033');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430602', '430602-����¥��', '4', null, null, '4', null, null, null, '2034');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430603', '430603-��Ϫ��', '4', null, null, '4', null, null, null, '2035');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430611', '430611-��ɽ��', '4', null, null, '4', null, null, null, '2036');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430621', '430621-������', '4', null, null, '4', null, null, null, '2037');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430623', '430623-������', '4', null, null, '4', null, null, null, '2038');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430624', '430624-������', '4', null, null, '4', null, null, null, '2039');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430626', '430626-ƽ����', '4', null, null, '4', null, null, null, '2040');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430681', '430681-������', '4', null, null, '4', null, null, null, '2041');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430682', '430682-������', '4', null, null, '4', null, null, null, '2042');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430700', '430700-������', '4', null, null, '4', null, null, null, '2043');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430701', '430701-��Ͻ��', '4', null, null, '4', null, null, null, '2044');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430702', '430702-������', '4', null, null, '4', null, null, null, '2045');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430703', '430703-������', '4', null, null, '4', null, null, null, '2046');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430721', '430721-������', '4', null, null, '4', null, null, null, '2047');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430722', '430722-������', '4', null, null, '4', null, null, null, '2048');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430723', '430723-���', '4', null, null, '4', null, null, null, '2049');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430724', '430724-�����', '4', null, null, '4', null, null, null, '2050');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430725', '430725-��Դ��', '4', null, null, '4', null, null, null, '2051');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430726', '430726-ʯ����', '4', null, null, '4', null, null, null, '2052');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430781', '430781-������', '4', null, null, '4', null, null, null, '2053');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430800', '430800-�żҽ���', '4', null, null, '4', null, null, null, '2054');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430801', '430801-��Ͻ��', '4', null, null, '4', null, null, null, '2055');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430802', '430802-������', '4', null, null, '4', null, null, null, '2056');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430811', '430811-����Դ��', '4', null, null, '4', null, null, null, '2057');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430821', '430821-������', '4', null, null, '4', null, null, null, '2058');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430822', '430822-ɣֲ��', '4', null, null, '4', null, null, null, '2059');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430900', '430900-������', '4', null, null, '4', null, null, null, '2060');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430901', '430901-��Ͻ��', '4', null, null, '4', null, null, null, '2061');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430902', '430902-������', '4', null, null, '4', null, null, null, '2062');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430903', '430903-��ɽ��', '4', null, null, '4', null, null, null, '2063');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430921', '430921-����', '4', null, null, '4', null, null, null, '2064');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430922', '430922-�ҽ���', '4', null, null, '4', null, null, null, '2065');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430923', '430923-������', '4', null, null, '4', null, null, null, '2066');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('430981', '430981-�佭��', '4', null, null, '4', null, null, null, '2067');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431000', '431000-������', '4', null, null, '4', null, null, null, '2068');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431001', '431001-��Ͻ��', '4', null, null, '4', null, null, null, '2069');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431002', '431002-������', '4', null, null, '4', null, null, null, '2070');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431003', '431003-������', '4', null, null, '4', null, null, null, '2071');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431021', '431021-������', '4', null, null, '4', null, null, null, '2072');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431022', '431022-������', '4', null, null, '4', null, null, null, '2073');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431023', '431023-������', '4', null, null, '4', null, null, null, '2074');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431024', '431024-�κ���', '4', null, null, '4', null, null, null, '2075');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431025', '431025-������', '4', null, null, '4', null, null, null, '2076');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431026', '431026-�����', '4', null, null, '4', null, null, null, '2077');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431027', '431027-����', '4', null, null, '4', null, null, null, '2078');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431028', '431028-������', '4', null, null, '4', null, null, null, '2079');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431081', '431081-������', '4', null, null, '4', null, null, null, '2080');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431100', '431100-������', '4', null, null, '4', null, null, null, '2081');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431101', '431101-��Ͻ��', '4', null, null, '4', null, null, null, '2082');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431102', '431102-������', '4', null, null, '4', null, null, null, '2083');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431103', '431103-��ˮ̲��', '4', null, null, '4', null, null, null, '2084');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431121', '431121-������', '4', null, null, '4', null, null, null, '2085');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431122', '431122-������', '4', null, null, '4', null, null, null, '2086');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431123', '431123-˫����', '4', null, null, '4', null, null, null, '2087');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431124', '431124-����', '4', null, null, '4', null, null, null, '2088');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431125', '431125-������', '4', null, null, '4', null, null, null, '2089');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431126', '431126-��Զ��', '4', null, null, '4', null, null, null, '2090');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431127', '431127-��ɽ��', '4', null, null, '4', null, null, null, '2091');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431128', '431128-������', '4', null, null, '4', null, null, null, '2092');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431129', '431129-��������������', '4', null, null, '4', null, null, null, '2093');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431200', '431200-������', '4', null, null, '4', null, null, null, '2094');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431201', '431201-��Ͻ��', '4', null, null, '4', null, null, null, '2095');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431202', '431202-�׳���', '4', null, null, '4', null, null, null, '2096');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431221', '431221-�з���', '4', null, null, '4', null, null, null, '2097');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431222', '431222-������', '4', null, null, '4', null, null, null, '2098');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431223', '431223-��Ϫ��', '4', null, null, '4', null, null, null, '2099');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431224', '431224-������', '4', null, null, '4', null, null, null, '2100');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431225', '431225-��ͬ��', '4', null, null, '4', null, null, null, '2101');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431226', '431226-��������������', '4', null, null, '4', null, null, null, '2102');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431227', '431227-�»ζ���������', '4', null, null, '4', null, null, null, '2103');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431228', '431228-�ƽ�����������', '4', null, null, '4', null, null, null, '2104');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431229', '431229-�������嶱��������', '4', null, null, '4', null, null, null, '2105');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431230', '431230-ͨ������������', '4', null, null, '4', null, null, null, '2106');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431281', '431281-�齭��', '4', null, null, '4', null, null, null, '2107');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431300', '431300-¦����', '4', null, null, '4', null, null, null, '2108');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431301', '431301-��Ͻ��', '4', null, null, '4', null, null, null, '2109');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431302', '431302-¦����', '4', null, null, '4', null, null, null, '2110');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431321', '431321-˫����', '4', null, null, '4', null, null, null, '2111');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431322', '431322-�»���', '4', null, null, '4', null, null, null, '2112');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431381', '431381-��ˮ����', '4', null, null, '4', null, null, null, '2113');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('431382', '431382-��Դ��', '4', null, null, '4', null, null, null, '2114');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('433100', '433100-��������������������', '4', null, null, '4', null, null, null, '2115');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('433101', '433101-������', '4', null, null, '4', null, null, null, '2116');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('433122', '433122-��Ϫ��', '4', null, null, '4', null, null, null, '2117');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('433123', '433123-�����', '4', null, null, '4', null, null, null, '2118');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('433124', '433124-��ԫ��', '4', null, null, '4', null, null, null, '2119');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('433125', '433125-������', '4', null, null, '4', null, null, null, '2120');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('433126', '433126-������', '4', null, null, '4', null, null, null, '2121');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('433127', '433127-��˳��', '4', null, null, '4', null, null, null, '2122');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('433130', '433130-��ɽ��', '4', null, null, '4', null, null, null, '2123');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440000', '440000-�㶫ʡ', '4', null, null, '4', null, null, null, '2124');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440100', '440100-������', '4', null, null, '4', null, null, null, '2125');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440101', '440101-��Ͻ��', '4', null, null, '4', null, null, null, '2126');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440103', '440103-������', '4', null, null, '4', null, null, null, '2127');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440104', '440104-Խ����', '4', null, null, '4', null, null, null, '2128');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440105', '440105-������', '4', null, null, '4', null, null, null, '2129');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440106', '440106-�����', '4', null, null, '4', null, null, null, '2130');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440111', '440111-������', '4', null, null, '4', null, null, null, '2131');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440112', '440112-������', '4', null, null, '4', null, null, null, '2132');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440113', '440113-��خ��', '4', null, null, '4', null, null, null, '2133');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440114', '440114-������', '4', null, null, '4', null, null, null, '2134');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440115', '440115-��ɳ��', '4', null, null, '4', null, null, null, '2135');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440117', '440117-�ӻ���', '4', null, null, '4', null, null, null, '2136');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440118', '440118-������', '4', null, null, '4', null, null, null, '2137');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440200', '440200-�ع���', '4', null, null, '4', null, null, null, '2138');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440201', '440201-��Ͻ��', '4', null, null, '4', null, null, null, '2139');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440203', '440203-�佭��', '4', null, null, '4', null, null, null, '2140');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440204', '440204-䥽���', '4', null, null, '4', null, null, null, '2141');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440205', '440205-������', '4', null, null, '4', null, null, null, '2142');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440222', '440222-ʼ����', '4', null, null, '4', null, null, null, '2143');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440224', '440224-�ʻ���', '4', null, null, '4', null, null, null, '2144');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440229', '440229-��Դ��', '4', null, null, '4', null, null, null, '2145');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440232', '440232-��Դ����������', '4', null, null, '4', null, null, null, '2146');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440233', '440233-�·���', '4', null, null, '4', null, null, null, '2147');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440281', '440281-�ֲ���', '4', null, null, '4', null, null, null, '2148');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440282', '440282-������', '4', null, null, '4', null, null, null, '2149');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440300', '440300-������', '4', null, null, '4', null, null, null, '2150');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440301', '440301-��Ͻ��', '4', null, null, '4', null, null, null, '2151');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440303', '440303-�޺���', '4', null, null, '4', null, null, null, '2152');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440304', '440304-������', '4', null, null, '4', null, null, null, '2153');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440305', '440305-��ɽ��', '4', null, null, '4', null, null, null, '2154');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440306', '440306-������', '4', null, null, '4', null, null, null, '2155');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440307', '440307-������', '4', null, null, '4', null, null, null, '2156');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440308', '440308-������', '4', null, null, '4', null, null, null, '2157');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440400', '440400-�麣��', '4', null, null, '4', null, null, null, '2158');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440401', '440401-��Ͻ��', '4', null, null, '4', null, null, null, '2159');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440402', '440402-������', '4', null, null, '4', null, null, null, '2160');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440403', '440403-������', '4', null, null, '4', null, null, null, '2161');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440404', '440404-������', '4', null, null, '4', null, null, null, '2162');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440500', '440500-��ͷ��', '4', null, null, '4', null, null, null, '2163');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440501', '440501-��Ͻ��', '4', null, null, '4', null, null, null, '2164');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440507', '440507-������', '4', null, null, '4', null, null, null, '2165');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440511', '440511-��ƽ��', '4', null, null, '4', null, null, null, '2166');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440512', '440512-婽���', '4', null, null, '4', null, null, null, '2167');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440513', '440513-������', '4', null, null, '4', null, null, null, '2168');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440514', '440514-������', '4', null, null, '4', null, null, null, '2169');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440515', '440515-�κ���', '4', null, null, '4', null, null, null, '2170');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440523', '440523-�ϰ���', '4', null, null, '4', null, null, null, '2171');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440600', '440600-��ɽ��', '4', null, null, '4', null, null, null, '2172');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440601', '440601-��Ͻ��', '4', null, null, '4', null, null, null, '2173');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440604', '440604-������', '4', null, null, '4', null, null, null, '2174');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440605', '440605-�Ϻ���', '4', null, null, '4', null, null, null, '2175');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440606', '440606-˳����', '4', null, null, '4', null, null, null, '2176');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440607', '440607-��ˮ��', '4', null, null, '4', null, null, null, '2177');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440608', '440608-������', '4', null, null, '4', null, null, null, '2178');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440700', '440700-������', '4', null, null, '4', null, null, null, '2179');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440701', '440701-��Ͻ��', '4', null, null, '4', null, null, null, '2180');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440703', '440703-���', '4', null, null, '4', null, null, null, '2181');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440704', '440704-������', '4', null, null, '4', null, null, null, '2182');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440705', '440705-�»���', '4', null, null, '4', null, null, null, '2183');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440781', '440781-̨ɽ��', '4', null, null, '4', null, null, null, '2184');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440783', '440783-��ƽ��', '4', null, null, '4', null, null, null, '2185');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440784', '440784-��ɽ��', '4', null, null, '4', null, null, null, '2186');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440785', '440785-��ƽ��', '4', null, null, '4', null, null, null, '2187');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440800', '440800-տ����', '4', null, null, '4', null, null, null, '2188');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440801', '440801-��Ͻ��', '4', null, null, '4', null, null, null, '2189');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440802', '440802-�࿲��', '4', null, null, '4', null, null, null, '2190');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440803', '440803-ϼɽ��', '4', null, null, '4', null, null, null, '2191');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440804', '440804-��ͷ��', '4', null, null, '4', null, null, null, '2192');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440811', '440811-������', '4', null, null, '4', null, null, null, '2193');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440823', '440823-��Ϫ��', '4', null, null, '4', null, null, null, '2194');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440825', '440825-������', '4', null, null, '4', null, null, null, '2195');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440881', '440881-������', '4', null, null, '4', null, null, null, '2196');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440882', '440882-������', '4', null, null, '4', null, null, null, '2197');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440883', '440883-�⴨��', '4', null, null, '4', null, null, null, '2198');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440900', '440900-ï����', '4', null, null, '4', null, null, null, '2199');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440901', '440901-��Ͻ��', '4', null, null, '4', null, null, null, '2200');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440902', '440902-ï����', '4', null, null, '4', null, null, null, '2201');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440904', '440904-�����', '4', null, null, '4', null, null, null, '2202');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440981', '440981-������', '4', null, null, '4', null, null, null, '2203');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440982', '440982-������', '4', null, null, '4', null, null, null, '2204');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('440983', '440983-������', '4', null, null, '4', null, null, null, '2205');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441200', '441200-������', '4', null, null, '4', null, null, null, '2206');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441201', '441201-��Ͻ��', '4', null, null, '4', null, null, null, '2207');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441202', '441202-������', '4', null, null, '4', null, null, null, '2208');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441203', '441203-������', '4', null, null, '4', null, null, null, '2209');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441204', '441204-��Ҫ��', '4', null, null, '4', null, null, null, '2210');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441223', '441223-������', '4', null, null, '4', null, null, null, '2211');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441224', '441224-������', '4', null, null, '4', null, null, null, '2212');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441225', '441225-�⿪��', '4', null, null, '4', null, null, null, '2213');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441226', '441226-������', '4', null, null, '4', null, null, null, '2214');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441284', '441284-�Ļ���', '4', null, null, '4', null, null, null, '2215');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441300', '441300-������', '4', null, null, '4', null, null, null, '2216');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441301', '441301-��Ͻ��', '4', null, null, '4', null, null, null, '2217');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441302', '441302-�ݳ���', '4', null, null, '4', null, null, null, '2218');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441303', '441303-������', '4', null, null, '4', null, null, null, '2219');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441322', '441322-������', '4', null, null, '4', null, null, null, '2220');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441323', '441323-�ݶ���', '4', null, null, '4', null, null, null, '2221');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441324', '441324-������', '4', null, null, '4', null, null, null, '2222');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441400', '441400-÷����', '4', null, null, '4', null, null, null, '2223');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441401', '441401-��Ͻ��', '4', null, null, '4', null, null, null, '2224');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441402', '441402-÷����', '4', null, null, '4', null, null, null, '2225');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441403', '441403-÷����', '4', null, null, '4', null, null, null, '2226');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441422', '441422-������', '4', null, null, '4', null, null, null, '2227');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441423', '441423-��˳��', '4', null, null, '4', null, null, null, '2228');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441424', '441424-�廪��', '4', null, null, '4', null, null, null, '2229');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441426', '441426-ƽԶ��', '4', null, null, '4', null, null, null, '2230');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441427', '441427-������', '4', null, null, '4', null, null, null, '2231');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441481', '441481-������', '4', null, null, '4', null, null, null, '2232');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441500', '441500-��β��', '4', null, null, '4', null, null, null, '2233');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441501', '441501-��Ͻ��', '4', null, null, '4', null, null, null, '2234');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441502', '441502-����', '4', null, null, '4', null, null, null, '2235');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441521', '441521-������', '4', null, null, '4', null, null, null, '2236');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441523', '441523-½����', '4', null, null, '4', null, null, null, '2237');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441581', '441581-½����', '4', null, null, '4', null, null, null, '2238');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441600', '441600-��Դ��', '4', null, null, '4', null, null, null, '2239');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441601', '441601-��Ͻ��', '4', null, null, '4', null, null, null, '2240');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441602', '441602-Դ����', '4', null, null, '4', null, null, null, '2241');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441621', '441621-�Ͻ���', '4', null, null, '4', null, null, null, '2242');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441622', '441622-������', '4', null, null, '4', null, null, null, '2243');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441623', '441623-��ƽ��', '4', null, null, '4', null, null, null, '2244');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441624', '441624-��ƽ��', '4', null, null, '4', null, null, null, '2245');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441625', '441625-��Դ��', '4', null, null, '4', null, null, null, '2246');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441700', '441700-������', '4', null, null, '4', null, null, null, '2247');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441701', '441701-��Ͻ��', '4', null, null, '4', null, null, null, '2248');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441702', '441702-������', '4', null, null, '4', null, null, null, '2249');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441704', '441704-������', '4', null, null, '4', null, null, null, '2250');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441721', '441721-������', '4', null, null, '4', null, null, null, '2251');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441781', '441781-������', '4', null, null, '4', null, null, null, '2252');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441800', '441800-��Զ��', '4', null, null, '4', null, null, null, '2253');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441801', '441801-��Ͻ��', '4', null, null, '4', null, null, null, '2254');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441802', '441802-�����', '4', null, null, '4', null, null, null, '2255');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441803', '441803-������', '4', null, null, '4', null, null, null, '2256');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441821', '441821-�����', '4', null, null, '4', null, null, null, '2257');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441823', '441823-��ɽ��', '4', null, null, '4', null, null, null, '2258');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441825', '441825-��ɽ׳������������', '4', null, null, '4', null, null, null, '2259');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441826', '441826-��������������', '4', null, null, '4', null, null, null, '2260');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441881', '441881-Ӣ����', '4', null, null, '4', null, null, null, '2261');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441882', '441882-������', '4', null, null, '4', null, null, null, '2262');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('441900', '441900-��ݸ��', '4', null, null, '4', null, null, null, '2263');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('442000', '442000-��ɽ��', '4', null, null, '4', null, null, null, '2264');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('445100', '445100-������', '4', null, null, '4', null, null, null, '2265');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('445101', '445101-��Ͻ��', '4', null, null, '4', null, null, null, '2266');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('445102', '445102-������', '4', null, null, '4', null, null, null, '2267');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('445103', '445103-������', '4', null, null, '4', null, null, null, '2268');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('445122', '445122-��ƽ��', '4', null, null, '4', null, null, null, '2269');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('445200', '445200-������', '4', null, null, '4', null, null, null, '2270');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('445201', '445201-��Ͻ��', '4', null, null, '4', null, null, null, '2271');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('445202', '445202-�ų���', '4', null, null, '4', null, null, null, '2272');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('445203', '445203-�Ҷ���', '4', null, null, '4', null, null, null, '2273');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('445222', '445222-������', '4', null, null, '4', null, null, null, '2274');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('445224', '445224-������', '4', null, null, '4', null, null, null, '2275');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('445281', '445281-������', '4', null, null, '4', null, null, null, '2276');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('445300', '445300-�Ƹ���', '4', null, null, '4', null, null, null, '2277');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('445301', '445301-��Ͻ��', '4', null, null, '4', null, null, null, '2278');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('445302', '445302-�Ƴ���', '4', null, null, '4', null, null, null, '2279');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('445303', '445303-�ư���', '4', null, null, '4', null, null, null, '2280');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('445321', '445321-������', '4', null, null, '4', null, null, null, '2281');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('445322', '445322-������', '4', null, null, '4', null, null, null, '2282');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('445381', '445381-�޶���', '4', null, null, '4', null, null, null, '2283');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450000', '450000-����׳��������', '4', null, null, '4', null, null, null, '2284');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450100', '450100-������', '4', null, null, '4', null, null, null, '2285');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450101', '450101-��Ͻ��', '4', null, null, '4', null, null, null, '2286');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450102', '450102-������', '4', null, null, '4', null, null, null, '2287');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450103', '450103-������', '4', null, null, '4', null, null, null, '2288');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450105', '450105-������', '4', null, null, '4', null, null, null, '2289');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450107', '450107-��������', '4', null, null, '4', null, null, null, '2290');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450108', '450108-������', '4', null, null, '4', null, null, null, '2291');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450109', '450109-������', '4', null, null, '4', null, null, null, '2292');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450110', '450110-������', '4', null, null, '4', null, null, null, '2293');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450123', '450123-¡����', '4', null, null, '4', null, null, null, '2294');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450124', '450124-��ɽ��', '4', null, null, '4', null, null, null, '2295');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450125', '450125-������', '4', null, null, '4', null, null, null, '2296');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450126', '450126-������', '4', null, null, '4', null, null, null, '2297');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450127', '450127-����', '4', null, null, '4', null, null, null, '2298');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450200', '450200-������', '4', null, null, '4', null, null, null, '2299');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450201', '450201-��Ͻ��', '4', null, null, '4', null, null, null, '2300');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450202', '450202-������', '4', null, null, '4', null, null, null, '2301');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450203', '450203-�����', '4', null, null, '4', null, null, null, '2302');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450204', '450204-������', '4', null, null, '4', null, null, null, '2303');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450205', '450205-������', '4', null, null, '4', null, null, null, '2304');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450206', '450206-������', '4', null, null, '4', null, null, null, '2305');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450222', '450222-������', '4', null, null, '4', null, null, null, '2306');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450223', '450223-¹կ��', '4', null, null, '4', null, null, null, '2307');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450224', '450224-�ڰ���', '4', null, null, '4', null, null, null, '2308');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450225', '450225-��ˮ����������', '4', null, null, '4', null, null, null, '2309');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450226', '450226-��������������', '4', null, null, '4', null, null, null, '2310');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450300', '450300-������', '4', null, null, '4', null, null, null, '2311');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450301', '450301-��Ͻ��', '4', null, null, '4', null, null, null, '2312');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450302', '450302-�����', '4', null, null, '4', null, null, null, '2313');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450303', '450303-������', '4', null, null, '4', null, null, null, '2314');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450304', '450304-��ɽ��', '4', null, null, '4', null, null, null, '2315');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450305', '450305-������', '4', null, null, '4', null, null, null, '2316');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450311', '450311-��ɽ��', '4', null, null, '4', null, null, null, '2317');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450312', '450312-�ٹ���', '4', null, null, '4', null, null, null, '2318');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450321', '450321-��˷��', '4', null, null, '4', null, null, null, '2319');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450323', '450323-�鴨��', '4', null, null, '4', null, null, null, '2320');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450324', '450324-ȫ����', '4', null, null, '4', null, null, null, '2321');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450325', '450325-�˰���', '4', null, null, '4', null, null, null, '2322');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450326', '450326-������', '4', null, null, '4', null, null, null, '2323');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450327', '450327-������', '4', null, null, '4', null, null, null, '2324');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450328', '450328-��ʤ����������', '4', null, null, '4', null, null, null, '2325');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450329', '450329-��Դ��', '4', null, null, '4', null, null, null, '2326');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450330', '450330-ƽ����', '4', null, null, '4', null, null, null, '2327');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450331', '450331-������', '4', null, null, '4', null, null, null, '2328');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450332', '450332-��������������', '4', null, null, '4', null, null, null, '2329');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450400', '450400-������', '4', null, null, '4', null, null, null, '2330');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450401', '450401-��Ͻ��', '4', null, null, '4', null, null, null, '2331');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450403', '450403-������', '4', null, null, '4', null, null, null, '2332');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450405', '450405-������', '4', null, null, '4', null, null, null, '2333');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450406', '450406-������', '4', null, null, '4', null, null, null, '2334');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450421', '450421-������', '4', null, null, '4', null, null, null, '2335');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450422', '450422-����', '4', null, null, '4', null, null, null, '2336');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450423', '450423-��ɽ��', '4', null, null, '4', null, null, null, '2337');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450481', '450481-�Ϫ��', '4', null, null, '4', null, null, null, '2338');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450500', '450500-������', '4', null, null, '4', null, null, null, '2339');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450501', '450501-��Ͻ��', '4', null, null, '4', null, null, null, '2340');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450502', '450502-������', '4', null, null, '4', null, null, null, '2341');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450503', '450503-������', '4', null, null, '4', null, null, null, '2342');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450512', '450512-��ɽ����', '4', null, null, '4', null, null, null, '2343');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450521', '450521-������', '4', null, null, '4', null, null, null, '2344');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450600', '450600-���Ǹ���', '4', null, null, '4', null, null, null, '2345');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450601', '450601-��Ͻ��', '4', null, null, '4', null, null, null, '2346');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450602', '450602-�ۿ���', '4', null, null, '4', null, null, null, '2347');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450603', '450603-������', '4', null, null, '4', null, null, null, '2348');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450621', '450621-��˼��', '4', null, null, '4', null, null, null, '2349');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450681', '450681-������', '4', null, null, '4', null, null, null, '2350');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450700', '450700-������', '4', null, null, '4', null, null, null, '2351');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450701', '450701-��Ͻ��', '4', null, null, '4', null, null, null, '2352');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450702', '450702-������', '4', null, null, '4', null, null, null, '2353');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450703', '450703-�ձ���', '4', null, null, '4', null, null, null, '2354');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450721', '450721-��ɽ��', '4', null, null, '4', null, null, null, '2355');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450722', '450722-�ֱ���', '4', null, null, '4', null, null, null, '2356');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450800', '450800-�����', '4', null, null, '4', null, null, null, '2357');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450801', '450801-��Ͻ��', '4', null, null, '4', null, null, null, '2358');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450802', '450802-�۱���', '4', null, null, '4', null, null, null, '2359');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450803', '450803-������', '4', null, null, '4', null, null, null, '2360');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450804', '450804-������', '4', null, null, '4', null, null, null, '2361');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450821', '450821-ƽ����', '4', null, null, '4', null, null, null, '2362');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450881', '450881-��ƽ��', '4', null, null, '4', null, null, null, '2363');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450900', '450900-������', '4', null, null, '4', null, null, null, '2364');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450901', '450901-��Ͻ��', '4', null, null, '4', null, null, null, '2365');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450902', '450902-������', '4', null, null, '4', null, null, null, '2366');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450903', '450903-������', '4', null, null, '4', null, null, null, '2367');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450921', '450921-����', '4', null, null, '4', null, null, null, '2368');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450922', '450922-½����', '4', null, null, '4', null, null, null, '2369');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450923', '450923-������', '4', null, null, '4', null, null, null, '2370');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450924', '450924-��ҵ��', '4', null, null, '4', null, null, null, '2371');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('450981', '450981-������', '4', null, null, '4', null, null, null, '2372');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451000', '451000-��ɫ��', '4', null, null, '4', null, null, null, '2373');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451001', '451001-��Ͻ��', '4', null, null, '4', null, null, null, '2374');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451002', '451002-�ҽ���', '4', null, null, '4', null, null, null, '2375');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451021', '451021-������', '4', null, null, '4', null, null, null, '2376');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451022', '451022-�ﶫ��', '4', null, null, '4', null, null, null, '2377');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451023', '451023-ƽ����', '4', null, null, '4', null, null, null, '2378');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451024', '451024-�±���', '4', null, null, '4', null, null, null, '2379');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451026', '451026-������', '4', null, null, '4', null, null, null, '2380');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451027', '451027-������', '4', null, null, '4', null, null, null, '2381');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451028', '451028-��ҵ��', '4', null, null, '4', null, null, null, '2382');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451029', '451029-������', '4', null, null, '4', null, null, null, '2383');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451030', '451030-������', '4', null, null, '4', null, null, null, '2384');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451031', '451031-¡�ָ���������', '4', null, null, '4', null, null, null, '2385');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451081', '451081-������', '4', null, null, '4', null, null, null, '2386');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451100', '451100-������', '4', null, null, '4', null, null, null, '2387');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451101', '451101-��Ͻ��', '4', null, null, '4', null, null, null, '2388');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451102', '451102-�˲���', '4', null, null, '4', null, null, null, '2389');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451103', '451103-ƽ����', '4', null, null, '4', null, null, null, '2390');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451121', '451121-��ƽ��', '4', null, null, '4', null, null, null, '2391');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451122', '451122-��ɽ��', '4', null, null, '4', null, null, null, '2392');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451123', '451123-��������������', '4', null, null, '4', null, null, null, '2393');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451200', '451200-�ӳ���', '4', null, null, '4', null, null, null, '2394');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451201', '451201-��Ͻ��', '4', null, null, '4', null, null, null, '2395');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451202', '451202-��ǽ���', '4', null, null, '4', null, null, null, '2396');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451221', '451221-�ϵ���', '4', null, null, '4', null, null, null, '2397');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451222', '451222-�����', '4', null, null, '4', null, null, null, '2398');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451223', '451223-��ɽ��', '4', null, null, '4', null, null, null, '2399');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451224', '451224-������', '4', null, null, '4', null, null, null, '2400');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451225', '451225-�޳�������������', '4', null, null, '4', null, null, null, '2401');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451226', '451226-����ë����������', '4', null, null, '4', null, null, null, '2402');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451227', '451227-��������������', '4', null, null, '4', null, null, null, '2403');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451228', '451228-��������������', '4', null, null, '4', null, null, null, '2404');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451229', '451229-������������', '4', null, null, '4', null, null, null, '2405');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451281', '451281-������', '4', null, null, '4', null, null, null, '2406');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451300', '451300-������', '4', null, null, '4', null, null, null, '2407');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451301', '451301-��Ͻ��', '4', null, null, '4', null, null, null, '2408');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451302', '451302-�˱���', '4', null, null, '4', null, null, null, '2409');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451321', '451321-�ó���', '4', null, null, '4', null, null, null, '2410');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451322', '451322-������', '4', null, null, '4', null, null, null, '2411');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451323', '451323-������', '4', null, null, '4', null, null, null, '2412');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451324', '451324-��������������', '4', null, null, '4', null, null, null, '2413');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451381', '451381-��ɽ��', '4', null, null, '4', null, null, null, '2414');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451400', '451400-������', '4', null, null, '4', null, null, null, '2415');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451401', '451401-��Ͻ��', '4', null, null, '4', null, null, null, '2416');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451402', '451402-������', '4', null, null, '4', null, null, null, '2417');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451421', '451421-������', '4', null, null, '4', null, null, null, '2418');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451422', '451422-������', '4', null, null, '4', null, null, null, '2419');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451423', '451423-������', '4', null, null, '4', null, null, null, '2420');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451424', '451424-������', '4', null, null, '4', null, null, null, '2421');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451425', '451425-�����', '4', null, null, '4', null, null, null, '2422');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('451481', '451481-ƾ����', '4', null, null, '4', null, null, null, '2423');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('460000', '460000-����ʡ', '4', null, null, '4', null, null, null, '2424');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('460100', '460100-������', '4', null, null, '4', null, null, null, '2425');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('460101', '460101-��Ͻ��', '4', null, null, '4', null, null, null, '2426');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('460105', '460105-��Ӣ��', '4', null, null, '4', null, null, null, '2427');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('460106', '460106-������', '4', null, null, '4', null, null, null, '2428');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('460107', '460107-��ɽ��', '4', null, null, '4', null, null, null, '2429');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('460108', '460108-������', '4', null, null, '4', null, null, null, '2430');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('460200', '460200-������', '4', null, null, '4', null, null, null, '2431');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('460201', '460201-��Ͻ��', '4', null, null, '4', null, null, null, '2432');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('460202', '460202-������', '4', null, null, '4', null, null, null, '2433');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('460203', '460203-������', '4', null, null, '4', null, null, null, '2434');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('460204', '460204-������', '4', null, null, '4', null, null, null, '2435');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('460205', '460205-������', '4', null, null, '4', null, null, null, '2436');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('460300', '460300-��ɳ��', '4', null, null, '4', null, null, null, '2437');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('460400', '460400-������', '4', null, null, '4', null, null, null, '2438');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('469000', '469000-ʡֱϽ�ؼ���������', '4', null, null, '4', null, null, null, '2439');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('469001', '469001-��ָɽ��', '4', null, null, '4', null, null, null, '2440');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('469002', '469002-������', '4', null, null, '4', null, null, null, '2441');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('469005', '469005-�Ĳ���', '4', null, null, '4', null, null, null, '2442');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('469006', '469006-������', '4', null, null, '4', null, null, null, '2443');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('469007', '469007-������', '4', null, null, '4', null, null, null, '2444');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('469021', '469021-������', '4', null, null, '4', null, null, null, '2445');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('469022', '469022-�Ͳ���', '4', null, null, '4', null, null, null, '2446');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('469023', '469023-������', '4', null, null, '4', null, null, null, '2447');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('469024', '469024-�ٸ���', '4', null, null, '4', null, null, null, '2448');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('469025', '469025-��ɳ����������', '4', null, null, '4', null, null, null, '2449');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('469026', '469026-��������������', '4', null, null, '4', null, null, null, '2450');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('469027', '469027-�ֶ�����������', '4', null, null, '4', null, null, null, '2451');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('469028', '469028-��ˮ����������', '4', null, null, '4', null, null, null, '2452');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('469029', '469029-��ͤ��������������', '4', null, null, '4', null, null, null, '2453');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('469030', '469030-������������������', '4', null, null, '4', null, null, null, '2454');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500000', '500000-������', '4', null, null, '4', null, null, null, '2455');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500100', '500100-��Ͻ��', '4', null, null, '4', null, null, null, '2456');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500101', '500101-������', '4', null, null, '4', null, null, null, '2457');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500102', '500102-������', '4', null, null, '4', null, null, null, '2458');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500103', '500103-������', '4', null, null, '4', null, null, null, '2459');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500104', '500104-��ɿ���', '4', null, null, '4', null, null, null, '2460');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500105', '500105-������', '4', null, null, '4', null, null, null, '2461');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500106', '500106-ɳƺ����', '4', null, null, '4', null, null, null, '2462');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500107', '500107-��������', '4', null, null, '4', null, null, null, '2463');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500108', '500108-�ϰ���', '4', null, null, '4', null, null, null, '2464');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500109', '500109-������', '4', null, null, '4', null, null, null, '2465');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500110', '500110-�뽭��', '4', null, null, '4', null, null, null, '2466');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500111', '500111-������', '4', null, null, '4', null, null, null, '2467');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500112', '500112-�山��', '4', null, null, '4', null, null, null, '2468');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500113', '500113-������', '4', null, null, '4', null, null, null, '2469');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500114', '500114-ǭ����', '4', null, null, '4', null, null, null, '2470');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500115', '500115-������', '4', null, null, '4', null, null, null, '2471');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500116', '500116-������', '4', null, null, '4', null, null, null, '2472');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500117', '500117-�ϴ���', '4', null, null, '4', null, null, null, '2473');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500118', '500118-������', '4', null, null, '4', null, null, null, '2474');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500119', '500119-�ϴ���', '4', null, null, '4', null, null, null, '2475');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500120', '500120-�ɽ��', '4', null, null, '4', null, null, null, '2476');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500151', '500151-ͭ����', '4', null, null, '4', null, null, null, '2477');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500152', '500152-������', '4', null, null, '4', null, null, null, '2478');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500153', '500153-�ٲ���', '4', null, null, '4', null, null, null, '2479');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500154', '500154-������', '4', null, null, '4', null, null, null, '2480');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500200', '500200-��', '4', null, null, '4', null, null, null, '2481');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500228', '500228-��ƽ��', '4', null, null, '4', null, null, null, '2482');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500229', '500229-�ǿ���', '4', null, null, '4', null, null, null, '2483');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500230', '500230-�ᶼ��', '4', null, null, '4', null, null, null, '2484');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500231', '500231-�潭��', '4', null, null, '4', null, null, null, '2485');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500232', '500232-��¡��', '4', null, null, '4', null, null, null, '2486');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500233', '500233-����', '4', null, null, '4', null, null, null, '2487');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500235', '500235-������', '4', null, null, '4', null, null, null, '2488');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500236', '500236-�����', '4', null, null, '4', null, null, null, '2489');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500237', '500237-��ɽ��', '4', null, null, '4', null, null, null, '2490');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500238', '500238-��Ϫ��', '4', null, null, '4', null, null, null, '2491');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500240', '500240-ʯ��������������', '4', null, null, '4', null, null, null, '2492');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500241', '500241-��ɽ����������������', '4', null, null, '4', null, null, null, '2493');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500242', '500242-��������������������', '4', null, null, '4', null, null, null, '2494');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('500243', '500243-��ˮ����������������', '4', null, null, '4', null, null, null, '2495');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510000', '510000-�Ĵ�ʡ', '4', null, null, '4', null, null, null, '2496');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510100', '510100-�ɶ���', '4', null, null, '4', null, null, null, '2497');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510101', '510101-��Ͻ��', '4', null, null, '4', null, null, null, '2498');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510104', '510104-������', '4', null, null, '4', null, null, null, '2499');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510105', '510105-������', '4', null, null, '4', null, null, null, '2500');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510106', '510106-��ţ��', '4', null, null, '4', null, null, null, '2501');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510107', '510107-�����', '4', null, null, '4', null, null, null, '2502');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510108', '510108-�ɻ���', '4', null, null, '4', null, null, null, '2503');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510112', '510112-��Ȫ����', '4', null, null, '4', null, null, null, '2504');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510113', '510113-��׽���', '4', null, null, '4', null, null, null, '2505');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510114', '510114-�¶���', '4', null, null, '4', null, null, null, '2506');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510115', '510115-�½���', '4', null, null, '4', null, null, null, '2507');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510116', '510116-˫����', '4', null, null, '4', null, null, null, '2508');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510121', '510121-������', '4', null, null, '4', null, null, null, '2509');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510124', '510124-ۯ��', '4', null, null, '4', null, null, null, '2510');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510129', '510129-������', '4', null, null, '4', null, null, null, '2511');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510131', '510131-�ѽ���', '4', null, null, '4', null, null, null, '2512');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510132', '510132-�½���', '4', null, null, '4', null, null, null, '2513');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510181', '510181-��������', '4', null, null, '4', null, null, null, '2514');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510182', '510182-������', '4', null, null, '4', null, null, null, '2515');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510183', '510183-������', '4', null, null, '4', null, null, null, '2516');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510184', '510184-������', '4', null, null, '4', null, null, null, '2517');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510185', '510185-������', '4', null, null, '4', null, null, null, '2518');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510300', '510300-�Թ���', '4', null, null, '4', null, null, null, '2519');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510301', '510301-��Ͻ��', '4', null, null, '4', null, null, null, '2520');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510302', '510302-��������', '4', null, null, '4', null, null, null, '2521');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510303', '510303-������', '4', null, null, '4', null, null, null, '2522');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510304', '510304-����', '4', null, null, '4', null, null, null, '2523');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510311', '510311-��̲��', '4', null, null, '4', null, null, null, '2524');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510321', '510321-����', '4', null, null, '4', null, null, null, '2525');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510322', '510322-��˳��', '4', null, null, '4', null, null, null, '2526');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510400', '510400-��֦����', '4', null, null, '4', null, null, null, '2527');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510401', '510401-��Ͻ��', '4', null, null, '4', null, null, null, '2528');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510402', '510402-����', '4', null, null, '4', null, null, null, '2529');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510403', '510403-����', '4', null, null, '4', null, null, null, '2530');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510411', '510411-�ʺ���', '4', null, null, '4', null, null, null, '2531');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510421', '510421-������', '4', null, null, '4', null, null, null, '2532');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510422', '510422-�α���', '4', null, null, '4', null, null, null, '2533');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510500', '510500-������', '4', null, null, '4', null, null, null, '2534');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510501', '510501-��Ͻ��', '4', null, null, '4', null, null, null, '2535');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510502', '510502-������', '4', null, null, '4', null, null, null, '2536');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510503', '510503-��Ϫ��', '4', null, null, '4', null, null, null, '2537');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510504', '510504-����̶��', '4', null, null, '4', null, null, null, '2538');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510521', '510521-����', '4', null, null, '4', null, null, null, '2539');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510522', '510522-�Ͻ���', '4', null, null, '4', null, null, null, '2540');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510524', '510524-������', '4', null, null, '4', null, null, null, '2541');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510525', '510525-������', '4', null, null, '4', null, null, null, '2542');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510600', '510600-������', '4', null, null, '4', null, null, null, '2543');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510601', '510601-��Ͻ��', '4', null, null, '4', null, null, null, '2544');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510603', '510603-�����', '4', null, null, '4', null, null, null, '2545');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510623', '510623-�н���', '4', null, null, '4', null, null, null, '2546');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510626', '510626-�޽���', '4', null, null, '4', null, null, null, '2547');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510681', '510681-�㺺��', '4', null, null, '4', null, null, null, '2548');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510682', '510682-ʲ����', '4', null, null, '4', null, null, null, '2549');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510683', '510683-������', '4', null, null, '4', null, null, null, '2550');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510700', '510700-������', '4', null, null, '4', null, null, null, '2551');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510701', '510701-��Ͻ��', '4', null, null, '4', null, null, null, '2552');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510703', '510703-������', '4', null, null, '4', null, null, null, '2553');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510704', '510704-������', '4', null, null, '4', null, null, null, '2554');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510705', '510705-������', '4', null, null, '4', null, null, null, '2555');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510722', '510722-��̨��', '4', null, null, '4', null, null, null, '2556');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510723', '510723-��ͤ��', '4', null, null, '4', null, null, null, '2557');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510725', '510725-������', '4', null, null, '4', null, null, null, '2558');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510726', '510726-����Ǽ��������', '4', null, null, '4', null, null, null, '2559');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510727', '510727-ƽ����', '4', null, null, '4', null, null, null, '2560');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510781', '510781-������', '4', null, null, '4', null, null, null, '2561');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510800', '510800-��Ԫ��', '4', null, null, '4', null, null, null, '2562');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510801', '510801-��Ͻ��', '4', null, null, '4', null, null, null, '2563');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510802', '510802-������', '4', null, null, '4', null, null, null, '2564');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510811', '510811-�ѻ���', '4', null, null, '4', null, null, null, '2565');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510812', '510812-������', '4', null, null, '4', null, null, null, '2566');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510821', '510821-������', '4', null, null, '4', null, null, null, '2567');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510822', '510822-�ന��', '4', null, null, '4', null, null, null, '2568');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510823', '510823-������', '4', null, null, '4', null, null, null, '2569');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510824', '510824-��Ϫ��', '4', null, null, '4', null, null, null, '2570');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510900', '510900-������', '4', null, null, '4', null, null, null, '2571');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510901', '510901-��Ͻ��', '4', null, null, '4', null, null, null, '2572');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510903', '510903-��ɽ��', '4', null, null, '4', null, null, null, '2573');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510904', '510904-������', '4', null, null, '4', null, null, null, '2574');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510921', '510921-��Ϫ��', '4', null, null, '4', null, null, null, '2575');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510922', '510922-�����', '4', null, null, '4', null, null, null, '2576');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('510923', '510923-��Ӣ��', '4', null, null, '4', null, null, null, '2577');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511000', '511000-�ڽ���', '4', null, null, '4', null, null, null, '2578');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511001', '511001-��Ͻ��', '4', null, null, '4', null, null, null, '2579');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511002', '511002-������', '4', null, null, '4', null, null, null, '2580');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511011', '511011-������', '4', null, null, '4', null, null, null, '2581');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511024', '511024-��Զ��', '4', null, null, '4', null, null, null, '2582');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511025', '511025-������', '4', null, null, '4', null, null, null, '2583');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511028', '511028-¡����', '4', null, null, '4', null, null, null, '2584');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511100', '511100-��ɽ��', '4', null, null, '4', null, null, null, '2585');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511101', '511101-��Ͻ��', '4', null, null, '4', null, null, null, '2586');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511102', '511102-������', '4', null, null, '4', null, null, null, '2587');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511111', '511111-ɳ����', '4', null, null, '4', null, null, null, '2588');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511112', '511112-��ͨ����', '4', null, null, '4', null, null, null, '2589');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511113', '511113-��ں���', '4', null, null, '4', null, null, null, '2590');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511123', '511123-��Ϊ��', '4', null, null, '4', null, null, null, '2591');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511124', '511124-������', '4', null, null, '4', null, null, null, '2592');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511126', '511126-�н���', '4', null, null, '4', null, null, null, '2593');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511129', '511129-�崨��', '4', null, null, '4', null, null, null, '2594');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511132', '511132-�������������', '4', null, null, '4', null, null, null, '2595');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511133', '511133-��������������', '4', null, null, '4', null, null, null, '2596');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511181', '511181-��üɽ��', '4', null, null, '4', null, null, null, '2597');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511300', '511300-�ϳ���', '4', null, null, '4', null, null, null, '2598');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511301', '511301-��Ͻ��', '4', null, null, '4', null, null, null, '2599');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511302', '511302-˳����', '4', null, null, '4', null, null, null, '2600');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511303', '511303-��ƺ��', '4', null, null, '4', null, null, null, '2601');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511304', '511304-������', '4', null, null, '4', null, null, null, '2602');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511321', '511321-�ϲ���', '4', null, null, '4', null, null, null, '2603');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511322', '511322-Ӫɽ��', '4', null, null, '4', null, null, null, '2604');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511323', '511323-���', '4', null, null, '4', null, null, null, '2605');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511324', '511324-��¤��', '4', null, null, '4', null, null, null, '2606');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511325', '511325-������', '4', null, null, '4', null, null, null, '2607');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511381', '511381-������', '4', null, null, '4', null, null, null, '2608');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511400', '511400-üɽ��', '4', null, null, '4', null, null, null, '2609');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511401', '511401-��Ͻ��', '4', null, null, '4', null, null, null, '2610');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511402', '511402-������', '4', null, null, '4', null, null, null, '2611');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511403', '511403-��ɽ��', '4', null, null, '4', null, null, null, '2612');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511421', '511421-������', '4', null, null, '4', null, null, null, '2613');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511423', '511423-������', '4', null, null, '4', null, null, null, '2614');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511424', '511424-������', '4', null, null, '4', null, null, null, '2615');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511425', '511425-������', '4', null, null, '4', null, null, null, '2616');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511500', '511500-�˱���', '4', null, null, '4', null, null, null, '2617');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511501', '511501-��Ͻ��', '4', null, null, '4', null, null, null, '2618');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511502', '511502-������', '4', null, null, '4', null, null, null, '2619');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511503', '511503-��Ϫ��', '4', null, null, '4', null, null, null, '2620');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511521', '511521-�˱���', '4', null, null, '4', null, null, null, '2621');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511523', '511523-������', '4', null, null, '4', null, null, null, '2622');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511524', '511524-������', '4', null, null, '4', null, null, null, '2623');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511525', '511525-����', '4', null, null, '4', null, null, null, '2624');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511526', '511526-����', '4', null, null, '4', null, null, null, '2625');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511527', '511527-������', '4', null, null, '4', null, null, null, '2626');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511528', '511528-������', '4', null, null, '4', null, null, null, '2627');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511529', '511529-��ɽ��', '4', null, null, '4', null, null, null, '2628');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511600', '511600-�㰲��', '4', null, null, '4', null, null, null, '2629');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511601', '511601-��Ͻ��', '4', null, null, '4', null, null, null, '2630');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511602', '511602-�㰲��', '4', null, null, '4', null, null, null, '2631');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511603', '511603-ǰ����', '4', null, null, '4', null, null, null, '2632');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511621', '511621-������', '4', null, null, '4', null, null, null, '2633');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511622', '511622-��ʤ��', '4', null, null, '4', null, null, null, '2634');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511623', '511623-��ˮ��', '4', null, null, '4', null, null, null, '2635');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511681', '511681-������', '4', null, null, '4', null, null, null, '2636');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511700', '511700-������', '4', null, null, '4', null, null, null, '2637');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511701', '511701-��Ͻ��', '4', null, null, '4', null, null, null, '2638');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511702', '511702-ͨ����', '4', null, null, '4', null, null, null, '2639');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511703', '511703-�ﴨ��', '4', null, null, '4', null, null, null, '2640');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511722', '511722-������', '4', null, null, '4', null, null, null, '2641');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511723', '511723-������', '4', null, null, '4', null, null, null, '2642');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511724', '511724-������', '4', null, null, '4', null, null, null, '2643');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511725', '511725-����', '4', null, null, '4', null, null, null, '2644');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511781', '511781-��Դ��', '4', null, null, '4', null, null, null, '2645');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511800', '511800-�Ű���', '4', null, null, '4', null, null, null, '2646');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511801', '511801-��Ͻ��', '4', null, null, '4', null, null, null, '2647');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511802', '511802-�����', '4', null, null, '4', null, null, null, '2648');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511803', '511803-��ɽ��', '4', null, null, '4', null, null, null, '2649');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511822', '511822-������', '4', null, null, '4', null, null, null, '2650');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511823', '511823-��Դ��', '4', null, null, '4', null, null, null, '2651');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511824', '511824-ʯ����', '4', null, null, '4', null, null, null, '2652');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511825', '511825-��ȫ��', '4', null, null, '4', null, null, null, '2653');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511826', '511826-«ɽ��', '4', null, null, '4', null, null, null, '2654');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511827', '511827-������', '4', null, null, '4', null, null, null, '2655');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511900', '511900-������', '4', null, null, '4', null, null, null, '2656');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511901', '511901-��Ͻ��', '4', null, null, '4', null, null, null, '2657');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511902', '511902-������', '4', null, null, '4', null, null, null, '2658');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511903', '511903-������', '4', null, null, '4', null, null, null, '2659');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511921', '511921-ͨ����', '4', null, null, '4', null, null, null, '2660');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511922', '511922-�Ͻ���', '4', null, null, '4', null, null, null, '2661');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('511923', '511923-ƽ����', '4', null, null, '4', null, null, null, '2662');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('512000', '512000-������', '4', null, null, '4', null, null, null, '2663');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('512001', '512001-��Ͻ��', '4', null, null, '4', null, null, null, '2664');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('512002', '512002-�㽭��', '4', null, null, '4', null, null, null, '2665');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('512021', '512021-������', '4', null, null, '4', null, null, null, '2666');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('512022', '512022-������', '4', null, null, '4', null, null, null, '2667');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513200', '513200-���Ӳ���Ǽ��������', '4', null, null, '4', null, null, null, '2668');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513201', '513201-��������', '4', null, null, '4', null, null, null, '2669');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513221', '513221-�봨��', '4', null, null, '4', null, null, null, '2670');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513222', '513222-����', '4', null, null, '4', null, null, null, '2671');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513223', '513223-ï��', '4', null, null, '4', null, null, null, '2672');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513224', '513224-������', '4', null, null, '4', null, null, null, '2673');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513225', '513225-��կ����', '4', null, null, '4', null, null, null, '2674');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513226', '513226-����', '4', null, null, '4', null, null, null, '2675');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513227', '513227-С����', '4', null, null, '4', null, null, null, '2676');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513228', '513228-��ˮ��', '4', null, null, '4', null, null, null, '2677');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513230', '513230-������', '4', null, null, '4', null, null, null, '2678');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513231', '513231-������', '4', null, null, '4', null, null, null, '2679');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513232', '513232-��������', '4', null, null, '4', null, null, null, '2680');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513233', '513233-��ԭ��', '4', null, null, '4', null, null, null, '2681');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513300', '513300-���β���������', '4', null, null, '4', null, null, null, '2682');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513301', '513301-������', '4', null, null, '4', null, null, null, '2683');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513322', '513322-����', '4', null, null, '4', null, null, null, '2684');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513323', '513323-������', '4', null, null, '4', null, null, null, '2685');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513324', '513324-������', '4', null, null, '4', null, null, null, '2686');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513325', '513325-�Ž���', '4', null, null, '4', null, null, null, '2687');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513326', '513326-������', '4', null, null, '4', null, null, null, '2688');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513327', '513327-¯����', '4', null, null, '4', null, null, null, '2689');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513328', '513328-������', '4', null, null, '4', null, null, null, '2690');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513329', '513329-������', '4', null, null, '4', null, null, null, '2691');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513330', '513330-�¸���', '4', null, null, '4', null, null, null, '2692');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513331', '513331-������', '4', null, null, '4', null, null, null, '2693');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513332', '513332-ʯ����', '4', null, null, '4', null, null, null, '2694');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513333', '513333-ɫ����', '4', null, null, '4', null, null, null, '2695');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513334', '513334-������', '4', null, null, '4', null, null, null, '2696');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513335', '513335-������', '4', null, null, '4', null, null, null, '2697');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513336', '513336-�����', '4', null, null, '4', null, null, null, '2698');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513337', '513337-������', '4', null, null, '4', null, null, null, '2699');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513338', '513338-������', '4', null, null, '4', null, null, null, '2700');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513400', '513400-��ɽ����������', '4', null, null, '4', null, null, null, '2701');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513401', '513401-������', '4', null, null, '4', null, null, null, '2702');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513422', '513422-ľ�����������', '4', null, null, '4', null, null, null, '2703');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513423', '513423-��Դ��', '4', null, null, '4', null, null, null, '2704');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513424', '513424-�²���', '4', null, null, '4', null, null, null, '2705');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513425', '513425-������', '4', null, null, '4', null, null, null, '2706');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513426', '513426-�ᶫ��', '4', null, null, '4', null, null, null, '2707');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513427', '513427-������', '4', null, null, '4', null, null, null, '2708');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513428', '513428-�ո���', '4', null, null, '4', null, null, null, '2709');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513429', '513429-������', '4', null, null, '4', null, null, null, '2710');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513430', '513430-������', '4', null, null, '4', null, null, null, '2711');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513431', '513431-�Ѿ���', '4', null, null, '4', null, null, null, '2712');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513432', '513432-ϲ����', '4', null, null, '4', null, null, null, '2713');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513433', '513433-������', '4', null, null, '4', null, null, null, '2714');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513434', '513434-Խ����', '4', null, null, '4', null, null, null, '2715');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513435', '513435-������', '4', null, null, '4', null, null, null, '2716');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513436', '513436-������', '4', null, null, '4', null, null, null, '2717');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('513437', '513437-�ײ���', '4', null, null, '4', null, null, null, '2718');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520000', '520000-����ʡ', '4', null, null, '4', null, null, null, '2719');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520100', '520100-������', '4', null, null, '4', null, null, null, '2720');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520101', '520101-��Ͻ��', '4', null, null, '4', null, null, null, '2721');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520102', '520102-������', '4', null, null, '4', null, null, null, '2722');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520103', '520103-������', '4', null, null, '4', null, null, null, '2723');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520111', '520111-��Ϫ��', '4', null, null, '4', null, null, null, '2724');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520112', '520112-�ڵ���', '4', null, null, '4', null, null, null, '2725');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520113', '520113-������', '4', null, null, '4', null, null, null, '2726');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520115', '520115-��ɽ����', '4', null, null, '4', null, null, null, '2727');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520121', '520121-������', '4', null, null, '4', null, null, null, '2728');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520122', '520122-Ϣ����', '4', null, null, '4', null, null, null, '2729');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520123', '520123-������', '4', null, null, '4', null, null, null, '2730');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520181', '520181-������', '4', null, null, '4', null, null, null, '2731');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520200', '520200-����ˮ��', '4', null, null, '4', null, null, null, '2732');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520201', '520201-��ɽ��', '4', null, null, '4', null, null, null, '2733');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520203', '520203-��֦����', '4', null, null, '4', null, null, null, '2734');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520221', '520221-ˮ����', '4', null, null, '4', null, null, null, '2735');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520222', '520222-����', '4', null, null, '4', null, null, null, '2736');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520300', '520300-������', '4', null, null, '4', null, null, null, '2737');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520301', '520301-��Ͻ��', '4', null, null, '4', null, null, null, '2738');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520302', '520302-�컨����', '4', null, null, '4', null, null, null, '2739');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520303', '520303-�㴨��', '4', null, null, '4', null, null, null, '2740');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520304', '520304-������', '4', null, null, '4', null, null, null, '2741');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520322', '520322-ͩ����', '4', null, null, '4', null, null, null, '2742');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520323', '520323-������', '4', null, null, '4', null, null, null, '2743');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520324', '520324-������', '4', null, null, '4', null, null, null, '2744');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520325', '520325-��������������������', '4', null, null, '4', null, null, null, '2745');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520326', '520326-������������������', '4', null, null, '4', null, null, null, '2746');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520327', '520327-�����', '4', null, null, '4', null, null, null, '2747');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520328', '520328-��̶��', '4', null, null, '4', null, null, null, '2748');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520329', '520329-������', '4', null, null, '4', null, null, null, '2749');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520330', '520330-ϰˮ��', '4', null, null, '4', null, null, null, '2750');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520381', '520381-��ˮ��', '4', null, null, '4', null, null, null, '2751');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520382', '520382-�ʻ���', '4', null, null, '4', null, null, null, '2752');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520400', '520400-��˳��', '4', null, null, '4', null, null, null, '2753');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520401', '520401-��Ͻ��', '4', null, null, '4', null, null, null, '2754');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520402', '520402-������', '4', null, null, '4', null, null, null, '2755');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520403', '520403-ƽ����', '4', null, null, '4', null, null, null, '2756');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520422', '520422-�ն���', '4', null, null, '4', null, null, null, '2757');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520423', '520423-��������������������', '4', null, null, '4', null, null, null, '2758');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520424', '520424-���벼��������������', '4', null, null, '4', null, null, null, '2759');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520425', '520425-�������岼����������', '4', null, null, '4', null, null, null, '2760');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520500', '520500-�Ͻ���', '4', null, null, '4', null, null, null, '2761');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520501', '520501-��Ͻ��', '4', null, null, '4', null, null, null, '2762');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520502', '520502-���ǹ���', '4', null, null, '4', null, null, null, '2763');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520521', '520521-����', '4', null, null, '4', null, null, null, '2764');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520522', '520522-ǭ����', '4', null, null, '4', null, null, null, '2765');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520523', '520523-��ɳ��', '4', null, null, '4', null, null, null, '2766');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520524', '520524-֯����', '4', null, null, '4', null, null, null, '2767');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520525', '520525-��Ӻ��', '4', null, null, '4', null, null, null, '2768');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520526', '520526-���������������������', '4', null, null, '4', null, null, null, '2769');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520527', '520527-������', '4', null, null, '4', null, null, null, '2770');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520600', '520600-ͭ����', '4', null, null, '4', null, null, null, '2771');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520601', '520601-��Ͻ��', '4', null, null, '4', null, null, null, '2772');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520602', '520602-�̽���', '4', null, null, '4', null, null, null, '2773');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520603', '520603-��ɽ��', '4', null, null, '4', null, null, null, '2774');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520621', '520621-������', '4', null, null, '4', null, null, null, '2775');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520622', '520622-��������������', '4', null, null, '4', null, null, null, '2776');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520623', '520623-ʯ����', '4', null, null, '4', null, null, null, '2777');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520624', '520624-˼����', '4', null, null, '4', null, null, null, '2778');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520625', '520625-ӡ������������������', '4', null, null, '4', null, null, null, '2779');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520626', '520626-�½���', '4', null, null, '4', null, null, null, '2780');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520627', '520627-�غ�������������', '4', null, null, '4', null, null, null, '2781');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('520628', '520628-��������������', '4', null, null, '4', null, null, null, '2782');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522300', '522300-ǭ���ϲ���������������', '4', null, null, '4', null, null, null, '2783');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522301', '522301-������', '4', null, null, '4', null, null, null, '2784');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522322', '522322-������', '4', null, null, '4', null, null, null, '2785');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522323', '522323-�հ���', '4', null, null, '4', null, null, null, '2786');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522324', '522324-��¡��', '4', null, null, '4', null, null, null, '2787');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522325', '522325-�����', '4', null, null, '4', null, null, null, '2788');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522326', '522326-������', '4', null, null, '4', null, null, null, '2789');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522327', '522327-�����', '4', null, null, '4', null, null, null, '2790');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522328', '522328-������', '4', null, null, '4', null, null, null, '2791');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522600', '522600-ǭ�������嶱��������', '4', null, null, '4', null, null, null, '2792');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522601', '522601-������', '4', null, null, '4', null, null, null, '2793');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522622', '522622-��ƽ��', '4', null, null, '4', null, null, null, '2794');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522623', '522623-ʩ����', '4', null, null, '4', null, null, null, '2795');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522624', '522624-������', '4', null, null, '4', null, null, null, '2796');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522625', '522625-��Զ��', '4', null, null, '4', null, null, null, '2797');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522626', '522626-᯹���', '4', null, null, '4', null, null, null, '2798');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522627', '522627-������', '4', null, null, '4', null, null, null, '2799');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522628', '522628-������', '4', null, null, '4', null, null, null, '2800');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522629', '522629-������', '4', null, null, '4', null, null, null, '2801');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522630', '522630-̨����', '4', null, null, '4', null, null, null, '2802');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522631', '522631-��ƽ��', '4', null, null, '4', null, null, null, '2803');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522632', '522632-�Ž���', '4', null, null, '4', null, null, null, '2804');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522633', '522633-�ӽ���', '4', null, null, '4', null, null, null, '2805');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522634', '522634-��ɽ��', '4', null, null, '4', null, null, null, '2806');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522635', '522635-�齭��', '4', null, null, '4', null, null, null, '2807');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522636', '522636-��կ��', '4', null, null, '4', null, null, null, '2808');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522700', '522700-ǭ�ϲ���������������', '4', null, null, '4', null, null, null, '2809');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522701', '522701-������', '4', null, null, '4', null, null, null, '2810');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522702', '522702-��Ȫ��', '4', null, null, '4', null, null, null, '2811');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522722', '522722-����', '4', null, null, '4', null, null, null, '2812');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522723', '522723-����', '4', null, null, '4', null, null, null, '2813');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522725', '522725-�Ͱ���', '4', null, null, '4', null, null, null, '2814');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522726', '522726-��ɽ��', '4', null, null, '4', null, null, null, '2815');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522727', '522727-ƽ����', '4', null, null, '4', null, null, null, '2816');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522728', '522728-�޵���', '4', null, null, '4', null, null, null, '2817');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522729', '522729-��˳��', '4', null, null, '4', null, null, null, '2818');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522730', '522730-������', '4', null, null, '4', null, null, null, '2819');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522731', '522731-��ˮ��', '4', null, null, '4', null, null, null, '2820');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('522732', '522732-����ˮ��������', '4', null, null, '4', null, null, null, '2821');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530000', '530000-����ʡ', '4', null, null, '4', null, null, null, '2822');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530100', '530100-������', '4', null, null, '4', null, null, null, '2823');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530101', '530101-��Ͻ��', '4', null, null, '4', null, null, null, '2824');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530102', '530102-�廪��', '4', null, null, '4', null, null, null, '2825');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530103', '530103-������', '4', null, null, '4', null, null, null, '2826');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530111', '530111-�ٶ���', '4', null, null, '4', null, null, null, '2827');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530112', '530112-��ɽ��', '4', null, null, '4', null, null, null, '2828');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530113', '530113-������', '4', null, null, '4', null, null, null, '2829');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530114', '530114-�ʹ���', '4', null, null, '4', null, null, null, '2830');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530122', '530122-������', '4', null, null, '4', null, null, null, '2831');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530124', '530124-������', '4', null, null, '4', null, null, null, '2832');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530125', '530125-������', '4', null, null, '4', null, null, null, '2833');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530126', '530126-ʯ������������', '4', null, null, '4', null, null, null, '2834');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530127', '530127-������', '4', null, null, '4', null, null, null, '2835');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530128', '530128-»Ȱ��������������', '4', null, null, '4', null, null, null, '2836');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530129', '530129-Ѱ���������������', '4', null, null, '4', null, null, null, '2837');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530181', '530181-������', '4', null, null, '4', null, null, null, '2838');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530300', '530300-������', '4', null, null, '4', null, null, null, '2839');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530301', '530301-��Ͻ��', '4', null, null, '4', null, null, null, '2840');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530302', '530302-������', '4', null, null, '4', null, null, null, '2841');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530303', '530303-մ����', '4', null, null, '4', null, null, null, '2842');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530321', '530321-������', '4', null, null, '4', null, null, null, '2843');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530322', '530322-½����', '4', null, null, '4', null, null, null, '2844');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530323', '530323-ʦ����', '4', null, null, '4', null, null, null, '2845');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530324', '530324-��ƽ��', '4', null, null, '4', null, null, null, '2846');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530325', '530325-��Դ��', '4', null, null, '4', null, null, null, '2847');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530326', '530326-������', '4', null, null, '4', null, null, null, '2848');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530381', '530381-������', '4', null, null, '4', null, null, null, '2849');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530400', '530400-��Ϫ��', '4', null, null, '4', null, null, null, '2850');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530401', '530401-��Ͻ��', '4', null, null, '4', null, null, null, '2851');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530402', '530402-������', '4', null, null, '4', null, null, null, '2852');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530403', '530403-������', '4', null, null, '4', null, null, null, '2853');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530422', '530422-�ν���', '4', null, null, '4', null, null, null, '2854');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530423', '530423-ͨ����', '4', null, null, '4', null, null, null, '2855');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530424', '530424-������', '4', null, null, '4', null, null, null, '2856');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530425', '530425-������', '4', null, null, '4', null, null, null, '2857');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530426', '530426-��ɽ����������', '4', null, null, '4', null, null, null, '2858');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530427', '530427-��ƽ�������������', '4', null, null, '4', null, null, null, '2859');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530428', '530428-Ԫ���������������������', '4', null, null, '4', null, null, null, '2860');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530500', '530500-��ɽ��', '4', null, null, '4', null, null, null, '2861');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530501', '530501-��Ͻ��', '4', null, null, '4', null, null, null, '2862');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530502', '530502-¡����', '4', null, null, '4', null, null, null, '2863');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530521', '530521-ʩ����', '4', null, null, '4', null, null, null, '2864');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530523', '530523-������', '4', null, null, '4', null, null, null, '2865');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530524', '530524-������', '4', null, null, '4', null, null, null, '2866');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530581', '530581-�ڳ���', '4', null, null, '4', null, null, null, '2867');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530600', '530600-��ͨ��', '4', null, null, '4', null, null, null, '2868');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530601', '530601-��Ͻ��', '4', null, null, '4', null, null, null, '2869');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530602', '530602-������', '4', null, null, '4', null, null, null, '2870');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530621', '530621-³����', '4', null, null, '4', null, null, null, '2871');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530622', '530622-�ɼ���', '4', null, null, '4', null, null, null, '2872');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530623', '530623-�ν���', '4', null, null, '4', null, null, null, '2873');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530624', '530624-�����', '4', null, null, '4', null, null, null, '2874');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530625', '530625-������', '4', null, null, '4', null, null, null, '2875');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530626', '530626-�罭��', '4', null, null, '4', null, null, null, '2876');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530627', '530627-������', '4', null, null, '4', null, null, null, '2877');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530628', '530628-������', '4', null, null, '4', null, null, null, '2878');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530629', '530629-������', '4', null, null, '4', null, null, null, '2879');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530630', '530630-ˮ����', '4', null, null, '4', null, null, null, '2880');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530700', '530700-������', '4', null, null, '4', null, null, null, '2881');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530701', '530701-��Ͻ��', '4', null, null, '4', null, null, null, '2882');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530702', '530702-�ų���', '4', null, null, '4', null, null, null, '2883');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530721', '530721-����������������', '4', null, null, '4', null, null, null, '2884');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530722', '530722-��ʤ��', '4', null, null, '4', null, null, null, '2885');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530723', '530723-��ƺ��', '4', null, null, '4', null, null, null, '2886');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530724', '530724-��������������', '4', null, null, '4', null, null, null, '2887');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530800', '530800-�ն���', '4', null, null, '4', null, null, null, '2888');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530801', '530801-��Ͻ��', '4', null, null, '4', null, null, null, '2889');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530802', '530802-˼é��', '4', null, null, '4', null, null, null, '2890');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530821', '530821-��������������������', '4', null, null, '4', null, null, null, '2891');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530822', '530822-ī��������������', '4', null, null, '4', null, null, null, '2892');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530823', '530823-��������������', '4', null, null, '4', null, null, null, '2893');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530824', '530824-���ȴ�������������', '4', null, null, '4', null, null, null, '2894');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530825', '530825-�������������������������', '4', null, null, '4', null, null, null, '2895');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530826', '530826-���ǹ���������������', '4', null, null, '4', null, null, null, '2896');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530827', '530827-������������������������', '4', null, null, '4', null, null, null, '2897');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530828', '530828-����������������', '4', null, null, '4', null, null, null, '2898');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530829', '530829-��������������', '4', null, null, '4', null, null, null, '2899');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530900', '530900-�ٲ���', '4', null, null, '4', null, null, null, '2900');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530901', '530901-��Ͻ��', '4', null, null, '4', null, null, null, '2901');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530902', '530902-������', '4', null, null, '4', null, null, null, '2902');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530921', '530921-������', '4', null, null, '4', null, null, null, '2903');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530922', '530922-����', '4', null, null, '4', null, null, null, '2904');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530923', '530923-������', '4', null, null, '4', null, null, null, '2905');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530924', '530924-����', '4', null, null, '4', null, null, null, '2906');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530925', '530925-˫�����������岼�������������', '4', null, null, '4', null, null, null, '2907');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530926', '530926-������������������', '4', null, null, '4', null, null, null, '2908');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('530927', '530927-��Դ����������', '4', null, null, '4', null, null, null, '2909');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532300', '532300-��������������', '4', null, null, '4', null, null, null, '2910');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532301', '532301-������', '4', null, null, '4', null, null, null, '2911');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532322', '532322-˫����', '4', null, null, '4', null, null, null, '2912');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532323', '532323-Ĳ����', '4', null, null, '4', null, null, null, '2913');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532324', '532324-�ϻ���', '4', null, null, '4', null, null, null, '2914');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532325', '532325-Ҧ����', '4', null, null, '4', null, null, null, '2915');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532326', '532326-��Ҧ��', '4', null, null, '4', null, null, null, '2916');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532327', '532327-������', '4', null, null, '4', null, null, null, '2917');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532328', '532328-Ԫı��', '4', null, null, '4', null, null, null, '2918');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532329', '532329-�䶨��', '4', null, null, '4', null, null, null, '2919');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532331', '532331-»����', '4', null, null, '4', null, null, null, '2920');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532500', '532500-��ӹ���������������', '4', null, null, '4', null, null, null, '2921');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532501', '532501-������', '4', null, null, '4', null, null, null, '2922');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532502', '532502-��Զ��', '4', null, null, '4', null, null, null, '2923');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532503', '532503-������', '4', null, null, '4', null, null, null, '2924');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532504', '532504-������', '4', null, null, '4', null, null, null, '2925');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532523', '532523-��������������', '4', null, null, '4', null, null, null, '2926');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532524', '532524-��ˮ��', '4', null, null, '4', null, null, null, '2927');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532525', '532525-ʯ����', '4', null, null, '4', null, null, null, '2928');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532527', '532527-������', '4', null, null, '4', null, null, null, '2929');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532528', '532528-Ԫ����', '4', null, null, '4', null, null, null, '2930');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532529', '532529-�����', '4', null, null, '4', null, null, null, '2931');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532530', '532530-��ƽ�����������������', '4', null, null, '4', null, null, null, '2932');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532531', '532531-�̴���', '4', null, null, '4', null, null, null, '2933');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532532', '532532-�ӿ�����������', '4', null, null, '4', null, null, null, '2934');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532600', '532600-��ɽ׳������������', '4', null, null, '4', null, null, null, '2935');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532601', '532601-��ɽ��', '4', null, null, '4', null, null, null, '2936');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532622', '532622-��ɽ��', '4', null, null, '4', null, null, null, '2937');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532623', '532623-������', '4', null, null, '4', null, null, null, '2938');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532624', '532624-��������', '4', null, null, '4', null, null, null, '2939');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532625', '532625-������', '4', null, null, '4', null, null, null, '2940');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532626', '532626-����', '4', null, null, '4', null, null, null, '2941');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532627', '532627-������', '4', null, null, '4', null, null, null, '2942');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532628', '532628-������', '4', null, null, '4', null, null, null, '2943');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532800', '532800-��˫���ɴ���������', '4', null, null, '4', null, null, null, '2944');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532801', '532801-������', '4', null, null, '4', null, null, null, '2945');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532822', '532822-�º���', '4', null, null, '4', null, null, null, '2946');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532823', '532823-������', '4', null, null, '4', null, null, null, '2947');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532900', '532900-��������������', '4', null, null, '4', null, null, null, '2948');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532901', '532901-������', '4', null, null, '4', null, null, null, '2949');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532922', '532922-�������������', '4', null, null, '4', null, null, null, '2950');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532923', '532923-������', '4', null, null, '4', null, null, null, '2951');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532924', '532924-������', '4', null, null, '4', null, null, null, '2952');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532925', '532925-�ֶ���', '4', null, null, '4', null, null, null, '2953');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532926', '532926-�Ͻ�����������', '4', null, null, '4', null, null, null, '2954');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532927', '532927-Ρɽ�������������', '4', null, null, '4', null, null, null, '2955');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532928', '532928-��ƽ��', '4', null, null, '4', null, null, null, '2956');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532929', '532929-������', '4', null, null, '4', null, null, null, '2957');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532930', '532930-��Դ��', '4', null, null, '4', null, null, null, '2958');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532931', '532931-������', '4', null, null, '4', null, null, null, '2959');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('532932', '532932-������', '4', null, null, '4', null, null, null, '2960');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('533100', '533100-�º���徰����������', '4', null, null, '4', null, null, null, '2961');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('533102', '533102-������', '4', null, null, '4', null, null, null, '2962');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('533103', '533103-â��', '4', null, null, '4', null, null, null, '2963');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('533122', '533122-������', '4', null, null, '4', null, null, null, '2964');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('533123', '533123-ӯ����', '4', null, null, '4', null, null, null, '2965');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('533124', '533124-¤����', '4', null, null, '4', null, null, null, '2966');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('533300', '533300-ŭ��������������', '4', null, null, '4', null, null, null, '2967');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('533301', '533301-��ˮ��', '4', null, null, '4', null, null, null, '2968');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('533323', '533323-������', '4', null, null, '4', null, null, null, '2969');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('533324', '533324-��ɽ������ŭ��������', '4', null, null, '4', null, null, null, '2970');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('533325', '533325-��ƺ����������������', '4', null, null, '4', null, null, null, '2971');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('533400', '533400-�������������', '4', null, null, '4', null, null, null, '2972');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('533401', '533401-���������', '4', null, null, '4', null, null, null, '2973');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('533422', '533422-������', '4', null, null, '4', null, null, null, '2974');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('533423', '533423-ά��������������', '4', null, null, '4', null, null, null, '2975');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540000', '540000-����������', '4', null, null, '4', null, null, null, '2976');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540100', '540100-������', '4', null, null, '4', null, null, null, '2977');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540101', '540101-��Ͻ��', '4', null, null, '4', null, null, null, '2978');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540102', '540102-�ǹ���', '4', null, null, '4', null, null, null, '2979');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540103', '540103-����������', '4', null, null, '4', null, null, null, '2980');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540121', '540121-������', '4', null, null, '4', null, null, null, '2981');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540122', '540122-������', '4', null, null, '4', null, null, null, '2982');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540123', '540123-��ľ��', '4', null, null, '4', null, null, null, '2983');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540124', '540124-��ˮ��', '4', null, null, '4', null, null, null, '2984');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540126', '540126-������', '4', null, null, '4', null, null, null, '2985');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540127', '540127-ī�񹤿���', '4', null, null, '4', null, null, null, '2986');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540200', '540200-�տ�����', '4', null, null, '4', null, null, null, '2987');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540202', '540202-ɣ������', '4', null, null, '4', null, null, null, '2988');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540221', '540221-��ľ����', '4', null, null, '4', null, null, null, '2989');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540222', '540222-������', '4', null, null, '4', null, null, null, '2990');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540223', '540223-������', '4', null, null, '4', null, null, null, '2991');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540224', '540224-������', '4', null, null, '4', null, null, null, '2992');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540225', '540225-������', '4', null, null, '4', null, null, null, '2993');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540226', '540226-������', '4', null, null, '4', null, null, null, '2994');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540227', '540227-лͨ����', '4', null, null, '4', null, null, null, '2995');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540228', '540228-������', '4', null, null, '4', null, null, null, '2996');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540229', '540229-�ʲ���', '4', null, null, '4', null, null, null, '2997');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540230', '540230-������', '4', null, null, '4', null, null, null, '2998');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540231', '540231-������', '4', null, null, '4', null, null, null, '2999');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540232', '540232-�ٰ���', '4', null, null, '4', null, null, null, '3000');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540233', '540233-�Ƕ���', '4', null, null, '4', null, null, null, '3001');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540234', '540234-��¡��', '4', null, null, '4', null, null, null, '3002');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540235', '540235-����ľ��', '4', null, null, '4', null, null, null, '3003');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540236', '540236-������', '4', null, null, '4', null, null, null, '3004');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540237', '540237-�ڰ���', '4', null, null, '4', null, null, null, '3005');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540300', '540300-������', '4', null, null, '4', null, null, null, '3006');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540302', '540302-������', '4', null, null, '4', null, null, null, '3007');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540321', '540321-������', '4', null, null, '4', null, null, null, '3008');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540322', '540322-������', '4', null, null, '4', null, null, null, '3009');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540323', '540323-��������', '4', null, null, '4', null, null, null, '3010');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540324', '540324-������', '4', null, null, '4', null, null, null, '3011');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540325', '540325-������', '4', null, null, '4', null, null, null, '3012');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540326', '540326-������', '4', null, null, '4', null, null, null, '3013');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540327', '540327-����', '4', null, null, '4', null, null, null, '3014');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540328', '540328-â����', '4', null, null, '4', null, null, null, '3015');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540329', '540329-��¡��', '4', null, null, '4', null, null, null, '3016');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540330', '540330-�߰���', '4', null, null, '4', null, null, null, '3017');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540400', '540400-��֥��', '4', null, null, '4', null, null, null, '3018');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540402', '540402-������', '4', null, null, '4', null, null, null, '3019');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540421', '540421-����������', '4', null, null, '4', null, null, null, '3020');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540422', '540422-������', '4', null, null, '4', null, null, null, '3021');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540423', '540423-ī����', '4', null, null, '4', null, null, null, '3022');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540424', '540424-������', '4', null, null, '4', null, null, null, '3023');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540425', '540425-������', '4', null, null, '4', null, null, null, '3024');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540426', '540426-����', '4', null, null, '4', null, null, null, '3025');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540500', '540500-ɽ����', '4', null, null, '4', null, null, null, '3026');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540501', '540501-��Ͻ��', '4', null, null, '4', null, null, null, '3027');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540502', '540502-�˶���', '4', null, null, '4', null, null, null, '3028');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540521', '540521-������', '4', null, null, '4', null, null, null, '3029');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540522', '540522-������', '4', null, null, '4', null, null, null, '3030');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540523', '540523-ɣ����', '4', null, null, '4', null, null, null, '3031');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540524', '540524-������', '4', null, null, '4', null, null, null, '3032');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540525', '540525-������', '4', null, null, '4', null, null, null, '3033');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540526', '540526-������', '4', null, null, '4', null, null, null, '3034');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540527', '540527-������', '4', null, null, '4', null, null, null, '3035');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540528', '540528-�Ӳ���', '4', null, null, '4', null, null, null, '3036');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540529', '540529-¡����', '4', null, null, '4', null, null, null, '3037');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540530', '540530-������', '4', null, null, '4', null, null, null, '3038');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('540531', '540531-�˿�����', '4', null, null, '4', null, null, null, '3039');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('542400', '542400-��������', '4', null, null, '4', null, null, null, '3040');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('542421', '542421-������', '4', null, null, '4', null, null, null, '3041');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('542422', '542422-������', '4', null, null, '4', null, null, null, '3042');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('542423', '542423-������', '4', null, null, '4', null, null, null, '3043');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('542424', '542424-������', '4', null, null, '4', null, null, null, '3044');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('542425', '542425-������', '4', null, null, '4', null, null, null, '3045');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('542426', '542426-������', '4', null, null, '4', null, null, null, '3046');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('542427', '542427-����', '4', null, null, '4', null, null, null, '3047');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('542428', '542428-�����', '4', null, null, '4', null, null, null, '3048');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('542429', '542429-������', '4', null, null, '4', null, null, null, '3049');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('542430', '542430-������', '4', null, null, '4', null, null, null, '3050');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('542431', '542431-˫����', '4', null, null, '4', null, null, null, '3051');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('542500', '542500-�������', '4', null, null, '4', null, null, null, '3052');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('542521', '542521-������', '4', null, null, '4', null, null, null, '3053');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('542522', '542522-������', '4', null, null, '4', null, null, null, '3054');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('542523', '542523-������', '4', null, null, '4', null, null, null, '3055');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('542524', '542524-������', '4', null, null, '4', null, null, null, '3056');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('542525', '542525-�Ｊ��', '4', null, null, '4', null, null, null, '3057');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('542526', '542526-������', '4', null, null, '4', null, null, null, '3058');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('542527', '542527-������', '4', null, null, '4', null, null, null, '3059');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610000', '610000-����ʡ', '4', null, null, '4', null, null, null, '3060');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610100', '610100-������', '4', null, null, '4', null, null, null, '3061');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610101', '610101-��Ͻ��', '4', null, null, '4', null, null, null, '3062');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610102', '610102-�³���', '4', null, null, '4', null, null, null, '3063');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610103', '610103-������', '4', null, null, '4', null, null, null, '3064');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610104', '610104-������', '4', null, null, '4', null, null, null, '3065');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610111', '610111-�����', '4', null, null, '4', null, null, null, '3066');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610112', '610112-δ����', '4', null, null, '4', null, null, null, '3067');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610113', '610113-������', '4', null, null, '4', null, null, null, '3068');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610114', '610114-������', '4', null, null, '4', null, null, null, '3069');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610115', '610115-������', '4', null, null, '4', null, null, null, '3070');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610116', '610116-������', '4', null, null, '4', null, null, null, '3071');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610117', '610117-������', '4', null, null, '4', null, null, null, '3072');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610122', '610122-������', '4', null, null, '4', null, null, null, '3073');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610124', '610124-������', '4', null, null, '4', null, null, null, '3074');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610125', '610125-����', '4', null, null, '4', null, null, null, '3075');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610200', '610200-ͭ����', '4', null, null, '4', null, null, null, '3076');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610201', '610201-��Ͻ��', '4', null, null, '4', null, null, null, '3077');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610202', '610202-������', '4', null, null, '4', null, null, null, '3078');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610203', '610203-ӡ̨��', '4', null, null, '4', null, null, null, '3079');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610204', '610204-ҫ����', '4', null, null, '4', null, null, null, '3080');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610222', '610222-�˾���', '4', null, null, '4', null, null, null, '3081');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610300', '610300-������', '4', null, null, '4', null, null, null, '3082');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610301', '610301-��Ͻ��', '4', null, null, '4', null, null, null, '3083');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610302', '610302-μ����', '4', null, null, '4', null, null, null, '3084');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610303', '610303-��̨��', '4', null, null, '4', null, null, null, '3085');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610304', '610304-�²���', '4', null, null, '4', null, null, null, '3086');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610322', '610322-������', '4', null, null, '4', null, null, null, '3087');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610323', '610323-�ɽ��', '4', null, null, '4', null, null, null, '3088');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610324', '610324-������', '4', null, null, '4', null, null, null, '3089');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610326', '610326-ü��', '4', null, null, '4', null, null, null, '3090');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610327', '610327-¤��', '4', null, null, '4', null, null, null, '3091');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610328', '610328-ǧ����', '4', null, null, '4', null, null, null, '3092');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610329', '610329-������', '4', null, null, '4', null, null, null, '3093');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610330', '610330-����', '4', null, null, '4', null, null, null, '3094');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610331', '610331-̫����', '4', null, null, '4', null, null, null, '3095');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610400', '610400-������', '4', null, null, '4', null, null, null, '3096');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610401', '610401-��Ͻ��', '4', null, null, '4', null, null, null, '3097');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610402', '610402-�ض���', '4', null, null, '4', null, null, null, '3098');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610403', '610403-������', '4', null, null, '4', null, null, null, '3099');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610404', '610404-μ����', '4', null, null, '4', null, null, null, '3100');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610422', '610422-��ԭ��', '4', null, null, '4', null, null, null, '3101');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610423', '610423-������', '4', null, null, '4', null, null, null, '3102');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610424', '610424-Ǭ��', '4', null, null, '4', null, null, null, '3103');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610425', '610425-��Ȫ��', '4', null, null, '4', null, null, null, '3104');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610426', '610426-������', '4', null, null, '4', null, null, null, '3105');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610427', '610427-����', '4', null, null, '4', null, null, null, '3106');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610428', '610428-������', '4', null, null, '4', null, null, null, '3107');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610429', '610429-Ѯ����', '4', null, null, '4', null, null, null, '3108');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610430', '610430-������', '4', null, null, '4', null, null, null, '3109');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610431', '610431-�书��', '4', null, null, '4', null, null, null, '3110');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610481', '610481-��ƽ��', '4', null, null, '4', null, null, null, '3111');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610500', '610500-μ����', '4', null, null, '4', null, null, null, '3112');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610501', '610501-��Ͻ��', '4', null, null, '4', null, null, null, '3113');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610502', '610502-��μ��', '4', null, null, '4', null, null, null, '3114');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610503', '610503-������', '4', null, null, '4', null, null, null, '3115');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610522', '610522-������', '4', null, null, '4', null, null, null, '3116');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610523', '610523-������', '4', null, null, '4', null, null, null, '3117');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610524', '610524-������', '4', null, null, '4', null, null, null, '3118');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610525', '610525-�γ���', '4', null, null, '4', null, null, null, '3119');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610526', '610526-�ѳ���', '4', null, null, '4', null, null, null, '3120');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610527', '610527-��ˮ��', '4', null, null, '4', null, null, null, '3121');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610528', '610528-��ƽ��', '4', null, null, '4', null, null, null, '3122');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610581', '610581-������', '4', null, null, '4', null, null, null, '3123');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610582', '610582-������', '4', null, null, '4', null, null, null, '3124');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610600', '610600-�Ӱ���', '4', null, null, '4', null, null, null, '3125');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610601', '610601-��Ͻ��', '4', null, null, '4', null, null, null, '3126');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610602', '610602-������', '4', null, null, '4', null, null, null, '3127');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610603', '610603-������', '4', null, null, '4', null, null, null, '3128');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610621', '610621-�ӳ���', '4', null, null, '4', null, null, null, '3129');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610622', '610622-�Ӵ���', '4', null, null, '4', null, null, null, '3130');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610623', '610623-�ӳ���', '4', null, null, '4', null, null, null, '3131');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610625', '610625-־����', '4', null, null, '4', null, null, null, '3132');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610626', '610626-������', '4', null, null, '4', null, null, null, '3133');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610627', '610627-��Ȫ��', '4', null, null, '4', null, null, null, '3134');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610628', '610628-����', '4', null, null, '4', null, null, null, '3135');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610629', '610629-�崨��', '4', null, null, '4', null, null, null, '3136');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610630', '610630-�˴���', '4', null, null, '4', null, null, null, '3137');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610631', '610631-������', '4', null, null, '4', null, null, null, '3138');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610632', '610632-������', '4', null, null, '4', null, null, null, '3139');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610700', '610700-������', '4', null, null, '4', null, null, null, '3140');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610701', '610701-��Ͻ��', '4', null, null, '4', null, null, null, '3141');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610702', '610702-��̨��', '4', null, null, '4', null, null, null, '3142');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610721', '610721-��֣��', '4', null, null, '4', null, null, null, '3143');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610722', '610722-�ǹ���', '4', null, null, '4', null, null, null, '3144');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610723', '610723-����', '4', null, null, '4', null, null, null, '3145');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610724', '610724-������', '4', null, null, '4', null, null, null, '3146');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610725', '610725-����', '4', null, null, '4', null, null, null, '3147');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610726', '610726-��ǿ��', '4', null, null, '4', null, null, null, '3148');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610727', '610727-������', '4', null, null, '4', null, null, null, '3149');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610728', '610728-�����', '4', null, null, '4', null, null, null, '3150');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610729', '610729-������', '4', null, null, '4', null, null, null, '3151');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610730', '610730-��ƺ��', '4', null, null, '4', null, null, null, '3152');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610800', '610800-������', '4', null, null, '4', null, null, null, '3153');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610801', '610801-��Ͻ��', '4', null, null, '4', null, null, null, '3154');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610802', '610802-������', '4', null, null, '4', null, null, null, '3155');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610803', '610803-��ɽ��', '4', null, null, '4', null, null, null, '3156');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610821', '610821-��ľ��', '4', null, null, '4', null, null, null, '3157');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610822', '610822-������', '4', null, null, '4', null, null, null, '3158');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610824', '610824-������', '4', null, null, '4', null, null, null, '3159');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610825', '610825-������', '4', null, null, '4', null, null, null, '3160');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610826', '610826-�����', '4', null, null, '4', null, null, null, '3161');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610827', '610827-��֬��', '4', null, null, '4', null, null, null, '3162');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610828', '610828-����', '4', null, null, '4', null, null, null, '3163');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610829', '610829-�Ɽ��', '4', null, null, '4', null, null, null, '3164');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610830', '610830-�彧��', '4', null, null, '4', null, null, null, '3165');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610831', '610831-������', '4', null, null, '4', null, null, null, '3166');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610900', '610900-������', '4', null, null, '4', null, null, null, '3167');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610901', '610901-��Ͻ��', '4', null, null, '4', null, null, null, '3168');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610902', '610902-������', '4', null, null, '4', null, null, null, '3169');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610921', '610921-������', '4', null, null, '4', null, null, null, '3170');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610922', '610922-ʯȪ��', '4', null, null, '4', null, null, null, '3171');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610923', '610923-������', '4', null, null, '4', null, null, null, '3172');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610924', '610924-������', '4', null, null, '4', null, null, null, '3173');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610925', '610925-᰸���', '4', null, null, '4', null, null, null, '3174');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610926', '610926-ƽ����', '4', null, null, '4', null, null, null, '3175');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610927', '610927-��ƺ��', '4', null, null, '4', null, null, null, '3176');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610928', '610928-Ѯ����', '4', null, null, '4', null, null, null, '3177');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('610929', '610929-�׺���', '4', null, null, '4', null, null, null, '3178');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('611000', '611000-������', '4', null, null, '4', null, null, null, '3179');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('611001', '611001-��Ͻ��', '4', null, null, '4', null, null, null, '3180');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('611002', '611002-������', '4', null, null, '4', null, null, null, '3181');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('611021', '611021-������', '4', null, null, '4', null, null, null, '3182');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('611022', '611022-������', '4', null, null, '4', null, null, null, '3183');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('611023', '611023-������', '4', null, null, '4', null, null, null, '3184');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('611024', '611024-ɽ����', '4', null, null, '4', null, null, null, '3185');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('611025', '611025-����', '4', null, null, '4', null, null, null, '3186');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('611026', '611026-��ˮ��', '4', null, null, '4', null, null, null, '3187');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620000', '620000-����ʡ', '4', null, null, '4', null, null, null, '3188');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620100', '620100-������', '4', null, null, '4', null, null, null, '3189');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620101', '620101-��Ͻ��', '4', null, null, '4', null, null, null, '3190');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620102', '620102-�ǹ���', '4', null, null, '4', null, null, null, '3191');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620103', '620103-�������', '4', null, null, '4', null, null, null, '3192');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620104', '620104-������', '4', null, null, '4', null, null, null, '3193');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620105', '620105-������', '4', null, null, '4', null, null, null, '3194');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620111', '620111-�����', '4', null, null, '4', null, null, null, '3195');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620121', '620121-������', '4', null, null, '4', null, null, null, '3196');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620122', '620122-������', '4', null, null, '4', null, null, null, '3197');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620123', '620123-������', '4', null, null, '4', null, null, null, '3198');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620200', '620200-��������', '4', null, null, '4', null, null, null, '3199');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620201', '620201-��Ͻ��', '4', null, null, '4', null, null, null, '3200');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620300', '620300-�����', '4', null, null, '4', null, null, null, '3201');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620301', '620301-��Ͻ��', '4', null, null, '4', null, null, null, '3202');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620302', '620302-����', '4', null, null, '4', null, null, null, '3203');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620321', '620321-������', '4', null, null, '4', null, null, null, '3204');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620400', '620400-������', '4', null, null, '4', null, null, null, '3205');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620401', '620401-��Ͻ��', '4', null, null, '4', null, null, null, '3206');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620402', '620402-������', '4', null, null, '4', null, null, null, '3207');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620403', '620403-ƽ����', '4', null, null, '4', null, null, null, '3208');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620421', '620421-��Զ��', '4', null, null, '4', null, null, null, '3209');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620422', '620422-������', '4', null, null, '4', null, null, null, '3210');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620423', '620423-��̩��', '4', null, null, '4', null, null, null, '3211');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620500', '620500-��ˮ��', '4', null, null, '4', null, null, null, '3212');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620501', '620501-��Ͻ��', '4', null, null, '4', null, null, null, '3213');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620502', '620502-������', '4', null, null, '4', null, null, null, '3214');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620503', '620503-�����', '4', null, null, '4', null, null, null, '3215');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620521', '620521-��ˮ��', '4', null, null, '4', null, null, null, '3216');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620522', '620522-�ذ���', '4', null, null, '4', null, null, null, '3217');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620523', '620523-�ʹ���', '4', null, null, '4', null, null, null, '3218');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620524', '620524-��ɽ��', '4', null, null, '4', null, null, null, '3219');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620525', '620525-�żҴ�����������', '4', null, null, '4', null, null, null, '3220');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620600', '620600-������', '4', null, null, '4', null, null, null, '3221');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620601', '620601-��Ͻ��', '4', null, null, '4', null, null, null, '3222');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620602', '620602-������', '4', null, null, '4', null, null, null, '3223');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620621', '620621-������', '4', null, null, '4', null, null, null, '3224');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620622', '620622-������', '4', null, null, '4', null, null, null, '3225');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620623', '620623-��ף����������', '4', null, null, '4', null, null, null, '3226');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620700', '620700-��Ҵ��', '4', null, null, '4', null, null, null, '3227');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620701', '620701-��Ͻ��', '4', null, null, '4', null, null, null, '3228');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620702', '620702-������', '4', null, null, '4', null, null, null, '3229');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620721', '620721-����ԣ����������', '4', null, null, '4', null, null, null, '3230');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620722', '620722-������', '4', null, null, '4', null, null, null, '3231');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620723', '620723-������', '4', null, null, '4', null, null, null, '3232');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620724', '620724-��̨��', '4', null, null, '4', null, null, null, '3233');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620725', '620725-ɽ����', '4', null, null, '4', null, null, null, '3234');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620800', '620800-ƽ����', '4', null, null, '4', null, null, null, '3235');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620801', '620801-��Ͻ��', '4', null, null, '4', null, null, null, '3236');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620802', '620802-�����', '4', null, null, '4', null, null, null, '3237');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620821', '620821-������', '4', null, null, '4', null, null, null, '3238');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620822', '620822-��̨��', '4', null, null, '4', null, null, null, '3239');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620823', '620823-������', '4', null, null, '4', null, null, null, '3240');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620824', '620824-��ͤ��', '4', null, null, '4', null, null, null, '3241');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620825', '620825-ׯ����', '4', null, null, '4', null, null, null, '3242');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620826', '620826-������', '4', null, null, '4', null, null, null, '3243');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620900', '620900-��Ȫ��', '4', null, null, '4', null, null, null, '3244');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620901', '620901-��Ͻ��', '4', null, null, '4', null, null, null, '3245');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620902', '620902-������', '4', null, null, '4', null, null, null, '3246');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620921', '620921-������', '4', null, null, '4', null, null, null, '3247');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620922', '620922-������', '4', null, null, '4', null, null, null, '3248');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620923', '620923-�౱�ɹ���������', '4', null, null, '4', null, null, null, '3249');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620924', '620924-��������������������', '4', null, null, '4', null, null, null, '3250');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620981', '620981-������', '4', null, null, '4', null, null, null, '3251');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('620982', '620982-�ػ���', '4', null, null, '4', null, null, null, '3252');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621000', '621000-������', '4', null, null, '4', null, null, null, '3253');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621001', '621001-��Ͻ��', '4', null, null, '4', null, null, null, '3254');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621002', '621002-������', '4', null, null, '4', null, null, null, '3255');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621021', '621021-�����', '4', null, null, '4', null, null, null, '3256');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621022', '621022-����', '4', null, null, '4', null, null, null, '3257');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621023', '621023-������', '4', null, null, '4', null, null, null, '3258');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621024', '621024-��ˮ��', '4', null, null, '4', null, null, null, '3259');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621025', '621025-������', '4', null, null, '4', null, null, null, '3260');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621026', '621026-����', '4', null, null, '4', null, null, null, '3261');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621027', '621027-��ԭ��', '4', null, null, '4', null, null, null, '3262');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621100', '621100-������', '4', null, null, '4', null, null, null, '3263');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621101', '621101-��Ͻ��', '4', null, null, '4', null, null, null, '3264');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621102', '621102-������', '4', null, null, '4', null, null, null, '3265');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621121', '621121-ͨμ��', '4', null, null, '4', null, null, null, '3266');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621122', '621122-¤����', '4', null, null, '4', null, null, null, '3267');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621123', '621123-μԴ��', '4', null, null, '4', null, null, null, '3268');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621124', '621124-�����', '4', null, null, '4', null, null, null, '3269');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621125', '621125-����', '4', null, null, '4', null, null, null, '3270');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621126', '621126-���', '4', null, null, '4', null, null, null, '3271');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621200', '621200-¤����', '4', null, null, '4', null, null, null, '3272');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621201', '621201-��Ͻ��', '4', null, null, '4', null, null, null, '3273');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621202', '621202-�䶼��', '4', null, null, '4', null, null, null, '3274');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621221', '621221-����', '4', null, null, '4', null, null, null, '3275');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621222', '621222-����', '4', null, null, '4', null, null, null, '3276');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621223', '621223-崲���', '4', null, null, '4', null, null, null, '3277');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621224', '621224-����', '4', null, null, '4', null, null, null, '3278');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621225', '621225-������', '4', null, null, '4', null, null, null, '3279');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621226', '621226-����', '4', null, null, '4', null, null, null, '3280');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621227', '621227-����', '4', null, null, '4', null, null, null, '3281');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('621228', '621228-������', '4', null, null, '4', null, null, null, '3282');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('622900', '622900-���Ļ���������', '4', null, null, '4', null, null, null, '3283');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('622901', '622901-������', '4', null, null, '4', null, null, null, '3284');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('622921', '622921-������', '4', null, null, '4', null, null, null, '3285');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('622922', '622922-������', '4', null, null, '4', null, null, null, '3286');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('622923', '622923-������', '4', null, null, '4', null, null, null, '3287');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('622924', '622924-�����', '4', null, null, '4', null, null, null, '3288');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('622925', '622925-������', '4', null, null, '4', null, null, null, '3289');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('622926', '622926-������������', '4', null, null, '4', null, null, null, '3290');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('622927', '622927-��ʯɽ�����嶫����������������', '4', null, null, '4', null, null, null, '3291');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('623000', '623000-���ϲ���������', '4', null, null, '4', null, null, null, '3292');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('623001', '623001-������', '4', null, null, '4', null, null, null, '3293');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('623021', '623021-��̶��', '4', null, null, '4', null, null, null, '3294');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('623022', '623022-׿����', '4', null, null, '4', null, null, null, '3295');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('623023', '623023-������', '4', null, null, '4', null, null, null, '3296');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('623024', '623024-������', '4', null, null, '4', null, null, null, '3297');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('623025', '623025-������', '4', null, null, '4', null, null, null, '3298');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('623026', '623026-µ����', '4', null, null, '4', null, null, null, '3299');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('623027', '623027-�ĺ���', '4', null, null, '4', null, null, null, '3300');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('630000', '630000-�ຣʡ', '4', null, null, '4', null, null, null, '3301');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('630100', '630100-������', '4', null, null, '4', null, null, null, '3302');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('630101', '630101-��Ͻ��', '4', null, null, '4', null, null, null, '3303');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('630102', '630102-�Ƕ���', '4', null, null, '4', null, null, null, '3304');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('630103', '630103-������', '4', null, null, '4', null, null, null, '3305');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('630104', '630104-������', '4', null, null, '4', null, null, null, '3306');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('630105', '630105-�Ǳ���', '4', null, null, '4', null, null, null, '3307');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('630121', '630121-��ͨ��������������', '4', null, null, '4', null, null, null, '3308');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('630122', '630122-������', '4', null, null, '4', null, null, null, '3309');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('630123', '630123-��Դ��', '4', null, null, '4', null, null, null, '3310');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('630200', '630200-������', '4', null, null, '4', null, null, null, '3311');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('630202', '630202-�ֶ���', '4', null, null, '4', null, null, null, '3312');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('630203', '630203-ƽ����', '4', null, null, '4', null, null, null, '3313');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('630222', '630222-��ͻ�������������', '4', null, null, '4', null, null, null, '3314');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('630223', '630223-��������������', '4', null, null, '4', null, null, null, '3315');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('630224', '630224-��¡����������', '4', null, null, '4', null, null, null, '3316');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('630225', '630225-ѭ��������������', '4', null, null, '4', null, null, null, '3317');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632200', '632200-��������������', '4', null, null, '4', null, null, null, '3318');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632221', '632221-��Դ����������', '4', null, null, '4', null, null, null, '3319');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632222', '632222-������', '4', null, null, '4', null, null, null, '3320');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632223', '632223-������', '4', null, null, '4', null, null, null, '3321');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632224', '632224-�ղ���', '4', null, null, '4', null, null, null, '3322');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632300', '632300-���ϲ���������', '4', null, null, '4', null, null, null, '3323');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632321', '632321-ͬ����', '4', null, null, '4', null, null, null, '3324');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632322', '632322-������', '4', null, null, '4', null, null, null, '3325');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632323', '632323-�����', '4', null, null, '4', null, null, null, '3326');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632324', '632324-�����ɹ���������', '4', null, null, '4', null, null, null, '3327');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632500', '632500-���ϲ���������', '4', null, null, '4', null, null, null, '3328');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632521', '632521-������', '4', null, null, '4', null, null, null, '3329');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632522', '632522-ͬ����', '4', null, null, '4', null, null, null, '3330');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632523', '632523-�����', '4', null, null, '4', null, null, null, '3331');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632524', '632524-�˺���', '4', null, null, '4', null, null, null, '3332');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632525', '632525-������', '4', null, null, '4', null, null, null, '3333');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632600', '632600-�������������', '4', null, null, '4', null, null, null, '3334');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632621', '632621-������', '4', null, null, '4', null, null, null, '3335');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632622', '632622-������', '4', null, null, '4', null, null, null, '3336');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632623', '632623-�ʵ���', '4', null, null, '4', null, null, null, '3337');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632624', '632624-������', '4', null, null, '4', null, null, null, '3338');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632625', '632625-������', '4', null, null, '4', null, null, null, '3339');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632626', '632626-�����', '4', null, null, '4', null, null, null, '3340');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632700', '632700-��������������', '4', null, null, '4', null, null, null, '3341');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632701', '632701-������', '4', null, null, '4', null, null, null, '3342');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632722', '632722-�Ӷ���', '4', null, null, '4', null, null, null, '3343');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632723', '632723-�ƶ���', '4', null, null, '4', null, null, null, '3344');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632724', '632724-�ζ���', '4', null, null, '4', null, null, null, '3345');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632725', '632725-��ǫ��', '4', null, null, '4', null, null, null, '3346');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632726', '632726-��������', '4', null, null, '4', null, null, null, '3347');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632800', '632800-�����ɹ������������', '4', null, null, '4', null, null, null, '3348');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632801', '632801-���ľ��', '4', null, null, '4', null, null, null, '3349');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632802', '632802-�������', '4', null, null, '4', null, null, null, '3350');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632821', '632821-������', '4', null, null, '4', null, null, null, '3351');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632822', '632822-������', '4', null, null, '4', null, null, null, '3352');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('632823', '632823-�����', '4', null, null, '4', null, null, null, '3353');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640000', '640000-���Ļ���������', '4', null, null, '4', null, null, null, '3354');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640100', '640100-������', '4', null, null, '4', null, null, null, '3355');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640101', '640101-��Ͻ��', '4', null, null, '4', null, null, null, '3356');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640104', '640104-������', '4', null, null, '4', null, null, null, '3357');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640105', '640105-������', '4', null, null, '4', null, null, null, '3358');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640106', '640106-�����', '4', null, null, '4', null, null, null, '3359');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640121', '640121-������', '4', null, null, '4', null, null, null, '3360');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640122', '640122-������', '4', null, null, '4', null, null, null, '3361');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640181', '640181-������', '4', null, null, '4', null, null, null, '3362');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640200', '640200-ʯ��ɽ��', '4', null, null, '4', null, null, null, '3363');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640201', '640201-��Ͻ��', '4', null, null, '4', null, null, null, '3364');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640202', '640202-�������', '4', null, null, '4', null, null, null, '3365');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640205', '640205-��ũ��', '4', null, null, '4', null, null, null, '3366');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640221', '640221-ƽ����', '4', null, null, '4', null, null, null, '3367');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640300', '640300-������', '4', null, null, '4', null, null, null, '3368');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640301', '640301-��Ͻ��', '4', null, null, '4', null, null, null, '3369');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640302', '640302-��ͨ��', '4', null, null, '4', null, null, null, '3370');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640303', '640303-���±���', '4', null, null, '4', null, null, null, '3371');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640323', '640323-�γ���', '4', null, null, '4', null, null, null, '3372');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640324', '640324-ͬ����', '4', null, null, '4', null, null, null, '3373');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640381', '640381-��ͭϿ��', '4', null, null, '4', null, null, null, '3374');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640400', '640400-��ԭ��', '4', null, null, '4', null, null, null, '3375');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640401', '640401-��Ͻ��', '4', null, null, '4', null, null, null, '3376');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640402', '640402-ԭ����', '4', null, null, '4', null, null, null, '3377');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640422', '640422-������', '4', null, null, '4', null, null, null, '3378');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640423', '640423-¡����', '4', null, null, '4', null, null, null, '3379');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640424', '640424-��Դ��', '4', null, null, '4', null, null, null, '3380');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640425', '640425-������', '4', null, null, '4', null, null, null, '3381');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640500', '640500-������', '4', null, null, '4', null, null, null, '3382');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640501', '640501-��Ͻ��', '4', null, null, '4', null, null, null, '3383');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640502', '640502-ɳ��ͷ��', '4', null, null, '4', null, null, null, '3384');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640521', '640521-������', '4', null, null, '4', null, null, null, '3385');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('640522', '640522-��ԭ��', '4', null, null, '4', null, null, null, '3386');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650000', '650000-�½�ά���������', '4', null, null, '4', null, null, null, '3387');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650100', '650100-��³ľ����', '4', null, null, '4', null, null, null, '3388');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650101', '650101-��Ͻ��', '4', null, null, '4', null, null, null, '3389');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650102', '650102-��ɽ��', '4', null, null, '4', null, null, null, '3390');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650103', '650103-ɳ���Ϳ���', '4', null, null, '4', null, null, null, '3391');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650104', '650104-������', '4', null, null, '4', null, null, null, '3392');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650105', '650105-ˮĥ����', '4', null, null, '4', null, null, null, '3393');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650106', '650106-ͷ�ͺ���', '4', null, null, '4', null, null, null, '3394');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650107', '650107-�������', '4', null, null, '4', null, null, null, '3395');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650109', '650109-�׶���', '4', null, null, '4', null, null, null, '3396');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650121', '650121-��³ľ����', '4', null, null, '4', null, null, null, '3397');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650200', '650200-����������', '4', null, null, '4', null, null, null, '3398');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650201', '650201-��Ͻ��', '4', null, null, '4', null, null, null, '3399');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650202', '650202-��ɽ����', '4', null, null, '4', null, null, null, '3400');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650203', '650203-����������', '4', null, null, '4', null, null, null, '3401');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650204', '650204-�׼�̲��', '4', null, null, '4', null, null, null, '3402');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650205', '650205-�ڶ�����', '4', null, null, '4', null, null, null, '3403');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650400', '650400-��³����', '4', null, null, '4', null, null, null, '3404');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650402', '650402-�߲���', '4', null, null, '4', null, null, null, '3405');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650421', '650421-۷����', '4', null, null, '4', null, null, null, '3406');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650422', '650422-�п�ѷ��', '4', null, null, '4', null, null, null, '3407');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650500', '650500-������', '4', null, null, '4', null, null, null, '3408');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650502', '650502-������', '4', null, null, '4', null, null, null, '3409');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650521', '650521-������������������', '4', null, null, '4', null, null, null, '3410');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('650522', '650522-������', '4', null, null, '4', null, null, null, '3411');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652300', '652300-��������������', '4', null, null, '4', null, null, null, '3412');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652301', '652301-������', '4', null, null, '4', null, null, null, '3413');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652302', '652302-������', '4', null, null, '4', null, null, null, '3414');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652323', '652323-��ͼ����', '4', null, null, '4', null, null, null, '3415');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652324', '652324-����˹��', '4', null, null, '4', null, null, null, '3416');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652325', '652325-��̨��', '4', null, null, '4', null, null, null, '3417');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652327', '652327-��ľ������', '4', null, null, '4', null, null, null, '3418');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652328', '652328-ľ�ݹ�����������', '4', null, null, '4', null, null, null, '3419');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652700', '652700-���������ɹ�������', '4', null, null, '4', null, null, null, '3420');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652701', '652701-������', '4', null, null, '4', null, null, null, '3421');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652702', '652702-����ɽ����', '4', null, null, '4', null, null, null, '3422');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652722', '652722-������', '4', null, null, '4', null, null, null, '3423');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652723', '652723-��Ȫ��', '4', null, null, '4', null, null, null, '3424');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652800', '652800-���������ɹ�������', '4', null, null, '4', null, null, null, '3425');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652801', '652801-�������', '4', null, null, '4', null, null, null, '3426');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652822', '652822-��̨��', '4', null, null, '4', null, null, null, '3427');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652823', '652823-ξ����', '4', null, null, '4', null, null, null, '3428');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652824', '652824-��Ǽ��', '4', null, null, '4', null, null, null, '3429');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652825', '652825-��ĩ��', '4', null, null, '4', null, null, null, '3430');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652826', '652826-���Ȼ���������', '4', null, null, '4', null, null, null, '3431');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652827', '652827-�;���', '4', null, null, '4', null, null, null, '3432');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652828', '652828-��˶��', '4', null, null, '4', null, null, null, '3433');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652829', '652829-������', '4', null, null, '4', null, null, null, '3434');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652900', '652900-�����յ���', '4', null, null, '4', null, null, null, '3435');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652901', '652901-��������', '4', null, null, '4', null, null, null, '3436');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652922', '652922-������', '4', null, null, '4', null, null, null, '3437');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652923', '652923-�⳵��', '4', null, null, '4', null, null, null, '3438');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652924', '652924-ɳ����', '4', null, null, '4', null, null, null, '3439');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652925', '652925-�º���', '4', null, null, '4', null, null, null, '3440');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652926', '652926-�ݳ���', '4', null, null, '4', null, null, null, '3441');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652927', '652927-��ʲ��', '4', null, null, '4', null, null, null, '3442');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652928', '652928-��������', '4', null, null, '4', null, null, null, '3443');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('652929', '652929-��ƺ��', '4', null, null, '4', null, null, null, '3444');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653000', '653000-�������տ¶�����������', '4', null, null, '4', null, null, null, '3445');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653001', '653001-��ͼʲ��', '4', null, null, '4', null, null, null, '3446');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653022', '653022-��������', '4', null, null, '4', null, null, null, '3447');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653023', '653023-��������', '4', null, null, '4', null, null, null, '3448');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653024', '653024-��ǡ��', '4', null, null, '4', null, null, null, '3449');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653100', '653100-��ʲ����', '4', null, null, '4', null, null, null, '3450');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653101', '653101-��ʲ��', '4', null, null, '4', null, null, null, '3451');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653121', '653121-�踽��', '4', null, null, '4', null, null, null, '3452');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653122', '653122-������', '4', null, null, '4', null, null, null, '3453');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653123', '653123-Ӣ��ɳ��', '4', null, null, '4', null, null, null, '3454');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653124', '653124-������', '4', null, null, '4', null, null, null, '3455');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653125', '653125-ɯ����', '4', null, null, '4', null, null, null, '3456');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653126', '653126-Ҷ����', '4', null, null, '4', null, null, null, '3457');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653127', '653127-�������', '4', null, null, '4', null, null, null, '3458');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653128', '653128-���պ���', '4', null, null, '4', null, null, null, '3459');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653129', '653129-٤ʦ��', '4', null, null, '4', null, null, null, '3460');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653130', '653130-�ͳ���', '4', null, null, '4', null, null, null, '3461');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653131', '653131-��ʲ�����������������', '4', null, null, '4', null, null, null, '3462');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653200', '653200-�������', '4', null, null, '4', null, null, null, '3463');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653201', '653201-������', '4', null, null, '4', null, null, null, '3464');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653221', '653221-������', '4', null, null, '4', null, null, null, '3465');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653222', '653222-ī����', '4', null, null, '4', null, null, null, '3466');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653223', '653223-Ƥɽ��', '4', null, null, '4', null, null, null, '3467');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653224', '653224-������', '4', null, null, '4', null, null, null, '3468');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653225', '653225-������', '4', null, null, '4', null, null, null, '3469');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653226', '653226-������', '4', null, null, '4', null, null, null, '3470');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('653227', '653227-�����', '4', null, null, '4', null, null, null, '3471');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654000', '654000-���������������', '4', null, null, '4', null, null, null, '3472');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654002', '654002-������', '4', null, null, '4', null, null, null, '3473');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654003', '654003-������', '4', null, null, '4', null, null, null, '3474');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654004', '654004-������˹��', '4', null, null, '4', null, null, null, '3475');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654021', '654021-������', '4', null, null, '4', null, null, null, '3476');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654022', '654022-�첼�������������', '4', null, null, '4', null, null, null, '3477');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654023', '654023-������', '4', null, null, '4', null, null, null, '3478');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654024', '654024-������', '4', null, null, '4', null, null, null, '3479');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654025', '654025-��Դ��', '4', null, null, '4', null, null, null, '3480');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654026', '654026-������', '4', null, null, '4', null, null, null, '3481');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654027', '654027-�ؿ�˹��', '4', null, null, '4', null, null, null, '3482');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654028', '654028-���տ���', '4', null, null, '4', null, null, null, '3483');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654200', '654200-���ǵ���', '4', null, null, '4', null, null, null, '3484');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654201', '654201-������', '4', null, null, '4', null, null, null, '3485');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654202', '654202-������', '4', null, null, '4', null, null, null, '3486');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654221', '654221-������', '4', null, null, '4', null, null, null, '3487');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654223', '654223-ɳ����', '4', null, null, '4', null, null, null, '3488');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654224', '654224-������', '4', null, null, '4', null, null, null, '3489');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654225', '654225-ԣ����', '4', null, null, '4', null, null, null, '3490');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654226', '654226-�Ͳ��������ɹ�������', '4', null, null, '4', null, null, null, '3491');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654300', '654300-����̩����', '4', null, null, '4', null, null, null, '3492');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654301', '654301-����̩��', '4', null, null, '4', null, null, null, '3493');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654321', '654321-��������', '4', null, null, '4', null, null, null, '3494');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654322', '654322-������', '4', null, null, '4', null, null, null, '3495');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654323', '654323-������', '4', null, null, '4', null, null, null, '3496');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654324', '654324-���ͺ���', '4', null, null, '4', null, null, null, '3497');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654325', '654325-�����', '4', null, null, '4', null, null, null, '3498');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('654326', '654326-��ľ����', '4', null, null, '4', null, null, null, '3499');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('659000', '659000-������ֱϽ�ؼ���������', '4', null, null, '4', null, null, null, '3500');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('659001', '659001-ʯ������', '4', null, null, '4', null, null, null, '3501');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('659002', '659002-��������', '4', null, null, '4', null, null, null, '3502');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('659003', '659003-ͼľ�����', '4', null, null, '4', null, null, null, '3503');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('659004', '659004-�������', '4', null, null, '4', null, null, null, '3504');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('659006', '659006-���Ź���', '4', null, null, '4', null, null, null, '3505');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('710000', '710000-̨��ʡ', '4', null, null, '4', null, null, null, '3506');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('810000', '810000-����ر�������', '4', null, null, '4', null, null, null, '3507');

insert into BI_AREAOFCHINA (AREA_CODE, AREA_NAME, FILLER1, FILLER2, FILLER3, ST, CRT_DT, LAST_UPD_TMS, LAST_UPD_OPER, REC_ID)
values ('820000', '820000-�����ر�������', '4', null, null, '4', null, null, null, '3508');