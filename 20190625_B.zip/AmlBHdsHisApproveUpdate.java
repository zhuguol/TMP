package com.huateng.report.hf.aml.update;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.orm.hibernate3.SessionFactoryUtils;

import resource.bean.report.AmlBhbsDs;
import resource.bean.report.AmlBhbsDsBak;

import com.huateng.commquery.result.MultiUpdateResultBean;
import com.huateng.commquery.result.UpdateResultBean;
import com.huateng.commquery.result.UpdateReturnBean;
import com.huateng.ebank.business.common.GlobalInfo;
import com.huateng.ebank.business.common.ROOTDAO;
import com.huateng.ebank.business.common.ROOTDAOUtils;
import com.huateng.ebank.framework.exceptions.CommonException;
import com.huateng.ebank.framework.web.commQuery.BaseUpdate;
import com.huateng.exception.AppException;
import com.huateng.report.constants.AMLConstants;
import com.huateng.report.hf.aml.utils.HsbcAmlBizLogUtils;
import com.huateng.report.hf.aml.utils.HsbcAmlUtils;

public class AmlBHdsHisApproveUpdate extends BaseUpdate {
    private static final String DATASET_ID = "AmlBHdsHisApprove";
    final int THREAD_COUNT = 8;
    AtomicInteger next = new AtomicInteger(0);  
    private CountDownLatch threadCompletedCounter = new CountDownLatch(THREAD_COUNT);  
    
    @Override
    public UpdateReturnBean saveOrUpdate(MultiUpdateResultBean multiUpdateResultBean, HttpServletRequest request, HttpServletResponse respone) throws AppException {
        GlobalInfo gi = GlobalInfo.getCurrentInstance();
        UpdateResultBean updateResultBean = multiUpdateResultBean.getUpdateResultBeanByID(DATASET_ID);
        UpdateReturnBean updateReturnBean = new UpdateReturnBean();
        String approveStatusChoose = updateResultBean.getParameter("approveStatusChoose");
        String approveResultChoose = updateResultBean.getParameter("approveResultChoose");
        String specialType = updateResultBean.getParameter("specialType");
        
        List<AmlBhbsDsBak> datalist = new ArrayList<AmlBhbsDsBak>();  
        while (updateResultBean.hasNext()) {
            Map map = updateResultBean.next();
            String select = (String) map.get("select");
            if (select != null && "true".equals(select)) {
                AmlBhbsDsBak bean = new AmlBhbsDsBak();
                mapToObject(bean, map);
                datalist.add(bean);  
            }
        }
        
        AmlBHdsHisApproveUpdate upd = new AmlBHdsHisApproveUpdate();  
        upd.runInMultiThreads(datalist,gi,approveStatusChoose,approveResultChoose,specialType);  
        
        return updateReturnBean;
    }
    
    /** 
     * 多线程处理：更新table 
     */  
    private void runInMultiThreads(final List<AmlBhbsDsBak> datalist,final GlobalInfo gi,final String approveStatusChoose,final String approveResultChoose,final String specialType) {  
        ExecutorService executor = Executors.newFixedThreadPool(THREAD_COUNT);  
        for (int i = 0; i < THREAD_COUNT; i++) {  
            executor.submit(new Runnable() {  
                public void run() {  
                	AmlBhbsDsBak bean = getNext(datalist);  
                    while (null != bean) {  
                        try {
                        	approveZC(bean.getId(), approveStatusChoose, approveResultChoose, specialType, bean.getFiller2(), bean.getTicd(),gi);
                        } catch (Exception e) {  
                        	System.out.println("table str update error    "+ e);  
                        }
                        bean = getNext(datalist);  
                    }  
                    threadCompletedCounter.countDown();  
                }  
            });  
        }  
        closeThreadPool(executor);  
        Long end = new Date().getTime();
    }  
    
    /** 
     * 同步处理：获取需要更新的一条数据 
     */  
    private synchronized AmlBhbsDsBak getNext(List<AmlBhbsDsBak> datalist){  
        if(next.intValue()>=datalist.size()){
        	return null;  
        }else{
        	next.incrementAndGet();  
        }
        return datalist.get(next.intValue()-1);  
    }  
      
    /** 
     * 关闭线程池 
     */  
    private void closeThreadPool(final ExecutorService executor) {  
        try {  
            threadCompletedCounter.await();  
            executor.shutdown();  
        } catch (InterruptedException e) {  
            e.printStackTrace();  
        }  
    }
    
    //大额自查详细页面审核按钮 (和AMLVaildService文件中该方法一直)
	public static String approveZC(String id, String approveStatusChoose, String approveResultChoose, String specialType, String filler2, String ticd, GlobalInfo gi) 
			throws CommonException, SQLException {
		String result = "";
		ROOTDAO rootdao = ROOTDAOUtils.getROOTDAO();
		StringBuilder sql = new StringBuilder();
		Connection conn = null;
		java.sql.PreparedStatement statement = null;
		java.sql.PreparedStatement delStatement = null;
		try {
			conn = SessionFactoryUtils.getDataSource(ROOTDAOUtils.getROOTDAO().getSessionFactory()).getConnection();
	          SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
	          if ("01".equals(approveStatusChoose)) {// 审核通过
	          	sql.append(" update aml_bhbs_ds_bak set approve_upd_tm= sysdate,approve_upd_tlr='"+gi.getTlrno()+"' , ");
	              sql.append(" filler2='01' ,filler3='"+approveResultChoose+"' where rec_id='"+id+"'");
	          	if ("02".equals(filler2)) {// 已审核过 且 处于审核不通过状态 (删除上次审核不通过生成的特殊报文)
	          		 String delHql = "delete from aml_bhbs_ds  where ticd = '"+ticd+"' and rec_status<>'06'";
	                   delStatement  = conn.prepareStatement(delHql);
	                   int i = delStatement.executeUpdate();
	                   if(i==0){
	                  	 result="该业务标识号在当前补录表已经存在,且处于已打包状态，无法审核通过并删除！";
	                   }else{
	                  	 statement  = conn.prepareStatement(sql.toString());
	                       statement.executeUpdate();
	                   }
	          	}else{ // 未审核过直接更新
	          		statement  = conn.prepareStatement(sql.toString());
	                  statement.executeUpdate();
	              }
	              HsbcAmlBizLogUtils.setLogToBizLog(gi,"Updater.log",new String[] { gi.getTlrno(), gi.getBrno(),"大额交易入库审核-审核-通过，业务标识号【" + ticd + "】" }, "大额交易入库审核");
	          } else {// 审核不通过
	              AmlBhbsDsBak bean_false = rootdao.query(AmlBhbsDsBak.class, id);
	              bean_false.setApproveUpdTlr(gi.getTlrno());
	              bean_false.setApproveUpdTm(sdf.parse(sdf.format(new Date())));
	              bean_false.setFiller2(AMLConstants.REPORT_APPROVESTATUS_02);
	              bean_false.setFiller3(approveResultChoose);
	              if (specialType != null && !"".equals(specialType.trim())) {// 审核不通过生成特殊报文
	                  // 添加校验业务标识号是否重复
	                  String[] para = new String[1];
	                  para[0] = bean_false.getTicd();
	                  StringBuffer hql = new StringBuffer("from AmlBhbsDs s where 1=1 AND s.ticd = ?");
	                  List<AmlBhbsDs> listAmlBhbsDs = rootdao.queryByQL2List(hql.toString(), para);
	                  if (listAmlBhbsDs != null && listAmlBhbsDs.size() > 0) {
	                  	result="该业务标识号在当前补录表已经存在";
	                  } else {// 将bak表的数据插入到当前补录表
	                      AmlBhbsDs amlBhbsDs = HsbcAmlUtils.amlBHbakToBH(gi,specialType, bean_false);
	                      rootdao.save(amlBhbsDs);
	                      rootdao.update(bean_false);
	                  }
	              }else{//3号令上线后走这里
	            	  rootdao.update(bean_false); 
	              }
	              HsbcAmlBizLogUtils.setLogToBizLog(gi, "Updater.log",new String[] { gi.getTlrno(), gi.getBrno(),"大额交易入库审核-审核-不通过，业务标识号【" + ticd + "】" }, "大额交易入库审核");
	          }
		} catch (Exception e) {
			result = "操作失败!";
			e.printStackTrace();
		}finally {
			if (delStatement != null) {
				delStatement.close();
			}
			if (statement != null) {
				statement.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return result;
	}
}
