/AML/topreport/com/huateng/hsbc/creditcard/operation/ApproveOperation.java
/AML/topreport/com/huateng/hsbc/creditcard/report/GenerateReportService.java
/AML/topreport/com/huateng/hsbc/creditcard/bean/CaseManagementReport.java
/AML/topreport/com/huateng/hsbc/creditcard/utils/CreditCommUtils.java
/AML/topreport/com/huateng/hsbc/creditcard/getter/CaseManagementReportGetter.java
/AML/topreport/com/huateng/hsbc/creditcard/report/CreditCardAction.java
/AML/WebContent/fpages/creditcard/xml/CaseManagementReport.xml
/AML/WebContent/fpages/creditcard/ftl/CaseManagementReport.ftl

/AML/topreport/resources/creditcard/hbm/pub/CaseManagementReport.hbm.xml
/AML/topreport/com/huateng/hsbc/creditcard/utils/CreditConstant.java